var FanXing = {
    init: function () {
        var that = this;
        this.isFlap = false;

        var fake_root = getUI(this, "fake_root");
        TouchUtils.setOnclickListener(fake_root, function () {
            if(that.isFlap == false) return;
            that.removeFromParent(true);
        });

        return true;
    },
    setData:function(data){
        var that = this;

        this.data = data;
        var cardimg = "res/image/ui/card/dx" + (data.XingCard) + ".png";
        if(data.XingCard > 10)  cardimg = "res/image/ui/card/dd" + (data.XingCard - 10) + ".png";
        for(var i=1;i<=1;i++) {
            (function(i){
                var cardback = getUI(that, "cardback" + i);
                TouchUtils.setOnclickListener(cardback, function (node) {
                    if(that.isFlap == true) return;
                    if (cardback) {
                        cardback.setVisible(true);
                        var action = cc.sequence(
                            cc.scaleTo(0.5, -1, 1)
                            , cc.callFunc(function () {
                                cardback.setTexture(cardimg);
                                cardback.setFlippedX(true);
                            })
                            , cc.delayTime(0.5)
                            , cc.callFunc(function () {
                                that.isFlap = true;
                                network.wsData("Fanxing/0");
                            })
                        );
                        cardback.runAction(action);
                    }
                });
            })(i);
        }
    }
};
