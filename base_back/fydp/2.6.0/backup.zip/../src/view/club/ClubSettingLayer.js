/**
 * Created by hjx on 2018/2/8.
 */

(function () {
    var exports = this;

    var $ = null;

    var ClubSettingLayer = cc.Layer.extend({
        ctor: function (clubid) {
            this._super();

            var that = this;

            var scene = ccs.load(res.ClubSettingLayer_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            TouchUtils.setOnclickListener($('root'), function () {
                console.log("remove setting layer");
                that.removeFromParent();
            });
            TouchUtils.setOnclickListener($('btn_gonggao'), function () {
                that.addChild(new ClubNoticeLayer(getClubData(clubid)));
            });
            TouchUtils.setOnclickListener($('btn_member'), function () {
                that.addChild(new ClubMemberLayer(getClubData(clubid)));
            });
            TouchUtils.setOnclickListener($('btn_updateName'), function () {
                var data = getClubData(clubid);
                if(gameData.uid == data['owner_uid'] || (data['admins'] && data['admins'].indexOf(gameData.uid)>=0)){
                    that.addChild(new ClubInputLayer('changeName', data));
                }else{
                    alert1('只有群主与管理员才可以修改俱乐部名称');
                }
            });
            TouchUtils.setOnclickListener($('btn_yysj'), function () {
                var data = getClubData(clubid);
                if (gameData.uid == data['owner_uid']) {
                    that.addChild(new ClubShowTimeLayer(getClubData(clubid)));
                } else {
                    //alert1('只有群主才可以设置开放时间');
                    var ctlayer=that.getParent();
                    var yyopen=data['openingtime']||'closed';
                    var stime=data['start']||'0:0';
                    var etime=data['end']||'0:0';
                    var isopen=ctlayer.getIsOpenState(stime,etime);
                    if(yyopen=='open'&&!isopen){//打烊状态
                        that.addChild(new ClubDayangLayer(stime,etime,1));
                    }else{//开放状态
                        that.addChild(new ClubDayangLayer(stime,etime,2));
                    }
                }
            });
            TouchUtils.setOnclickListener($('btn_dataManager'), function () {
            });
            TouchUtils.setOnclickListener($('btn_jiesan'), function () {
                alert2('确定解散该俱乐部？', function(){
                    network.send(2103, {cmd:'deleteClub', club_id:clubid});
                    that.removeFromParent();
                });
            });
            TouchUtils.setOnclickListener($('word_tcjlb'), function () {
                alert2('确定退出该俱乐部？', function() {
                    network.send(2103, {cmd: 'leaveClub', club_id: clubid, uid: gameData.uid});
                    that.removeFromParent();
                });
            });
            var data = getClubData(clubid);
            $('word_tcjlb').setVisible(data['owner_uid'] != gameData.uid)
            $('btn_jiesan').setVisible(data['owner_uid'] == gameData.uid)

            return true;
        }
    });

    exports.ClubSettingLayer = ClubSettingLayer;
})(window);