var MaLayer_sc = cc.Layer.extend({

})