// ConfirmJiesan
var ConfirmJiesan = {
    init:function () {
        this.bt1 = getUI(this, "bt1");
        this.bt1.addTouchEventListener(this.onOk, this);
        this.bt2 = getUI(this, "bt2");
        this.bt2.addTouchEventListener(this.onClose, this);
        this.t0 = getUI(this, "t0");
        this.bg = getUI(this, "bg");
        return true;
    },
    setData:function(okFunc, content){
        this.okFunc = okFunc;
        if (content){
            this.t0.setString(content);
            if (content.length <= 10) this.t0.setPositionX(this.bg.getContentSize().width/2);
        }
    },

    onClose:function(sender, type) {
        var ok = touch_process(sender, type);
        if(ok) {
            this.hide(true);
        }
    },
    onOk: function (sender, type) {
        var ok = touch_process(sender, type);
        if(ok){
            this.hide(true);
            this.okFunc();
        }
    }
};