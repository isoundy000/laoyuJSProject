/**
 * Created by dabai on 2017/8/30.
 */
(function (exports) {
    var appId = null;
    exports.XianLiaoUtils = {
        //获取是否安装闲聊
        isXianLiaoAppInstalled: function () {
            if (!cc.sys.isNative)
                return false;
            return (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "isXianLiaoAppInstalled")
                : jsb.reflection.callStaticMethod(packageUri + "/utils/XianLiaoUtil", "isXLAppInstalled", "()I"));
        },
        //拉起闲聊登陆
        redirectToXianLiaoLogin: function () {
            if (cc.sys.os == cc.sys.OS_IOS)
                jsb.reflection.callStaticMethod("XianLiaoUtil", "login");
            else
                jsb.reflection.callStaticMethod(packageUri + "/utils/XianLiaoUtil", "redirectXianLiaoLogin", "()V");
        },
        //获取闲聊AppId
        getAppid: function () {
            if (appId)
                return appId;
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "getXianLiaoAppId")
                : jsb.reflection.callStaticMethod(packageUri + '/Global', "getXianliaoAppId", "()Ljava/lang/String;"));
        },

        //获取分享房间号
        getRoomId: function () {
            return (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "getXianLiaoRoomId")
                : jsb.reflection.callStaticMethod(packageUri + '/Global', "getXianLiaoRoomId", "()Ljava/lang/String;"));
        },


        clearRoomId :function () {
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod("XianLiaoUtil", "clearRoomId");
            } else if (cc.sys.os == cc.sys.OS_ANDROID) {
                jsb.reflection.callStaticMethod(packageUri + '/Global', "clearXianLiaoRoomId", "()V");
            }
        },

        //获取闲聊登陆返回Code
        getXianLiaoLoginCode: function () {
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "getXianLiaoLoginCode")
                : jsb.reflection.callStaticMethod(packageUri + "/Global", "getXianLiaoLoginCode", "()Ljava/lang/String;"));
        },
        //获取闲聊登陆状态
        getXianLiaoLoginState: function () {
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "getXianLiaoLoginState")
                : jsb.reflection.callStaticMethod(packageUri + "/Global", "getXianLiaoLoginState", "()Ljava/lang/String;"));
        },
        //设置闲聊登陆Code
        setXianLiaoLoginCode: function (code) {
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("XianLiaoUtil", "setXianLiaoLoginCode:", code)
                : jsb.reflection.callStaticMethod(packageUri + "/Global", "setXianLiaoLoginCode", "(Ljava/lang/String;)V", code));
        },

        //分享文本
        shareText: function (text) {
            if (!cc.sys.isNative) {
                return;
            }
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(
                    "XianLiaoUtil",
                    "shareText:",
                    text
                );
            }
            else {
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/XianLiaoUtil",
                    "shareText",
                    "(Ljava/lang/String;)V",
                    text
                );
            }
        },
        //分享Url
        shareUrlWithIcon: function (url) {
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(
                    "XianLiaoUtil",
                    "shareUrlWithIcon:",
                    url
                );
            }
            else {
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/XianLiaoUtil",
                    "shareUrlWithIcon",
                    "(Ljava/lang/String;)V",
                    url
                );
            }
        },

        //分享游戏截图
        captureAndShareToXianLiao: function (node, depthStencilFormat) {
            var winSize = cc.director.getWinSize();
            var texture = new cc.RenderTexture(winSize.width, winSize.height,null,depthStencilFormat);
            if (!texture)
                return;

            texture.retain();
            texture.setAnchorPoint(0, 0);
            texture.begin();
            node.visit();
            texture.end();

            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/XianLiaoUtil",
                        "sharePic",
                        "(Ljava/lang/String;)V",
                        nameJPG
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "XianLiaoUtil",
                        "sharePic:imageName:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG
                    );
                });
            }
        },



        captureAndShareToXianLiao2: function (texture) {
            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/XianLiaoUtil",
                        "sharePic",
                        "(Ljava/lang/String;)V",
                        nameJPG
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "XianLiaoUtil",
                        "sharePic:imageName:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG
                    );
                });
            }
        },

        //分享游戏
        shareGame: function (roomId,title,text) {
            roomId = roomId + "";
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(
                    "XianLiaoUtil",
                    "shareGame:title:text:",
                    roomId,
                    title,
                    text
                );
            }
            else {
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/XianLiaoUtil",
                    "shareGame",
                    "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
                    roomId,
                    title,
                    text
                );
            }
        }
    };

})(this);


