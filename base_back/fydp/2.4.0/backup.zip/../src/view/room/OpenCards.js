var OpenCards = {
    init: function () {
        this.removeAllChildren();
        return true;
    },

    setPos: function (pos) {
        this.pos = pos;
    },

    addCards: function (cards, typ, isOpen, isPeng) {
        var that = this;
        //cc.log("ruru--------addCards:"+cards+ "/" +typ+ "/" +isOpen + "/" +Chi);
        var comboList = mAction.combos[this.pos];
        var comboInfo = {};
        comboInfo.typ = typ;
        comboInfo.cards = cards;
        var colIndex = 0;

        //ti和pao的替换处理
        if (isOpen == true) {
            var card = comboInfo.cards[0];
            for (var i = 0; i < comboList.length; i++) {
                var comb = comboList[i];
                var cardInCombo = comb.cards[0];
                if (card == cardInCombo) {
                    if (comb.typ == mCard.comboTypes.peng ||
                        comb.typ == mCard.comboTypes.wei ||
                        comb.typ == mCard.comboTypes.chouwei) {
                        comb.cards = cards;
                        comb.typ = typ;
                        colIndex = i + 1;
                        break;
                    }
                }
            }
            var children = this.getChildren();
            for (var i = children.length-1; i >=0; i--) {
                var child = children[i];
                if (child && child.getTag() == colIndex) {
                    child.removeFromParent();
                }
            }

            var children = this.getChildren();
            for(var i = 0; i < children.length; i++) {
                //移动之前的位置 如果跑的是之前的牌,移动到最后面的位置,之前的往前移动
                var child = children[i];
                if (child.getTag() > colIndex) {
                    var tag = child.getTag();
                    tag = tag - 1;
                    if(mRoom.getPlayerNum() == 3){
                        if(this.pos == 1){
                            child.setPositionX(270 - (tag - 1) * 45);
                        }else{
                            child.setPositionX((tag - 1) * 45 + 24)
                        }
                    }else{
                        if(mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.HENGDONG || mRoom.wanfatype == mRoom.MAOHUZI) {
                            if (this.pos == 1 || this.pos == 2) {
                                child.setPositionX(150 - (tag - 1) * 45);
                            } else {
                                child.setPositionX((tag - 1) * 45 + 24)
                            }
                        }else {
                            if (this.pos == 1) {
                                child.setPositionX(150 - (tag - 1) * 45);
                            } else {
                                child.setPositionX((tag - 1) * 45 + 24)
                            }
                        }
                    }
                    child.setTag(tag);
                }
            }
            //交换数据
            var tmp = null;
            if(colIndex >= 1){
                tmp = comboList[colIndex-1];
            }else{
                tmp = comboList[0];
            }
            for(var i=0;i<comboList.length-1;i++){
                if(i >= colIndex-1){
                    comboList[i] = comboList[i+1];
                }
            }
            comboList[comboList.length - 1] = tmp;
            colIndex = comboList.length;
        } else {
            comboList.push(comboInfo);
            colIndex = comboList.length;
        }

        var isHide = false;
        var isHideAll = false;

        if (typ == mCard.comboTypes.wei) {
            isHideAll = true;
            isHide = true;
        } else if (typ == mCard.comboTypes.ti) {
            isHide = true;
        }else if(typ == mCard.comboTypes.chouwei){
            isHide = true;
        }

        var isSelfHide = false;
        if (isHide == true && this.pos == 0) {
            isSelfHide = true;
        }

        var showChiIndex = false;
        for (var j = 0; j < cards.length; j++) {
            var newpos = this.getPosByPlayerNum(colIndex, j, isPeng, cards.length);
            var card = HUD.showLayer(HUD_LIST.Card, this);
            card.setName("card" + j);
            card.cardType = typ;
            var cardMask = null;
            if (isHide == true && (j < cards.length - 1 || isHideAll == true)) {
                if (isSelfHide == true) {
                    card.setData(cards[j], null, 2);
                    cardMask = HUD.showLayer(HUD_LIST.Card, this);
                    cardMask.setData(cards[j], null, 2, isHide);
                    cardMask.setOpacity(150);
                    cardMask.setPosition(newpos);
                    cardMask.setTag(colIndex);
                    cardMask.setName("cardMask" + j);
                } else {
                    card.setData(cards[j], null, 2, isHide);
                }
            } else {
                card.setData(cards[j], null, 2);
            }
            card.setPosition(newpos);
            card.setTag(colIndex);
            var canFanzhuan = false;
            if(mRoom.isReplay == true) {
                //臭偎  后两张盖着
                if (typ == mCard.comboTypes.chouwei || typ == mCard.comboTypes.wei) {
                    if (j != 2) {
                        if (card) card.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                        if (cardMask) cardMask.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                    }else{
                        if (card) card.setData(cards[j], null, 2);
                        if (cardMask) cardMask.setData(cards[j], null, 2);
                    }
                }
                //提  后三张盖着
                if (typ == mCard.comboTypes.ti) {
                    if (j != 3) {
                        if (card) card.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                        if (cardMask) cardMask.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                    } else {
                        if (card) card.setData(cards[j], null, 2);
                        if (cardMask) cardMask.setData(cards[j], null, 2);
                    }
                }
                // //偎的牌  点击才反过来
                // if (typ == mCard.comboTypes.wei) {
                //     canFanzhuan = true;
                //     var pre = "ss";
                //     var cardnum = parseInt(cards[j]);
                //     if(parseInt(cards[j]) > 10){
                //         pre = "s";
                //         cardnum = cardnum - 10;
                //     }
                //     card.imgSrc = Card.getCardImg(pre + cardnum);
                // }
            }else{
                //臭偎  后两张盖着
                if(typ == mCard.comboTypes.chouwei && this.pos == 0){
                    if(j != 2){
                        if(card) card.setOpacity(0);
                        if(cardMask) cardMask.setOpacity(255);
                    }
                }
                //提  后三张盖着
                if(typ == mCard.comboTypes.ti && this.pos == 0){
                    if(j != 3){
                        if(card) card.setOpacity(0);
                        if(cardMask) cardMask.setOpacity(255);
                    }
                }
                //衡东六胡抢   提 只有自己能看  其他人看都是盖着的
                if(mRoom.wanfatype == mRoom.HENGDONG){
                    if(typ == mCard.comboTypes.ti && this.pos != 0){
                        if (card) card.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                        if (cardMask) cardMask.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                    }
                }
                //偎的牌  点击才反过来
                if (typ == mCard.comboTypes.wei && this.pos == 0) {
                    if(mRoom.wanfatype == mRoom.YOUXIAN) {
                        //攸县碰胡子
                        if (j != 2) {
                            if (card) card.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                            if (cardMask) cardMask.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                            cardMask.setOpacity(255);
                        }else{
                            if (card) card.setData(cards[j], null, 2);
                            if (cardMask) cardMask.setData(cards[j], null, 2);
                            cardMask.setOpacity(0);
                        }
                        canFanzhuan = false;
                    }else {
                        canFanzhuan = true;
                    }
                }

                //吃的牌红色显示
                if(typ == mCard.comboTypes.o123 || typ == mCard.comboTypes.o2710 || typ == mCard.comboTypes.o234 ||
                    typ == mCard.comboTypes.jiao || typ == mCard.comboTypes.chi){
                    if(j == 2){
                        card.setRedCard();
                    }
                }
            }
            if (canFanzhuan) {
                card.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                if (cardMask) {
                    cardMask.setOpacity(255);
                }
                that.canFlap = true;
                TouchUtils.setOnclickListener(card, function (node) {
                    if (that.canFlap == false) return;
                    var curindex = card.getTag();
                    that.hideColIndex(curindex, false);
                    that.canFlap = false;
                    for (var s = 0; s < 3; s++) {
                        (function (curs) {
                            var flapcard = that.getChildByName("flapcard" + curindex + curs);
                            if (flapcard == null) {
                                flapcard = new cc.Sprite(res.back_png);
                                flapcard.setPosition(cc.p(card.getPositionX() + 50, curs * 45 + 45));
                                flapcard.setName("flapcard" + colIndex + curs);
                                that.addChild(flapcard, 1);
                            }
                            if (flapcard) {
                                flapcard.setVisible(true);
                                var action = cc.sequence(
                                    cc.scaleTo(0.3, -1, 1)
                                    , cc.callFunc(function () {
                                        setPokerFrameByName(flapcard, card.imgSrc);
                                        flapcard.setFlippedX(true);
                                    })
                                    , cc.delayTime(1)
                                    , cc.scaleTo(0.3, 1, 1)
                                    , cc.callFunc(function () {
                                        setPokerFrameByName(flapcard, "back.png");
                                        flapcard.setVisible(false);
                                        that.canFlap = true;
                                        that.hideColIndex(curindex, true);
                                    })
                                );
                                flapcard.runAction(action);
                            }
                        })(s);
                    }
                });
            }
        }
        var hx = mCard.getHuXi(comboList);
        if(mRoom.wanfatype == mRoom.WEIMAQUE){
            hx = mCard.getHuXiWeiMaQue(comboList);
        }
        var showHx = mCard.getHuXi(comboList, (this.pos == 0) ? true:false);
        if(mRoom.wanfatype == mRoom.WEIMAQUE){
            showHx = mCard.getHuXiWeiMaQue(comboList);
        }
        mAction.hx[this.pos] = hx;
        mAction.showHx[this.pos]= showHx;


        if (isPeng){
            //cc.log("ruru------------可以删除");
            var children = this.getChildren();
            for (var i = 0; i < children.length; i++) {
                var child = children[i];
                if (i == children.length - 1) {
                    child.setVisible(false);
                }
            }
        }
    },
    //把偎的牌设置成 第一张明  后两张暗
    setWeiColor:function(pos){
        var comboList = mAction.combos[pos];
        for (var i = 0; i < comboList.length; i++) {
            var comb = comboList[i];
            if (comb.typ == mCard.comboTypes.wei) {
                var children = this.getChildren();
                for (var j = children.length-1; j >=0; j--) {
                    var child = children[j];
                    // console.log("child.getTag()" + child.getTag() + "===" + (i+1));
                    if (child && child.getTag() == (i+1)) {
                        if (child.getName() == "card0" || child.getName() == "card1") {
                            child.img.loadTexture("back.png", ccui.Widget.PLIST_TEXTURE);
                            child.setOpacity(255);
                        }else if(child.getName() == "card2"){
                            child.setData(comb.cards[0], null, 2);
                            child.setOpacity(255);
                        }
                    }
                }
            }
        }
    },
    getPosByPlayerNum:function(colIndex, j, isPeng, cardlength){
        var newpos = null;
        if(mRoom.getPlayerNum() == 3){
            if(this.pos == 1){
                newpos = cc.p(270 - (colIndex - 1) * 45, j * 45 + 25 - 45);
            }else{
                newpos = cc.p((colIndex - 1) * 45 + 24, j * 45 + 25 - 45);
            }
            return newpos;
        }else{
            //碰胡子  1 2 位置 是行下往上
            if(mRoom.wanfatype == mRoom.YOUXIAN) {
                if (this.pos == 1) {
                    newpos = cc.p(150 - (colIndex - 1) * 45, j * 45 + 35 + (isPeng?45:0) + ((cardlength == 4)?-45:0));
                } else if (this.pos == 2) {
                    newpos = cc.p((colIndex - 1) * 45 + 24, j * 45 + 35 + (isPeng?45:0) + ((cardlength == 4)?-45:0));
                } else if (this.pos == 0 || this.pos == 3) {
                    newpos = cc.p((colIndex - 1) * 45 + 24, j * 45 + 25 - 45);
                }
            }else if(mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.HENGDONG || mRoom.wanfatype == mRoom.MAOHUZI){
                newpos = cc.p((this.pos == 0 || this.pos == 3)? (colIndex - 1) * 45 + 24: 150 - (colIndex - 1) * 45,
                    (this.pos == 0 || this.pos == 1)? j * 45 + 25 - 45: j * 45 + 25 - 45);
            }else {
                if (this.pos == 1) {
                    newpos = cc.p(150 - (colIndex - 1) * 45, j * 45 + 25 - 45);
                } else {
                    newpos = cc.p((colIndex - 1) * 45 + 24, j * 45 + 25 - 45);
                }
            }
            return newpos;
        }
    },
    hideColIndex:function(colIndex, flag){
        var children = this.getChildren();
        for (var i = 0; i < children.length; i++) {
            var child = children[i];
            if (child.getTag() == colIndex) {
                child.setVisible(flag);
            }
        }
    },
    //偎  结束后翻过牌来
    openWei: function(colIndex, card){
        var children = this.getChildren();
        for (var i = 0; i < children.length; i++) {
            var child = children[i];
            if (child.getTag() == colIndex && child.getPositionY() >= 50) {
                child.setData(card, null, 2);
            }
        }
    },
    getColIndex: function () {
        var max = 0;
        var children = this.getChildren();
        for (var i = 0; i < children.length; i++) {
            var child = children[i];
            if (max < child.getTag()) {
                max = child.getTag();
            }
        }
        return max;
    },
    getCardColIndex:function(card){
        var index = 0;
        var children = this.getChildren();
        var cardindex = 0;
        for (var i = 0; i < children.length; i++) {
            var child = children[i];
            if(child.data == card[cardindex]){
                cardindex ++;
                if(cardindex == card.length){
                    return child.getTag();
                }
            }
        }
        return index;
    },

    /** @returns OpenCards */
    getCom: function (p, name) {
        return getCom(p, name, this);
    }
};