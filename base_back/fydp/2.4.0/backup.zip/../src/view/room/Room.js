var Room = {


    init: function () {

        this.effectEmojiQueue = {};
        this.effectEmojiCfg = {
            1: {'name': 'zan', 'startFrames': 9, 'endFrames': 10, 'offsetX': 0, 'offsetY': 0},
            2: {'name': 'bomb', 'startFrames': 0, 'endFrames': 10, 'offsetX': 3, 'offsetY': 11},
            3: {'name': 'egg', 'startFrames': 9, 'endFrames': 10, 'offsetX': 0, 'offsetY': 22},
            4: {'name': 'shoe', 'startFrames': 5, 'endFrames': 10, 'offsetX': -1, 'offsetY': -1},
            5: {'name': 'flower', 'startFrames': 11, 'endFrames': 13, 'offsetX': 0, 'offsetY': 0}
        };
        this.max_player_num = 4;

        var that = this;
        //cc.spriteFrameCache.addSpriteFrames(res.card_plist);
        cc.spriteFrameCache.addSpriteFrames(res.card_common_plist);
        //ccs.armatureDataManager.addArmatureFileInfo("res/image/ui/room/finger.ExportJson");  //去掉手滑动画
        this.goldTexture = cc.textureCache.addImage(res.goldmini);

        this.signal1 = cc.textureCache.addImage(res.signal1);
        this.signal2 = cc.textureCache.addImage(res.signal2);
        this.signal3 = cc.textureCache.addImage(res.signal3);
        this.signal4 = cc.textureCache.addImage(res.signal4);
        this.signal5 = cc.textureCache.addImage(res.signal5);

        this.BatteryTextures = {
            "battery1": cc.textureCache.addImage(res.battery_1),
            "battery2": cc.textureCache.addImage(res.battery_2),
            "battery3": cc.textureCache.addImage(res.battery_3),
            "battery4": cc.textureCache.addImage(res.battery_4),
            "battery5": cc.textureCache.addImage(res.battery_5)
        };
        //手牌的大小
        this.cardSize = {w: 98, h: 122};
        this.cardBigSize = {w: 76, h: 226};
        this.cardScale = 0.9;


        this.posConf = {
            ltqpPos: {}
            , ltqpRect: {}
            , ltqpCapInsets: {
                0: cc.rect(44, 25, 1, 1)
                , 1: cc.rect(26, 31, 1, 1)
                , 2: cc.rect(44, 25, 1, 1)
                , 3: cc.rect(42, 26, 1, 1)
            }
            , ltqpEmojiPos: {
                0: cc.p(40, 28)
                , 1: cc.p(39, 28)
                , 2: cc.p(40, 40)
                , 3: cc.p(56, 28)
            }
            , ltqpVoicePos: {
                0: cc.p(40, 40)
                , 1: cc.p(37, 28)
                , 2: cc.p(42, 28)
                , 3: cc.p(58, 28)
            }
            , ltqpEmojiSize: {}
            , ltqpTextDelta: {
                0: cc.p(0, -4)
                , 1: cc.p(-7, 2)
                , 2: cc.p(-1, 9)
                , 3: cc.p(8, 3)
            }
        };

        //是否加入成功
        this.joinRoom = false;

        //三人玩  四人玩加载不同的ccs
        this.playersNum = mRoom.getPlayerNum();
        if (this.playersNum == 3) {
            // this.playersInfo = getUI(this, "playersInfo");
            // var playerNodes = ccs.load(res.RoomThreeplayer_json, "res/");
            // this.playersInfo.addChild(playerNodes.node);
        } else {
            if (mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.HENGDONG || mRoom.wanfatype == mRoom.MAOHUZI) {
                this.playersInfo = getUI(this, "playersInfo");
                var playerNodes = ccs.load(res.RoomFourplayerHY_json, "res/");
                this.playersInfo.addChild(playerNodes.node);
            } else {
                this.playersInfo = getUI(this, "playersInfo");
                var playerNodes = ccs.load(res.RoomFourplayer_json, "res/");
                this.playersInfo.addChild(playerNodes.node);
            }
        }

        this.roomCleanData = null;

        for (var i = 0; i < this.playersNum; i++) {
            var head = getUI(this, "head" + i);
            head.setVisible(false);
            var info = getUI(this, "info" + i);
            info.setVisible(false);

            if (mRoom.niao == true) {
                if (i == 2 || i == 1) {
                    var avatorbg = getUI(info, "avatorbg_" + i);
                    if (avatorbg) avatorbg.setScaleX(1.3);
                }
            } else {
                if (mRoom.wanfatype == mRoom.YOUXIAN || mRoom.wanfatype == mRoom.HENGYANG
                    || mRoom.wanfatype == mRoom.HENGDONG || mRoom.wanfatype == mRoom.MAOHUZI) {
                    var avatorbg = getUI(info, "avatorbg_" + i);
                    if (avatorbg) avatorbg.setScaleX(0.9);
                } else {
                    if (i == 2 || i == 1) {
                        var avatorbg = getUI(info, "avatorbg_" + i);
                        if (avatorbg) avatorbg.setScaleX(0.9);
                    }
                }
            }

            this["txtUserName" + i] = getUI(this, "txtUserName" + i);
            this["txtHX" + i] = getUI(this, "txtHX" + i);
            this["txtScore" + i] = getUI(this, "txtScore" + i);
            if (i != 0) {
                this["txtUserName" + i].setVisible(false);
                this["txtHX" + i].setVisible(false);
            }
            this["open" + i] = OpenCards.getCom(this, "open" + i);
            this["open" + i].setPos(i);
            this["out" + i] = OutCards.getCom(this, "out" + i);
            this["out" + i].setPos(i);

            //气泡
            var ltqp = getUI(info, "qp" + i);
            this.posConf.ltqpPos[i] = ltqp.getPosition();
            var rowchange = i;
            if (i == 0) {
                rowchange = 2
            } else if (i == 2) {
                rowchange = 0;
            }
            this.posConf.ltqpRect[rowchange] = cc.rect(0, 0, ltqp.getContentSize().width, ltqp.getContentSize().height);
            this.posConf.ltqpEmojiSize[rowchange] = cc.size({
                0: 80,
                1: 90,
                2: 84,
                3: 100
            }[rowchange], this.posConf.ltqpRect[rowchange].height);
            // ltqp.removeFromParent();
        }
        this.nAction = getUI(this, "nAction");
        this.txtNeedPlayer = getUI(this, "txtNeedPlayer");
        this.txtCardCount = getUI(this, "txtCardCount");
        this.txtRound = getUI(this, "txtRound");
        this.txtRoomId = getUI(this, "txtRoomId");
        this.txtRoom = getUI(this, "txtRoom");
        this.game_title = getUI(this, "game_title");
        this.game_zhang = getUI(this, "game_zhang");
        this.game_ju = getUI(this, "game_ju");

        this.cd = getUI(this, "cd");
        this.cdtext = getUI(this, "cdtext");
        this.arrow_tou = getUI(this, "arrow_tou");
        this.cd.setVisible(false);
        this.diaoPaoSprite = null;

        //进度条指针
        // var cdbar = new cc.ProgressTimer(cc.Sprite.create(res.greenquan));
        //
        // cdbar.setPositionX(46);
        // cdbar.setPositionY(46+2);
        // cdbar.setType(cc.ProgressTimer.TYPE_RADIAL);
        // cdbar.setMidpoint(cc.p(0.5, 0.5));
        // cdbar.setReverseDirection(true);
        // cdbar.runAction(
        //     cc.progressTo(0.1, 100)
        // );
        // this.cd.addChild(cdbar);
        // this.cdbar = cdbar;
        //背景声音
        var setting_bgm = cc.sys.localStorage.getItem('setting_bgm') || 1;
        playMusic("vbg" + setting_bgm);
        //聊天
        this.chat = getUI(this, "chat");
        //邀请
        this.invite = getUI(this, "invite");
        TouchUtils.setOnclickListener(this.invite, function () {
            that.inviteFunc();
        });

        //
        this.btn_inviteLiaobei = getUI(this, "btn_inviteLiaobei");
        TouchUtils.setOnclickListener(this.btn_inviteLiaobei, function () {
            that.inviteLBFunc();
        });

        //邀请
        this.inviteXianLiao = getUI(this, "inviteXianLiao");
        TouchUtils.setOnclickListener(this.inviteXianLiao, function () {
            that.inviteXLFunc();
        });

        TouchUtils.setOnclickListener(this.chat, function () {
            var chatLayer = new ChatLayer();
            that.addChild(chatLayer);
        });
        // this.copyroom = getUI(this, "copyroom");
        // TouchUtils.setOnclickListener(this.copyroom, function() {
        //     that.copyroomFunc()
        // });
        //退出
        this.tuichu = getUI(this, "btn_fanhui");
        TouchUtils.setOnclickListener(this.tuichu, function () {
            that.tuichuFunc()
        });
        //解散
        this.jiesan = getUI(this, "btn_jiesan");
        TouchUtils.setOnclickListener(this.jiesan, function () {
            that.jiesanFunc()
        });
        //无人进入的快速解散
        this.btnJiesanfangjian = getUI(this, "btjiesanfangjian");
        TouchUtils.setOnclickListener(this.btnJiesanfangjian, function () {
            that.jiesanFunc()
        });
        this.btnJiesanfangjian.setVisible(false);


        // this.jushou = getUI(this, "jushou");//举手
        // this.bujushou = getUI(this, "bujushou");
        // this.jushou.setVisible(false);
        // this.bujushou.setVisible(false);
        // TouchUtils.setOnclickListener(this.jushou, function (node) {
        //     network.wsData("Jushou/1");
        // });
        // TouchUtils.setOnclickListener(this.bujushou, function (node) {
        //     network.wsData("Jushou/2");
        // });
        this.lbTime = getUI(this, "lbTime");
        // if(mRoom.isReplay == true) {
        this.invite.setVisible(false);
        this.inviteXianLiao.setVisible(false);
        this.btn_inviteLiaobei.setVisible(false);

        if (window.inReview) {
            this.invite.setVisible(false);
            this.inviteXianLiao.setVisible(false);
            this.btn_inviteLiaobei.setVisible(false);
        }

        this.imgAct = getUI(this, "imgAct");
        this.imgAct.setOpacity(0);

        this.debugRow = 0;
        this.timeAdd = 5;//20秒倒计时
        this.nDebug = getUI(this, "nDebug");
        this.actCard = Card.getCom(this, "actCard");
        this.showCard = Card.getCom(this, "showCard");
        this.nChiList = getUI(this, "nChiList");
        this.isReady = false;
        this.btReady = getUI(this, "btReady");
        this.btn_resultbg = getUI(this, "btn_resultbg");
        this.btJiesuan = getUI(this, "btJiesuan");
        this.btn_xszm = getUI(this, 'btn_xszm');
        this.btSetting = getUI(this, "setting");
        this.btn_resultbg = getUI(this, "btn_resultbg");

        this.safenode = getUI(this, "safenode");

        this.resultLayer = getUI(this, "resultLayer");
        this["nCards0"] = getUI(this.playersInfo, "nCards0");
        if (mRoom.isReplay) {
            this["nCards1"] = getUI(this.playersInfo, "nCards1");
            this["nCards2"] = getUI(this.playersInfo, "nCards2");
            this["nCards3"] = getUI(this.playersInfo, "nCards3");
        } else {
            this["nCards1"] = getUI(this.resultLayer, "nCards1");
            this["nCards2"] = getUI(this.resultLayer, "nCards2");
            this["nCards3"] = getUI(this.resultLayer, "nCards3");
        }

        this.tipLine = getUI(this, 'tipLine');
        this.tipLine.setPositionY(280);
        this.tipLine.setVisible(false);

        TouchUtils.setOnclickListener(this.btReady, function () {
            that.onReady()
        });
        TouchUtils.setOnclickListener(this.btn_resultbg, function () {
            that.onJiesuan();
        });
        TouchUtils.setOnclickListener(this.btSetting, function () {
            that.onSetting()
        });

        // this.battery = getUI(this, "battery_pro");
        this.wifi = getUI(this, "wifi");

        // this.BatteryTextures = {
        //     "full": cc.textureCache.addImage(res.battery_f),
        //     "empty": cc.textureCache.addImage(res.battery_e),
        //     "half": cc.textureCache.addImage(res.battery_h)
        // };

        this.WIFITextures = {
            "full": cc.textureCache.addImage(res.wifi_f),
            "empty": cc.textureCache.addImage(res.wifi_e),
            "half": cc.textureCache.addImage(res.wifi_h)
        };

        this.listActBtn = [];
        for (var i = 1; i < 5; i++) {
            (function (i) {
                var bt = getUI(that.nAction, "bt" + i);
                if (bt) {
                    bt.setTag(i);
                    if (i == 1) {
                        var ccsScene = ccs.load(res.PhzHuAni_json, "res/");
                        var huani = ccsScene.node;
                        huani.setPosition(cc.p(bt.getContentSize().width / 2, bt.getContentSize().height / 2 - 10));
                        bt.addChild(huani);
                        huani.runAction(ccsScene.action);
                        ccsScene.action.play('action', true);
                    }

                    TouchUtils.setOnclickListener(bt, function () {
                        that.onActionBtn(i)
                    });
                    that.listActBtn.push(bt);
                }
            })(i)
        }

        mRoom.scoreInfo = {};
        mRoom.isPause = false;

        var content = "";
        var wanfaArr = mRoom.wanfa.split(",");
        if (wanfaArr.length > 0) {
            for (var s = 1; s < wanfaArr.length; s++) {
                //content += wanfaArr[s] + "\n";
                if (s != wanfaArr.length - 1) {
                    content += wanfaArr[s] + "/";
                }
                else {
                    content += wanfaArr[s];
                }
            }
        }
        this.txtRoom.setString("" + mRoom.roomId);//房号：
        this.txtRoomId.setString(content);
        this.txtRoomId.setVisible(true);
        if (mRoom.wanfatype == mRoom.CHANGDE && mRoom.subWanfa == 'bashifan')
            this.game_title.setTexture(res.title_bashifan_png);
        else
            this.game_title.setTexture(res["title_" + mRoom.wanfatype + "_png"]);

        this.round = 0;
        mRoom.curRound = this.round;
        this.clearRoom();

        //房卡数有变动
        // network.addListener(3013, function (data) {
        //     gameData.numOfCards = data['numof_cards'];
        // });

        network.addCustomListener(P.GS_StatusChange, this.onStatusChange.bind(this));
        network.addCustomListener(P.GS_GameStart, this.onGameStart.bind(this));
        network.addCustomListener(P.GS_CardDeal, this.onCardDeal.bind(this));
        network.addCustomListener(P.GS_RoomInfo, this.onResumeRoom.bind(this));
        // network.addCustomListener(P.GS_UserJoin, this.onUserJoin.bind(this));
        network.addCustomListener(P.GS_UserDisconnect, this.onUserDisconnect.bind(this));

        network.addCustomListener(P.GS_Login, this.onRoleLoginOK.bind(this));      //房间内断开重连
        network.addCustomListener(P.GS_UserLeave, this.onLeaveOK.bind(this));      //离开房间
        network.addCustomListener(P.GS_UserJoin, this.onJoinOK.bind(this));      //离开房间

        network.addCustomListener(P.GS_GameTurn_Out, this.onTurnOut.bind(this));   //出牌
        network.addCustomListener(P.GS_GameTurn_In, this.onTurnIn.bind(this));     //进牌
        network.addCustomListener(P.GS_BroadcastAction, this.onBroadCast.bind(this));
        // todo 这里报错, 暂时注释 network.addCustomListener(P.GS_PreAction, this.onPreAction.bind(this));

        network.addCustomListener(P.GS_GameOver, this.onGameOver.bind(this));
        network.addCustomListener(P.GS_Vote, this.onGameVote.bind(this));
        network.addCustomListener(P.GS_Chat, this.onVoice.bind(this));
        network.addCustomListener(P.GS_Marquee, this.onMaDeng.bind(this));
        network.addCustomListener(P.GS_RoomResult, this.onRoomResult.bind(this));
        network.addCustomListener(P.GS_UserKick, this.onUserKick.bind(this));
        network.addCustomListener(P.GS_Niao_Status, this.onNiao_Status.bind(this));
        network.addCustomListener(P.GS_Jushou_Status, this.onJushou_Status.bind(this));
        network.addCustomListener(P.GS_Pls_Disconnect, this.Pls_Disconnect_MSG.bind(this));
        network.addCustomListener(P.GS_Baojing_Status, this.onBaojing.bind(this));
        network.addCustomListener(P.GS_Fanxing_Status, this.onFanXing.bind(this));
        network.addCustomListener(EVENT_CLEAN_ROOM, this.beginReplay.bind(this));
        network.addCustomListener(EVENT_EATCARD, this.onEatCard.bind(this));
        network.addCustomListener(EVENT_EATOVER, this.hideReplayAction.bind(this));
        //网络连接断开
        network.addCustomListener(P.GS_NetWorkClose, this.NetWorkCloseFunc.bind(this));
        //切home
        network.addCustomListener("game_on_hide", this.Game_On_Hide.bind(this));
        network.addCustomListener("game_on_show", this.Game_On_Show.bind(this));
        this.onTimer();
        if (!mRoom.isReplay) {
            this.schedule(this.onTimer, 0.1);
            this.schedule(this.onPing, 5);
        }
        this.onBattery();
        this.schedule(this.onBattery, 60);
        this.refreshTime();
        this.schedule(this.refreshTime, 1);

        this.btReady.setVisible(false);
        this.btJiesuan.setVisible(false);

        network.start();

        // if (mRoom.roomType == 1) {
        //     // var cmd = "joinHall";
        //     // network.wsData(cmd);
        //     // mRoom.rounds = 8;
        // } else if (mRoom.roomType == 2) {
        //     if (mRoom.oldRoom == 0) {
        //         this.isStart = false;
        //         var cmd = "JoinRoom/" + mRoom.roomId;
        //         network.wsData(cmd, true);
        //     } else {
        //         var cmd = "Continue/" + mRoom.roomId;
        //         network.wsData(cmd, true);
        //     }
        // }

        this.txtUserName0.setString(ellipsisStr(gameData.nickname, 5));
        this.setPlayerAvator(0, gameData.headimgurl);
        mRoom.isClean = false;

        // this.initChatBtn();
        // this.initMic();
        var btn_mic = getUI(this, "btn_mic");
        this.btn_mic = btn_mic;
        MicLayer.init(btn_mic, this);
        this.chat.setVisible(false);
        this.btn_mic.setVisible(true);

        if (window.inReview) this.btn_mic.setVisible(false);

        //跑马灯
        this.speaker = getUI(this, 'speaker');
        this.speaker.setVisible(false);
        this.wandesc = getUI(this, "wandesc");

        if (mRoom.isReplay) {
            this.beginReplay();
            var playernacklayer = HUD.showLayer(HUD_LIST.PlayerBackLayer, this);
            playernacklayer.setData(this);
        }
        //玩法介绍
        // if(mRoom.subWanfa != "bashifan" && mRoom.wanfatype != mRoom.HENGDONG && mRoom.wanfatype != mRoom.WEIMAQUE) {
        //     var wanfa = HUD.showLayer(HUD_LIST.WanfaDesc, this.wandesc);
        //     wanfa.setPosition(0, 0);
        //     if (mRoom.getPlayerNum() == 4) wanfa.setPositionY(-50);
        //     wanfa.setData();
        // }

        if (mRoom.isReplay == true) {
            this.btSetting.setVisible(false);
        }

        //设置背景图
        this.initBG();

        this.showSafeTipLayer();
        for (var i = 1; i <= 3; i++) {
            var safe_line = getUI(this.safenode, "safe_line" + i);
            safe_line.setOpacity(255);
            safe_line.setVisible(false);
        }
        // this.fingerAni();

        this.setupPlayers();

        this.getVersion();

        TouchUtils.setOnclickListener(getUI(this, 'btn_control_btns'), function () {
            that.changeBtnStatus();
        });
        that.hideControlBtns();
        TouchUtils.setOnclickListener(getUI(this, 'bg'), function () {
            that.hideControlBtns();
        }, {sound:"no", effect: TouchUtils.effects.NONE});

        //test
        // console.log(mCard.getComboHuXiWeiMaQue({typ:10, cards:[11,11]}, [{typ:10, cards:[11,11]}, {typ:7, cards:[11,12,13]}]));
        // console.log(mCard.getComboHuXiWeiMaQue({typ:10, cards:[12,12]}, [{typ:10, cards:[12,12]}, {typ:9, cards:[12,13,14]}]));
        //
        // console.log(mCard.getComboHuXiWeiMaQue({typ:1, cards:[3,3,3]}, [{typ:1, cards:[3,3,3]}, {typ:9, cards:[3,4,5]}]));
        // console.log(mCard.getComboHuXiWeiMaQue({typ:1, cards:[12,12,12]}, [{typ:1, cards:[12,12,12]}, {typ:9, cards:[12,13,14]}]));
        //
        // console.log(mCard.getComboHuXiWeiMaQue({typ:2, cards:[3,3,3]}, [{typ:2, cards:[3,3,3]}, {typ:9, cards:[3,4,5]}]));
        // console.log(mCard.getComboHuXiWeiMaQue({typ:2, cards:[12,12,12]}, [{typ:2, cards:[12,12,12]}, {typ:9, cards:[12,13,14]}]));
        //
        // console.log(mCard.getComboHuXiWeiMaQue({typ:3, cards:[3,3,3]}, [{typ:3, cards:[3,3,3]}, {typ:9, cards:[3,4,5]}]));
        // console.log(mCard.getComboHuXiWeiMaQue({typ:3, cards:[12,12,12]}, [{typ:3, cards:[12,12,12]}, {typ:9, cards:[12,13,14]}]));
        window.gameLayer = this;


        //断线重连解散房间
        if(mRoom.VoteInfo && mRoom.VoteInfo.Vote && mRoom.VoteInfo.Vote.Users){
            mRoom.isPause = false;
            if(mRoom.isPause != true){
                var vote = new RoomQuit();
                this.addChild(vote);
                for(var i=0;i<mRoom.VoteInfo.Vote.Users.length;i++){
                    if(mRoom.VoteInfo.Vote.Users[i].Content != ""){
                        var content = mRoom.VoteInfo.Vote.Users[i].UserID + "/Vote/quit/"+ mRoom.VoteInfo.Vote.Users[i].Content +"/0/0";
                        if(mRoom.VoteInfo.Vote.ByWho == mRoom.VoteInfo.Vote.Users[i].UserID) {
                            vote.setData(content, true, this);
                        }
                    }
                }
                for(var i=0;i<mRoom.VoteInfo.Vote.Users.length;i++){
                    if(mRoom.VoteInfo.Vote.Users[i].Content != ""){
                        var content = mRoom.VoteInfo.Vote.Users[i].UserID + "/Vote/quit/"+ mRoom.VoteInfo.Vote.Users[i].Content +"/0/0";
                        if(mRoom.VoteInfo.Vote.ByWho != mRoom.VoteInfo.Vote.Users[i].UserID){
                            vote.setData(content, false, this);
                        }
                    }
                }
            }
        }

        //
        MWUtil.clearRoomId();
        return true;
    },
    hideControlBtns: function () {
        getUI(this, 'btn_bg').setVisible(false);
        getUI(this, 'setting').setVisible(false);
        getUI(this, 'btn_fanhui').setVisible(false);
        getUI(this, 'btn_jiesan').setVisible(false);

        if(mRoom.isReplay){
            var btn_control_btns = getUI(this, 'btn_control_btns');
            btn_control_btns.setVisible(false);
        }
    },

    changeBtnStatus: function () {
        var btn_bg = getUI(this, 'btn_bg');
        var setting = getUI(this, 'setting');
        var btn_fanhui = getUI(this, 'btn_fanhui');
        var btn_jiesan = getUI(this, 'btn_jiesan');
        var btn_control_btns = getUI(this, 'btn_control_btns');

        btn_bg.setVisible(!btn_bg.isVisible());
        setting.setVisible(!setting.isVisible());
        btn_fanhui.setVisible(!btn_fanhui.isVisible());
        btn_jiesan.setVisible(!btn_jiesan.isVisible());

        btn_control_btns.setFlippedY(!btn_control_btns.isFlippedY());
    },
    getVersion: function () {
        var versiontxt = window.curVersion;
        var version = new ccui.Text();
        version.setFontSize(15);
        version.setTextColor(cc.color(255, 255, 255));
        version.setPosition(cc.p(1280 - 10, 10));
        version.setAnchorPoint(cc.p(1, 0.5));
        version.setString(versiontxt);
        this.addChild(version, 2);
    },
    initBG: function () {
        var sceneid = cc.sys.localStorage.getItem('sceneid') || 0;
        var bg = getUI(this, "bg");
        bg.loadTexture(res["table_back" + sceneid + "_jpg"]);
    },
    //GPS 提示
    showSafeTipLayer: function () {
        var visible = true;
        if (mRoom.isReplay) visible = false;
        var that = this;
        this.safenode.setVisible(visible);
        var safebtn = getUI(this.safenode, "safebtn");
        var safe_gps = getUI(this.safenode, "safe_gps");
        var safe_gps2 = getUI(this.safenode, "safe_gps2");
        safe_gps.runAction(cc.repeatForever(cc.sequence(cc.fadeIn(0.5), cc.fadeOut(0.5))));
        safe_gps2.runAction(cc.repeatForever(cc.sequence(cc.fadeOut(0.5), cc.fadeIn(0.5))));

        TouchUtils.setOnclickListener(safebtn, function () {
            var posArr = {pos0: that.pos0, pos1: that.pos1, pos2: that.pos2, pos3: that.pos3};
            var safelayer = new SafeTipLayer(that, posArr);
            safelayer.setName("safelayer");
            that.addChild(safelayer, 10);
        });
    },
    //GPS 提示信息
    addGpsTip: function (pos, name, loc) {
        var that = this;
        // var loc = '0.000001,0.00001';
        // gameData.location = '0.000001,0.00001';
        // console.log(pos+"?????????????=="+name+"==");

        var safelayer = this.getChildByName("safelayer");
        if (safelayer) {
            var posArr = {pos0: this.pos0, pos1: this.pos1, pos2: this.pos2, pos3: this.pos3};
            safelayer.setPlayerJuli(posArr);
        }
        if (loc == undefined || loc == null || loc == "false" || loc == false || loc == "") {
            return;
        }
        var templocation1 = loc.split(',');
        var otherpeoplelocationlat = 0;
        var otherpeoplelocationlng = 0;
        if (templocation1.length == 2) {
            otherpeoplelocationlat = templocation1[1];
            otherpeoplelocationlng = templocation1[0];
        }

        var mylocationlat = 0;
        var mylocationlng = 0;
        if (gameData.location && gameData.location.length > 0) {
            var templocation2 = gameData.location.split(',');
            if (templocation2.length == 2) {
                mylocationlat = templocation2[1];
                mylocationlng = templocation2[0];
            }
        }
        var juli = "";
        var distance = getFlatternDistance(mylocationlat, mylocationlng, otherpeoplelocationlat, otherpeoplelocationlng);
        if (distance <= 100) {
            name = ellipsisStr(name, 7);
            juli = '玩家[' + name + ']' + '距您距离过近（' + distance + "米）";

            var safe_line = getUI(this.safenode, "safe_line" + pos);
            if (safe_line) {
                if (this.safenode.nodeNum == undefined || this.safenode.nodeNum == null) {
                    this.safenode.nodeNum = 0;
                }
                safe_line.setOpacity(255);
                safe_line.setVisible(true);
                if (!safe_line.pos) {
                    this.safenode.nodeNum += 1;
                    safe_line.setPositionY(-80 + (this.safenode.nodeNum - 1) * 40);
                    // console.log(pos + "==="+ safe_line.getPositionY());
                }
                safe_line.pos = true;
                var tip = safe_line.getChildByName("tip");
                tip.setString(juli);
                safe_line.runAction(cc.sequence(
                    cc.delayTime(15),
                    cc.fadeOut(1),
                    cc.callFunc(function () {
                        safe_line.pos = false;
                        safe_line.setVisible(false);
                        if (that.safenode.nodeNum > 0) that.safenode.nodeNum -= 1;
                    })
                ))
            }
        }
    },
    NetWorkCloseFunc: function () {
        //cc.eventManager.removeAllListeners(););
        HUD.showScene(HUD_LIST.Login, this);
        AgoraUtil.closeVideo();
    },
    Game_On_Hide: function () {
        var msg = JSON.stringify({
            roomid: mRoom.roomId, type: 'user_leave',
            content: '有事离开，等我一下', from: gameData.uid
        });
        network.wsData("Say/" + msg);
    },
    Game_On_Show: function () {
        var msg = JSON.stringify({
            roomid: mRoom.roomId, type: 'user_back',
            content: '我回来了', from: gameData.uid
        });
        network.wsData("Say/" + msg);
    },
    chatFunc: function (sender, type) {
        var that = this;
        var chatLayer = new ChatLayer();
        that.addChild(chatLayer);
    },
    fingerAni: function (isShow) {
        //新手势动作
        var fingerAni = this.getChildByName('fingerAnimation');
        if (!fingerAni) {
            var ccsScene = ccs.load(res.PhzShou_json, "res/");
            fingerAni = ccsScene.node;
            fingerAni.setName("fingerAnimation");
            fingerAni.setPosition(cc.p(975, 200));
            this.addChild(fingerAni);
            fingerAni.runAction(ccsScene.action);
            ccsScene.action.play('action', true);
        }
        fingerAni.setVisible(isShow);
    },
    inviteFunc: function (sender, type) {
        var title = COMPANYNAME[gameData.appId]+"-";
        title += mRoom.getWanfaName(mRoom.wanfatype);
        title += "-" + mRoom.roomId;
        var userLength = 1;
        if(DD[T.PlayerList])  userLength = DD[T.PlayerList].length;
        var shareContent = mRoom.rounds + "局" + mRoom.wanfa + ",已有" + userLength +  "人";
        // console.log(shareContent);
        // WXUtils.shareUrl("http://www.yayayouxi.com/penghuzi2?roomid="+mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
        //关闭魔窗
        // WXUtils.shareUrl('http://www.yayayouxi.com/openapp/?url=https://aidhyd.mlinks.cc/A0Gc?roomid='+mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
        WXUtils.shareUrl(MWINDOWURL[gameData.appId] + '?roomid=' + mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
    },

    inviteLBFunc:  function (sender, type) {
        var title = COMPANYNAME[gameData.appId]+"-";
        title += mRoom.getWanfaName(mRoom.wanfatype);
        title += "-" + mRoom.roomId;
        var userLength = 1;
        if(DD[T.PlayerList])  userLength = DD[T.PlayerList].length;
        var shareContent = mRoom.rounds + "局" + mRoom.wanfa + ",已有" + userLength +  "人";
        //关闭魔窗
        XianLiaoUtils.shareUrl(MWINDOWURL[gameData.appId] + '?roomid='+mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
    },
    inviteXLFunc: function (sender, type) {
        var title = COMPANYNAME[gameData.appId]+"-";
        title += mRoom.getWanfaName(mRoom.wanfatype);
        title += "-" + mRoom.roomId;
        var userLength = 1;
        if(DD[T.PlayerList])  userLength = DD[T.PlayerList].length;
        var shareContent = mRoom.rounds + "局" + mRoom.wanfa + ",已有" + userLength +  "人";
        // console.log(shareContent);
        // WXUtils.shareUrl("http://www.yayayouxi.com/penghuzi2?roomid="+mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
        //关闭魔窗
        XianLiaoUtils.shareGame(MWINDOWURL[gameData.appId] + '?roomid='+mRoom.roomId, title, shareContent, 0, getCurTimestamp() + gameData.uid);
    },

    copyroomFunc: function (sender, type) {
        //if (!cc.sys.isNative)
        //    return;
        var sharecontent = "衡阳棋牌：" + "房号: " + gameData.roomId + "," +
            (mRoom.wanfa ? decodeURIComponent(mRoom.wanfa) + "," : "") +
            "速度来啊! 【衡阳棋牌】";
        savePasteBoard(sharecontent);
        alert1("复制房间信息成功", function () {
        });
    },
    getPlayerInfoLayer: function (i, userinfo) {
        var that = this;
        if (userinfo == null) {
            return;
        }
        var headbg = getUI(this, "head" + i);
        TouchUtils.setOnclickListener(headbg, function () {
            if (window.inReview)
                return;
            var scene = ccs.load(res.PlayerInfo_json, "res/");
            that.addChild(scene.node);

            var head = getUI(scene.node, 'head');
            var lbNickname = getUI(scene.node, 'lb_nickname');
            var lbId = getUI(scene.node, 'lb_id');
            var lbIp = getUI(scene.node, 'lb_ip');
            var male = getUI(scene.node, 'male');
            var female = getUI(scene.node, 'female');
            var fake_root = getUI(scene.node, 'fake_root');
            var panel = getUI(scene.node, 'panel');
            var lbAd = getUI(scene.node, 'lb_ad');
            var lbDt = getUI(scene.node, 'lb_dt');
            lbDt.setVisible(false);

            console.log(userinfo);
            lbNickname.setString(ellipsisStr(userinfo.NickName, 6));
            lbId.setString(userinfo.ID);
            lbIp.setString(userinfo.IP);
            male.setVisible(userinfo.Sex == '1');
            female.setVisible(userinfo.Sex == '2');
            loadImageToSprite(((userinfo.HeadIMGURL == null || userinfo.HeadIMGURL == '') ? res.defaultHead : userinfo.HeadIMGURL), head);

            //定位
            lbAd.setVisible(true);
            if (!userinfo.Location || userinfo.Location == '') {
                lbAd.setString('您可能没有开启定位权限');
            } else {
                lbAd.setString(decodeURIComponent(userinfo.locationCN));
            }

            TouchUtils.setOnclickListener(fake_root, function () {
                scene.node.removeFromParent(true);
            });
            TouchUtils.setOnclickListener(panel, function () {
            }, {effect: TouchUtils.effects.NONE});
        });
    },
    tuichuFunc: function (sender, type) {
        if (this.isStart == false) {
            mRoom.quitRoom(this);
        }
        else {
            network.wsData("Vote/quit/1/0/0");
        }
    },
    jiesanFunc: function (sender, type) {
        var that = this;
        // var confirmJiesan = HUD.showLayer(HUD_LIST.ConfirmJiesan, this);
        var okfunc = function () {
            if (that.isStart == false) {
                network.wsData("Discard/" + mRoom.roomId);
                that.scheduleOnce(function () {
                    DC.closeByClient = true;
                    clearGameMWRoomId();
                    HUD.showScene(HUD_LIST.Home, this);
                    AgoraUtil.closeVideo();
                }, 0.5);
            } else {
                network.wsData("Vote/quit/1/0/0");
            }
        }
        // var content = "解散房间不扣房卡,是否确定解散房间";
        // if (window.inReview) {
        //     content = "是否确定解散房间";
        // }
        // confirmJiesan.setData(okfunc, content);

        if (window.inReview)
            okfunc();
        else
            alert2('解散房间不扣房卡，是否确定解散？', function () {
                okfunc();
            }, null, false, false);
    },
    onPing: function (dt) {
        DC.wsPing();
        var cur = Date.now();
        var delay = cur - DC.lastPong;
        // if (delay < 6000) {
        //     this.wifi.setTexture(this.WIFITextures["full"]);
        // } else if (delay < 8000) {
        //     this.wifi.setTexture(this.WIFITextures["half"]);
        // } else {
        //     this.wifi.setTexture(this.WIFITextures["empty"]);
        // }
        if (delay < 200) this.wifi.setTexture(this.signal3);
        else if (delay < 600) this.wifi.setTexture(this.signal2);
        else this.wifi.setTexture(this.signal1);
        if (delay > 1000 * 8) {
        }
    },
    updateScore: function (pos) {
        var users = DD[T.PlayerList];
        var userIndex = this["pos" + pos];
        var userID = null;
        if (users[userIndex] && users[userIndex].ID) {
            userID = users[userIndex].ID;
            var score = mRoom.scoreInfo[userID] || 0;
            if (mRoom.wanfatype == mRoom.YOUXIAN) {
                this["txtScore" + pos].setString("总分:" + score);
            } else {
                this["txtScore" + pos].setString("得分:" + score);
            }
        }
    },

    clearRoom: function (roundNotAdd) {
        mRoom.inSeq = 0;//

        for (var i = 0; i < this.playersNum; i++) {
            this["out" + i].removeAllChildren();
            this["open" + i].removeAllChildren();

            if (mRoom.wanfatype == mRoom.LEIYANG) {
                this["txtHX" + i].setString("胡子:0");
            } else if (mRoom.wanfatype == mRoom.YOUXIAN || mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.MAOHUZI) {
                this["txtHX" + i].setString("得分:0");
            } else if (mRoom.wanfatype == mRoom.WEIMAQUE) {
                this["txtHX" + i].setString("硬息:0");
            } else {
                this["txtHX" + i].setString("胡息:0");
            }
            this.hideImaAct()
        }
        //清理 手牌和 结算  继续游戏
        this.btReady.setVisible(false);
        this.resultLayer.setVisible(false);
        this["nCards1"].removeAllChildren();
        this["nCards2"].removeAllChildren();
        if (this["nCards3"]) this["nCards3"].removeAllChildren();

        this.actCard.setVisible(false);
        this.showCard.setVisible(false);

        if (this.isStart == true) {
            for (var i = 0; i < this.playersNum; i++) {
                this.updateScore(i);
            }
        } else {
            this.isStart = false;
        }

        this.secondsLeft = 0;
        this.turnPos = 0;
        this.nCards0.setVisible(false);
        this.nAction.setVisible(false);

        this.nAction.setVisible(false);
        mAction.initGame();
        if (roundNotAdd != true) {
            this.txtCardCount.setString(mAction.leftCardCount);
            this.round++;
        } else {
            //断线回来
            if (this.playersNum == 4) {
                mAction.leftCardCount = 23;
            } else {
                mAction.leftCardCount = 19;
            }
            if (mRoom.wanfatype == mRoom.WEIMAQUE) mAction.leftCardCount = 22;
            this.txtCardCount.setString(mAction.leftCardCount);
        }
        if (mRoom.isReplay) {
            this.round = mRoom.replayData.round;
            mRoom.rounds = mRoom.replayData.rounds;
        }
        mRoom.curRound = this.round;

        var showTxtRound = mRoom.getRound(this.round);
        this.txtRound.setString(showTxtRound);
        this.isTurnOut = false;
        this.isTurnIn = false;
        this.gameOverHuInfo = null;

        this.Freeze = null;//冻结字段
        if (this.diaoPaoSprite) {
            this.diaoPaoSprite.setVisible(false);
        }
    },

    onGameStart: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        if(!mRoom.isReplay)  this.openLocation();
        this.isStart = true;
        this.setupPlayers();
        this.setupGameStart();
        this.setZhuangjia(data.Banker, data.LianZhuang);//设置庄家
        this.scheduleOnce(function () {
            this.setAllReadyVisible(false);//准备隐藏
        }, 1);
        //隐藏抓鸟
        var players = DD[T.PlayerList];
        for (var i = 0; i < players.length; i++) {
            this.setSelectNiao(players[i].ID, 0, false);
            this.setNiaoNumVisible(players[i].ID, true);
        }
        //回放的得分数据
        if (mRoom.isReplay && data.Score) {
            for (var i = 0; i < data.Score.length; i++) {
                if (mRoom.wanfatype == mRoom.YOUXIAN || mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.MAOHUZI) {
                    this["txtScore" + i].setString("总分:" + data.Score[i]);
                } else {
                    this["txtScore" + i].setString("得分:" + data.Score[i]);
                }
            }
        }
        // this.openAgoraUtil(players);
    },

    openAgoraUtil: function(players){
            AgoraUtil.initVideoView(this.getUserHeaderData(players));
            setTimeout(function () {
                AgoraUtil.openVideo(gameData.roomId.toString(), gameData.uid.toString());
            }, 1000);
    },

    getUserHeaderData:function(players){
        var data = {};
        // var players = gameData.players;
        var scale = cc.view.getFrameSize().width / cc.director.getWinSize().width;
        var theight = cc.view.getFrameSize().height / scale;
        var boardHeight = (theight - cc.director.getWinSize().height) / 2;
        for (var i = 0; i < players.length; i++) {
            var player = players[i];


            var pos = mRoom.getUserPosIndex(players[i].ID);

            var headbg = getUI(this, "head" + pos);
            var header = headbg.getChildByName('head');
            // var pos = uid2position[player.uid];
            // var header = $('info' + pos + '.head' + pos + ".head");
            var headerPos = header.convertToWorldSpace(cc.p(0, 0));
            var width = header.getBoundingBox().width;
            var height = header.getBoundingBox().height;
            var x = headerPos.x;
            var y = headerPos.y + height - boardHeight;
            data[player.ID] = {
                x: x,
                y: y,
                width: width,
                height: height
            };
        }
        return JSON.stringify(data);
    },

    setupGameStart: function () {
        this.invite.setVisible(false);
        this.inviteXianLiao.setVisible(false);
        this.btn_inviteLiaobei.setVisible(false);
        // this.copyroom.setVisible(false);

        if (mRoom.isReplay != true) {
            this.chat.setVisible(true);
            this.btn_mic.setVisible(true);
            if (window.inReview) {
                this.btn_mic.setVisible(false);
                this.chat.setVisible(false);
            }
        }
    },

    //todo 去掉动画
    onCardDeal: function (event) {
        var that = this;
        //断线重连回来  清理牌桌  这里局数不+1
        // var event = {"__instanceId":5398,"_type":6,"_eventName":107,
        // "_userData":{"Head":null,
        // "Cards":[2,2,3,13,14,15,5,5,6,16,17,18,19,20,10],
        // "ToUser":111243},"_currentTarget":null,
        //     getUserData: function () {
        //         return this._userData;
        //     }};
        if (!mRoom.isReplay) {
            this.clearRoom(true);
        }
        if (this.checkNoRunning()) return;
        var that = this;
        var data = event.getUserData();

        var beforeSrotCard = deepCopy(data.Cards);

        var cards = JSON.stringify(DD[T.CardList]);
        if (mRoom.isReplay) {
            var users = DD[T.PlayerList];
            if (data.ToUser == users[this.pos0].ID) {
                DD[T.CardList] = data.Cards;
                var cards = DD[T.CardList];
                cards.sort(function (a, b) {
                    return a - b;
                });
                var cardList = mCard.getCardList();
                this.cardList = cardList;
                this.setupCards();
            } else if (data.ToUser == users[this.pos1].ID) {
                DD[T.CardList1] = data.Cards;
                this.cardList1 = mCard.getCardList(DD[T.CardList1]);
                this.setupOtherCards(1);
            } else if (data.ToUser == users[this.pos2].ID) {
                DD[T.CardList2] = data.Cards;
                this.cardList2 = mCard.getCardList(DD[T.CardList2]);
                this.setupOtherCards(2);
            } else if (data.ToUser == users[this.pos3].ID) {
                DD[T.CardList3] = data.Cards;
                this.cardList3 = mCard.getCardList(DD[T.CardList3]);
                this.setupOtherCards(3);
            }
        } else {
            // var cards = DD[T.CardList];
            // cards.sort(function (a, b) {
            //     return a - b;
            // });
            //
            // var cardList = mCard.getCardList();
            // this.cardList = cardList;
            // this.setupCards();
            var users = DD[T.PlayerList];
            if (data.ToUser == users[this.pos0].ID) {
                DD[T.CardList] = data.Cards;
            }

            network.stop();//消息暂停

            if (mRoom.wanfatype == mRoom.CHEHUZI && data.Card && data.Card == 21) {
                var cards = DD[T.CardList];
                cards.sort(function (a, b) {
                    return a - b;
                });
                this.cardList = mCard.getCardList();
                this.setupCards();
            } else {
                //动画
                var beforeCardList = [];
                var t = [];
                for (var i = 0; i < beforeSrotCard.length; i++) {
                    t.push(beforeSrotCard[i]);
                    if (t.length == 2 || i == beforeSrotCard.length - 1) {
                        beforeCardList.push(t);
                        t = [];
                    }
                }
                this.cardList = deepCopy(beforeCardList);

                //排序后的数组
                var changeIndex = function (value, yindex, xindex) {
                    var changIndex = [0, 0];
                    for (var s = 0; s < afterCardList.length; s++) {//x
                        for (var k = 0; k < afterCardList[s].length; k++) {//y
                            if (value == afterCardList[s][k]) {
                                afterCardList[s][k] = 0;
                                changIndex[0] = s - xindex;
                                changIndex[1] = k - yindex;
                                // console.log(changIndex);
                                break;
                            }
                        }
                    }
                    return changIndex;
                };
                //重新排序
                var cards = deepCopy(beforeSrotCard);
                cards.sort(function (a, b) {
                    return a - b;
                });
                var afterCardList = mCard.getCardList(cards);

                this.nCards0.setPositionX(1280 * 0.5 - (7 + 1 / 2) * 0.5 * this.cardSize.w * this.cardScale);
                this.setupCardWithAnmi(afterCardList.length - beforeCardList.length);//发牌动画

                //居中手牌
                if (mRoom.getPlayerNum() == 3) {
                    this.nCards0.setPositionX(1280 * 0.5 - (afterCardList.length + 1 / 2) * 0.5 * this.cardSize.w * this.cardScale);
                } else {
                    this.nCards0.setPositionX(1280 * 0.5 - (afterCardList.length + 1 / 2) * 0.5 * this.cardSize.w * this.cardScale);
                }
                this.scheduleOnce(function () {
                    var cardList = this.nCards0.getChildren();
                    for (var i = 0; i < cardList.length; i++) {
                        var card = cardList[i];
                        var moveIndex = changeIndex(card.data, card.row, card.column);
                        card.runAction(cc.sequence(
                            cc.moveBy(0.2, cc.p(moveIndex[0] * (that.cardSize.w * that.cardScale - 2),
                                moveIndex[1] * (that.cardSize.h * that.cardScale - 15)))
                        ))
                    }
                }, 2); //3

                this.scheduleOnce(function () {
                    that.cardList = mCard.getCardList();
                    network.start();
                    that.enableChuPai();
                    that.setupCards();
                }, 2.2);//3.5
            }
        }

        if (this.diaoPaoSprite) {
            this.diaoPaoSprite.setVisible(false);
        }
    },


    getUserPosIndex: function (userId) {
        var users = DD[T.PlayerList];
        var pos = 0;
        if (mRoom.isReplay) {
            if (userId == gameData.uid) {
                pos = 0;
            } else if (users[this.pos1] != null && userId == users[this.pos1].ID) {
                pos = 1;
            } else if (users[this.pos2] != null && userId == users[this.pos2].ID) {
                pos = 2;
            } else if (users[this.pos3] != null && userId == users[this.pos3].ID) {
                pos = 3;
            }
        } else {
            if (userId == gameData.uid) {
                pos = 0;
            } else if (users[this.pos1] != null && userId == users[this.pos1].ID) {
                pos = 1;
            } else if (users[this.pos2] != null && userId == users[this.pos2].ID) {
                pos = 2;
            } else if (users[this.pos3] != null && userId == users[this.pos3].ID) {
                pos = 3;
            }
        }
        return pos;
    },

    setupPlayers: function () {
        if (mRoom.isReplay) {
            DD[T.PlayerList] = mRoom.replayData.users;
        }
        var data = DD[T.PlayerList];
        // console.log(data);
        if (data == null || data == undefined) {
            return;
        }
        var pos = 0;
        if (mRoom.isReplay == true) {
            for (var i = 0; i < data.length; i++) {
                if (data[i].ID == gameData.uid) {
                    pos = i;
                    break;
                }
            }
        } else {
            for (var i = 0; i < data.length; i++) {
                if (data[i].ID == gameData.uid) {
                    pos = i;
                    break;
                }
            }
        }
        this.pos0 = pos;
        this.pos1 = (pos + 1) % this.playersNum;
        this.pos2 = (pos + 2) % this.playersNum;
        this.pos3 = (pos + 3) % this.playersNum;
        if (mRoom.isReplay) {
            if (data.length > this.pos1) {
                this.txtUserName0.setString(ellipsisStr(data[this.pos0].NickName, 5));
                this.setPlayerAvator(0, decodeURIComponent(data[this.pos0].HeadIMGURL), data[this.pos0].ID);
                this.txtUserName0.setVisible(true);//打开显示名字
                this.txtHX0.setVisible(true);
            }
        }
        //报警  100以内  报警
        var needBaojing = false;
        // gameData.location = "0.1,0.1";
        for (var i = 0; i < data.length; i++) {
            // data[i]['Location'] = "0.1,0.1";
            if (data[i].ID != gameData.uid) {
                var pos = mRoom.getUserPosIndex(data[i].ID);
                // console.log(pos+"==="+data[i].NickName);
                this.addGpsTip(pos, data[i]['NickName'], data[i]['Location']);
            }
        }
        //任意两个人距离 <500 就报警
        for (var i = 0; i < data.length; i++) {
            for (var j = i + 1; j < data.length; j++) {
                var distance = this.getJuliByLoc(data[i]['Location'], data[j]['Location']);
                if (distance <= 500) {
                    needBaojing = true;
                    break;
                }
            }
        }
        var safebtn = getUI(this.safenode, "safebtn");
        safebtn.setVisible(needBaojing);

        for(var i=1;i<=3;i++){
            if(data.length > this['pos' + i]){
                this['txtUserName' + i].setString(ellipsisStr(data[this['pos' + i]].NickName, 5));
                this.setPlayerAvator(i, decodeURIComponent(data[this['pos' + i]].HeadIMGURL), data[this['pos' + i]].ID);
                this['txtUserName' + i].setVisible(true);//打开显示名字
                this['txtHX' + i].setVisible(true);

                this.addGpsTip(i, data[this['pos' + i]].NickName, data[this['pos' + i]]['Location']);
            }else{
                this['txtUserName' + i].setVisible(false);
                this['txtHX' + i].setVisible(false);
                this.setPlayerAvator(i, 'hide');
            }
        }



        if (mRoom.isReplay != true) {
            if (mRoom.ownner == gameData.uid.toString()) {
                //房主
                this.setInviteBtn();

                this.tuichu.setOpacity(50);
                TouchUtils.setClickDisable(this.tuichu, true);
                this.jiesan.setOpacity(255);
                TouchUtils.setClickDisable(this.jiesan, false);
            } else {
                this.setInviteBtn();

                this.tuichu.setOpacity(255);
                TouchUtils.setClickDisable(this.tuichu, false);
                this.jiesan.setOpacity(50);
                TouchUtils.setClickDisable(this.jiesan, true);
            }
        }
        if (window.inReview) {
            this.invite.setVisible(false);
            this.inviteXianLiao.setVisible(false);
            this.btn_inviteLiaobei.setVisible(false);
            // this.copyroom.setVisible(false);
        }
        if (data.length >= this.playersNum) {
            this.invite.setVisible(false);
            this.inviteXianLiao.setVisible(false);
            this.btn_inviteLiaobei.setVisible(false);

            this.tuichu.setOpacity(50);
            TouchUtils.setClickDisable(this.tuichu, true);
            this.jiesan.setOpacity(255);
            TouchUtils.setClickDisable(this.jiesan, false);

            this.txtNeedPlayer.setVisible(false);
            if (this.playersNum == 4) {
                mAction.leftCardCount = 23;
            } else {
                mAction.leftCardCount = 19;
            }
            if (mRoom.wanfatype == mRoom.WEIMAQUE) mAction.leftCardCount = 22;
            this.txtCardCount.setString(mAction.leftCardCount);
        }
        for (var i = 0; i < this.playersNum; i++) {
            if (data[this["pos" + i]]) {
                this.updateScore(i);
                this.getPlayerInfoLayer(i, data[this["pos" + i]]);
            }
        }
    },
    setInviteBtn: function(){
        if(getNativeVersion() >= "2.2.0") {
            this.invite.setVisible(true);
            this.inviteXianLiao.setVisible(true);
            this.btn_inviteLiaobei.setVisible(true);
        }else{
            this.invite.setVisible(true);
            this.invite.setPositionX(640);
            this.inviteXianLiao.setVisible(false);
            this.btn_inviteLiaobei.setVisible(false);
        }
    },
    getJuliByLoc: function (loc, loc2) {
        var distance = 100000;
        if (loc) {
            var templocation1 = loc.split(',');
            var otherpeoplelocationlat = 0;
            var otherpeoplelocationlng = 0;
            if (templocation1.length == 2) {
                otherpeoplelocationlat = templocation1[1];
                otherpeoplelocationlng = templocation1[0];
            }

            var mylocationlat = 0;
            var mylocationlng = 0;
            if (loc2) {
                var templocation2 = loc2.split(',');
                if (templocation2.length == 2) {
                    mylocationlat = templocation2[1];
                    mylocationlng = templocation2[0];
                }
            }
            distance = getFlatternDistance(mylocationlat, mylocationlng, otherpeoplelocationlat, otherpeoplelocationlng);
        }
        return distance;
    },
    setPlayerAvator: function (pos, url, uid) {
        //头像
        var info = getUI(this, "info" + pos);
        var headbg = getUI(this, "head" + pos);
        if (url == 'hide') {
            headbg.setVisible(false);
            info.setVisible(false);
            return;
        } else {
            headbg.setVisible(true);
            info.setVisible(true);
        }
        if (url == undefined || url == "" || url == null) {
            url = res.defaultHead;
        }
        var avator = headbg.getChildByName('head');
        avator.setLocalZOrder(-1);
        // avator.setScale(0.8);
        loadImageToSprite(url, avator);//头像
    },

    setupCardWithAnmi: function (movecha) {
        var that = this;
        this.nCards0.setVisible(true);
        this.nCards0.removeAllChildren();
        this.nCards0.setScale(1);

        var zOrderBak = this.cd.getLocalZOrder();
        // this.cd.setLocalZOrder(8888);

        // this.scheduleOnce(function(){
        //     that.cd.setLocalZOrder(zOrderBak)
        // }, 2);
        // console.log("movecha==="+movecha);

        var cardList = this.cardList;
        var distPosMap = [];
        var cardMap = [];
        for (var i = 0; i < 2; i++) {
            distPosMap[i] = [];
            cardMap[i] = [];
            for (var j = 0; j < cardList.length; j++) {
                var card = HUD.showLayer(HUD_LIST.Card, this.nCards0);
                card.setData(0, this, 0);
                card.setLocalZOrder(3 - i);
                card.setRowColumn(i, j);
                card.setScale(this.cardScale);
                distPosMap[i][j] = cc.p(j * (this.cardSize.w * this.cardScale - 2), i * (this.cardSize.h * this.cardScale - 30) - 90);
                var pos = _.clone(this.cd.getPosition());
                pos.x -= card.getParent().getPositionX();
                pos.y -= card.getParent().getPositionY();
                if (movecha == -1) {
                    pos.x += -30;
                } else if (movecha == 0) {
                    pos.x += 0;
                } else if (movecha == 1) {
                    pos.x += 30;
                } else if (movecha == 2) {
                    pos.x += 60;
                } else if (movecha == 3) {
                    pos.x += 90;
                } else if (movecha == 4) {
                    pos.x += 120;
                }
                card.setPosition(pos);
                card.setScale(0.2);
                card.setVisible(true);
                // card.setSelectedCard(that.actCard);
                cardMap[i][j] = card;

                var newCard = HUD.showLayer(HUD_LIST.Card, this.nCards0);
                newCard.setData(cardList[j][i], this);
                newCard.setLocalZOrder(3 - i);
                newCard.setRowColumn(i, j);
                newCard.setScale(this.cardScale);
                newCard.setPosition(distPosMap[i][j]);
                newCard.setVisible(false);
                // newCard.setSelectedCard(that.actCard);
                card.newCard = newCard;
            }
        }

        var duration = 0.2;
        for (var i = 0; i < 2; i++) {
            for (var j = 0; j < cardList.length; j++) {
                var card = cardMap[i][j];
                var delay = (i * cardList.length + j) * 0.1;  //0.15 20张牌时间为3S ruru
                card.isLast = i == 1 && j == cardList.length - 1;
                card.runAction(
                    cc.sequence(
                        cc.delayTime(delay),
                        cc.spawn(
                            cc.scaleTo(duration / 2, this.cardScale),
                            cc.moveTo(duration, distPosMap[i][j])
                        ),
                        cc.callFunc(function () {
                            var posBak = _.clone(this.getPosition());
                            this.setPosition(cc.p(posBak.x + this.getBoundingBox().width / 2, posBak.y));
                            this.setAnchorPoint(0.5, 0);
                            this.newCard.setAnchorPoint(0.5, 0);
                            this.newCard.setPosition(cc.p(posBak.x + this.getBoundingBox().width / 2, posBak.y));
                            this.posBak = posBak;
                        }, card),
                        cc.sequence(cc.show(), cc.orbitCamera(duration * 0.5, 1, 0, 0, -90, 0, 0), cc.hide(), cc.callFunc(function () {
                            this.newCard.runAction(cc.sequence(cc.show(), cc.orbitCamera(duration * 0.5, 1, 0, 90, -90, 0, 0), cc.callFunc(function () {
                                this.setAnchorPoint(0, 0);
                                this.newCard.setAnchorPoint(0, 0);
                                this.setPosition(this.posBak);
                                this.newCard.setPosition(this.posBak);
                                that.nCards0.removeChild(this, true);
                                delete this.posBak;
                                delete this.newCard;
                                delete this.isLast;
                            }, this)))
                        }, card))
                    )
                );
            }
        }

        playEffect('gan');
    },
    setupCards: function () {
        //var cards = DD[T.CardList];
        this.nCards0.setVisible(true);
        this.nCards0.removeAllChildren();
        this.nCards0.setScale(1);

        var cardList = _.clone(this.cardList, true);
        for (var i = 0; i < cardList.length; i++) {
            var cards = cardList[i];
            var isKan = false;
            var isGray = false;
            //坎 不能移动
            if (cards.length == 3 && cards[0] == cards[1] && cards[1] == cards[2]) {
                isKan = true;
                if (mRoom.wanfatype == mRoom.WEIMAQUE) {
                    isKan = false;
                    isGray = true;
                }
            }
            for (var j = cards.length - 1; j >= 0; j--) {
                var card = HUD.showLayer(HUD_LIST.Card, this.nCards0);
                card.setData(cards[j], this);
                card.setRowColumn(j, i);
                if (isKan == false) {
                    // card.setSelectedCard(this.actCard);
                }
                card.setLocalZOrder(3 - j);
                if (isGray) card.setGreenCard(isGray);
                card.setScale(this.cardScale);
                card.setPosition(i * (this.cardSize.w * this.cardScale - 2), j * (this.cardSize.h * this.cardScale - 30) - 90);
                var tag = (i + 1) * 100 + j + 1;
                card.setTag(tag);
            }
        }

        //冻结
        this.setFreezeCard(this.Freeze);

        //居中手牌
        if (mRoom.getPlayerNum() == 3) {
            this.nCards0.setPositionX(1280 * 0.5 - (cardList.length + 1 / 2) * 0.5 * this.cardSize.w * this.cardScale + 40);
        } else {
            this.nCards0.setPositionX(1280 * 0.5 - (cardList.length + 1 / 2) * 0.5 * this.cardSize.w * this.cardScale + 40);
        }
        return;

        // 居中手牌
        // var cardSpriteList = this.nCards0.getChildren();
        // var cardSpriteListClone = cardSpriteList.concat();
        // var moveCard = function (cardArr, x) {
        //     var y = 0;
        //     while (cardArr.length > 0) {
        //         var cardIdx = _.findLastIndex(cardSpriteListClone, function (card) {
        //             return card.data == cardArr[0];
        //         });
        //         if (cardIdx < 0)
        //             return;
        //         var card = cardSpriteListClone.splice(cardIdx, 1)[0];
        //         card.setPosition(x, y - 90);
        //         card.setLocalZOrder(3 - card.row);
        //         // console.log(card.data + '  ' + card.row);
        //         y += (this.cardSize.h * this.cardScale - 25);
        //         cardArr.shift();
        //     }
        // };
        // var x = (cc.winSize.width - (cardList.length - (cardList.length % 2 == 1 ? 0 : 1)) * (this.cardSize.w * this.cardScale - 2)) / 2;
        // var t = (this.cardSize.w * this.cardScale - 2);
        // cardList.length == 1 && (x -= 3.5*t);
        // cardList.length == 2 && (x -= 3*t);
        // cardList.length == 3 && (x -= 2.5*t);
        // cardList.length == 4 && (x -= 2*t);
        // cardList.length == 5 && (x -= 1.5*t);
        // cardList.length == 6 && (x -= t);
        // cardList.length == 7 && (x -= t / 2);
        // cardList.length == 8;
        // cardList.length == 9 && (x += t / 2);
        // cardList.length == 10 && (x += t);
        //
        // // if (cardList.length % 2 == 1)
        // //     x -= (this.cardSize.w * this.cardScale - 2) / 2;
        // var xa = x;
        // var xb = x;
        // moveCard.call(this, cardList[Math.floor(cardList.length / 2)], x);
        // for (var j = Math.floor(cardList.length / 2) - 1; j >= 0; j--) {
        //     xa -= (this.cardSize.w * this.cardScale - 2);
        //     moveCard.call(this, cardList[j], xa);
        // }
        // for (var j = Math.floor(cardList.length / 2) + 1; j < cardList.length; j++) {
        //     xb += (this.cardSize.w * this.cardScale - 2);
        //     moveCard.call(this,cardList[j], xb);
        // }
    },
    setupOtherCards: function (id) {
        //亮牌数据
        this["nCards" + id].setVisible(true);
        this["nCards" + id].removeAllChildren();
        this["nCards" + id].setScale(0.3);
        var cardList = this["cardList" + id];
        if (cardList == undefined || cardList == null) {
            return;
        }
        for (var i = 0; i < cardList.length; i++) {
            var cards = cardList[i];
            var isKan = false;
            //坎 不能移动
            if (cards.length == 3 && cards[0] == cards[1] && cards[1] == cards[2]) {
                isKan = true;
            }
            for (var j = cards.length - 1; j >= 0; j--) {
                var card = HUD.showLayer(HUD_LIST.Card, this["nCards" + id]);
                card.setData(cards[j], this);
                if (isKan == false) {
                    // card.setSelectedCard(this.actCard);
                }
                card.setTouchEnableStatus(false);
                card.setPosition(i * this.cardSize.w - Math.floor(cardList.length / 2) * this.cardSize.w, j * this.cardSize.h - 80);
                var tag = (i + 1) * 100 + j + 1;
                card.setTag(tag);
            }
        }
    },

    addNewColCard: function (i, card, row, col) {
        var cardList = this.cardList;
        var addCol = 0;
        var sCards = cardList[col];

        if (i <= col) {
            addCol = 1;
        }
        if (sCards.length > 1 && cardList.length >= 10) {
            return false;
        }

        cardList.splice(i, 0, [card.data]);
        sCards.splice(row, 1);
        if (sCards.length == 0) {
            cardList.splice(col + addCol, 1);
        }
        return true;
    },
    setSameCardShow: function (showcard, isshow) {
        // for(var i=0;i<this.playersNum;i++){
        //     var open = this["open" + i];
        //     var openChileren = open.getChildren();
        //     for(var j=0;j<openChileren.length;j++){
        //         var card = openChileren[j];
        //         if (card.cardType == mCard.comboTypes.wei || card.cardType == mCard.comboTypes.ti)
        //             continue;
        //
        //         if(card.data == showcard) {
        //             card.setGreenCard(isshow);
        //         }
        //     }
        //     var out = this["out" + i];
        //     var outChileren = out.getChildren();
        //     for(var j=0;j<outChileren.length;j++){
        //         var card = outChileren[j];
        //         if(card.data == showcard) {
        //             card.setGreenCard(isshow);
        //         }
        //     }
        // }
        if (this.isTurnOut)
            this.tipLine.setVisible(isshow);
    },
    //出牌
    enableChuPai: function () {
        var that = this;
        var touchLayer = this.getChildByName("touchLayer");
        if (touchLayer)  return;

        touchLayer = new cc.LayerColor(cc.color(0, 0, 0, 0), cc.winSize.width, 400);
        touchLayer.setName("touchLayer");
        touchLayer.setAnchorPoint(0, 0);
        this.addChild(touchLayer);


        var movecard = null;
        var positionBak = null;
        var zorderBak = null;
        var chupaiListener = cc.EventListener.create({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function (touch, event) {
                var cardSprites = that.nCards0.getChildren();
                for (var i = 0; i < cardSprites.length; i++) {
                    if (TouchUtils.isTouchMe(cardSprites[i], touch, event, null)) {
                        movecard = cardSprites[i];
                        zorderBak = movecard.getLocalZOrder();
                        positionBak = movecard.getPosition();
                        movecard.setLocalZOrder(5);

                        that.setSameCardShow(movecard.data, true);//选中相同颜色的
                        return true;
                    }
                }
                return false;
            },
            onTouchMoved: function (touch, event) {
                if (movecard) {
                    var p = touch.getLocation();
                    p = movecard.convertToNodeSpace(touch.getLocation());
                    p.x += movecard.getPositionX() - movecard.getBoundingBox().width / 2;
                    p.y += movecard.getPositionY() - movecard.getBoundingBox().height / 2;
                    movecard.setPosition(p);
                    // console.log(movecard.getPositionY());
                }
            },
            onTouchEnded: function (touch, event) {
                if (movecard) {
                    that.setSameCardShow(movecard.data, false);//选中相同颜色的
                    var isMove = false;
                    var movexy = {x: movecard.column, y: movecard.row};
                    var movetoxy = null;

                    if (movecard.getPositionY() >= 200) {
                        if (that.isTurnOut == true) {

                            that.userShowCard(movecard.data, false, movecard.row, movecard.column);
                            return;
                        }
                    }

                    //先判断是不是移动到最左边  或者最右边  数组需要新建一列
                    var firsrCard = that.nCards0.getChildByTag(101);
                    var lastCard = that.nCards0.getChildByTag(that.cardList.length * 100 + 1);
                    if (firsrCard && that.cardList.length < 10 &&
                        (movecard.getPositionX() + movecard.getBoundingBox().width / 2) < firsrCard.getPositionX()) {
                        //移到最左边
                        isMove = true;
                        movetoxy = {x: 0, add: "left"};
                        // console.log("移到最左边");
                    }
                    if (isMove == false && lastCard && that.cardList.length < 10 &&
                        (movecard.getPositionX() + movecard.getBoundingBox().width / 2) > lastCard.getPositionX() + lastCard.getBoundingBox().width) {
                        //移到最右边
                        isMove = true;
                        movetoxy = {x: that.cardList.length, add: "right"};
                        // console.log("移到最右边");
                    }
                    if (isMove == false) {
                        var cardSprites = that.nCards0.getChildren();
                        for (var i = 0; i < cardSprites.length; i++) {
                            var cardi = cardSprites[i];
                            var moveCardMidX = movecard.getPositionX() + movecard.getBoundingBox().width / 2;
                            var moveCardMidY = movecard.getPositionY() + movecard.getBoundingBox().height / 2;
                            var cardiL = cardi.getPositionX() + cardi.getBoundingBox().width * 0.1;
                            var cardiL2 = cardi.getPositionX() - cardi.getBoundingBox().width * 0.1;
                            var cardiR = cardi.getPositionX() + cardi.getBoundingBox().width * 0.9;
                            var cardiT = cardi.getPositionY() + cardi.getBoundingBox().height * 0.9;
                            var cardiD = cardi.getPositionY() + cardi.getBoundingBox().height * 0.1;
                            var cardiD2 = cardi.getPositionY() - cardi.getBoundingBox().height * 0.1;
                            // console.log("movecard==="+movecard.column+"=="+movecard.row+"==="+moveCardMidX);
                            // console.log(cardi.getPositionX());
                            // console.log(cardi.column+"=="+cardi.row+"=="+cardiL+"==="+cardiR);
                            // console.log(cardi.column+"=="+cardi.row+"=="+ (cardiL));
                            if (movecard.column == cardi.column && movecard.row == cardi.row) {
                            } else {
                                // console.log("movecardY==="+movecard.column+"=="+movecard.row+"==="+moveCardMidY);
                                // console.log(cardi.getPositionY());
                                // console.log(cardi.column+"=="+cardi.row+"=="+cardiT+"==="+cardiD);
                                // console.log(cardi.column+"=="+cardi.row+"=="+ (cardiD2));
                                if (moveCardMidX >= cardiL && moveCardMidX <= cardiR) {
                                    var cardColunmTopRow = null;
                                    for (var s = 3; s >= 0; s--) {
                                        if (that.nCards0.getChildByTag(((cardi.column + 1) * 100) + s)) {
                                            cardColunmTopRow = that.nCards0.getChildByTag(((cardi.column + 1) * 100) + s);
                                            break;
                                        }
                                    }
                                    isMove = true;
                                    if (moveCardMidY >= cardiD && moveCardMidY <= cardiT) {
                                        movetoxy = {x: cardi.column, y: cardi.row};
                                        break;
                                    } else if (moveCardMidY <= cardiD && moveCardMidY >= cardiD2) {
                                        movetoxy = {x: cardi.column, y: cardi.row};
                                        break;
                                    } else if (cardColunmTopRow && that.cardList[cardi.column].length < 4 &&
                                        moveCardMidY >= (cardColunmTopRow.getPositionY() + cardColunmTopRow.getBoundingBox().height)) {
                                        movetoxy = {x: cardi.column, y: that.cardList[cardi.column].length};
                                        break;
                                    }
                                } else if (cardi.column > 0 && moveCardMidX <= cardiL && moveCardMidX >= cardiL2) {
                                    //之前 中间增加一列
                                    movetoxy = {x: cardi.column, add: "mid"};
                                    isMove = true;
                                    break;
                                }
                            }
                        }
                    }
                    //如果不是相同列移动， 移到能够到得列数量大于4，则不移动
                    if (movetoxy && movetoxy.x != movexy.x && that.cardList[movetoxy.x] &&
                        that.cardList[movetoxy.x].length >= 3) {
                        isMove = false;
                    }
                    if (movetoxy && movetoxy.add && that.cardList.length >= 10) {
                        isMove = false;
                    }
                    if (isMove == false) {
                        movecard.setPosition(positionBak);
                    } else {
                        // console.log(movetoxy);
                        if (movetoxy) {
                            var tmp = that.cardList[movexy.x][movexy.y];
                            if (movetoxy.x == 0 && movetoxy.add) {
                                //移动到第一列
                                if (that.cardList[movexy.x].length == 1) {
                                    that.cardList[movexy.x].splice(movexy.y, 1);
                                    for (var i = movexy.x; i > 0; i--) {
                                        that.cardList[i] = that.cardList[i - 1];
                                    }
                                    that.cardList[0] = [];
                                    that.cardList[0].push(tmp);
                                } else {
                                    that.cardList[movexy.x].splice(movexy.y, 1);
                                    for (var i = that.cardList.length - 1; i >= 0; i--) {
                                        that.cardList[i + 1] = that.cardList[i];
                                    }
                                    that.cardList[0] = [];
                                    that.cardList[0].push(tmp);
                                }
                            } else if (movetoxy.x == that.cardList.length && movetoxy.add) {
                                //移动到最后一列
                                if (that.cardList[movexy.x].length == 1) {
                                    that.cardList[movexy.x].splice(movexy.y, 1);
                                    for (var i = movexy.x; i < that.cardList.length - 1; i++) {
                                        that.cardList[i] = that.cardList[i + 1];
                                    }
                                    that.cardList[that.cardList.length - 1] = [];
                                    that.cardList[that.cardList.length - 1].push(tmp);
                                } else {
                                    that.cardList[movexy.x].splice(movexy.y, 1);
                                    var addNum = that.cardList.length;
                                    that.cardList[addNum] = [];
                                    that.cardList[addNum].push(tmp);
                                }
                            } else {
                                if (movetoxy.x && movetoxy.y == undefined) {
                                    //中间增加一列
                                    that.cardList[movexy.x].splice(movexy.y, 1);
                                    for (var i = that.cardList.length - 1; i >= movetoxy.x; i--) {
                                        that.cardList[i + 1] = that.cardList[i];
                                    }
                                    that.cardList[movetoxy.x] = [];
                                    that.cardList[movetoxy.x].push(tmp);
                                } else {
                                    if (movetoxy.x == movexy.x) {
                                        //当前列交换数据
                                        that.cardList[movexy.x][movexy.y] = that.cardList[movetoxy.x][movetoxy.y];
                                        that.cardList[movetoxy.x][movetoxy.y] = tmp;
                                        // console.log(that.cardList[movetoxy.x]);
                                    } else {
                                        that.cardList[movexy.x].splice(movexy.y, 1);
                                        //y 所有的网上移动
                                        for (var s = that.cardList[movetoxy.x].length - 1; s >= movetoxy.y; s--) {
                                            that.cardList[movetoxy.x][s + 1] = that.cardList[movetoxy.x][s];
                                        }
                                        that.cardList[movetoxy.x][movetoxy.y] = tmp;
                                        if (that.cardList[movexy.x].length == 0) {
                                            that.cardList.splice(movexy.x, 1);
                                        }
                                    }
                                    //移除空的项
                                    if (that.cardList[movetoxy.x] && that.cardList[movetoxy.x].length > 0) {
                                        for (var j = that.cardList[movetoxy.x].length - 1; j >= 0; j--) {
                                            if (that.cardList[movetoxy.x][j] == undefined) {
                                                that.cardList[movetoxy.x].splice(j, 1);
                                            }
                                        }
                                    }
                                }
                            }
                            //移除空的项
                            for (var i = that.cardList.length - 1; i >= 0; i--) {
                                if (that.cardList[i] == undefined || (that.cardList[i] && that.cardList[i].length == 0)) {
                                    that.cardList.splice(i, 1);
                                }
                            }
                            // console.log(that.cardList);
                            that.setupCards();
                        } else {
                            movecard.setPosition(positionBak);
                        }
                    }
                    movecard.setLocalZOrder(zorderBak || 0);

                    // console.log(zorderBak);
                    zorderBak = null;
                    movetoxy = null;
                    movecard = null;
                    positionBak = null;
                }
            }
        });
        return cc.eventManager.addListener(chupaiListener, touchLayer);
    },
    moveCard: function (card, px, py) {
        var cardList = this.cardList;
        var tag = card.getTag();
        var col = parseInt(tag / 100) - 1;
        var row = tag % 100 - 1;
        var offset = this.nCards0.getPositionX() - 10;

        var isMoved = false;
        var cardscale = 1;
        var cardWidth = this.cardSize.w * this.cardScale;
        var cardL = cardWidth * 0.4;
        var cardR = cardWidth * 0.6;
        for (var i = 0; i < cardList.length; i++) {
            var canMove = true;
            var cards = cardList[i];
            if (cardList[i].length == 3 && cardList[i][0] == cardList[i][1] && cardList[i][0] == cardList[i][2]) {
                canMove = false;
            }
            var tCard = this.nCards0.getChildByTag((i + 1) * 100 + 1);
            if (tCard != null && i != col && canMove) {
                var cx = cardWidth * cardscale * i + offset;
                var dis = px - cx;
                if (dis < -cardL * cardscale && i == 0) {
                    isMoved = this.addNewColCard(i, card, row, col);
                    break;
                } else if (dis > cardL * cardscale && i == cardList.length - 1) {
                    isMoved = this.addNewColCard(i + 1, card, row, col);
                    break;
                } else if (dis >= -cardL * cardscale && dis <= cardL * cardscale) {
                    if (cards.length < 3) {
                        cards.push(card.data);
                        var sCards = cardList[col];
                        sCards.splice(row, 1);
                        if (sCards.length == 0) {
                            cardList.splice(col, 1);
                        }
                        isMoved = true;
                    }
                    break;
                } else if (dis > cardL * cardscale && dis < cardR * cardscale) {
                    isMoved = this.addNewColCard(i + 1, card, row, col);
                    break;
                }
            }
            if (tCard != null && canMove) {
                //移动 y 的
                var cx = cardWidth * cardscale * i + offset;
                var dis = px - cx;
                if (dis >= -cardL * cardscale && dis <= cardL * cardscale) {
                    for (var j = 0; j < cards.length; j++) {
                        if (py >= 88 / 2 && py >= 88 * (j - 1 / 2) && py <= 88 * (j + 1 / 2)) {
                            if (cards[card.row] && cards[j]) {
                                if (card.row > j) {
                                    var tmp = cards[j];
                                    for (var s = j; s < card.row; s++) {
                                        cards[s] = cards[s + 1];
                                    }
                                    cards[card.row] = tmp;
                                    isMoved = true;
                                } else if (card.row < j) {
                                    var tmp = cards[card.row];
                                    for (var s = card.row; s < j; s++) {
                                        cards[s] = cards[s + 1];
                                    }
                                    cards[j] = tmp;
                                    isMoved = true;
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (isMoved == true)
            this.setupCards();
    },

    removeCardInList: function (card, userPos, outCardColumn, outCardRow) {
        var cardList = userPos == 0 ? this.cardList : this["cardList" + userPos];
        if (cardList == undefined || cardList == null) {
            return;
        }
        if (outCardColumn && outCardRow) {
            for (var i = cardList.length - 1; i >= 0; i--) {
                var cards = cardList[i];
                for (var j = cards.length - 1; j >= 0; j--) {
                    if (i == (outCardColumn - 1) && j == (outCardRow - 1) && card == cards[j]) {
                        cards.splice(j, 1);
                        if (cards.length == 0) {
                            cardList.splice(i, 1);
                        }
                        return;
                    }
                }
            }
        }
        for (var i = cardList.length - 1; i >= 0; i--) {
            var cards = cardList[i];
            for (var j = cards.length - 1; j >= 0; j--) {
                if (cards[j] == card) {
                    cards.splice(j, 1);
                    if (cards.length == 0) {
                        cardList.splice(i, 1);
                    }
                    return;
                }
            }
        }
    },

    removeCards: function (cardsToRemove, userPos, outCardColumn, outCardRow) {
        var cards = userPos == 0 ? DD[T.CardList] : DD[T["CardList" + userPos]];
        for (var i = 0; i < cardsToRemove.length; i++) {
            var deleteList = [];
            for (var j = cards.length - 1; j >= 0; j--) {
                if (cards[j] == cardsToRemove[i]) {
                    deleteList.push([j]);
                    break;
                }
            }
            removeInArray(cards, deleteList);
        }
        if (cardsToRemove && cardsToRemove.length == 1 && outCardColumn && outCardRow) {
            this.removeCardInList(cardsToRemove[0], userPos, outCardColumn, outCardRow);
        } else {
            for (var i = 0; i < cardsToRemove.length; i++) {
                this.removeCardInList(cardsToRemove[i], userPos);
            }
        }

        if (userPos == 0) {
            this.setupCards();
        } else {
            this.setupOtherCards(userPos);
        }
    },

    addCard: function (cardToAdd) {
        var cards = DD[T.CardList];
        cards.push(cardToAdd);
        cards.sort(function (a, b) {
            return a - b;
        });

        //cards = cards.concat([cardToAdd]);
        var isAdd = false;
        for (var i = 0; i < this.cardList.length; i++) {
            var cards = this.cardList[i];
            if ((cards.length == 1 && cards[0] == cardToAdd) || (cards.length == 2 && cards[0] == cardToAdd && cards[1] == cardToAdd)) {
                cards.push(cardToAdd);
                isAdd = true;
                break;
            }
        }
        if (isAdd == false) {
            this.cardList.push([cardToAdd]);
        }
        this.setupCards();
    },

    onBack: function (sender, type) {
        if (this.isStart == false) {
            mRoom.quitRoom(this);
        }
        else {
            network.wsData("Vote/quit/1/0/0");
        }
    },

    onGameVote: function (event) {                  //出牌
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        if (mRoom.isPause != true) {
            // var vote = HUD.showLayer(HUD_LIST.RoomQuit, HUD.getTipLayer(), null, true);
            // vote.setData(data.Content, true, this);
            var vote = new RoomQuit();
            vote.setName("RoomQuit");
            this.addChild(vote);
            vote.setLocalZOrder(3);
            vote.setData(data.Content, true, this);
        }
    },

    onVoice: function (event) {
        //语音
        var data = event.getUserData();
        var respJson = JSON.parse(data.Msg);
        var uid = respJson['from'];
        var type = respJson['type'];
        var voice = respJson['voice'];
        var content = respJson['content'];
        //row
        var row = mRoom.getUserPosIndex(uid);
        this.showChat(row, type, content, voice, uid);
    },
    //开启或者关闭位置共享
    openLocation: function (value) {
        var msg = JSON.stringify({
            roomid: mRoom.roomId,
            type: 'location',
            voice: '',
            content: value,
            from: gameData.uid
        });
        network.wsData("Say/" + msg);
    },
    //跑马灯
    onMaDeng: function (event) {
        var that = this;
        var data = event.getUserData();

        var interval = null;
        if (data && (data.Content == "" || data.Content == null)) {
            return;
        }
        var func = function () {
            if (!that || !cc.sys.isObjectValid(that)) {
                if (interval) {
                    clearInterval(interval);
                    interval = null;
                }
                return;
            }
            var content = data.Content;
            that.pmdContent = content;
            gameData.pmdContent = content;
            var speaker = getUI(that, 'speaker');
            speaker.setVisible(true);
            speaker.setLocalZOrder(100);
            var speakerPanel = getUI(that, 'speakerpanel');
            speaker.runAction(cc.fadeIn(0.2));
            var text = new ccui.Text();
            text.setFontSize(26);
            text.setColor(cc.color(254, 245, 92));
            text.setAnchorPoint(cc.p(0, 0));
            text.enableOutline(cc.color(0, 0, 0), 1);
            speakerPanel.removeAllChildren();
            speakerPanel.addChild(text);
            text.setString(content);
            text.setPositionX(speakerPanel.getContentSize().width);
            text.setPositionY(5);
            text.runAction(cc.sequence(
                cc.delayTime(0.2),
                cc.moveTo((content.length * 0.3 <= 10) ? 10 : content.length * 0.3, -text.getVirtualRendererSize().width, 5),
                cc.delayTime(0.3),
                cc.callFunc(function () {
                    speaker.runAction(cc.fadeOut(0.2))
                })
            ));
        };
        func();
        var t = (that.pmdContent.length * 0.3 <= 30) ? 30 : (that.pmdContent.length * 0.3 + 5);
        interval = setInterval(func, t * 1000);
    },
    playUrlVoice: function (row, type, content, voice, uid) {
        var url = decodeURIComponent(content);
        var arr = null;
        if (url.indexOf('.aac') >= 0) {
            arr = url.split(/\.aac/)[0].split(/-/);
        } else if (url.indexOf('.spx') >= 0) {
            arr = url.split(/\.spx/)[0].split(/-/);
            // playVoiceByUrl(url);
        }
        mRoom.voiceMap[uid] = null;
        mRoom.voiceMap[uid] = url;
        var duration = arr[arr.length - 1] / 1000;
        window.soundQueue = window.soundQueue || [];
        window.soundQueue.push({url: url, duration: duration, row: row});
        if (window.soundQueue.length > 1) {
        } else {
            this.playVoiceQueue();
        }
    },
    playVoiceQueue: function () {
        var that = this;
        var queue = window.soundQueue[0];
        if (queue && queue.url && queue.duration && _.isNumber(queue.row)) {
            if (queue.url.indexOf('.aac') >= 0) {
                VoiceUtils.play(queue.url);
            } else if (queue.url.indexOf('.spx') >= 0) {
                OldVoiceUtils.playVoiceByUrl(queue.url);
            }
            var scale9sprite = this.initQP(queue.row);
            scale9sprite.setContentSize(this.posConf.ltqpEmojiSize[queue.row]);
            var innerNodes = this.initSpeaker(queue.row, scale9sprite);
            this.qpAction(innerNodes, scale9sprite, queue.duration);
            //关闭背景音域
            if (!_.isUndefined(window.musicID)) {
                jsb.AudioEngine.pause(window.musicID);
            }
            setTimeout(function () {
                window.soundQueue.shift();
                that.playVoiceQueue();
                //开启背景音乐
                if (!_.isUndefined(window.musicID)) {
                    jsb.AudioEngine.resume(window.musicID);
                }
            }, queue.duration * 1000);
        }
    },
    initQP: function (row) {
        //row转换
        var rowChange = row;
        if (row == 0) {
            rowChange = 2;
        } else if (row == 2) {
            rowChange = 0;
        }

        var that = this;
        var head = getUI(this, "head" + row);
        var scale9sprite = head.getChildByName('qp9');
        var qprow = head.getChildByName('qp' + row);
        if (!scale9sprite) {
            if (mRoom.getPlayerNum() == 3) {
                scale9sprite = new cc.Scale9Sprite(res["phzltqp" + rowChange + "_png"], this.posConf.ltqpRect[rowChange],
                    that.posConf.ltqpCapInsets[rowChange]);
                scale9sprite.setAnchorPoint(row == 1 ? cc.p(1, 0) : cc.p(0, 0));
            } else {
                scale9sprite = new cc.Scale9Sprite(res["phzltqp" + rowChange + "_png"], this.posConf.ltqpRect[rowChange],
                    this.posConf.ltqpCapInsets[rowChange]);
                scale9sprite.setAnchorPoint((row == 0 || row == 2 || row == 3) ? cc.p(0, 0) : cc.p(1, 0));
            }
            scale9sprite.setName('qp9');
            scale9sprite.setPosition(cc.p(qprow.getPosition().x, qprow.getPosition().y - 30));
            head.addChild(scale9sprite);
        }

        for (var i = (cc.sys.isNative ? 0 : 1); i < scale9sprite.getChildren().length; i++)
            scale9sprite.getChildren()[i].setVisible(false);
        return scale9sprite;
    },
    initSpeaker: function (row, scale9sprite) {
        var map = {};
        var innerNodes = [];
        for (var i = 1; i <= 3; i++) {
            var sp = getUI(scale9sprite, 'speaker' + i);
            if (!sp) {
                sp = new cc.Sprite(res['phzspeaker' + i + '_png']);
                sp.setName('speaker' + i);
                sp.setPosition(this.posConf.ltqpVoicePos[row]);
                scale9sprite.addChild(sp);
            }
            map[i] = sp;
            map[i].setVisible(true);
            innerNodes.push(map[i]);
        }
        map[2].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.25), cc.fadeIn(0.25)).repeatForever());
        map[3].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.50), cc.fadeIn(0.50)).repeatForever());
        return innerNodes;
    },
    qpAction: function (innerNodes, scale9sprite, duration) {
        scale9sprite.stopAllActions();
        scale9sprite.setVisible(true);
        scale9sprite.setOpacity(255);
        scale9sprite.setScale(1.6, 1.6);
        scale9sprite.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5), cc.callFunc(function () {
            for (var i = 0; i < innerNodes.length; i++)
                innerNodes[i].setVisible(false);
        })));
    },
    showChat: function (row, type, content, voice, uid) {
        if (uid == gameData.uid && (type == 'user_back' || type == 'user_leave')) {
            return;
        }
        //回放不播放语音聊天
        if (mRoom.isReplay == true) {
            return;
        }

        if (type == 'voice') {
            var url = decodeURIComponent(content);
            if (url && url.split(/\.spx/).length > 2){
                return;
            }
        }

        if (type == 'voice') {
            this.playUrlVoice(row, type, content, voice, uid);
            return;
        }

        //row转换
        var rowChange = row;
        if (row == 0) {
            rowChange = 2;
        } else if (row == 2) {
            rowChange = 0;
        }

        var that = this;
        var head = getUI(this, "head" + row);
        var scale9sprite = head.getChildByName('qp9');
        var qprow = head.getChildByName('qp' + row);
        if (!scale9sprite) {
            if (mRoom.getPlayerNum() == 3) {
                scale9sprite = new cc.Scale9Sprite(res["phzltqp" + rowChange + "_png"], this.posConf.ltqpRect[rowChange],
                    that.posConf.ltqpCapInsets[rowChange]);
                scale9sprite.setAnchorPoint(row == 1 ? cc.p(1, 0) : cc.p(0, 0));
            } else {
                scale9sprite = new cc.Scale9Sprite(res["phzltqp" + rowChange + "_png"], this.posConf.ltqpRect[rowChange],
                    this.posConf.ltqpCapInsets[rowChange]);
                scale9sprite.setAnchorPoint((row == 0 || row == 2 || row == 3) ? cc.p(0, 0) : cc.p(1, 0));
            }
            scale9sprite.setName('qp9');
            scale9sprite.setPosition(cc.p(qprow.getPosition().x, qprow.getPosition().y - 30));
            head.addChild(scale9sprite);
        }

        for (var i = (cc.sys.isNative ? 0 : 1); i < scale9sprite.getChildren().length; i++)
            scale9sprite.getChildren()[i].setVisible(false);

        var duration = 4;
        var innerNodes = [];
        if (type == 'emoji') {
            scale9sprite.setContentSize(this.posConf.ltqpEmojiSize[rowChange]);
            // var sprite = getUI(head, "emoji");
            // if (!sprite) {
            //     sprite = new cc.Sprite();
            //     sprite.setName('emoji');
            //     sprite.setPosition(cc.p(qprow.getPosition().x, qprow.getPosition().y));
            //     head.addChild(sprite);
            // }
            // sprite.setScale(2);
            // scale9sprite.setVisible(false);
            // setSpriteFrameByName(sprite, content, 'chat/emoji');
            // sprite.setVisible(true);
            // innerNodes.push(sprite);
            //表情动画
            var index = content.substring(10, 11);
            var ccsScene = ccs.load(res['expression' + index], "res/");
            var express = ccsScene.node;
            express.setName("express");
            var posx = (row == 1) ? -30:20;
            var posy = (row == 2) ? -30:20;
            express.setPosition(cc.p(head.getContentSize().width/2 + posx, head.getContentSize().height / 2 + posy));
            head.addChild(express);
            express.runAction(ccsScene.action);
            ccsScene.action.play('action', true);
            this.scheduleOnce(function(){
                express.removeFromParent();
            }, 2);
        }
        else if (type == 'text' || type == 'user_leave' || type == 'user_back') {
            var text = getUI(scale9sprite, "text");
            if (!text) {
                text = new ccui.Text();
                text.setName('text');
                text.setFontSize(22);
                text.setTextColor(cc.color(0, 0, 0));
                text.setAnchorPoint(0, 0);
                // text.enableOutline(cc.color(255, 255, 255), 1);
                scale9sprite.addChild(text);
            }
            text.setString(content);
            var size = cc.size(text.getVirtualRendererSize().width + this.posConf.ltqpRect[rowChange].width,
                this.posConf.ltqpRect[rowChange].height);
            text.setPosition(
                (size.width - text.getVirtualRendererSize().width) / 2 + this.posConf.ltqpTextDelta[rowChange].x,
                (size.height - text.getVirtualRendererSize().height) / 2 + this.posConf.ltqpTextDelta[rowChange].y
            );
            scale9sprite.setContentSize(size);
            text.setVisible(true);
            innerNodes.push(text);
            if (type == 'user_leave') {
                //用户切home
                this.setDisconnect(uid, true);
            } else if (type == 'user_back') {
                this.setDisconnect(uid, false);
            }
        } else if (type == 'voice') {
            var url = decodeURIComponent(content);
            // playVoiceByUrl(url);
            VoiceUtils.play(url);

            scale9sprite.setContentSize(this.posConf.ltqpEmojiSize[rowChange]);
            var map = {};
            for (var i = 1; i <= 3; i++) {
                var sp = scale9sprite.getChildByName('speaker' + i);
                if (!sp) {
                    sp = new cc.Sprite(res['phzspeaker' + i + '_png']);
                    sp.setName('speaker' + i);
                    sp.setPosition(that.posConf.ltqpVoicePos[rowChange]);
                    scale9sprite.addChild(sp);
                }
                map[i] = sp;
                map[i].setVisible(true);
                innerNodes.push(map[i]);
            }
            map[2].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.25), cc.fadeIn(0.25)).repeatForever());
            map[3].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.50), cc.fadeIn(0.50)).repeatForever());
        } else if (type == "location") {
            //位置共享
            var players = DD[T.PlayerList];
            for (var i = 0; i < players.length; i++) {
                if (players[i].ID == uid) {
                }
            }
        } else if (type == "effectemoji") {
            // cc.eventManager.dispatchCustomEvent(P.GS_BIAOQING,  JSON.parse(content));
            var data = JSON.parse(content);
            //ruru 根据返回的内容播放动画
            var delaytimeList = [1, 1.6, 1, 0.4, 1];
            that.scheduleOnce(function(){
                playEffect("itr_biaoqing" + data.emoji_idx);
            }, delaytimeList[data.emoji_idx - 1]);
            this.addEffectEmojiQueue(data.from_uid, data.target_uid, data.emoji_idx, data.emoji_times);
        }

        scale9sprite.stopAllActions();
        scale9sprite.setVisible((type == 'emoji' || type == 'location' || type == 'effectemoji') ? false : true);
        scale9sprite.setOpacity(255);
        scale9sprite.setScale(1.6, 1.6);
        scale9sprite.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5), cc.callFunc(function () {
            for (var i = 0; i < innerNodes.length; i++)
                innerNodes[i].setVisible(false);
        })));

        if (type != 'voice') {
            for (var i = 0; i < innerNodes.length; i++) {
                var innerNode = innerNodes[i];
                innerNode.stopAllActions();
                innerNode.setVisible(true);
                innerNode.setOpacity(255);
                //innerNode.setScale(1.5, 1.5);
                innerNode.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5)));
            }
        }
        if (voice && !window.inReview) {
            playEffect(voice);
        }
    },

    onReady: function (sender, type) {
        //情理上局留下的别人的手牌
        for (var i = 1; i < this.playersNum; i++) {
            this["nCards" + i].removeAllChildren();
        }

        this.isReady = true;
        this.btReady.setVisible(false);
        this.btJiesuan.setVisible(false);
        if (mRoom.wanfatype == mRoom.FANGPAOFA ||
            mRoom.wanfatype == mRoom.SHAOYANGBOPI ||
            mRoom.wanfatype == mRoom.XIANGXIANG) {
            var isDone = network.wsData("Ready", true);
            if (isDone == false)  return;
            this.clearRoom();
        } else {
            if (mRoom.curRound >= mRoom.rounds) {
            } else {
                var isDone = network.wsData("Ready", true);
                if (isDone == false)  return;
                this.clearRoom();
            }
        }
        var players = DD[T.PlayerList];
        for (var i = 0; i < players.length; i++) {
            if (mRoom.wanfatype == mRoom.LEIYANG) {
                this.setJushou(players[i].ID, 0, 0, false);//举手
            }
            this.setBaojing(players[i].ID, 0);//报警
        }
        var gameResult = this.resultLayer.getChildByName('gameResult');
        if (gameResult) {
            gameResult.onClose();
        }
    },
    onJiesuan: function (sender, type) {
        // this.showGameResult();
        var resultlayer = getUI(this, 'resultLayer');
        var gameResult = resultlayer.getChildByName('gameResult');
        if (gameResult) {
            if (this.showJiesuan) {
                this.showJiesuan = false;
                gameResult.setVisible(false);
                this.btJiesuan.setVisible(false);
                this.btn_xszm.setVisible(true);
            } else {
                this.showJiesuan = true;
                this.btJiesuan.setVisible(true);
                this.btn_xszm.setVisible(false);
                gameResult.setVisible(true);

                // var btn_control_btns = getUI(this, 'btn_control_btns');
                // btn_control_btns.setVisible(false);
                // this.hideControlBtns();
            }
        }
    },
    showReadyJiesuan: function (flag) {
        this.btReady.setVisible(flag);
        this.btJiesuan.setVisible(flag);

        // var btn_control_btns = getUI(this, 'btn_control_btns');
        // btn_control_btns.setVisible(true);
        // this.changeBtnStatus();
    },
    onTimer: function (dt) {
        if (mRoom.isPause == true) {
            return;
        }
        var cd = this.cd;//this.turnPos
        var rotate = [0, -90, 90];
        if (mRoom.getPlayerNum() == 4) {
            if (mRoom.wanfatype == mRoom.HENGYANG || mRoom.wanfatype == mRoom.HENGDONG || mRoom.wanfatype == mRoom.MAOHUZI) {
                rotate = [0, -45, -135, 135];
            } else {
                rotate = [0, -90, -180, 90];
            }
        }
        var toupos = [cc.p(128 / 2, -20), cc.p(128 + 20, 128 / 2), cc.p(128 / 2, 128 + 30), cc.p(-20, 128 / 2)];
        //cd.setRotation(rotate[this.turnPos]);
        this.arrow_tou.setRotation(rotate[this.turnPos]);
        this.arrow_tou.setPosition(toupos[this.turnPos]);
        cd.setVisible(true);
        //cd 中显示光圈
        if (mRoom.isReplay != true && this.isStart == true) {
            for (var i = 0; i < mRoom.getPlayerNum(); i++) {
                var head = getUI(this, "head" + i);
                var guangquan = head.getChildByName('guangquan');
                if (!guangquan) {
                    var ccsScene = ccs.load(res.PhzHead_json, "res/");
                    guangquan = ccsScene.node;
                    guangquan.setName("guangquan");
                    guangquan.setPosition(cc.p(head.getContentSize().width / 2, head.getContentSize().height / 2));
                    head.addChild(guangquan);
                    guangquan.runAction(ccsScene.action);
                    ccsScene.action.play('action', true);
                }
                guangquan.setVisible((i == this.turnPos) ? true : false);
            }
        }
        //有手牌   才显示倒计时
        var hasCard = function () {
            if (DD && DD[T.CardList] != null && DD[T.CardList].length > 0) {
                return true;
            }
            return false;
        }
        if (this.secondsLeft > 0 && hasCard() == true) {
            this.secondsLeft -= 0.1;
            // this.cdtext.setString(this.secondsLeft);
            cd.setVisible(true);
            //进度条百分比刷新
            var bili = this.secondsLeft / 25 * 100;
            // if(dt != false) {
            //     this.cdbar.runAction(
            //         cc.progressTo(1, bili)
            //     );
            // }
            // var cdbarsprite = this.cdbar.getSprite();
            // cdbarsprite.setTexture((this.secondsLeft < 13) ? res.redquan : res.greenquan);
            //倒计时震动
            if (this.secondsLeft == 0) {
                if (this.isTurnOut == true || this.isTurnIn == true)
                    vibrate();
            }
            // if(this.secondsLeft == 15){
            //     if (this.isTurnOut){
            //         this.fingerAni(true);
            //     }
            // }
            //到了就出牌
            if (this.isTurnOut && this.secondsLeft && Math.floor(this.secondsLeft) == 20)
                this.fingerAni(true);
        } else {
            if (this.isStart == true && hasCard() == true) {
                cd.setVisible(true);
                this.cdtext.setString("0");
            }
        }
    },

    onBattery: function () {
        // if(getBatteryLevel() > 80){
        //     this.battery.setTexture(this.BatteryTextures["full"]);
        // }else if(getBatteryLevel() > 30){
        //     this.battery.setTexture(this.BatteryTextures["half"]);
        // }else {
        //     this.battery.setTexture(this.BatteryTextures["empty"]);
        // }
        // var pro = DeviceUtils.getBatteryPercent();
        // this.battery.setPercent(pro);


        var battery = getUI(this, 'battery');
        var level = DeviceUtils.getBatteryLevel();
        if (cc.sys.isObjectValid(battery)) {
            if (level > 75) {
                battery.setTexture(this.BatteryTextures["battery5"]);
            } else if (level > 50) {
                battery.setTexture(this.BatteryTextures["battery4"]);
            } else if (level > 25) {
                battery.setTexture(this.BatteryTextures["battery3"]);
            } else if (level > 10) {
                battery.setTexture(this.BatteryTextures["battery2"]);
            } else {
                battery.setTexture(this.BatteryTextures["battery1"]);
            }
        }
    },

    refreshTime: function () {
        if (mRoom.isReplay && mRoom.replayTime) {
            var timeArr = mRoom.replayTime.split(" ");
            var time = timeArr[1].split(":");
            if (time && time.length == 3) this.lbTime.setString(time[0] + ":" + time[1]);
        } else {
            var date = new Date();
            var seconds = date.getSeconds();
            var minutes = (date.getMinutes() < 10 ? "0" : "") + date.getMinutes();
            var hours = (date.getHours() < 10 ? "0" : "") + date.getHours();
            if (cc.sys.isObjectValid(this.lbTime)) {
                //修改冒号不闪烁
                // var maohao = " ";
                // if ((seconds % 2 == 1)) {
                //     maohao = ":";
                // }
                var maohao = ":";
                this.lbTime.setString(hours + maohao + minutes);
            }
        }
    },

    showActions: function (actList) {
        this.nAction.setVisible(true);
        var index = 0;
        var count = actList.length;
        this.bigAction = GUO;
        for (var i = 0; i < this.listActBtn.length; i++) {
            var bt = this.listActBtn[i];
            var btAct = mAction.getBTAct(i, actList);
            if (btAct > 0) {
                bt.setVisible(true);
                bt.setPositionX((index - 0.5 * (count - 1)) * 140);
                bt.setPositionY(95);

                switch (i) {
                    case 1:
                        this.bigAction = CHI;
                        break;
                    case 2:
                        this.bigAction = PENG;
                        break;
                    case 0:
                        this.bigAction = HU;
                        break;
                }

                if (btAct == GUO) {
                    bt.setTag(4);
                } else if (btAct == WEI) {
                    bt.setTag(5);
                } else if (btAct == PAO) {
                    bt.setTag(6);
                }
                index++;
            } else {
                bt.setVisible(false);
            }
        }
    },
    //录像回放  小手点击
    showReplayAction: function (action) {
        var actionData = action.split("/");
        var userId = actionData[0];
        var mainAction = actionData[1];
        var subAction = actionData[2];
        var replay_act = null;
        if (subAction == "chi" || subAction == "peng" || subAction == "hu" || subAction == "guo") {
            var pos = this.getUserPosIndex(userId);
            replay_act = getUI(this, "replay_act" + pos);
            replay_act.setVisible(true);
            var bt = getUI(replay_act, subAction);
            this.playHand(bt);

            // //回放需要知道吃喂提胡  的操作
            // var chipeng = mAction.getActList(999999, actionData[3]);  //吃碰判断
            // var showOpList = [];
            // if(chipeng.indexOf(CHI) >= 0) showOpList.push("chi");
            // if(chipeng.indexOf(PENG) >= 0) showOpList.push("peng");
            // var huInfo = mAction.isHaveHu(actionData[3], true);
            // if(huInfo != null){
            //     showOpList.push("hu");
            // }
            // showOpList.push("guo");
            // var cphg = ["chi", "peng", "hu", "guo"];
            // for(var s = 0 ; s < cphg.length ; s++){
            //     var bt = getUI(replay_act, cphg[s]);
            //     TouchFilter.grayScale(bt);
            //     if(showOpList.indexOf(cphg[s]) >= 0){
            //         TouchFilter.remove(bt);
            //     }
            // }
        }
    },
    playHand: function (bt) {
        cc.spriteFrameCache.addSpriteFrames(res.hand_plist);
        var animFrames = [cc.spriteFrameCache.getSpriteFrame("hand0.png"), cc.spriteFrameCache.getSpriteFrame("hand1.png")];
        var animation = new cc.Animation(animFrames, 0.2);
        var action = cc.animate(animation);
        var sprite = new cc.Sprite(animFrames[0]);
        sprite.x = 40;
        sprite.y = 20;
        bt.addChild(sprite);
        sprite.runAction(action);
    },
    hideReplayAction: function () {
        for (var i = 0; i < this.playersNum; i++) {
            var replay_act = getUI(this, "replay_act" + i);
            getUI(replay_act, "chi").removeAllChildren();
            getUI(replay_act, "peng").removeAllChildren();
            getUI(replay_act, "hu").removeAllChildren();
            getUI(replay_act, "guo").removeAllChildren();
            replay_act.setVisible(false);
        }
    },
    onActionBtn: function (tag) {
        var that = this;
        if (tag == 2) {
            var hubtn = getUI(this.nAction, "bt1");
            if (hubtn.isVisible() == true) {
                HUD.showMessageBox('提示', "当前可以胡牌，请问是否选择吃?", function () {
                    that.showChiSelect();
                })
            } else {
                that.showChiSelect();
            }
        } else if (tag == 3) {
            var hubtn = getUI(this.nAction, "bt1");
            if (hubtn.isVisible() == true) {
                HUD.showMessageBox('提示', "当前可以胡牌，请问是否选择碰?", function () {
                    that.userAct(PENG, that.showNo);
                })
            } else {
                that.userAct(PENG, that.showNo);
            }
        } else if (tag == 1) {
            that.userAct(HU, that.showNo);
        } else if (tag == 4) {
            //过得时候判断一下  有没有 胡的选项,有的话,提示
            var hubtn = getUI(this.nAction, "bt1");
            if (hubtn.isVisible() == true) {
                HUD.showMessageBox('提示', "当前可以胡牌，请问是否选择过?", function () {
                    that.userAct(GUO, that.showNo);
                })
            } else {
                that.userAct(GUO, that.showNo);
            }
        }
    },

    showChiSelect: function () {
        var chiList = null;
        chiList = this.chiArray;

        this.nChiList.removeAllChildren();
        if (chiList == null) return;

        var chibilayer = HUD.showLayer(HUD_LIST.ChiBiLayer, this.nChiList);
        chibilayer.setData(chiList, this.showNo, this);
    },

    onTurnIn: function (event) {                   //进牌
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        this.goTurnIn(data.Card, data.Flag, data.Remark, data.Seq, data.ChiList);
    },
    getChiListByServer: function (chiListServer) {
        if (chiListServer == null || chiListServer == undefined) return null;
        var chiArray = [];
        for (var i = 0; i < chiListServer.Nodes.length; i++) {
            var chionei = [];
            if (chiListServer.Nodes[i].Cards.length > 0) {
                for (var j = 0; j < chiListServer.Nodes[i].Cards.length; j++) {
                    chionei.push(chiListServer.Nodes[i].Cards[j]);
                }
            }
            if (chiListServer.Nodes[i].Nodes.length > 0) {
                var chionex = [];
                for (var j = 0; j < chiListServer.Nodes[i].Nodes.length; j++) {
                    var chionej = [];
                    for (var l = 0; l < chiListServer.Nodes[i].Nodes[j].Cards.length; l++) {
                        chionej.push(chiListServer.Nodes[i].Nodes[j].Cards[l]);
                    }
                    //
                    if (chiListServer.Nodes[i].Nodes[j].Nodes.length > 0) {
                        var chioney = [];
                        for (var k = 0; k < chiListServer.Nodes[i].Nodes[j].Nodes.length; k++) {
                            var chionek = chiListServer.Nodes[i].Nodes[j].Nodes[k].Cards;
                            chioney.push(chionek);
                        }
                        chionej.push(chioney);
                    }
                    chionex.push(chionej);
                }
                chionei.push(chionex);
            }
            chiArray.push(chionei);
        }
        return chiArray
    },

    goTurnIn: function (card, flag, remark, seq, ChiList) {
        this.chiArray = null;
        this.nChiList.removeAllChildren();
        this.isTurnOut = false;
        this.isTurnIn = true;
        mRoom.inSeq = seq;

        cc.log("turn in id +++++", gameData.uid, remark, flag, card);

        // this.turnPos = 0;  this.getUserPosIndex(userId);
        this.secondsLeft = 15 + this.timeAdd;

        this.turnInData = {};
        this.turnInData.Card = card;
        this.turnInData.Flag = flag;

        //改到后端计算  debug spring
        this.chiArray = this.getChiListByServer(ChiList);
        //只有一个过
        if (flag == GUO) {
            return;
        }
        var chi = ((flag & CHI) > 0) ? true : false;
        var peng = ((flag & PENG) > 0) ? true : false;
        var hu = ((flag & HU) > 0) ? true : false;
        var guo = ((flag & GUO) > 0) ? true : false;
        var pao = ((flag & PAO) > 0) ? true : false;
        var ti = ((flag & TI) > 0) ? true : false;
        var wei = ((flag & WEI) > 0) ? true : false;
        var chouwei = ((flag & CHOUWEI) > 0) ? true : false;
        var tianhu = ((flag & TIANHU) > 0) ? true : false;//TIANHU
        var actList = [];
        if (tianhu == true) {
            if (mRoom.wanfatype == mRoom.FANGPAOFA ||
                mRoom.wanfatype == mRoom.SHAOYANGBOPI ||
                mRoom.wanfatype == mRoom.XIANGXIANG ||
                mRoom.wanfatype == mRoom.YOUXIAN ||
                mRoom.wanfatype == mRoom.HENGYANG ||
                mRoom.wanfatype == mRoom.HENGDONG) {
                this.userAct(HU, card);
                return;
            }
        } else if (pao == true) {
            this.userAct(PAO, card);
        } else if (ti == true) {
            this.userAct(TI, card);
        } else if (wei == true) {
            this.userAct(WEI, card);
        } else {
            if (peng == true) actList.push(PENG);
            if (chi == true) actList.push(CHI);
            if (guo == true) actList.push(GUO);
            if (hu == true) actList.push(HU);
            this.showActions(actList);
        }
    },

    onTurnOut: function (event) {                  //出牌
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        this.goTurnOut(data.Turn, data.Second, data.Seq, data.Freeze);
    },

    goTurnOut: function (userId, seconds, seq, Freeze) {
        this.setTurnInOver();
        this.showCard.setVisible(false);
        this.nChiList.removeAllChildren();
        var turnPos = this.getUserPosIndex(userId);
        this.turnPos = turnPos;
        this.secondsLeft = seconds + this.timeAdd;
        this.bigAction = null;

        if (turnPos == 0) {
            this.isTurnOut = true;
            this.isTurnIn = false;
            mRoom.outSeq = seq;

            var cards = DD[T.CardList];
            if (cards.length == 0) {
                this.userShowCard(0, true);
            }
        }
        //冻结 Freeze
        if (userId == gameData.uid && Freeze && Freeze.length > 0) this.setFreezeCard(Freeze);
    },
    setFreezeCard: function (Freeze) {
        this.Freeze = Freeze;
        if (Freeze) {
            var isFreeze = function (freezeCard) {
                for (var i = 0; i < Freeze.length; i++) {
                    if (Freeze[i] == freezeCard) {
                        return true;
                    }
                }
                return false;
            }
            var cardList = this.nCards0.getChildren();
            for (var i = 0; i < cardList.length; i++) {
                var card = cardList[i];
//                card.setGrayCard(isFreeze(card.data));
            }
        }
    },
    showLZCardAtPos: function (card, userPos, isMo, ts, sex) {
        this.showCardAtPos(card, userPos, isMo, true, sex);
        this.scheduleOnce(function () {
            this.showCard.setVisible(false);
            if (userPos == 0 && !mRoom.isReplay) {
                if (mRoom.isInOpenList(card) == false) {
                    //提过的亮张不要放进手牌  计算手里的牌数量
                    var cards = DD[T.CardList];
                    var comboList = mAction.combos[0];
                    var comboNum = 0;
                    for (var s = 0; s < comboList.length; s++) {
                        comboNum = comboNum + comboList[s].cards.length;
                    }
                    //手牌的数量 3人玩 手牌21  四人玩 手牌15
                    var handcards = 21;
                    if (this.playersNum == 4) handcards == 15;
                    if (cards && (cards.length + comboNum) != handcards) {
                        this.addCard(card);
                        var cardList = mCard.getCardList();
                        this.cardList = cardList;
                        this.setupCards();
                    }
                }
            }
        }, 1);
        if (mRoom.isReplay) {
            //提过的亮张不要放进手牌  计算手里的牌数量
            var addLiangZhangCard = false;
            var cards = null;
            if (userPos == 0) {
                cards = DD[T.CardList];
            } else {
                cards = DD[T["CardList" + userPos]];
            }
            var comboList = mAction.combos[userPos];
            var comboNum = 0;
            for (var s = 0; s < comboList.length; s++) {
                comboNum = comboNum + comboList[s].cards.length;
            }
            if (cards && (cards.length + comboNum) != 21) {
                addLiangZhangCard = true;
            }
            if (userPos == 0) {
                if (addLiangZhangCard)
                    DD[T.CardList].push(card);
                var cardList = mCard.getCardList();
                this.cardList = cardList;
                this.setupCards();
            } else {
                if (addLiangZhangCard)
                    DD[T["CardList" + userPos]].push(card);
                this["cardList" + userPos] = mCard.getOtherCardList(DD[T["CardList" + userPos]]);
                this.setupOtherCards(userPos);
            }
        }
    },

    showCardAtPos: function (card, userPos, isMo, isLz, sex) {
        if (isMo == undefined || isMo == null) isMo = false;
        if (card != 0) {

            this.playEffectByMap(card, sex);
        }
        this.showNo = card;
        this.showCard.setScale(1);
        this.showCard.setVisible(true);
        this.showCard.setData(this.showNo, null, 1);
        this.showCard.setMo(isMo);
        if (isLz) {
            mEffect.liangPai(this.showCard, userPos);
        } else {
            if (isMo) {
                mEffect.moPai(this.showCard, userPos);
            } else {
                mEffect.chuPai(this.showCard, userPos);
            }
        }
        this.lastShowCard = [card, userPos, isMo, isLz];
    },
    playEffectByMap: function (card, sex) {
        if (mRoom.wanfatype == mRoom.FANGPAOFA ||
            mRoom.wanfatype == mRoom.CHANGSHA ||
            mRoom.wanfatype == mRoom.HONGGUAIWAN ||
            mRoom.wanfatype == mRoom.XIANGXIANG) {
            playEffect(card, 1, 'ld');
        } else if (mRoom.wanfatype == mRoom.YOUXIAN) {
            playEffect(card, sex, 'yx');
        } else if (mRoom.wanfatype == mRoom.GUILIN) {
            playEffect(card, sex, 'guilin');
        } else {
            playEffect(card, sex, 'cd');
        }
    },
    playCPTPHEffect: function (cp, sex) {
        if (mRoom.wanfatype == mRoom.YOUXIAN) {
            playEffect(cp, sex, 'yx');
        } else if (mRoom.wanfatype == mRoom.GUILIN) {
            playEffect(cp, sex, 'guilin');
        } else {
            playEffect(cp, sex, 'cd');
        }
    },
    addOutCard: function (isCombo) {
        if (this.lastShowCard != null && this.lastShowCard[3] != true) { //不是亮张
            if (isCombo != true) {
                var userPos = this.lastShowCard[1];
                var card = this.lastShowCard[0];
                var out = this["out" + userPos];
                out.addCard(card, true, this.showCard, this);
            }
            this.lastShowCard = null;
        }
    },

    moCard: function () {
        if (mAction.leftCardCount > 0) {
            mAction.leftCardCount -= 1;
            this.txtCardCount.setString(mAction.leftCardCount);
        }
    },

    updateHX: function (userPos) {
        var txt = this["txtHX" + userPos];
        var showHx = mAction.showHx[userPos];
        if (mRoom.wanfatype == mRoom.LEIYANG) {
            txt.setString("胡子:" + showHx);
        } else if (mRoom.wanfatype == mRoom.YOUXIAN) {
            var newpos = (userPos + this.pos0) % this.playersNum;
            var scorenum = mRoom.InGameScore[newpos] || 0;
            txt.setString("得分:" + scorenum);
        } else if (mRoom.wanfatype == mRoom.WEIMAQUE) {
            txt.setString("硬息:" + showHx);
        } else {
            txt.setString("胡息:" + showHx);
        }
        this.lastShowCard = null;
    },
    hideImaAct: function () {
        this.imgAct.stopAllActions();
        this.imgAct.setOpacity(0);
    },
    showImgAct: function (typ, userPos) {
        var imgScale = 1.5;
        var img = "";
        var timeAdd = 0;
        var inSeq = mRoom.inSeq;
        if (inSeq == undefined || inSeq == null) {
            inSeq = 0;
        }

        switch (typ) {
            case mCard.comboTypes.chi:
                img = "chiSay";
                break;
            case mCard.comboTypes.chouwei:
                img = (mRoom.wanfatype == mRoom.GUILIN || mRoom.wanfatype == mRoom.YOUXIAN) ? "guosaoSay" : "weiSay";
                break;
            case mCard.comboTypes.hu:
                img = "huSay";
                timeAdd = 1.0;
                break;
            case mCard.comboTypes.pao:
                img = (mRoom.wanfatype == mRoom.GUILIN) ? "kaiduoSay" : "paoSay";
                break;
            case mCard.comboTypes.peng:
                img = "pengSay";
                break;
            case mCard.comboTypes.ti:
                img = (mRoom.wanfatype == mRoom.GUILIN) ? "saochuanSay" : "tiSay";
                break;
            case mCard.comboTypes.wei:
                img = (mRoom.wanfatype == mRoom.GUILIN || mRoom.wanfatype == mRoom.YOUXIAN) ? "saoSay" : "weiSay";
                if (mRoom.wanfatype == mRoom.YOUXIAN && inSeq <= 1) {
                    img = "PHZ_kan";
                }
                break;
        }
        if (img != "") {
            var src = res[img];
            // console.log("spring==="+src+"==="+inSeq);
            this.imgAct.setTexture(src);

            if (mRoom.getPlayerNum() == 3) {
                if (userPos == 0) {
                    this.imgAct.setPosition(560, 250);
                } else if (userPos == 1) {
                    this.imgAct.setPosition(800, 500);
                } else {
                    this.imgAct.setPosition(320, 500);
                }
            } else {
                if (userPos == 0) {
                    this.imgAct.setPosition(1280 / 2, 250);
                } else if (userPos == 1) {
                    this.imgAct.setPosition(1280 - 200, 450);
                } else if (userPos == 2) {
                    this.imgAct.setPosition(1280 / 2, 600);
                } else {
                    this.imgAct.setPosition(200, 360);
                }
            }

            this.imgAct.removeAllChildren();
            if (typ == mCard.comboTypes.hu) {
                var ccsScene = ccs.load(res.PhzHu_json, "res/");
                var huani = ccsScene.node;
                huani.setScale(1.0);
                huani.setPosition(cc.p(this.imgAct.getContentSize().width / 2, this.imgAct.getContentSize().height / 2));
                this.imgAct.addChild(huani);
                huani.runAction(ccsScene.action);
                ccsScene.action.play('action', true);
            } else {
                //闪光特效
                this.tpwhEffect(this.imgAct, src, imgScale, userPos);
            }
            this.imgAct.setOpacity(255);

            // //重放的胡牌  一直存在,不消失
            if (typ == mCard.comboTypes.hu) {
                if (!mRoom.isReplay) {
                    this.imgAct.stopAllActions();
                    var seq = cc.sequence(
                        cc.delayTime(5)
                        //, cc.fadeOut(0.1)
                    );
                    this.imgAct.runAction(seq);
                }
            } else {
                var time = 0.5;
                if (userPos == 0) {
                    time = 0.35;
                }
                var seq = cc.sequence(
                    cc.delayTime(time),
                    cc.fadeOut(0.1),
                    cc.callFunc(this.imgAct.removeAllChildren())
                );
                this.imgAct.runAction(seq);
            }
        }
    },
    tpwhEffect: function (tpwhNode, src, imgScale, userPos) {
        var clipper = function () {  //创建剪切区域
            var clipper = new cc.ClippingNode();
            var gameTitle = new cc.Sprite(src);
            // gameTitle.setScale(imgScale);
            clipper.setStencil(gameTitle);
            clipper.setAlphaThreshold(0);
            clipper.setContentSize(cc.size(gameTitle.getContentSize().width, gameTitle.getContentSize().height));
            return clipper;
        }

        var time = 1;
        if (userPos == 0) {
            time = 0.7;
        }

        tpwhNode.setScale(0);
        tpwhNode.stopAllActions();
        tpwhNode.runAction(cc.sequence(
            cc.scaleTo(0.1 * time, 0.8 * imgScale, 1.2 * imgScale),     //0.2
            cc.scaleTo(0.1 * time, 1.1 * imgScale, 0.9 * imgScale),     //0.2
            cc.scaleTo(0.05 * time, 0.95 * imgScale, 1.05 * imgScale),   //0.1
            cc.scaleTo(0.05 * time, imgScale, imgScale),                 //0.1
            cc.callFunc(function () {
                    var clip = clipper();
                    var clipSize = cc.size(200, 80);
                    clip.setPosition(cc.p(tpwhNode.getContentSize().width / 2, tpwhNode.getContentSize().height / 2));
                    var gameTitle = new cc.Sprite(res.transparent_97x99_png);
                    var spark = new cc.Sprite(res.eff_spark_png);
                    // spark.setScale(imgScale);
                    clip.addChild(gameTitle, 1);
                    spark.setPosition(-tpwhNode.getContentSize().width / 2, 0);
                    clip.addChild(spark, 2);
                    tpwhNode.addChild(clip, 4);
                    var moveAction = cc.moveTo(0.5 * time, cc.p(clipSize.width, 0));
                    var seq = cc.sequence(moveAction);
                    spark.runAction(seq);
                }
            )
        ));
    },
    //todo 第一把时间缩短为原来的0.2
    onBroadCast: function (event) {               //广播操作
        // var cmd = "Continue/" + mRoom.roomId;
        // network.wsData(cmd, true);
        if (this.checkNoRunning()) return;
        var that = this;
        var data = event.getUserData();
        // console.log(data);
        var action = data.Action;
        var actList = action.split("/");
        var userId = actList[0];
        var actStatus = actList[1];
        var actName = actList[2];
        var card = parseInt(actList[3]);
        var seq = parseInt(actList[4]);  //序号小等1
        var info = "";
        if (actList.length > 5)
            info = actList[5];
        //mRoom.seq = seq;
        var ScoreChange = data.ScoreChange;

        var userPos = this.getUserPosIndex(userId);
        var userInfo = mRoom.getUserByUserId(userId);
        var userSex = 1;
        if (!userInfo) {
            userSex = 1;
        } else {
            userSex = userInfo.Sex;
        }

        var _moveCoefficient = 0.7;
        if (userPos == 0) _moveCoefficient = 0.5;
        var timeMultiple = 1;
        if(seq <= 1){
            timeMultiple = 0.2;
            _moveCoefficient = _moveCoefficient*timeMultiple;
        }

        if (actStatus == 1) {
            //设置在线
            this.setDisconnect(userId, false);

            switch (actName) {
                case "liangzhang":
                    mRoom.inSeq = 0;
                    this.showLZCardAtPos(card, userPos, true, true, userSex);
                    network.stop();
                    this.scheduleOnce(function () {
                        network.start();
                    }, 0.5 * _moveCoefficient);
                    break;
                case "ShowCard":
                    if (this.diaoPaoSprite) {
                        this.diaoPaoSprite.setVisible(false);
                    }
                    network.stop();
                    this.scheduleOnce(function () {
                        network.start();
                    }, 0.5 * _moveCoefficient);

                    this.showCardAtPos(card, userPos, false, false, userSex);

                    if (userPos == 0 || mRoom.isReplay) {
                        var deleteCards = [card];
                        this.removeCards(deleteCards, userPos, this.outCardColumn, this.outCardRow);
                        this.outCardColumn = null;
                        this.outCardRow = null;
                    }

                    playEffect('runcard');//出牌
                    this.playEffectByMap(card.toString(), userSex);
                    break;
                case "mo":
                    network.stop();
                    this.addOutCard(false);
                    var that = this;
                    this.runAction(cc.sequence(
                        cc.delayTime(0.3),
                        cc.callFunc(function () {
                            that.turnPos = userPos;
                            that.showCardAtPos(card, userPos, true);
                            that.moCard();
                        }),
                        cc.delayTime(0.3),
                        cc.callFunc(function () {
                            network.start();
                        })
                    ));
                    playEffect('takecard');//摸牌
                    break;
                case "bakuai":
                    this.addOutCard(false);
                    //this.showCardAtPos(card, userPos);
                    this.moCard();
                    if (userPos == 0) {
                        this.addCard(card);
                    }
                    break;
                case "peng":
                    that.addOutCard(true);
                    var cardList = [card, card, card];
                    var isPeng = false;
                    if (info != "") {
                        isPeng = true;
                    }
                    var open = that["open" + userPos];
                    open.addCards(cardList, mCard.comboTypes.peng, false, isPeng);

                    if (isPeng) {
                        var userId = parseInt(info);
                        var userPosTo = this.getUserPosIndex(userId);
                        var outCards = that["out" + userPosTo];
                        outCards.addCard(cardList[0]);
                    }
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);

                    that.showImgAct(mCard.comboTypes.peng, userPos);

                    if (userPos == 0 || mRoom.isReplay) {
                        var deleteCards = [card, card, card];
                        that.removeCards(deleteCards, userPos);
                    }

                    if (mRoom.wanfatype == mRoom.YOUXIAN) {
                        var comboList = mAction.combos[userPos];
                        var num = 0;
                        for (var m = 0; m < comboList.length; m++) {
                            if (comboList[m].typ == mCard.comboTypes.peng ||
                                comboList[m].typ == mCard.comboTypes.wei ||
                                comboList[m].typ == mCard.comboTypes.ti ||
                                comboList[m].typ == mCard.comboTypes.pao ||
                                comboList[m].typ == mCard.comboTypes.chouwei) {
                                num++;
                            }
                        }
                        if (num == 3) {
                            this.playCPTPHEffect('pengsanda', userSex);
                        } else if (num == 4) {
                            this.playCPTPHEffect('pengsiqing', userSex);
                        } else {
                            this.playCPTPHEffect('peng', userSex);
                        }
                    } else {
                        this.playCPTPHEffect('peng', userSex);
                    }
                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                case "chi":
                    that.addOutCard(true);
                    that.nChiList.removeAllChildren();
                    var cardList = info.split(",");
                    var open = that["open" + userPos];
                    var count = cardList.length / 3;
                    for (var i = 0; i < count; i++) {
                        var combo = [];
                        var index = i * 3;
                        combo.push(cardList[index]);
                        combo.push(cardList[index + 1]);
                        combo.push(cardList[index + 2]);

                        var comboTyp = mCard.getComboType(combo);
                        // open.addCards(combo, comboTyp);
                        //吃的第几张牌需要特殊现实   王常春 2016-7-8 add
                        //吃的放在第一个位置
                        for (var x = 0; x < combo.length; x++) {
                            if (parseInt(card) == parseInt(combo[x])) {
                                var tmp = combo[x];
                                for (var y = x + 1; y < 3; y++) {
                                    combo[y - 1] = combo[y];
                                }
                                combo[2] = tmp;
                            }
                        }
                        open.addCards(combo, comboTyp, false);
                    }
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);

                    that.showImgAct(mCard.comboTypes.chi, userPos);
                    if (userPos == 0 || mRoom.isReplay) {
                        var removeCards = mCard.copyCards(cardList);
                        for (var i = 0; i < removeCards.length; i++) {
                            if (removeCards[i] == card) {
                                removeCards.splice(i, 1);
                                break;
                            }
                        }
                        that.removeCards(removeCards, userPos);
                    }

                    if (mRoom.wanfatype == mRoom.GUILIN) {
                        this.playCPTPHEffect('chi', userSex);
                    } else {
                        if (count > 1) {
                            this.playCPTPHEffect('bi', userSex);
                        } else {
                            this.playCPTPHEffect('chi', userSex);
                        }
                    }
                    break;
                case "ti":
                    network.stop();
                    this.scheduleOnce(function () {
                        network.start();
                    }, 1);

                    that.addOutCard(true);
                    var cardList = [card, card, card, card];
                    var isOpen = false;

                    //info == true牌桌上的偎
                    if (info == "true") {
                        isOpen = true;
                    }
                    var open = that["open" + userPos];
                    open.addCards(cardList, mCard.comboTypes.ti, isOpen);
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);//add hide

                    that.showImgAct(mCard.comboTypes.ti, userPos);
                    if ((userPos == 0 && isOpen == false) || mRoom.isReplay) {
                        var deleteCards = [card, card, card, card];
                        that.removeCards(deleteCards, userPos);
                    }
                    if (mRoom.wanfatype == mRoom.YOUXIAN) {
                        this.playCPTPHEffect('ti', userSex);
                    } else {
                        this.playCPTPHEffect('ti', userSex);
                    }
                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                case "pao":
                    network.stop();
                    this.scheduleOnce(function () {
                        network.start();
                    }, 0.5);

                    var cardList = [card, card, card, card];
                    var isOpen = false;
                    if (info == "true") {
                        isOpen = true;   //碰变跑
                    }
                    var open = that["open" + userPos];
                    open.addCards(cardList, mCard.comboTypes.pao, isOpen);
                    if (isOpen) {//碰变跑,回收所有弃牌里面的当前牌
                        for (var i = 0; i < mRoom.getPlayerNum(); ++i) {
                            var outCard = that["out" + i];
                            outCard.removeCard(cardList[0]);
                        }
                    }
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);

                    that.showImgAct(mCard.comboTypes.pao, userPos);

                    if ((userPos == 0 && isOpen == false) || mRoom.isReplay) {
                        var deleteCards = [card, card, card];
                        that.removeCards(deleteCards, userPos);
                    }

                    this.playCPTPHEffect('pao', userSex);
                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                case "wei":
                    network.stop();

                    if (seq > 1){
                        this.scheduleOnce(function () {
                            network.start();
                        }, 1);
                    } else{
                        this.scheduleOnce(function () {
                            network.start();
                        }, 0.3);
                    }
                    that.addOutCard(true);
                    var cardList = [card, card, card];
                    var open = that["open" + userPos];
                    if (mRoom.isReplay) {
                        open.addCards(cardList, mCard.comboTypes.chouwei);
                    } else {
                        open.addCards(cardList, mCard.comboTypes.wei);
                    }
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);//add hide

                    that.showImgAct(mCard.comboTypes.wei, userPos);

                    if (userPos == 0 || mRoom.isReplay) {
                        var deleteCards = [card, card, card];
                        that.removeCards(deleteCards, userPos);
                    }


                    if (mRoom.wanfatype == mRoom.YOUXIAN) {
                        var comboList = mAction.combos[userPos];
                        var num = 0;
                        for (var m = 0; m < comboList.length; m++) {
                            if (comboList[m].typ == mCard.comboTypes.peng ||
                                comboList[m].typ == mCard.comboTypes.wei ||
                                comboList[m].typ == mCard.comboTypes.ti ||
                                comboList[m].typ == mCard.comboTypes.pao ||
                                comboList[m].typ == mCard.comboTypes.chouwei) {
                                num++;
                            }
                        }
                        if (mRoom.inSeq <= 1 && mRoom.wanfatype == mRoom.YOUXIAN) {

                            if (num == 3) {
                                this.playCPTPHEffect('kan', userSex);
                            } else if (num == 4) {
                                this.playCPTPHEffect('kan', userSex);
                            } else {
                                this.playCPTPHEffect('kan', userSex);
                            }
                        } else {
                            if (num == 3) {
                                this.playCPTPHEffect('saosanda', userSex);
                            } else if (num == 4) {
                                this.playCPTPHEffect('saosiqing', userSex);
                            } else {
                                this.playCPTPHEffect('wei', userSex);
                            }
                        }
                    } else {
                        this.playCPTPHEffect('wei', userSex);
                    }
                    //this.playCPTPHEffect('wei', gameData.sex);
                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                case "chouwei":
                    network.stop();
                    this.scheduleOnce(function () {
                        network.start();
                    }, 1);

                    that.addOutCard(true);
                    var cardList = [card, card, card];
                    var open = that["open" + userPos];
                    open.addCards(cardList, mCard.comboTypes.chouwei);
                    mEffect.chiPai(open, userPos, timeMultiple);
                    // that.updateHX(userPos);//株洲 计算分数从后端去，不自己计算
                    that.showCard.setVisible(false);//add hide

                    that.showImgAct(mCard.comboTypes.chouwei, userPos);

                    if (userPos == 0 || mRoom.isReplay) {
                        var deleteCards = [card, card, card];
                        that.removeCards(deleteCards, userPos);
                    }

                    if (mRoom.wanfatype == mRoom.GUILIN) {
                        this.playCPTPHEffect('chouwei', userSex);
                    } else {
                        if (mRoom.wanfatype == mRoom.YOUXIAN) {
                            var comboList = mAction.combos[userPos];
                            var num = 0;
                            for (var m = 0; m < comboList.length; m++) {
                                if (comboList[m].typ == mCard.comboTypes.peng ||
                                    comboList[m].typ == mCard.comboTypes.wei ||
                                    comboList[m].typ == mCard.comboTypes.ti ||
                                    comboList[m].typ == mCard.comboTypes.pao ||
                                    comboList[m].typ == mCard.comboTypes.chouwei) {
                                    num++;
                                }
                            }
                            if (num == 3) {
                                this.playCPTPHEffect('saosanda', userSex);
                            } else if (num == 4) {
                                this.playCPTPHEffect('saosiqing', userSex);
                            } else {
                                this.playCPTPHEffect('wei', userSex);
                            }
                        } else {
                            this.playCPTPHEffect('wei', userSex);
                        }
                    }
                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                case "hu":
                    cc.log("check game hu +++++");
                    if (info != null && info.length > 0) {
                        this.gameOverHuInfo = JSON.parse(info);
                    }
                    //this.processGameOver();
                    cc.log("rurururururururururu-----------------"+this.gameOverHuInfo.ByWho);
                    if (this.gameOverHuInfo.ByWho && this.gameOverHuInfo.ByWho != 0) {
                        var _userPos = this.getUserPosIndex(this.gameOverHuInfo.ByWho);
                        var _offset = 0;
                        if (!this.diaoPaoSprite) {
                            this.diaoPaoSprite = new cc.Sprite(res.diaopao_end_png);
                            this.diaoPaoSprite.setVisible(true);
                            if (_userPos == 0) {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2 - _offset, this.showCard.getContentSize().height / 2);
                            } else if (_userPos == 2) {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2, this.showCard.getContentSize().height / 2);
                            } else {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2, this.showCard.getContentSize().height / 2);
                            }
                            this.diaoPaoSprite.setLocalZOrder(0);
                            // var _userPos = this.getUserPosIndex(this.gameOverHuInfo.ByWho);
                            // if(_userPos == 2 || _userPos == 0){
                            //     this.diaoPaoSprite.rotation = 90;
                            // } else {
                            this.diaoPaoSprite.rotation = 360 - this.showCard.getRotation();
                            // }
                            if (this.showCard.visible == false) {
                                this.showCard.setVisible(true);
                            }
                            this.showCard.addChild(this.diaoPaoSprite);
                        } else {
                            if (_userPos == 0) {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2 - _offset, this.showCard.getContentSize().height / 2);
                            } else if (_userPos == 2) {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2, this.showCard.getContentSize().height / 2);
                            } else {
                                this.diaoPaoSprite.setPosition(this.showCard.getContentSize().width / 2, this.showCard.getContentSize().height / 2);
                            }
                            this.diaoPaoSprite.setVisible(true);
                        }
                    }
                    this.showImgAct(mCard.comboTypes.hu, userPos);

                    //攸县玩法  显示得分
                    this.showDefen(ScoreChange);
                    break;
                default :
                    break;
            }
        } else {
            // this.setTurnInOver();


            // if (this.bigAction != null) {
            //     var act = mAction.getActionByString(actName);
            //     if (act == TI || act == WEI || act == CHOUWEI) {
            //         //提偎 不自动过牌
            //     } else {
            //         if (this.lastShowCard != null && this.bigAction != null) {
            //             var moPos = this.lastShowCard[1];
            //             if (moPos != 0 && act == this.bigAction) {    //最高级操作相同时
            //                 var needAuto = false;
            //                 if (moPos == userPos) {                   //摸牌人操作
            //                     needAuto = true;
            //                 } else {
            //                     if (moPos == 1 && userPos == 2) {     //摸牌人是下家
            //                         needAuto = true;
            //                     }
            //                 }
            //                 if (needAuto == true) {
            //                     //自动过牌
            //                     mRoom.inSeq = seq;
            //                     this.userAct(GUO, card, true);
            //                     // this.setTurnInOver();
            //                 }
            //             } else if (act < this.bigAction) {             //最高级操作小于广播
            //                 //自动过牌
            //                 // mRoom.inSeq = seq;
            //                 // this.userAct(GUO, card, true);
            //                 this.setTurnInOver();
            //             }
            //         }
            //     }
            // }
        }

        if (userId.length > 10)
            userId = userId.substr(0, 5);

        if (seq == null) {
            cc.log("seq is null");
        }
    },
    showDefen: function (ScoreChange) {
        if (ScoreChange) {
            var scoreList = ScoreChange.split("/");
            // 数字提示的特效显示
            if (scoreList && scoreList.length == 8) {
                for (var i = 0; i < mRoom.getPlayerNum(); i++) {
                    var defenNum = scoreList[(this.pos0 + i) % 4 + 4];
                    // 胡息数据更新
                    var zongfenNum = scoreList[(this.pos0 + i) % 4];
                    this["txtHX" + i].setString("得分:" + zongfenNum);
                    // console.log(zongfenNum);
                    mRoom.InGameScore[i] = zongfenNum;
                    if (defenNum && parseInt(defenNum) != 0) {
                        var row = i;
                        var head = getUI(this, "head" + i);
                        var defen = head.getChildByName('defen');
                        if (!defen) {
                            if (defenNum > 0) {
                                defen = new cc.LabelBMFont("", res.jiafen_fnt);
                            } else {
                                defen = new cc.LabelBMFont("", res.jianfen_fnt);
                            }
                            defen.setName('defen');
                            defen.setScale(0.9);
                            if (defenNum) defen.setString(defenNum);
                            // defen.setPosition((row == 0 || row == 1) ? cc.p(50, 0) : cc.p(50, -20));
                            // head.addChild(defen);
                            if (row == 0 || row == 2) {
                                defen.setPosition((row == 0) ? cc.p(1280 / 2, 360 - 60) : cc.p(1280 / 2, 500 + 30));
                            } else {
                                defen.setAnchorPoint((row == 1) ? cc.p(0, 0.5) : cc.p(1, 0.5));
                                defen.setPosition((row == 1) ? cc.p(1280 / 2 + 80, 420) : cc.p(1280 / 2 - 90, 420));
                            }
                            this.addChild(defen, 100)
                        }
                        defen.stopAllActions();
                        defen.runAction(cc.sequence(
                            cc.delayTime(2),
                            cc.fadeOut(1)
                            , cc.callFunc(function (sender) {
                                sender.removeFromParent();
                            })
                        ))
                    }
                }
            }


            //金币飞舞的特效显示
            if (scoreList && scoreList.length == 8) {
                var winArr = [];
                var loseArr = [];
                //找到输赢座位的位置
                for (var i = 0; i < mRoom.getPlayerNum(); i++) {
                    var defenNum = scoreList[(this.pos0 + i) % 4 + 4];
                    if (defenNum && parseInt(defenNum) != 0) {
                        if (defenNum > 0) {
                            winArr.push(i);
                        }
                        if (defenNum < 0) {
                            loseArr.push(i);
                        }
                    }
                }

                //绘制金币特效
                for (var i = 0; i < winArr.length; i++) {
                    var winId = winArr[i];
                    for (var j = 0; j < loseArr.length; j++) {
                        var loseId = loseArr[j];

                        var _beginNode = (getUI(this, "head" + loseId)).getChildByName("head");
                        var _endNode = (getUI(this, "head" + winId)).getChildByName("head");
                        var _count = Math.abs(scoreList[(this.pos0 + loseArr[j]) % 4 + 4]);
                        this.playCoinsFlyAnim(_beginNode, _endNode, _count);
                    }
                }
            }
        }
    },
    //金币转移的特效
    playCoinsFlyAnim: function (beginNode, endNode, count) {

        //金币飞舞的声音
        AudioEngine.playEffect(resMusic.gold_fly);

        var beginPos = beginNode.convertToWorldSpace(beginNode.getPosition());
        var endPos = endNode.convertToWorldSpace(endNode.getPosition());

        for (var i = 0; i < count; i++) {
            this.coinFly(beginPos, endPos, i);
        }
    },
    //一个金币飞舞
    coinFly: function (beginPos, endPos, i) {
        var sprite = new cc.Sprite(this.goldTexture);
        sprite.setPosition(beginPos);
        this.addChild(sprite, 30);
        sprite.runAction(cc.sequence(
            cc.delayTime(0.01 * i),
            cc.jumpTo(0.5,
                cc.p(endPos.x - 30 + Math.floor(Math.random() * 61), endPos.y - 30 + Math.floor(Math.random() * 61)),
                30,
                1).easing(cc.easeOut(1.5)),
            cc.delayTime(0.2),
            cc.callFunc(function () {
                sprite.removeFromParent(true);
            })
        ))
    },

    userShowCard: function (card, isAuto, row, column) {
        var that = this;
        this.outCardRow = row + 1;
        this.outCardColumn = column + 1;

        //放炮罚玩法  射跑的判断
        if (mRoom.wanfatype == mRoom.FANGPAOFA ||
            mRoom.wanfatype == mRoom.LEIYANG ||
            mRoom.wanfatype == mRoom.SHAOYANGBOPI ||
            mRoom.wanfatype == mRoom.SHAOYANG ||
            mRoom.wanfatype == mRoom.XIANGXIANG ||
            mRoom.wanfatype == mRoom.CHENZHOU ||
            mRoom.mingwei == true) {
            var isShepao = false;
            for (var i = 1; i <= this.playersNum; i++) {
                if (mAction.combos[i] && mAction.combos[i].length > 0) {
                    for (var j = 0; j < mAction.combos[i].length; j++) {
                        if ((mAction.combos[i][j].typ == mCard.comboTypes.chouwei
                            || mAction.combos[i][j].typ == mCard.comboTypes.wei)
                            && parseInt(mAction.combos[i][j].cards[0]) == parseInt(card)) {
                            isShepao = true;
                            break;
                        }
                    }
                }
            }
            if (isShepao) {
                HUD.showMessageBox('提示', '射跑，之后您将无法吃、碰，请问是否出牌?', function () {
                    // that.fingerAni(false);
                    network.wsData("ShowCard/" + card + "/" + mRoom.outSeq, true);
                    this.tipLine.setVisible(false);
                });
                return;
            }
        }
        if (isAuto == true) {
            this.scheduleOnce(function () {
                that.fingerAni(false);
                network.wsData("ShowCard/" + card + "/" + mRoom.outSeq, true);
                this.tipLine.setVisible(false);
            }, 1);
        } else {
            that.fingerAni(false);
            //偎麻雀判断  是不是冻结的牌,冻结的牌不能出
            if (mRoom.wanfatype == mRoom.WEIMAQUE) {
                if (that.Freeze && that.Freeze.length > 0 && that.Freeze.indexOf(card) >= 0) {
                    return;
                }
            }
            network.wsData("ShowCard/" + card + "/" + mRoom.outSeq, true);
            this.tipLine.setVisible(false);
        }

        this.setTurnOutOver();

        if (mRoom.outSeq == null) {
            cc.log("outSeq is null");
        }
    },

    userAct: function (act, card, isAuto, info) {
        var actString = mAction.getActionString(act);
        if (info != null) {
            info = "/" + info;
        } else {
            info = "";
        }

        if (actString == "none") {
            actString = "guo";
        }

        network.wsData("EatCard/" + actString + "/" + card + "/" + mRoom.inSeq + info, true);

        this.setTurnInOver();
    },

    setTurnOutOver: function () {
        this.isTurnOut = false;
        this.secondsLeft = 0;
    },

    setTurnInOver: function () {
        this.nAction.setVisible(false);
        this.nChiList.removeAllChildren();
        this.secondsLeft = 0;
        this.isTurnIn = false;
        if (this.showCard.visible == false) {
            this.showCard.setVisible(true);
        }
    },

    onUserJoin: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        // if(data && data.Users && data.Users.length > 0){
        //     for(var i=0;i<data.Users.length;i++){
        //         if(data.Users[i].ID == gameData.uid){
        //             this.joinRoom = true;
        //             break;
        //         }
        //     }
        // }
        if (data.Result != null && data.Result == -1) {
            HUD.showMessageBox('提示', data.ErrorMsg, function () {
                clearGameMWRoomId();
                HUD.showScene(HUD_LIST.Home, this);
                AgoraUtil.closeVideo();
                DC.requestLastRoom = false;
                DC.closeByClient = true;
            }, true);
        } else {
            this.setupPlayers();
            var offLines = data.OfflineList;
            for (var i = 0; i < offLines.length; i++) {
                var userId = Math.abs(offLines[i]);
                this.setDisconnect(userId, offLines[i] < 0);
            }
        }
    },
    //掉线
    onUserDisconnect: function (event) {
        var data = event.getUserData();
        var flag = false;
        if (data.ConnectStatus == "disconnected") {
            flag = true;
        } else if (data.ConnectStatus == "online") {
            flag = false;
        }
        this.setDisconnect(data.UserID, flag);
    },
    onUserKick: function (event) {
        var data = event.getUserData();

        this.scheduleOnce(function () {
            gameData.errMessage = "当前账号已在IP：" + data.OtherIP + "登录，如不是您本人操作，请尽快确认您的微信账户安全。";
            HUD.showScene(HUD_LIST.Login, this);
            AgoraUtil.closeVideo();
            DC.closeByClient = true;
        }, 0);
    },
    Pls_Disconnect_MSG: function (event) {
        var data = event.getUserData();
    },

    onEatCard: function (event) {
        var data = event.getUserData();
        this.showReplayAction(data);
    },

    onStatusChange: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        cc.log("is Status Change  +++++", data.Status);
        //UserID
        if (data.Status == "ReadyForNext") {
            //断线回来
        }
        this.setDisconnect(data.UserID, false);
        this.setReady(data.UserID);
    },

    onPreAction: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        // cc.log("onPreAction   +++++", data.Action, data.Card);
    },

    onGameOver: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        this.showCard.setVisible(false);
        if (mRoom.isClean != true) {
            this.gameOverData = data;
            this.processGameOver();
            //显示别人的手牌
            if (mRoom.isReplay != true) {
                var users = DD[T.PlayerList];
                for (var i = 0; i < data.Users.length; i++) {
                    if (mRoom.getPlayerNum() == 3) {
                        if (data.Users[i].UserID == users[this.pos1].ID) {
                            DD[T.CardList1] = data.Users[i].Hand;
                            this.cardList1 = mCard.getCardList(DD[T.CardList1]);
                            this.setupOtherCards(1);
                            this.open1.setWeiColor(1);
                        } else if (data.Users[i].UserID == users[this.pos2].ID) {
                            DD[T.CardList2] = data.Users[i].Hand;
                            this.cardList2 = mCard.getCardList(DD[T.CardList2]);
                            this.setupOtherCards(2);
                            this.open2.setWeiColor(2);
                        }
                    } else {
                        if (data.Users[i].UserID == users[this.pos1].ID) {
                            DD[T.CardList1] = data.Users[i].Hand;
                            this.cardList1 = mCard.getCardList(DD[T.CardList1]);
                            this.setupOtherCards(1);
                            this.open1.setWeiColor(1);
                        } else if (data.Users[i].UserID == users[this.pos2].ID) {
                            DD[T.CardList2] = data.Users[i].Hand;
                            this.cardList2 = mCard.getCardList(DD[T.CardList2]);
                            this.setupOtherCards(2);
                            this.open2.setWeiColor(2);
                        } else if (data.Users[i].UserID == users[this.pos3].ID) {
                            DD[T.CardList3] = data.Users[i].Hand;
                            this.cardList3 = mCard.getCardList(DD[T.CardList3]);
                            this.setupOtherCards(3);
                            this.open3.setWeiColor(3);
                        }
                    }
                }
            }
            //显示那张牌胡的,显示偎的牌  Winner
            // for(var i=0;i<3;i++){
            //     var comboList = mAction.combos[i];
            //     for(var j=0;j<comboList.length;j++){
            //         var comb = comboList[j];
            //         if (comb.typ == mCard.comboTypes.wei) {
            //             this["open" + i].openWei(j+1, comb.cards[0]);
            //         }
            //     }
            // }
            // if(data.ByCard && data.Winner){
            //     var index = mRoom.getUserPosIndex(data.Winner);
            //     var handCards = this["nCards" + index].getChildren();
            //     var openCards = this["open" + index].getChildren();
            //     for(var i=0;i<handCards.length;i++){
            //         if(handCards[i].data == data.ByCard){
            //             var huicon = new cc.Sprite('res/image/ui/card/back.png');
            //             huicon.setAnchorPoint(cc.p(0.5, 0.5));
            //             huicon.setPosition(cc.p(handCards[i].getContentSize().width/2, handCards[i].getContentSize().height/2));
            //             huicon.setOpacity(160);
            //             huicon.setScaleX(73/42);
            //             huicon.setScaleY(110/42);
            //             handCards[i].addChild(huicon, 2);
            //             return;
            //         }
            //     }
            //     for(var i=0;i<openCards.length;i++){
            //         if(openCards[i].data == data.ByCard){
            //             var huicon = new cc.Sprite('res/image/ui/card/back.png');
            //             huicon.setAnchorPoint(cc.p(0.5, 0.5));
            //             huicon.setPosition(cc.p(openCards[i].getContentSize().width/2, openCards[i].getContentSize().height/2));
            //             huicon.setOpacity(160);
            //             huicon.setScaleX(73/42);
            //             huicon.setScaleY(110/42);
            //             openCards[i].addChild(huicon, 2);
            //             return;
            //         }
            //     }
            // }
        }
    },


    onResumeRoom: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        cc.log("room resume ==============");
        this.clearRoom();
        mRoom.resumeRoom(this, data);
    },

    //房间内断开重连
    onRoleLoginOK: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();

        this.txtUserName0.setString(ellipsisStr(gameData.nickname, 5));
    },

    onLeaveOK: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        //如果是自己离开的消息。socket关闭
        if (data.Users[0] == gameData.uid) {
            //cc.eventManager.removeAllListeners(););
            clearGameMWRoomId();
            HUD.showScene(HUD_LIST.Home, this);
            AgoraUtil.closeVideo();
        }

    },
    onJoinOK: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        if (data.Result != null && data.Result == -1) {
            HUD.showMessageBox('提示', data.ErrorMsg, function () {
                clearGameMWRoomId();
                HUD.showScene(HUD_LIST.Home, this);
                AgoraUtil.closeVideo();
                DC.requestLastRoom = false;
            }, true);
        } else {
            DD[T.PlayerList] = data['Users'];
            this.setupPlayers();
        }
    },

    processGameOver: function () {
        if (this.gameOverHuInfo == null) {
            playEffect('huangz');//胡不得
        } else {
            // if(this.gameOverData.WinnerZimo){
            //     // playEffect('zimo');//自摸
            //     this.playCPTPHEffect('hu', gameData.sex);
            // }else {
            //     this.playCPTPHEffect('hu', gameData.sex);
            // }
            if (this.showCard.visible == false) {
                this.showCard.setVisible(true);
            }

            if (this.gameOverData.Winner > 0) {
                var huType = "";
                if (this.gameOverData.HuType == 0x200) { //调将胡
                    huType = "hu";
                } else if (this.gameOverData.HuType == 0x40) { //跑胡
                    huType = "paohu";
                } else if (this.gameOverData.HuType == 0x20) { //平胡
                    huType = "hu";
                } else if (this.gameOverData.HuType == 0x8) { //扫胡,畏
                    huType = "saohu";
                } else if (this.gameOverData.HuType == 0x80) { //碰胡
                    huType = "penghu";
                } else if (this.gameOverData.HuType == 0x4) { //提胡
                    huType = "tihu";
                } else if (this.gameOverData.HuType == 0x1) {  //天胡
                    huType = "tianhu";
                } else if (this.gameOverData.HuType == 0x2) {  //地胡
                    huType = "dihu";
                } else if (this.gameOverData.HuType == 0x100) {  //吃胡
                    huType = "hu";
                } else {
                    huType = "hu";
                }
                if (this.gameOverData.FanRemark == "扫三大连胡") {
                    huType = "saosandalianhu";
                } else if (this.gameOverData.FanRemark == "扫四清连胡") {
                    huType = "saosiqinglianhu";
                } else if (this.gameOverData.FanRemark == "碰四清连胡") {
                    huType = "pengsiqinglianhu";
                } else if (this.gameOverData.FanRemark == "碰三大连胡") {
                    huType = "pengsandalianhu";
                } else if (this.gameOverData.FanRemark == "五福连胡"
                    || this.gameOverData.FanRemark == "碰五福连胡"
                    || this.gameOverData.FanRemark == "扫五福连胡") {
                    huType = "huwufu";
                }
                if (huType == "") {
                    huType = "hu";
                }
                var userInfo = mRoom.getUserByUserId(this.gameOverData.Winner);
                var userSex = 1;
                if (!userInfo) {
                    userSex = 1;
                } else {
                    userSex = userInfo.Sex;
                }
                this.playCPTPHEffect(huType, userSex);
            }
            this.flyCoin();//胜利飞金币
        }
        this.setTurnInOver();
        this.scheduleOnce(this.showGameResult, 2);
    },
    flyCoin: function () {
        //结算飞金币
        var winplayer = [];
        var loseplayer = [];
        for (var i = 0; i < this.gameOverData.Users.length; i++) {
            var gr = this.gameOverData.Users[i];
            var pos = mRoom.getUserPosIndex(gr.UserID);
            if (gr.Result > 0) {
                winplayer.push(pos);
            }
            if (gr.Result < 0) {
                loseplayer.push(pos);
            }
        }
        // console.log(loseplayer);
        // console.log(winplayer);
        var loseNodeList = [];
        var winNodeList = [];
        for (var i = 0; i < winplayer.length; i++) {
            var node = (getUI(this, "head" + winplayer[i])).getChildByName("head");
            winNodeList.push(node);
        }
        for (var i = 0; i < loseplayer.length; i++) {
            var node = (getUI(this, "head" + loseplayer[i])).getChildByName("head");
            loseNodeList.push(node);
        }
        for (var i = 0; i < loseNodeList.length; i++) {
            for (var j = 0; j < winNodeList.length; j++) {
                this.playCoinsFlyAnim(loseNodeList[i], winNodeList[j], 20);
            }
        }
    },
    onSetting: function (sender, type) {
        var setting = HUD.showLayer(HUD_LIST.Settings, this, false, true);
        setting.setSetting(this, "penghuzi");//penghuzi打开的界面
        setting.setLocalZOrder(5);
        setting.setSettingLayerType({hidelogout: true, hideyijianxiufu: true, isStart: this.isStart});
    },

    showGameResult: function () {
        // var gameResult = HUD.showLayer(HUD_LIST.GameResult, this);
        // gameResult.setLocalZOrder(3);
        // gameResult.setName("gameResult");
        // gameResult.setRoom(this, this.gameOverHuInfo, this.gameOverData, mRoom.isReplay);

        // var gameResultLayer = new GameResultLayer(this, this.gameOverHuInfo, this.gameOverData, mRoom.isReplay);
        // // gameResultLayer.setLocalZOrder(3);
        // // gameResultLayer.setName("gameResultLayer");
        // this.addChild(gameResultLayer);
        // gameResultLayer.setRoomInfo();


        var that = this;
        this.resultLayer.setVisible(true);
        var gameResult = this.resultLayer.getChildByName('gameResult');
        if (this.gameOverData.LeftCards && this.gameOverData.LeftCards.length > 0) {
            var leftcards = this.gameOverData.LeftCards;
            var dipai = getUI(this.resultLayer, "dipai");
            //dipai.setPositionX(1280/2 - (44 * leftcards.length) / 2 - 50);
            for (var i = 0; i < 25; i++) {
                var card = this.resultLayer.getChildByName("card" + i);
                if (card) card.removeFromParent();
            }
            for (var i = 0; i < leftcards.length; i++) {
                var card = HUD.showLayer(HUD_LIST.Card, this.resultLayer);
                card.setData(leftcards[i], null, 2);
                card.setName("card" + i);
                //横排显示
                //card.setPosition(cc.p(1280 / 2 - (leftcards.length / 2 - i) * 44 + 22, dipai.getPositionY() - 60));
                //三排显示，每行8个
                var _count = 8;
                var _scale = 0.8;
                var _x = 1280 / 2 - (Math.floor(i % _count) - 3) * 44 * _scale;   //锚点是（0,0）
                var _y = dipai.getPositionY() - (Math.floor(i / _count) + 0.5) * 44 * _scale;
                card.setScale(_scale);
                card.setPosition(cc.p(_x, _y));
            }
        }
        if (gameResult) {
            gameResult.removeFromParent();
        }
        gameResult = new GameResultLayer(this, this.gameOverHuInfo, this.gameOverData, mRoom.isReplay);
        this.resultLayer.addChild(gameResult);
        gameResult.setLocalZOrder(5);
        gameResult.setName("gameResult");
        gameResult.setRoomInfo();
        this.btn_resultbg.setLocalZOrder(6);
        this.btReady.setLocalZOrder(6);
        this.showJiesuan = true;

        //最后一局 点击显示总结算
        if (mRoom.curRound == mRoom.rounds) {
            TouchUtils.setOnclickListener(this.btReady, function () {
                that.showRoomClean();
            });
        } else {
            TouchUtils.setOnclickListener(this.btReady, function () {
                that.onReady();
            });
        }

        if (mRoom.isReplay) {
            this.btn_resultbg.setVisible(false);
            this.btJiesuan.setVisible(false);
            this.btn_xszm.setVisible(false);
            this.btReady.setVisible(false);
        } else {
            this.btJiesuan.setVisible(true);
            this.btn_xszm.setVisible(false);
            this.btReady.setVisible(true);
        }

        //单局结算分数清0
        if (mRoom.wanfatype == mRoom.YOUXIAN) {
            for (var i = 0; i < 4; i++) {
                var txt = this["txtHX" + i];
                txt.setString("得分:" + 0);
            }
        }

        // if(this.diaoPaoSprite){
        //     this.diaoPaoSprite.setVisible(false);
        // }
    },

    onRoomResult: function (event) {
        var data = event.getUserData();
        this.roomCleanData = data;
    },
    showRoomClean: function () {
        if (this.getChildByName('roomclean')) return;
        if (this.roomCleanData == null || this.roomCleanData == undefined) return;
        if (mRoom.wanfatype == mRoom.FANGPAOFA ||
            mRoom.wanfatype == mRoom.SHAOYANGBOPI ||
            mRoom.wanfatype == mRoom.XIANGXIANG) {
            var roomcleanfpf = HUD.showLayer(HUD_LIST.RoomCleanFpf, this, null, true);
            roomcleanfpf.setLocalZOrder(2);
            roomcleanfpf.setName("roomclean");
            roomcleanfpf.setRoom(this, this.roomCleanData);
            this.roomCleanData = null;
        } else if (mRoom.wanfatype == mRoom.YOUXIAN) {
            try {
                mRoom.voiceMap = {};
                DD[T.PlayerList] = [];
                var roomcleanPenghz = new RoomCleanPenghz();
                this.addChild(roomcleanPenghz);
                roomcleanPenghz.setLocalZOrder(2);
                roomcleanPenghz.setName("roomclean");
                roomcleanPenghz.setRoom(this, this.roomCleanData);
            } catch (e) {
                if (typeof e === 'string') {
                    alert1(e);
                }
                else {
                    alert1(e.message);
                }
            }
        } else {
            var roomclean = HUD.showLayer(HUD_LIST.RoomClean, this, null, true);
            roomclean.setLocalZOrder(2);
            roomclean.setName("roomclean");
            roomclean.setRoom(this, this.roomCleanData);
            this.roomCleanData = null;
        }
    },
    //语音
    initMic: function () {
        var that = this;
        var cancelOrSend = false;
        var chatTime = 0;
        var animNode = null;
        var voiceFilename = null;
        var uploadFilename = null;
        var btn_mic = getUI(this, "btn_mic");
        this.btn_mic = btn_mic;
        if (btn_mic == null)
            return;

        if (window.inReview || mRoom.isReplay)
            btn_mic.setVisible(false);

        TouchUtils.setListeners(btn_mic, {
            onTouchBegan: function (node, touch, event) {
                if (animNode && animNode.getParent()) {
                    animNode.removeFromParent();
                }

                cancelOrSend = true;
                var ccsScene = ccs.load("res/ccs/room/AnimMic.json", "res/");
                animNode = ccsScene.node;
                that.addChild(animNode);
                animNode.runAction(ccsScene.action);
                ccsScene.action.play('action', true);
                //
                chatTime = getCurrentTimeMills();
                voiceFilename = getCurTimestamp() + '-' + gameData.uid + '-';
                uploadFilename = voiceFilename;
                voiceFilename += Math.floor(Math.random() * 100) + '.spx';
                // cc.log(voiceFilename);
                VoiceUtils.startRecord(voiceFilename);
            },
            onTouchMoveIn: function (node, touch, event) {
                if (!cancelOrSend) {
                    cancelOrSend = true;

                    animNode.removeFromParent();
                    // animNode = playAnimScene(that, "res/ccs/room/AnimMic.json", 0, 0, true);
                    animNode = HUD.showLayer(HUD_LIST.AnimMic, that);
                }
            },
            onTouchMoveOut: function (node, touch, event) {
                if (cancelOrSend) {
                    cancelOrSend = false;
                    animNode.removeFromParent();
                    // animNode = ccs.load("res/ccs/room/ChatNotSendNode.json").node;
                    animNode = HUD.showLayer(HUD_LIST.ChatNotSendNode, that);
                    animNode.setPosition(that.getContentSize().width / 2, that.getContentSize().height / 2);
                }
            },
            onTouchEndedWithoutCheckTouchMe: function (node, touch, event) {
                chatTime = getCurrentTimeMills() - chatTime;
                animNode.removeFromParent();
                animNode = null;
                if (cancelOrSend) {
                    if (chatTime > 1000) {
                        VoiceUtils.stopRecord(voiceFilename);
                        var interval = null;
                        var checkFunc = function () {
                            var isOpened = OldVoiceUtils.isFileOpened(voiceFilename);
                            if (!isOpened) {
                                clearInterval(interval);
                                uploadFilename = uploadFilename + '' + (Math.floor(chatTime) + 500) + '.spx';
                                NetUtils.uploadFileToOSS(voiceFilename, uploadFilename, function (url) {
                                    //network.send(3008, {room_id: gameData.roomId, type: 'voice', content: url});
                                    var urlbase64 = encodeURIComponent(url);
                                    var msg = JSON.stringify({
                                        roomid: mRoom.roomId,
                                        type: 'voice',
                                        voice: '',
                                        content: urlbase64,
                                        from: gameData.uid
                                    });
                                    network.wsData("Say/" + msg);
                                }, function () {
                                    // console.log('upload fail');
                                });
                            }
                        };
                        interval = setInterval(checkFunc, 32);
                    } else {
                        // animNode = ccs.load("res/ccs/room/ChatErrorNode.json").node;
                        animNode = HUD.showLayer(HUD_LIST.ChatErrorNode, that);
                        animNode.setPosition(that.getContentSize().width / 2, that.getContentSize().height / 2);
                        animNode.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(function () {
                            animNode.removeFromParent();
                            animNode = null;
                        })));
                        VoiceUtils.stopRecord(voiceFilename);
                    }
                }
                else
                    VoiceUtils.stopRecord(voiceFilename);
            }
        });
    },
    initChatBtn: function () {
        if (mRoom.isReplay == true || window.inReview) {
            this.chat.setVisible(false);
            return;
        }
        var that = this;
        // var chatposX = cc.sys.localStorage.getItem("chatposX");
        // var chatposY = cc.sys.localStorage.getItem("chatposY");
        // if(chatposX == null || chatposX == undefined || chatposX == "") chatposX = SW - 45;
        // if(chatposY == null || chatposY == undefined || chatposY == "") chatposY = SH/2;
        // if(chatposX <= 0 || chatposX >= SW) chatposX = SW - 45;
        // if(chatposY <= 0 || chatposY >= SH) chatposY = SH/2;
        // this.chat.setPosition(cc.p(chatposX, chatposY));
        var btn_chat = this.chat;

        var touchbeginpos = null;
        TouchUtils.setListeners(btn_chat, {
            onTouchBegan: function (node, touch, event) {
                touchbeginpos = touch.getLocation();
            },
            onTouchMoved: function (node, touch, event) {
                // btn_chat.setPosition(touch.getLocation());
            },
            onTouchEnded: function (node, touch, event) {
                var position = touch.getLocation();
                if (Math.abs(touchbeginpos.x - position.x) < 4 && Math.abs(touchbeginpos.y - position.y) < 4) {
                    var chatLayer = new ChatLayer();
                    that.addChild(chatLayer);
                } else {
                    var movexy = [];
                    var minmovepos = SW;
                    var movedir = "x";
                    movexy[0] = 0 - position.x + 45;
                    movexy[1] = SW - position.x - 45;
                    movexy[2] = 0 - position.y + 45;
                    movexy[3] = SH - position.y - 45;
                    for (var i = 0; i < 4; i++) {
                        if (Math.abs(minmovepos) >= Math.abs(movexy[i])) {
                            movedir = (i <= 1) ? "x" : "y";
                            minmovepos = movexy[i];
                        }
                    }
                    if (movedir == "x") {
                        btn_chat.runAction(cc.sequence(
                            cc.sequence(cc.moveBy(0.5, cc.p(minmovepos, 0)).easing(cc.easeIn(0.3)))
                        ));
                        cc.sys.localStorage.setItem("chatposX", position.x + minmovepos);
                        cc.sys.localStorage.setItem("chatposY", position.y);
                    } else {
                        btn_chat.runAction(cc.sequence(
                            cc.sequence(cc.moveBy(0.5, cc.p(0, minmovepos)).easing(cc.easeIn(0.3)))
                        ));
                        cc.sys.localStorage.setItem("chatposX", position.x);
                        cc.sys.localStorage.setItem("chatposY", position.y + minmovepos);
                    }
                }
            }
        });
    },

    setReady: function (uid) {
        var row = mRoom.getUserPosIndex(uid);
        var head = getUI(this, "head" + row);
        var ready = head.getChildByName('ready');
        if (!ready) {
            ready = new cc.Sprite(res.ready_png);
            ready.setName('ready');
            ready.setAnchorPoint(cc.p(0.5, 0.5));
            ready.setPosition(cc.p(head.getContentSize().width / 2, (row == 1 || row == 2) ? -20 : 120));
            head.addChild(ready);
        }
        ready.setVisible(true);
    },
    setAllReadyVisible: function (flag) {
        for (var i = 0; i < mRoom.getPlayerNum(); i++) {
            var head = getUI(this, "head" + i);
            var ready = head.getChildByName('ready');
            if (!ready) {
                ready = new cc.Sprite(res.ready_png);
                ready.setName('ready');
                ready.setAnchorPoint(cc.p(0.5, 0.5));
                ready.setPosition(cc.p(head.getContentSize().width / 2, (i == 1 || i == 2) ? -20 : 120));
                head.addChild(ready);
            }
            ready.setVisible(flag);
        }
    },
    setZhuangjia: function (pos, lzhuang) {
        if (pos == undefined || pos < 0) return;
        //不足三人不显示庄家
        var users = DD[T.PlayerList];
        if (users != undefined && users.length == this.playersNum) {
            for (var i = 0; i < this.playersNum; i++) {
                var head = getUI(this, "head" + i);
                var zhuang = head.getChildByName('zhuang');
                if (!zhuang) {
                    if (parseInt(lzhuang) >= 0) {
                        if (lzhuang > 9) {
                            lzhuang = 0;
                        }
                        zhuang = new cc.Sprite(res['room_zhuang' + (lzhuang + 1) + '_png']);
                    } else {
                        zhuang = new cc.Sprite(res.room_zhuang1_png);
                    }
                    zhuang.setName('zhuang');
                    zhuang.setAnchorPoint((i != 1) ? cc.p(0, 1) : cc.p(1, 1));
                    zhuang.setPosition((i != 1) ? cc.p(55 - 18 + 4, 105 - 22 + 4) : cc.p(20 + 22 - 4, 105 - 22 + 4));
                    head.addChild(zhuang);
                } else {
                    if (parseInt(lzhuang) > 9) {
                        lzhuang = 0;
                    }
                    zhuang.setTexture(res['room_zhuang' + (lzhuang + 1) + '_png']);
                }
                var index = mRoom.getUserIndex(gameData.uid);
                zhuang.setVisible(((index + i) % this.playersNum == pos) ? true : false);
            }
        }
    },
    isZhuangjia: function () {
        var head = getUI(this, "head0");
        var zhuang = head.getChildByName('zhuang');
        if (zhuang && zhuang.isVisible()) {
            return true;
        } else {
            return false;
        }
    },
    beginReplay: function () {
        this.clearRoom();
        this.setupPlayers();
    },
    setDisconnect: function (uid, flag) {
        var row = mRoom.getUserPosIndex(uid);
        var head = getUI(this, "head" + row);
        var disconnect = head.getChildByName('disconnect');
        if (!disconnect) {
            disconnect = new cc.Sprite(res.disconnect_png);
            disconnect.setName('disconnect');
            disconnect.setAnchorPoint(cc.p(0.5, 0.5));
            disconnect.setPosition(cc.p(head.getContentSize().width / 2, head.getContentSize().height / 2));
            disconnect.setScale(head.getContentSize().width / disconnect.getContentSize().width)
            head.addChild(disconnect);
        }
        disconnect.setVisible(flag);
    },
    onJushou_Status: function (event) {
        if (this.checkNoRunning())    return;
        var data = event.getUserData();
        var canchupai = true;
        if (data && data.Users) {
            for (var i = 0; i < data.Users.length; i++) {
                this.setJushou(data.Users[i].UserID, data.Users[i].IsSet, data.Users[i].CanSet);
                if (data.Users[i].CanSet == 1 && data.Users[i].IsSet == 0) {
                    canchupai = false;
                }
            }
        }
        this.setMyCardsTouch(canchupai);
    },
    setJushou: function (uid, isset, canset, status) {
        if (mRoom.wanfatype != mRoom.LEIYANG) return;
        var row = mRoom.getUserPosIndex(uid);
        var head = getUI(this, "head" + row);
        var info = getUI(this, "info" + row);
        //举手中
        var jushou = head.getChildByName('jushou');
        if (!jushou) {
            jushou = new cc.Sprite(res.jushouzhong2_png);
            jushou.setName('jushou');
            jushou.setAnchorPoint(cc.p(0.5, 0.5));
            var jushoupos = cc.p(150, 50);
            if (row == 1) {
                jushoupos = cc.p(-170, 50);
            } else if (row == 2) {
                jushoupos = cc.p(270, 50);
            }
            jushou.setPosition(jushoupos);
            head.addChild(jushou);
            jushou.setVisible(false);
        }
        if (jushou) {
            //已举手
            if (isset == 1) {
                jushou.setVisible(true);
                jushou.setTexture(res.yijushou2_png);
            }
            //举手中
            if (canset == 1 && isset == 0) {
                jushou.setVisible(true);
                jushou.setTexture(res.jushouzhong2_png);
            }
            //不举手
            if (isset == 2) {
                jushou.setVisible(false);
            }
        }
        if (gameData.uid == uid) {
            if (canset == 1 && isset == 0) {
                this.jushou.setVisible(true);
                this.bujushou.setVisible(true);
            } else {
                this.jushou.setVisible(false);
                this.bujushou.setVisible(false);
            }
        }
        if (status == false) {
            jushou.setVisible(false);
        }
    },
    setMyCardsTouch: function (status) {
        var cardList = this.nCards0.getChildren();
        for (var i = 0; i < cardList.length; i++) {
            var card = cardList[i];
            card.setTouchEnableStatus(status);
        }
    },
    //报警
    onBaojing: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        for (var i = 0; i < data.Users.length; i++) {
            this.setBaojing(data.Users[i].UserID, data.Users[i].Stat);
        }
    },
    //反省
    onFanXing: function (event) {
        // if (this.checkNoRunning()) return;
        // var data = event.getUserData();
        // if(gameData.uid == data.UserID && data.Status != 5) {
        //     this.scheduleOnce(function () {
        //         var fanxing = HUD.showLayer(HUD_LIST.FanXing, this);
        //         fanxing.setData(data);
        //     }, 1);
        // }
    },
    setBaojing: function (uid, status) {
        var row = mRoom.getUserPosIndex(uid);
        var head = getUI(this, "head" + row);
        var info = getUI(this, "info" + row);
        //举手中
        var baojing = head.getChildByName('baojing');
        var baojingAni = head.getChildByName('baojingAni');
        if (!baojing) {
            //报警图片
            baojing = new cc.Sprite(res.baojingwan1_png);
            baojing.setName('baojing');
            baojing.setAnchorPoint(cc.p(0.5, 0.5));

            //报警动画
            var ccsScene = ccs.load(res.MJ_baojingdeng_json, "res/");
            baojingAni = ccsScene.node;
            baojingAni.setScale(0.5);
            baojingAni.setName('baojingAni');
            baojingAni.runAction(ccsScene.action);
            ccsScene.action.play('action', true);

            var jushoupos = cc.p(50, 150);
            if (row == 0) {
                jushoupos = cc.p(220, 60);
            } else if (row == 1) {
                jushoupos = cc.p(-180, 60);
            } else if (row == 3) {
                jushoupos = cc.p(220, 60);
            } else if (row == 2) {
                jushoupos = cc.p(50, -30);
            }

            baojing.setPosition(jushoupos);
            baojingAni.setPosition(jushoupos);
            head.addChild(baojing);
            head.addChild(baojingAni);
            baojing.setVisible(false);
            baojingAni.setVisible(false);


        }
        if (baojing) {
            if (status == 2) {
                //已报警
                baojing.setVisible(true);
                baojing.setTexture((row == 2)
                    ? res.baojingwan1_png : res.baojingwan2_png);
                if (baojingAni) {
                    baojingAni.setVisible(false);
                }

            } else if (status == 1) {
                //报警中
                baojing.setVisible(false);
                baojing.setTexture((row == 2)
                    ? res.baojingzhong1_png : res.baojingzhong2_png);
                if (baojingAni)
                    baojingAni.setVisible(true);
            } else {
                baojing.setVisible(false);
                if (baojingAni)
                    baojingAni.setVisible(false);
            }
        }
        if (uid == gameData.uid && status == 1) {
            //0:不能设置报警  1:能设置，但是没有设置  2:已经报警  3:选择不报警
            HUD.showConfirmBox('报警', '选择报警或者不报警', function () {
                network.wsData("Baojing/2");
            }, "报警", function () {
                network.wsData("Baojing/3");
            }, "不报警");
        }
    },
    onNiao_Status: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        this.invite.setVisible(false);
        this.inviteXianLiao.setVisible(false);
        this.btn_inviteLiaobei.setVisible(false);

        this.tuichu.setOpacity(50);
        TouchUtils.setClickDisable(this.tuichu, true);
        this.jiesan.setOpacity(255);
        TouchUtils.setClickDisable(this.jiesan, false);

        var isSelfSelect = false;
        for (var i = 0; i < data.Users.length; i++) {
            this.setSelectNiao(data.Users[i].UserID, data.Users[i].IsSet, true, data.Users[i].TuoNiao);
            if (data.Users[i].UserID == gameData.uid && data.Users[i].IsSet == 1) {
                isSelfSelect = true;
            }
        }
        if (isSelfSelect == false && mRoom.isReplay != true) {
            //准备娄底放炮罚  加抓鸟选项
            if (mRoom.niao == true && this.zhuoniao == null) {
                var zhuoniao = HUD.showLayer(HUD_LIST.Zhuoniao, this);
                this.zhuoniao = zhuoniao;
            }
        }
    },
    //选鸟
    setSelectNiao: function (uid, niaotype, hide, niaonum) {
        if (mRoom.niao != true) return;
        var row = mRoom.getUserPosIndex(uid);
        var head = getUI(this, "head" + row);
        var niao = head.getChildByName('niao');
        if (!niao) {
            niao = new cc.Sprite((row == 0) ? 'res/image/ui/room/zhuaniao/znzhong2.png' : 'res/image/ui/room/zhuaniao/znzhong1.png');
            niao.setName('niao');
            niao.setAnchorPoint(cc.p(0.5, 0.5));
            niao.setPosition((row == 0) ? cc.p(150, 50) : cc.p(50, -50));
            head.addChild(niao);
        }
        var info = getUI(this, "info" + row);
        var niaoLabel = getUI(info, "niaonum" + row);
        if (niaoLabel) {
            niaoLabel.setVisible(false);
            if (niaonum != undefined) niaoLabel.setString("拖鸟:" + niaonum);
        }

        if (hide == false) {
            niao.setVisible(false);
        } else {
            niao.setVisible(true);
            if (niaotype == 0) {
                niao.setTexture((row == 0) ? 'res/image/ui/room/zhuaniao/znzhong2.png' : 'res/image/ui/room/zhuaniao/znzhong1.png');
            } else {
                niao.setTexture((row == 0) ? 'res/image/ui/room/zhuaniao/yzn2.png' : 'res/image/ui/room/zhuaniao/yzn1.png');
            }
        }
        //如果是自己 并且没设置 显示捉鸟界面
        if (uid == gameData.uid && niaotype == 0 && mRoom.isReplay != true && this.isStart == true) {
            //准备娄底放炮罚  加抓鸟选项
            if (mRoom.niao == true && this.zhuoniao == null) {
                var zhuoniao = HUD.showLayer(HUD_LIST.Zhuoniao, this);
                this.zhuoniao = zhuoniao;
            }
        }
    },
    setNiaoNumVisible: function (uid, visible) {
        if (mRoom.niao == true) {
            var row = mRoom.getUserPosIndex(uid);
            var info = getUI(this, "info" + row);
            var head = getUI(this, "head" + row);
            var niaoLabel = getUI(info, "niaonum" + row);
            if (niaoLabel) {
                niaoLabel.setVisible(visible);
            }
            var niao = head.getChildByName('niao');
            if (niao) {
                niao.setVisible(!visible);
            }
        }
    },
    //更换字体
    setCardFont: function () {
        for (var i = 0; i < this.playersNum; i++) {
            var open = this["open" + i];
            var openChileren = open.getChildren();
            for (var j = 0; j < openChileren.length; j++) {
                openChileren[j].resetCardImg();
            }
            var out = this["out" + i];
            var outChileren = out.getChildren();
            for (var j = 0; j < outChileren.length; j++) {
                outChileren[j].resetCardImg();
            }
        }
        var mycards = this.nCards0.getChildren();
        for (var j = 0; j < mycards.length; j++) {
            mycards[j].resetCardImg();
        }
    },
    getRowByUid: function (uid) {
        //麻将和跑胡子坐标转换
        var row = mRoom.getUserPosIndex(uid);
        return row;
    },
    getRootNode: function () {
        return this.playersInfo;
    }
};
