(function () {
    var exports = this;

    var $ = null;

    var DaiKaiItem = cc.Layer.extend({
        layerHeight: 0,
        ctor: function (data, isNew, isWhite, parent) {
            this._super();
            var that = this;

            if(data['option']) {
                data['option'] = JSON.parse(data['option']);
            }
            if(data['optionstring']) {
                data['option'] = JSON.parse(data['optionstring']);
            }

            var scene = ccs.load(res.DaiKaiItem_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            this.layerHeight = this.getChildByName("Layer").getBoundingBox().height;

            TouchUtils.setOnclickListener($('button_yq'), function () {
                var title = "";
                var content = "";

                if(data['map_id'] == MAP_ID_DN) {
                    title = COMPANYNAME[gameData.appId]+"拼十-" + data['room_id'];
                    content = COMPANYNAME[gameData.appId]+"拼十" + data['wanfa'];
                }else if(data['map_id'] == MAP_ID_PDK) {
                    title = COMPANYNAME[gameData.appId]+"跑得快-" + data['room_id'];
                    content = COMPANYNAME[gameData.appId]+"跑得快" + data['wanfa'];
                }else if(data['map_id'] == MAP_ID_ZJH){
                    title = COMPANYNAME[gameData.appId]+"拼三张-" + data['room_id'];
                    content = COMPANYNAME[gameData.appId]+"拼三张" + data['wanfa'];
                }else{
                    title = COMPANYNAME[gameData.appId]+"碰胡子-" + data['room_id'];
                    content = COMPANYNAME[gameData.appId]+"碰胡子-" + data['wanfa'];
                }
                WXUtils.shareUrl(MWINDOWURL[gameData.appId] + '?roomid='+mRoom.roomId, title, content, 0, getCurTimestamp() + gameData.uid);
            });

            TouchUtils.setOnclickListener($('button_js'), function () {
                alert2("是否确定解散该房间？", function () {
                    showLoading();
                    network.send(3003, {daikai_room_id: data['room_id']});
                }, function () {

                });
            });

            $('button_yq').setVisible(!data['is_start']);
            $('button_js').setVisible(!data['is_start']);

            if(data['room_id']) {
                $('lb_roomid').setString(data['room_id']);
            }
            if(data['roomid']) {
                $('lb_roomid').setString(data['roomid']);
            }
            if (isNew) {
                //代开
                // $('lb_jushu').setVisible(false);
                if (data['is_start']) {
                    $('lb_state').setString('已开始');
                    $('button_yq').setVisible(false);
                    $('button_js').setVisible(false);
                } else {
                    $('lb_state').setString('未开始');
                }
                if(data['nicknames']) {
                    for (var i = 0; i < 6; i++) {
                        var nickname = data['nicknames'][i];
                        var header = data['heads'][i];
                        if (nickname) {
                            if(header == null || header == undefined || header == ""){
                                $('header' + (i + 1)).setTexture(res.defaultHead)
                            }else{
                                loadImageToSprite(decodeURIComponent(header), $('header' + (i + 1)));
                            }
                            $('lb_nickname' + (i + 1)).setString(ellipsisStr(nickname, 7));
                            $('lb_nickname' + (i + 1)).setVisible(true);
                            $('header' + (i + 1)).setVisible(true);
                        } else {
                            $('lb_nickname' + (i + 1)).setVisible(false);
                            $('header' + (i + 1)).setVisible(false);
                        }
                    }
                }else{
                    for (var i = 0; i < 6; i++) {
                        $('lb_nickname' + (i + 1)).setVisible(false);
                        $('header' + (i + 1)).setVisible(false);
                    }
                }
            } else {
                //已开
                if (data['cardused'] != 0) {
                    $('lb_state').setVisible(true);
                    $('lb_state').setString('已扣卡(' + data['cur_round'] + "/" + data['total_round'] + ")");
                } else {
                    $('lb_state').setVisible(true);
                    $('lb_state').setString('未扣卡(' + data['cur_round'] + "/" + data['total_round'] + ")");
                }
                if(data['nickname1']) {
                    for (var i = 0; i < 6; i++) {
                        var nickname = data['nickname' + (i+1)];
                        var header = data['heads'][i];
                        if (nickname) {
                            if(header == null || header == undefined || header == ""){
                                $('header' + (i + 1)).setTexture(res.defaultHead)
                            }else{
                                loadImageToSprite(decodeURIComponent(header), $('header' + (i + 1)));
                            }
                            $('lb_nickname' + (i + 1)).setString(ellipsisStr(nickname, 7));
                            $('lb_nickname' + (i + 1)).setVisible(true);
                            $('header' + (i + 1)).setVisible(true);
                        } else {
                            $('lb_nickname' + (i + 1)).setVisible(false);
                            $('header' + (i + 1)).setVisible(false);
                        }
                    }
                }else{
                    for (var i = 0; i < 6; i++) {
                        $('lb_nickname' + (i + 1)).setVisible(false);
                        $('header' + (i + 1)).setVisible(false);
                    }
                }
            }

            //牛牛的解散  只要有2人  就不能解散
            if(data['map_id'] == MAP_ID_DN && data['nicknames'] && data['nicknames'][1]){
                $('button_js').setVisible(false);
            }

            var wanfastr = COMPANYNAME[gameData.appId]+"碰胡子";
            if(data['map_id'] == MAP_ID_DN) {
                wanfastr = COMPANYNAME[gameData.appId]+"拼十";
            }else if(data['map_id'] == MAP_ID_PDK) {
                wanfastr = COMPANYNAME[gameData.appId]+"跑得快" ;
            }else if(data['map_id'] == MAP_ID_ZJH){
                wanfastr = COMPANYNAME[gameData.appId]+"拼三张";
            }
            $('lb_wanfa').setString(wanfastr + data['wanfa']); //mRoom.getWanfaName(data['option']['wanfa']) + data['option']['wanfadesc']);
            if(data['create_time']){
                $('lb_time').setString(timestamp2time(data['create_time']));
            }
            if(data['createtime']){
                $('lb_time').setString(timestamp2time(data['createtime']));
            }

            $('bgPanel.cellbg').setVisible(isWhite);
            $('bgPanel.cellbg2').setVisible(!isWhite);

            return true;
        },
        getLayerHeight: function () {
            return this.layerHeight;
        }
    });

    exports.DaiKaiItem = DaiKaiItem;
})(window);
