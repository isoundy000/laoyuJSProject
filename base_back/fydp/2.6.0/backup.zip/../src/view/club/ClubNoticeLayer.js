(function () {
    var exports = this;

    var $ = null;

    var ClubNoticeLayer = cc.Layer.extend({
        // onEnter: function () {
        //     cc.Layer.prototype.onEnter.call(this);
        // },
        ctor: function (data) {
            this._super();

            var that = this;
            var notice = data["notice"] == "" ? "暂无公告！" : data["notice"];
            var content = "【" + data["name"] + "】俱乐部：" + notice;
            if (!notice) {
               content = '俱乐部暂无公告';
            }

            var Layer = ccs.load(res.ClubNoticeLayer_json, 'res/');
            this.addChild(Layer.node);
            $ = create$(this.getChildByName("Layer"));
            $('lb_content').setString(content);
            TouchUtils.setOnclickListener($('btn_back'), function (node) {
                // that.setVisible(false);
                that.removeFromParent();
            });

            TouchUtils.setOnclickListener($('black'), function (node) {
                // that.setVisible(false);
                that.removeFromParent();
            });
            return true;
        },
        setContent: function (data) {
            var that = this;
            var notice = data["notice"] == "" ? "暂无公告！" : data["notice"];
            var content = data["name"] + "俱乐部：" + notice;
            $('lb_content').setString(content);
        }
    });

    exports.ClubNoticeLayer = ClubNoticeLayer;
})(window);



