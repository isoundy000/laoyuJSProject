/**
 * Created by wcc on 2018/4/7.
 */
(function () {
    var exports = this;

    var $ = null;

    var ClubZhanjiLayer = cc.Layer.extend({
        ctor: function (club_id) {
            this._super();
            this.club_id = club_id;
            var that = this;

            var mainscene = ccs.load(res.History_json, "res/");
            this.addChild(mainscene.node);

            this.init();
        },
        init: function () {
            var that = this;
            this.btBack = getUI(this, "btn_back");
            this.scrollview = getUI(this, "scrollview");
            this.btOthers = getUI(this, "btOthers");
            this.btOthers.setVisible(false);
            TouchUtils.setOnclickListener(this.btBack, function () {
                that.removeFromParent();
            }, {sound: 'close'});


            //按钮 0碰胡子 1牛牛 2麻将 3跑得快 4拼三张
            var showBtnArr = [0, 1, 2, 3, 4];
            if(gameData.appId == APP_ID.FYDP){
                showBtnArr = [1, 2, 3, 4, 5];
            }
            if(gameData.appId == APP_ID.PENGHUZI){
                showBtnArr = [0, 1, 2, 3];
            }

            var index = 0;
            for(var i=0;i<6;i++){
                this['bt' + i] = getUI(this, 'btn_' + i);
                if(showBtnArr.indexOf(i) >= 0){
                    this['bt' + i].setPositionX(150 + index*170);
                    index++;
                }else{
                    this['bt' + i].setVisible(false);
                }
            }
            var tab1 = res.history_tab2;
            var tab1_1 = res.history_tab2_1;
            var tab2 = res.history_tab3;
            var tab2_1 = res.history_tab3_1;
            if (gameData.appId == APP_ID.FYDP) {
                tab1 = res.history_tab4;
                tab1_1 = res.history_tab4_1;
                tab2 = res.history_tab5;
                tab2_1 = res.history_tab5_1;
            }
            this.bt0.setTexture(res.history_tab1);
            this.bt1.setTexture(tab1_1);
            this.bt2.setTexture(tab2_1);

            if(showBtnArr.indexOf(0) >= 0){
                //有碰胡子
                this.zhanjiTab = "penghuzi";
                this.bt1.setTexture(tab1_1);
            }else{
                this.zhanjiTab = "dn";
                this.bt1.setTexture(tab1);
            }
            TouchUtils.setOnclickListener(this.bt0, function () {
                if (that.zhanjiTab != "penghuzi") {
                    that.zhanjiTab = "penghuzi";
                    that.bt0.setTexture(res.history_tab1);
                    that.bt1.setTexture(tab1_1);
                    that.bt2.setTexture(tab2_1);
                    that.bt3.setTexture(res.history_tab6_1);
                    that.bt4.setTexture(res.history_tab7_1);
                    that.bt5.setTexture(res.history_tab8_1);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});
            TouchUtils.setOnclickListener(this.bt1, function () {
                if (that.zhanjiTab != "dn") {
                    that.zhanjiTab = "dn";
                    that.bt0.setTexture(res.history_tab1_1);
                    that.bt1.setTexture(tab1);
                    that.bt2.setTexture(tab2_1);
                    that.bt3.setTexture(res.history_tab6_1);
                    that.bt4.setTexture(res.history_tab7_1);
                    that.bt5.setTexture(res.history_tab8_1);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});
            TouchUtils.setOnclickListener(this.bt2, function () {
                if (that.zhanjiTab != "majiang") {
                    that.zhanjiTab = "majiang";
                    that.bt0.setTexture(res.history_tab1_1);
                    that.bt1.setTexture(tab1_1);
                    that.bt2.setTexture(tab2);
                    that.bt3.setTexture(res.history_tab6_1);
                    that.bt4.setTexture(res.history_tab7_1);
                    that.bt5.setTexture(res.history_tab8_1);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});
            TouchUtils.setOnclickListener(this.bt3, function () {
                if (that.zhanjiTab != "pdk") {
                    that.zhanjiTab = "pdk";
                    that.bt0.setTexture(res.history_tab1_1);
                    that.bt1.setTexture(tab1_1);
                    that.bt2.setTexture(tab2_1);
                    that.bt3.setTexture(res.history_tab6);
                    that.bt4.setTexture(res.history_tab7_1);
                    that.bt5.setTexture(res.history_tab8_1);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});
            TouchUtils.setOnclickListener(this.bt4, function () {
                if (that.zhanjiTab != "zjh") {
                    that.zhanjiTab = "zjh";
                    that.bt0.setTexture(res.history_tab1_1);
                    that.bt1.setTexture(tab1_1);
                    that.bt2.setTexture(tab2_1);
                    that.bt3.setTexture(res.history_tab6_1);
                    that.bt4.setTexture(res.history_tab7);
                    that.bt5.setTexture(res.history_tab8_1);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});
            TouchUtils.setOnclickListener(this.bt5, function () {
                if (that.zhanjiTab != "kaokao") {
                    that.zhanjiTab = "kaokao";
                    that.bt0.setTexture(res.history_tab1_1);
                    that.bt1.setTexture(tab1_1);
                    that.bt2.setTexture(tab2_1);
                    that.bt3.setTexture(res.history_tab6_1);
                    that.bt4.setTexture(res.history_tab7_1);
                    that.bt5.setTexture(res.history_tab8);
                    that.createContent();
                    that.reTry();
                }
            }, {sound: 'tab'});

            this.createContent();
            this.reTry();

            return true;
        },
        reTry: function (retryCnt) {
            var that = this;

            retryCnt = typeof retryCnt === 'undefined' ? 0 : retryCnt;
            var urlreq = "/Record/youxianRecord";
            var req = {UserID: gameData.uid, mapid: 310};
            if (that.zhanjiTab == "majiang") {
                req = {
                    UserID: gameData.uid,
                    mapid: "" + MAP_ID.CHANGSHA + "," + MAP_ID.ZHUANZHUAN + "," + MAP_ID.HONGZHONG + ","
                    + MAP_ID.SICHUAN_XUELIU + "," + MAP_ID.SICHUAN_XUEZHAN + "," + MAP_ID.SICHUAN_MZ + "," + MAP_ID.SICHUAN_TRLF
                    , club_id:this.club_id
                };
                urlreq = "/Record/niuniuRecord";
            } else if (that.zhanjiTab == "dn") {
                req = {
                    UserID: gameData.uid,
                    mapid: "4000,400",
                    club_id:this.club_id
                };
                urlreq = "/Record/niuniuRecord";
            } else if (that.zhanjiTab == "pdk") {
                req = {
                    UserID: gameData.uid,
                    mapid: MAP_ID.PDK,
                    club_id:this.club_id
                };
                urlreq = "/Record/niuniuRecord";
            }else if (that.zhanjiTab == "zjh") {
                req = {
                    UserID: gameData.uid,
                    mapid: MAP_ID.ZJH,
                    club_id:this.club_id
                };
                urlreq = "/Record/niuniuRecord";
            }else if (that.zhanjiTab == "kaokao"){
                req = {
                    UserID: gameData.uid,
                    mapid: MAP_ID.CP_KAOKAO,
                    club_id:this.club_id
                };
                urlreq = "/Record/mianzhuRecord";
            }
            //var ip = gameData.ipList[parseInt(retryCnt) % gameData.ipList.length];
            var ip = "http://rec.yygameapi.com:56790";
            // this.ip = ip;
            this.ip = 'http://gg-paohuzi.oss-cn-hangzhou.aliyuncs.com/niuniu-rec/';
            DC.httpData(urlreq, req, function (data) {
                cc.log(data);
                if (data != null && data.result == 0) {
                    that.ip = ip;//正确的ip
                    that.itemList = data.data;
                    if (that.itemList) {
                        var lb_nozhanji = getUI(that, "lb_nozhanji");
                        lb_nozhanji.setVisible(that.itemList.length == 0);
                    }
                    that.itemList.sort(function (a, b) {
                        return b.create_time - a.create_time;
                    });
                    tableViewRefresh(that.tableView);

                    var bg_cell = getUI(that, 'bg_cell');
                    if(that.zhanjiTab == "dn" || that.zhanjiTab == "zjh"){
                        bg_cell.setVisible((that.itemList && that.itemList.length == 0));
                    }else{
                        bg_cell.setVisible(true);
                    }

                    //移动到第一行
                    var innerHeight = that.itemList.length * 130;
                    if (that.zhanjiTab == "dn" || that.zhanjiTab == "zjh") {
                        innerHeight = 0;
                        for (var k = 0; k < that.itemList.length; k++) {
                            var curH = 240;
                            if (that.itemList[k]["uid7"]) {
                                curH = 500;
                            } else if (that.itemList[k]["uid4"]) {
                                curH = 370;
                            }
                            innerHeight = innerHeight + curH;
                        }
                    }
                    that.tableView.setContentOffset(cc.p(0, -innerHeight + that.scrollview.getContentSize().height), false);
                }
            }, false, ip, function () {
                retryCnt = typeof retryCnt === 'undefined' ? 0 : retryCnt;
                if (retryCnt < gameData.ipList.length - 1) {
                    retryCnt++;
                    that.reTry(retryCnt);
                    HUD.showMessage("正在进行第" + parseInt(retryCnt) + "次重试");
                } else {
                    HUD.showMessageBox('提示', '请求信息失败,请检查您的网络', function () {
                    }, true);
                }
            });
        },
        updateContent: function (info) {
            //this.itemList = mItem.getItemList(this.index-1)
            var result = info.result;
            if (result != "0") {

            }
            this.itemList = info.data;
            this.itemList.sort(function (a, b) {
                return b.create_time - a.create_time;
            });
            // this.itemList = [1, 2, 3, 4, 5];
            tableViewRefresh(this.tableView);
        },

        createContent: function () {
            //scrollview
            if (this.tableView) {
                this.tableView.removeFromParent();
                this.tableView = null;
                this.itemList = [];
            }
            var tableView = new cc.TableView(this, cc.size(this.scrollview.getContentSize().width, this.scrollview.getContentSize().height));
            tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
            tableView.x = 0;
            tableView.y = 0;
            tableView.setDelegate(this);
            tableView.setBounceable(true);
            this.scrollview.addChild(tableView);
            this.tableView = tableView;
        },

        tableCellTouched: function (table, cell) {
            if (this.zhanjiTab == "dn") {
                // showLoading();
                var layer = new HistoryDetailNiuNiu(this.itemList[cell.getIdx()]);
                this.addChild(layer);
            } else {
                var content = HUD.showLayer(HUD_LIST.HistoryDetail, this);
                content.updateContent(this.itemList[cell.getIdx()]);
            }
        },

        tableCellSizeForIndex: function (table, idx) {
            if (this.zhanjiTab != "dn" && this.zhanjiTab != "zjh") {
                return cc.size(1180, 130);
            } else {
                //牛牛  几个人
                var size = null;
                if (this.itemList[idx]["uid7"]) {
                    size = cc.size(1180, 500);
                } else if (this.itemList[idx]["uid4"]) {
                    size = cc.size(1180, 370);
                } else {
                    size = cc.size(1180, 240);
                }
                return size;
            }
        },


        tableCellAtIndex: function (table, idx) {
            var cell = table.dequeueCell();
            if (cell == null) {
                cell = new cc.TableViewCell();
                var node = null;
                // console.log(this.zhanjiTab);
                if (this.zhanjiTab != "dn" && this.zhanjiTab != "zjh") {
                    node = HUD.createTableCell(HUD_LIST.HistoryCell, cell);
                } else {
                    node = HUD.createTableCell(HUD_LIST.NiuniuHistoryCell, cell);
                    node.setParentLayer(this);
                }
                node.setIndex(idx, this.itemList[idx]);
            } else {
                cell.node.setIndex(idx, this.itemList[idx]);
            }
            return cell;
        },

        numberOfCellsInTableView: function (table) {
            if (this.itemList == null) return 0;
            return this.itemList.length;
        },

        lookOther: function (sender, type) {
            var that = this;
            var ok = touch_process(sender, type);
            if (ok) {
                // var seeOtherZhanji = HUD.showLayer(HUD_LIST.InputPlayBack, this);
                // seeOtherZhanji.setData(this.ip);
                var seeOtherZhanji = new ZhanjiHuiFangLayer(that.ip);
                that.addChild(seeOtherZhanji);
            }
        }
    });

    exports.ClubZhanjiLayer = ClubZhanjiLayer;
})(window);