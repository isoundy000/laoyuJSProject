/**
 * Created by liuru on 2017/5/18.
 */
/**
 * Created by liuru on 2017/5/18.
 */
(function (exports) {

    //变量
    var $ = null;


    var RoomCleanPenghz = cc.Layer.extend({

        ctor: function () {
            this._super();
            var that = this;

            var scene = ccs.load(res.RoomCleanPenghz_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));


            var daikuan = getUI(this, 'daikuan');
            daikuan.setVisible(!window.inReview);
            TouchUtils.setOnclickListener(daikuan, function () {
                if(cc.sys.isNative){
                    cc.sys.openURL(DAIKUAN_URL);
                }else{
                    window.open(DAIKUAN_URL, "_blank");
                }
            }, {effect : TouchUtils.effects.SEPIA});

            this.bt1 = $("bt1");
            this.bt1.addTouchEventListener(this.onShareWx, this);
            if(window.inReview){
                this.bt1.setVisible(false);
            }

            this.close = $("close");

            this.title = $("title");
            this.txtTime = $("txtTime");
            this.txtRoomId = $("txtRoomId");
            this.txtRounds = $("txtRounds");
            this.title.setString(mRoom.getWanfaName(mRoom.wanfatype) + "--牌局结束");

            //playEffect('yin_win');
            mRoom.isClean = true;

            //关闭按钮 5秒后 才可以点击
            this.leftSecond = 3;
            this.closelabel = $("closelabel", this.close);
            this.closelabel.setString("关闭");
            TouchUtils.setOnclickListener(that.close, function (node) {
                mRoom.isClean = false;
                //cc.eventManager.removeAllListeners(););
                DC.closeByClient = true;
                clearGameMWRoomId();
                HUD.showScene(HUD_LIST.Home, that);
                // DC.socket.close();
            });

            return true;
        },
        setRoom: function (resultlayer, gameOverData) {
            this.gameOverData = gameOverData;

            //格式化时间
            this.txtTime.setString(this.gameOverData.EndTime);
            this.txtRoomId.setString("房间号:" + this.gameOverData.RoomID);
            this.txtRounds.setString("局数:" + this.gameOverData.CurrentRound + "/" + this.gameOverData.TotalRound);
            this.setData();

            //红包活动
            // if(data['cur_round']>3){
            // if(this.gameOverData.CurrentRound > 1 && gameData.opt_conf && gameData.opt_conf['hongbaoyu']) {
            //     var timemiao = Date.parse(new Date(this.gameOverData.EndTime))/1000;
            //     activityRedRain(timemiao, 'yyzhuzhou');
            // }
        },
        setData: function () {
            var maxScore = -100;
            var maxPao = -100;
            if (this.gameOverData.Users[0].Score == 0
                && this.gameOverData.Users[1].Score == 0
                && this.gameOverData.Users[2].Score == 0) {
                maxScore = 9999;//都是0,没有赢家
            } else {
                //计算最高的分数
                for (var s = 0; s < this.gameOverData.Users.length; s++) {
                    var score = this.gameOverData.Users[s].Score;
                    if (score > maxScore) {
                        maxScore = score;
                    }
                }
                //计算最佳炮手
                for (var s = 0; s < this.gameOverData.Users.length; s++) {
                    var pao = this.gameOverData.Users[s].LoseCount;
                    if (pao >= maxPao) {
                        maxPao = pao;
                    }
                }
                if (maxPao >= 0){
                    var paoCount = 0;
                    for (var s = 0; s < this.gameOverData.Users.length; s++) {
                        if( maxPao == this.gameOverData.Users[s].LoseCount)
                            paoCount++;
                    }
                    if (paoCount > 1){
                        maxPao = -100;
                    }
                }
            }

            if (mRoom.getPlayerNum() == 3) {
                var info4 = $(this, "info4");
                info4.setVisible(false);
                for (var i = 0; i < 3; i++) {
                    var info = $("info" + (i + 1));
                    info.setPositionX(50 + i * 392 + (1 - i) * 40);
                }
            }
            var pList = this.gameOverData.Users;
            var fangzhuIsIn = false;
            var winnerId = 0;
            for (var i = 0; i < pList.length; i++) {
                var player = pList[i];

                var result = $("result");
                var info = $("info" + (i + 1));
                var table = $("bg_table", info);
                // var table_tiao= $("score_table", info);
                var name = $("name", info);
                var id = $("id", info);
                var score = $("score", info);
                var scoreZi   = $("score_zi", info);
                var winner = $("winner", info);
                var hpcs = $("hpcs", info);
                var zghx = $("zghx", info);
                var zgfx = $("zgfx", info);
                var zgjf = $("zgjf", info);

                name.setString(ellipsisStr(player.UserName, 7) || '');
                id.setString("ID："+ (player.UserID || ''));

                if (player.Score >= 0) {
                    score.setFntFile(res.jiafenhuang_fnt);
                    score.setString("+" + (player.Score || '0'));
                    scoreZi.setTexture(res.icon_jiafenhuang_png);
                } else {
                    score.setFntFile(res.koufen_hong_fnt);
                    score.setString(player.Score || '0');
                    scoreZi.setTexture(res.icon_koufen_hong_png);
                }
                //score.setString(player.Score || '0'); //结算到本局为止，包括本局
                hpcs.setString(""+(player.HuCount || '0'));//胡牌次数
                zghx.setString("" + (player.Lianzhuang || '0'));   //连庄次数
                zgfx.setString("" + (player.LoseCount || '0'));    //点炮次数
                //zghx.setString(player.MaxHuxi || '0');//最大胡息
                //zgfx.setString(player.MaxFanCount || '0'); //最大番
                //zgjf.setString(player.MaxJi || '0');//最大番

                //本人数据显示胜利或者失败
                if (player.UserID == gameData.uid){
                    if (player.Score >= maxScore) {
                        result.setTexture(res.icon_win);
                    } else {
                        result.setTexture(res.icon_lose);
                    }
                }
                //头像
                var clipper = function () {  //创建剪切区域
                    var clipper = new cc.ClippingNode();
                    var gameTitle = new cc.Sprite('res/image/head.png');
                    gameTitle.setScale(0.5);
                    clipper.setAlphaThreshold(255);
                    clipper.setStencil(gameTitle);
                    clipper.setAlphaThreshold(0);
                    clipper.setContentSize(cc.size(gameTitle.getContentSize().width, gameTitle.getContentSize().height));
                    return clipper;
                }
                var clip = clipper();
                clip.setPosition(cc.p(150, 410));
                info.addChild(clip);
                var avator = new cc.Sprite('res/image/defaultHead.jpg');
                avator.setScale(0.75);
                avator.setPosition(cc.p(0, 0));
                clip.addChild(avator);
                var url = decodeURIComponent(player.HeadImgURL);
                if (url == undefined || (url.length == 0)) url = res.defaultHead;
                loadImageToSprite2(url, avator);//头像

                var head = $('head' + (i + 1), info);
                head.setPosition(clip.getPosition());
                head.setLocalZOrder(1);
                head.setTexture((player.Score >= maxScore) ? 'res/image/ui/roomclean2/avatorbg2.png': 'res/image/ui/roomclean2/avatorbg1.png');

                //大赢家数据
                if (player.Score >= maxScore) {
                    winner.setVisible(true);
                    winner.setTexture(res.king_winner);
                    table.setTexture(res.huang_mianban);
                    // table_tiao.setTexture(res.bei_huang);
                    winnerId = player.UserID;
                } else {
                    winner.setVisible(false);
                    table.setTexture(res.lan_mianban);
                    // table_tiao.setTexture(res.bei_lan);
                }

                //最佳炮手
                if (player.LoseCount == maxPao) {
                    winner.setVisible(true);
                    winner.setTexture(res.king_pao);
                }

                if (this.gameOverData.Owner && this.gameOverData.Owner == player.UserID) {
                    fangzhuIsIn = true;
                }
            }
            //不是第一句结算 结算
            if(maxScore != 9999){
                if(gameData.uid == winnerId){
                    playEffect('yx_bwin');
                } else {
                    playEffect('yx_bfail');
                }
            }
            var fangzhu = $("icon_fz_1", info);
            if (fangzhu) {
                fangzhu.setVisible(fangzhuIsIn);
                fangzhu.setLocalZOrder(3);
            }
        },
        onOk: function (sender, type) {
            var ok = touch_process(sender, type);
            if (ok) {

            }
        },
        onShareWx: function (sender, type) {
            var that = this;
            var ok = touch_process(sender, type);
            if (ok) {
                //先隐藏按钮  在现实
                that.bt1.setVisible(false);
                that.close.setVisible(false);
                that.scheduleOnce(function () {
                    that.bt1.setVisible(true);
                    that.close.setVisible(true);
                }, 1);
                if (!cc.sys.isNative)
                    return;
                DC.closeByClient = true;
                // WXUtils.captureAndShareToWX(that);
                WXUtils.captureAndShareToWX(that, 0x88F0);//0x88F0
            }
        }


    });

    exports.RoomCleanPenghz = RoomCleanPenghz;

})(this);