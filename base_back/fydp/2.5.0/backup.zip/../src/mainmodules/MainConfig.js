var main_src = [
    'src/mainmodules/common/CommonConfig.js'
];