var Home = {
    init: function () {
        //test
        // gameData.opt_conf['hongbaoyu'] = 1;
        // gameData.opt_conf['jizhan'] = 1;
        // gameData.opt_conf['zjkztjr'] = 1;
        //cc.spriteFrameCache.addSpriteFrames(res.card_plist);
        cc.spriteFrameCache.addSpriteFrames(res.card_common_plist);

        this.isHotUpdate();

        var that = this;
        partical_huaban = null;
        partical_bianpao_zha = null;
        partical_bianpao_diao = null;

        this.nBTN = getUI(this, "nBTN");
        this.nMain = getUI(this, "nMain");
        this.txtCount = getUI(this, "txtCount");
        this.messagenum = getUI(this, "messagenum");
        this.message_numbg = getUI(this, "message_numbg");
        this.message_numbg.setVisible(false);
        this.messagenum.setString("");
        this.lottery = getUI(this, "lottery");
        this.btn_yaoqing = getUI(this, "btn_yaoqing");
        this.btn_yaoqing.setVisible(false);
        // getUI(this, "tablexm").setVisible(false);
        this.isXM = false;

        //2.2.0改名牛大王
        if (getNativeVersion() >= "2.2.0") {
            var hall_title_41 = getUI(this, 'hall_title_41');
            hall_title_41.setTexture('res/image/ui/hall/hall_title_ndw.png');
            // var bg = getUI(this, 'bg');
            // bg.loadTexture('res/image/ui/login/bg_ndw.jpg');
        }

        //初始化限免标志
        if (gameData.free) {
            this.freeData = gameData.free.split(',');
            for (var i = 0; i < this.freeData.length; ++i) {
                if (this.freeData[i] == 10000) {
                    getUI(this, "tablexm").setVisible(true);
                    Filter.grayScale(getUI(this, "btn_iap"));
                    Filter.grayScale(getUI(this, "binding"));
                    this.isXM = true;
                }
            }
        }
        //实名认证
        this.btn_verify = getUI(this, "btn_verify");
        TouchUtils.setOnclickListener(this.btn_verify, function () {
            var verifyLayer = new VerifyLayer(that);
            that.addChild(verifyLayer);
        });
        this.setYanzheng(gameData.real_name == "");

        //活动 10.1-10.3开启
        this.lottery.setVisible(false);
        TouchUtils.setOnclickListener(this.lottery, function () {
            // var lottery = new LotteryLayer();
            // that.addChild(lottery);
            that.showLotterlayer();
        });
        var daikuan = getUI(this, "daikuan");
        daikuan.setVisible(!window.inReview);
        TouchUtils.setOnclickListener(daikuan, function () {
            if(cc.sys.isNative){
                cc.sys.openURL(DAIKUAN_URL);
            }else{
                window.open(DAIKUAN_URL, "_blank");
            }
        }, {effect : TouchUtils.effects.SEPIA});
        var boluodai_liuguang = ccs.load(res["boluodai_liuguang_json"], "res/");
        var boluodai_liuguangAni = boluodai_liuguang.node;
        boluodai_liuguangAni.setScale(2.5);
        boluodai_liuguangAni.setPosition(cc.p(daikuan.getContentSize().width/2, daikuan.getContentSize().height/2));
        daikuan.addChild(boluodai_liuguangAni);
        boluodai_liuguangAni.runAction(boluodai_liuguang.action);
        boluodai_liuguang.action.play('action', true);

        //顶部的按钮
        this.nBTN = getUI(this, "nBTN");
        var topRightBtn = ["btn_msg", "btn_wf", "btn_zj", "btn_sz", "btn_dc"];
        for (var i = 0; i < topRightBtn.length; i++) {
            var btn = getUI(this.nBTN, topRightBtn[i]);
            var btn = getUI(this.nBTN, topRightBtn[i]);
            btn.setVisible(false);
        }
        //根据平台开启按钮
        var showBtn = ["btn_msg", "btn_wf", "btn_zj", "btn_sz", "btn_dc"];
        if (window.inReview) showBtn = ["btn_sz", "btn_dc"];
        else {
            if (cc.sys.os == cc.sys.OS_ANDROID) showBtn = ["btn_msg", "btn_wf", "btn_zj", "btn_sz", "btn_dc"];
            if (cc.sys.os == cc.sys.OS_IOS) showBtn = ["btn_msg", "btn_wf", "btn_zj", "btn_sz", "btn_dc"];
            //showBtn = ["btn_wf", "btn_zj", "btn_sz"];
        }
        var _distance = getUI(this.nBTN, "btn_dc").getPositionX() - getUI(this.nBTN, "btn_sz").getPositionX();
        var _posX = getUI(this.nBTN, "btn_dc").getPositionX();

        //重置位置和开启
        for (var i = 0; i < showBtn.length; i++) {
            var btn = getUI(this.nBTN, showBtn[i]);
            btn.setVisible(true);
            btn.setPositionX(_posX - _distance * (showBtn.length - 1 - i));
        }

        // todo 推荐制度暂时去掉，需要做完andriod的接口在打开，有问题的内容
        //iap 支付  btn_iap 购买房卡 roomcard_2
        var openShopOnClick = function () {
            if (window.inReview) {
                // 此处为ios原商店
                var iaplayer = new ShopLayer(that);
                that.addChild(iaplayer);
            } else if (that.isXM) {
                Filter.grayScale(getUI(that, "btn_iap"));
                alert1('限免期间，商城关闭');
            } else {
                that.openShop();
            }
        }
        var iapclick = function () {
            var shop = new ShopLayer();
            that.addChild(shop);
        }
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_iap'), openShopOnClick);
        // if (cc.sys.os == cc.sys.OS_IOS && gameData.triggers && gameData.triggers.length >= 5 && gameData.triggers[4] == 0) {
        //     TouchUtils.setOnclickListener(getUI(this, "add_3"), iapclick);
        // } else {
        //     TouchUtils.setOnclickListener(getUI(this, "add_3"), openShopOnClick);
        // }
        TouchUtils.setOnclickListener(getUI(this, "add_3"), openShopOnClick);

        getUI(this, "binding").setVisible(!window.inReview);
        //getUI(this, "binding").setVisible(false);  //todo 推荐制上线的时候需要去掉这句话
        TouchUtils.setOnclickListener(getUI(this, "binding"), function () {
            if (that.isXM) {
                Filter.grayScale(getUI(that, "binding"));
                alert1('限免期间，此功能关闭');
            } else {
                that.addChild(new BindingAgencyLayer(gameData.parent_id));
            }
        });

        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_msg'), function () {
            // var notice = HUD.showLayer(HUD_LIST.NoticeLayer, that);
            // if (that.noticeData) {
            //     notice.setData(that.noticeData, that);
            // } else {
            //     notice.setData([], that);
            // }
            var notice = new ActivityMsgLayer(that.noticeData || []);
            that.addChild(notice);
        });
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_wf'), function () {
            var rule = HUD.showLayer(HUD_LIST.Rule, that);
        });
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_zj'), function () {
            var his = HUD.showLayer(HUD_LIST.History, that);
        });
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_sz'), function () {
            var setting = HUD.showLayer(HUD_LIST.Settings, that);
            setting.setSetting(that, "room");//大厅里面打开界面
            setting.setSettingLayerType({hidejiesan: that});
        });
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_dc'), function () {

            alert2('是否确定退出登录？', function () {
                exitGame();
            }, null, false, false);

            var exitGame = function () {
                cc.sys.localStorage.removeItem('wxToken');
                cc.sys.localStorage.removeItem('openid');
                cc.sys.localStorage.removeItem('xianliao_openid');
                cc.sys.localStorage.removeItem('lbopenid');
                gameData.hasLogined = false;
                network.disconnect();
                HUD.showScene(HUD_LIST.Login, null);
            };
        });
        getUI(this.nBTN, 'btn_share').setVisible(!window.inReview);
        TouchUtils.setOnclickListener(getUI(this.nBTN, 'btn_share'), function () {
            var shareLayer = new ShareLayer();
            that.addChild(shareLayer);
        });

        var games = ['niuniu', 'pdk', 'psz', 'majiang', 'huzi'];//240
        if(gameData.appId == APP_ID_QUANMINDOUPAI){
            games = ['niuniu', 'pdk', 'majiang', 'psz'];//240
        }
        if(window.inReview){
            games = ['niuniu', 'pdk', 'majiang'];
        }
        var scrollview = getUI(this.nMain, 'scroll');

        if(true){
            scrollview.setVisible(false);
            that.addChild(new RotatingMenu(that, games));
        }else{
            var scrollW = 920;
            if(games.length > 4)  scrollW = 230*games.length;
            scrollview.setInnerContainerSize(cc.size(scrollW, 400));
            for(var i=0;i<games.length;i++){
                (function(name){
                    that['btn_createroom_' + name] = getUI(scrollview, 'btn_createroom_' + name);
                    that['btn_createroom_' + name].setPositionX(230*(i+1/2));
                    TouchUtils.setOnclickListener(that['btn_createroom_' + name], function () {
                        that.createRoomLayer(false, name);
                    }, {swallowTouches : false});
                })(games[i]);
            }
            //扫光
            var clipper = function (src) {  //创建剪切区域
                var clipper = new cc.ClippingNode();
                var gameTitle = new cc.Sprite('res/image/ui/hall/title_roomcreate_' + src + '.png');
                clipper.setStencil(gameTitle);
                clipper.setAlphaThreshold(0);
                clipper.setContentSize(cc.size(gameTitle.getContentSize().width, gameTitle.getContentSize().height));
                return clipper;
            };
            //title_roomcreate_niuniu
            var saoguangBtnArr = ['huzi', 'niuniu', 'pdk', 'psz', 'majiang'];//240
            for(var i=0;i<saoguangBtnArr.length;i++){
                var huzititle = this['btn_createroom_' + saoguangBtnArr[i]].getChildByName('title');
                var clip = clipper(saoguangBtnArr[i]);
                var clipSize = cc.size(160, 75);
                clip.setPosition(cc.p(huzititle.getContentSize().width / 2, huzititle.getContentSize().height / 2));
                var gameTitle = new cc.Sprite(res.transparent_97x99_png);
                var spark = new cc.Sprite(res.eff_spark_png);
                clip.addChild(gameTitle, 1);
                spark.setPosition(-huzititle.getContentSize().width / 2, 0);
                clip.addChild(spark, 2);
                huzititle.addChild(clip, 4);
                var seq = cc.sequence(
                    cc.delayTime(i * 2),
                    cc.moveTo(2, cc.p(clipSize.width, 0)),
                    cc.moveTo(0, cc.p(-clipSize.width, 0)),
                    cc.delayTime((saoguangBtnArr.length-i)*2)
                    //cc.delayTime((1 - i) * 2)
                );
                spark.runAction(cc.repeatForever(seq));
            }

        }
        TouchUtils.setOnclickListener(getUI(this.nMain, 'btn_joinroom'), function () {
            HUD.showLayer(HUD_LIST.RoomJoin, HUD.getTipLayer(), null, true);
        });
        var btn_yikai = getUI(this.nMain, 'btn_yikai');
        TouchUtils.setOnclickListener(btn_yikai, function () {
            that.addChild(new DaiKai());
        });
        var btn_daikai = getUI(this.nMain, 'btn_daikai');
        btn_daikai.setVisible(false);
        TouchUtils.setOnclickListener(btn_daikai, function () {
            that.createRoomLayer(true);
        });


        var wmxybg = new LunBoLayer();
        wmxybg.setScale(0.9);
        wmxybg.setPosition(cc.p(50, 70));
        this.addChild(wmxybg);

        btn_yikai.setVisible(!window.inReview);
        if (getNativeVersion() >= "2.2.0") {
            btn_yikai.setVisible(false);
        }
        wmxybg.setVisible(!window.inReview);

        if (!window.inReview) {
            var myClubLayer = new ClubLayer();
            myClubLayer.setName('ClubLayer');
            this.addChild(myClubLayer);
        }
        var txtName = getUI(this, "txtName");
        var name = ellipsisStr(gameData.nickname, 6);
        txtName.setString(name);
        var txtID = getUI(this, "txtID");
        txtID.setString(" ID:" + gameData.uid);
        if (window.inReview) txtID.setString("LV:1");
        this.txtCount.setString(gameData.cardnum || "0");
        var headbg = getUI(this, "head_1");
        var head = getUI(this, "head");
        loadImageToSprite(((gameData.headimgurl == undefined || gameData.headimgurl == null || gameData.headimgurl == '') ?
            res.defaultHead : gameData.headimgurl), head);


        playMusic('vbg5');

        this.btn_yaoqing.addTouchEventListener(this.onYaoQing, this);
        //
        TouchUtils.setOnclickListener(headbg, function () {
            if (window.inReview)
                return;
            var scene = ccs.load(res.PlayerInfo_json, "res/");
            that.addChild(scene.node);

            var head = getUI(scene.node, 'head');
            var lbNickname = getUI(scene.node, 'lb_nickname');
            var lbId = getUI(scene.node, 'lb_id');
            var lbIp = getUI(scene.node, 'lb_ip');
            var male = getUI(scene.node, 'male');
            var female = getUI(scene.node, 'female');
            var fake_root = getUI(scene.node, 'fake_root');
            var panel = getUI(scene.node, 'panel');
            var lbAd = getUI(scene.node, 'lb_ad');
            var lbDt = getUI(scene.node, 'lb_dt');
            lbDt.setVisible(false);

            lbNickname.setString(ellipsisStr(gameData.nickname, 6));
            lbId.setString(gameData.uid);
            lbIp.setString(gameData.ip);
            male.setVisible(gameData.sex == '1');
            female.setVisible(gameData.sex == '2');
            loadImageToSprite(((gameData.headimgurl == null || gameData.headimgurl == '') ? res.defaultHead : gameData.headimgurl), head);

            //定位
            lbAd.setVisible(true);
            if (!gameData.location || gameData.location == '') {
                lbAd.setString('您可能没有开启定位权限');
            } else {
                lbAd.setString(decodeURIComponent(gameData.locationInfo));
            }

            TouchUtils.setOnclickListener(fake_root, function () {
                scene.node.removeFromParent(true);
            });
            TouchUtils.setOnclickListener(panel, function () {
            }, {effect: TouchUtils.effects.NONE});
        });

        network.addCustomListener(P.GS_StatusChange, this.onStatusChange.bind(this));
        network.addCustomListener(P.GS_Login, this.onRoleLoginOK.bind(this));
        network.addCustomListener(P.GS_UserJoin, this.onUserJoin.bind(this));

        this.getUserInfo();
        this.nInfo = getUI(this, "nInfo");


        //去掉游戏大厅所有交叉推广图标
        //this.showShareGames();

        if (window.inReview) {
            getUI(this, 'hall_title_41').setPositionX(1280 / 2);
        }

        //未读消息
        var request = {};
        request.test = "";

        DC.httpData("/qmdp", request, this.onMessageList.bind(this), true, "http://notice.yygameapi.com:34567");

        if (gameData.errMessage) {
            HUD.showMessageBox("提示", gameData.errMessage, function () {
            }, true);
            gameData.errMessage = null;
        }

        if (typeof regBakBtn !== 'undefined')
            regBakBtn.call(this);

        // this.startParticles();

        //预创建粒子资源
        new cc.ParticleSystem(res.flyIcon_plist);

        that.roomId = null;
        gameData.roomId = null;
        this.isConnect = false;

        network.addListener(3001, function (data, errorCode) {
            if (errorCode) {
                var errorMsg = '创建房间失败, 请重试';
                if (errorCode == -40) errorMsg = '创建房间失败, 您的房卡不足';
                if (errorCode == -2) errorMsg = '版本过低。请退出后重新登陆';
                if (data && data.errorMsg) {
                    errorMsg = data.errorMsg;
                }
                alert1(errorMsg);
                HUD.removeLoading();
                return;
            }
            hideLoading();
            //俱乐部创建的
            if (data && data['club_id']) {
                var club_id = data['club_id'];
                var createRoomLayer = that.getChildByName('createRoomLayer');
                if (createRoomLayer) createRoomLayer.removeFromParent();
                network.send(2101, {cmd: 'listClubRoom', club_id: club_id});
                return;
            }
            if (data && data['is_daikai']) {
                that.mapId = data['map_id'] || 0;
                alert2(
                    "代开房间创建成功，房间号：" + data['room_id'] + "，代扣房卡" + data['need_cards'] + "张",
                    function () {
                        that.addChild(new DaiKai(that.mapId));
                    },
                    null,
                    false,
                    true,
                    true,
                    null,
                    null
                );
            }
        });
        network.addListener(3006, function (data) {
            mRoom.wanfatype ="";
            gameData.roomId = data['room_id'];
            gameData.mapId = data['map_id'];
            gameData.playerNum = data['players'].length;
            gameData.daikaiPlayer = data['daikai_player'];
            if(gameData.mapId == MAP_ID_PDK) {
                var maScene = new PuKeScene(data);
                cc.director.runScene(maScene);
            }else if(gameData.mapId == MAP_ID_ZJH){
                cc.director.runScene(new ZJHScene(data));
            }else{
                var maScene = new MaScene(data);
                cc.director.runScene(maScene);
            }
        });
        network.addListener(3002, function (data, errorCode) {
            if (errorCode) {
                var errorMsg = null;
                if (errorCode == -20) errorMsg = '房间号不存在, 请重新输入';
                if (errorCode == -30) errorMsg = '该房间已满员, 无法加入';
                if (errorCode == -60) errorMsg = '该房间已开始, 无法加入';
                if (errorCode == -40) errorMsg = '您的房卡不足';
                if (errorCode == -2) errorMsg = '版本过低。请退出后重新登陆';
                if (data && data.errorMsg) {
                    errorMsg = data.errorMsg;
                }
                alert1(errorMsg, null, null, true, true, true);
                HUD.removeLoading();
                return;
            }

            network.stop();

            //加入房间成功  立即停止魔窗循环检测
            gameData.roomId = data['room_id'];
            gameData.mapId = data['map_id'];
            gameData.players = data['players'];
            gameData.ownerUid = data['owner'];
            gameData.last3002 = data;
            gameData.wanfaDesp = data['desp'];
            gameData.playerNum = data['max_player_cnt'];
            gameData.daikaiPlayer = data['daikai_player'];
            gameData.curRound = data['cur_round'];
            if (that.returnRoomId)
                ;
            else {
                if (gameData.mapId == MAP_ID_DN){
                    cc.director.runScene(new NiuNiuScene());
                }else if(gameData.mapId == MAP_ID_PDK){
                    cc.director.runScene(new PuKeScene());
                }else if(gameData.mapId == MAP_ID_ZJH){
                    cc.director.runScene(new ZJHScene());
                }else {
                    cc.director.runScene(new MaScene());
                }
            }
        });

        network.addCustomListener(P.GS_UserJoin_NiuNiu, function (event) {
            var data = event.getUserData();
            var Result = null;
            if (data.Head) {
                Result = data.Head.Result;
            }
            if (data.Result != null) {
                Result = data.Result;
            }
            if (Result == 0) {
                // if (mRoom.oldRoom != 0) {
                network.stop();
                gameData.maxPlayerNum = 6;
                var option = data.Option == "" ? {} : JSON.parse(decodeURIComponent(data.Option));
                gameData.totalRound = option.rounds;
                // gameData.wanfaDesp = option.desp || "";
                gameData.leftRound = gameData.totalRound - (data.CurrentRound || 0);
                gameData.currentRound = data.CurrentRound;
                gameData.Option = option;
                gameData.is_daikai = option.is_daikai;
                gameData.Option.currentRound = data.CurrentRound;
                gameData.roomId = data.RoomID;
                gameData.mapId = option['mapid'];
                gameData.ownerUid = data.Owner;
                gameData.wanfatype = option.wanfa;
                gameData.players = data['Users'];
                gameData.WatchingUsers = data.WatchingUsers;

                mRoom.wanfatype = option.wanfa;
                mRoom.roomInfo = gameData.Option;
                // mRoom.owner = data.Owner;
                // gameData.ownerUid = data.Owner;
                mRoom.BeiShu = option.BeiShu;
                mRoom.Preview = option.Preview;
                mRoom.ZhuangMode = option.ZhuangMode;
                mRoom.is_daikai = option.is_daikai;
                mRoom.Is_ztjr = option.Is_ztjr;
                mRoom.Cuopai = option.Cuopai;
                mRoom.noColor = option.noColor;
                if (option.Players == "jiu") {
                    gameData.maxPlayerNum = 9;
                }

                cc.director.runScene(new NiuNiuScene(data));
            } else {
                hideLoading();
                HUD.showMessageBox('提示', data.ErrorMsg);
            }
        });

        network.addListener(3005, function (data, errorCode) {
        });

        that.onMaDeng();
        network.addListener(3200, function (data) {
            if (data.content) {
                gameData.Content = data.content;
                that.onMaDeng();
            }
        });
        this.scheduleOnce(function () {
            network.send(3013, {});
        }, 0.5);
        network.addListener(3013, function (data, errorCode) {
            gameData.numOfCards = data['numof_cards'];
            if (gameData.numOfCards[1]) {
                gameData.cardnum = gameData.numOfCards[1];
                if (that.txtCount) that.txtCount.setString(gameData.cardnum || "0");
            }
        });

        this.scheduleUpdate();

        //商城
        var shoprow1 = getUI(this, 'shoprow1');
        var shoprow2 = getUI(this, 'shoprow2');
        var shoprow3 = getUI(this, 'shoprow3');
        shoprow1.setOpacity(0);
        shoprow2.setOpacity(0);
        shoprow3.setOpacity(0);
        shoprow1.runAction(cc.repeatForever(cc.sequence(cc.delayTime(0), cc.fadeIn(0.2), cc.delayTime(0.4), cc.fadeOut(0.2), cc.delayTime(0.6))));
        shoprow2.runAction(cc.repeatForever(cc.sequence(cc.delayTime(0.2), cc.fadeIn(0.2), cc.delayTime(0.4), cc.fadeOut(0.2), cc.delayTime(0.4))));
        shoprow3.runAction(cc.repeatForever(cc.sequence(cc.delayTime(0.4), cc.fadeIn(0.2), cc.delayTime(0.4), cc.fadeOut(0.2), cc.delayTime(0.2))));

        return true;
    },
    //转盘抽奖
    showLotterlayer: function () {
        var layer = new cc.LayerColor(cc.color(0, 0, 0, 127), cc.winSize.width, cc.winSize.height);
        layer.setAnchorPoint(0, 0);
        var playerId = gameData.uid;
        var area = 'yyzhuzhou';
        var signKey = Crypto.MD5("feiyu-activity" + playerId + area);
        var webView = new ccui.WebView("http://pay.yayayouxi.com/activity-front/zhuzhou_zhuanpan?playerId=" + playerId + "&area=" + area + "&signKey=" + signKey);
        webView.setContentSize(cc.winSize.width * 0.8, cc.winSize.height * 0.8);
        webView.setAnchorPoint(0, 0);
        webView.setPosition(cc.winSize.width * 0.1, cc.winSize.height * 0.1);
        layer.addChild(webView);
        this.addChild(layer);
        TouchUtils.setOnclickListener(layer, function (node) {
            layer.removeFromParent(true);
        });
    },
    getUserInfo: function () {
        // if(mRoom.isCheckedReJoin != true){
        //     mRoom.isCheckedReJoin = true;

        var reqPara = {};
        var url = '/Auth/Info?UserID=' + gameData.uid;
        DC.httpData(url, reqPara, this.onUserInfo.bind(this), true, DC.httpHost2);
    },
    //反外挂
    showNoPluginLayer: function () {
        var that = this;
        var scene = ccs.load(res.NoPluginLayer_json, "res/");
        that.addChild(scene.node);

        var fake_root = getUI(scene.node, 'root');
        var close = getUI(scene.node, 'close');

        TouchUtils.setOnclickListener(close, function () {
            scene.node.removeFromParent(true);
        });
        TouchUtils.setOnclickListener(fake_root, function () {
            scene.node.removeFromParent(true);
        }, {effect: TouchUtils.effects.NONE});
    },
    openShop: function () {
        var that = this;
        showLoading("努力加载中..");
        var sendData = {area: gameData.parent_area, playerid: gameData.uid, unionid: gameData.unionid};
        // console.log(sendData);
        NetUtils.httpPost("http://pay.yayayouxi.com/payServer/commodity/findCommodityInfoListByArea"  //推荐制 通过地区查找商品信息
            , sendData,
            function (data) {
                if (data) {
                    hideLoading();
                    that.addChild(new WxShopLayer(data));
                } else {
                    alert1("支付请求失败,请检查网络");
                }
            },
            function (error) {
                alert1("支付请求失败,请检查网络");
            }
        );
    },
    setYanzheng: function (_bool) {
        this.btn_verify.setVisible(_bool);
        if (window.inReview) {
            this.btn_verify.setVisible(!window.inReview);
        }
    },
    update: function (dt) {
        if (!this._time)
            this._time = 0;
        this._time += dt * 1000;
        if (this._time >= 250) {
            var autoJoinRoomId = _.trim(MWUtil.getRoomId() || "");
            // console.log("autoJoinRoomId==="+autoJoinRoomId);
            if (autoJoinRoomId) {
                if (autoJoinRoomId.indexOf("0") == 0 && autoJoinRoomId.length == 6) {
                    var clubid = autoJoinRoomId.substr(1, 5);
                    if (clubid && clubid.length == 5) {
                        var cLayer = this.getChildByName('ClubLayer');
                        if (cLayer) {
                            MWUtil.clearRoomId();
                            cLayer.showClub();
                            this.scheduleOnce(function () {
                                cLayer.showCreateOrAddClubLayer('add', clubid);
                            }, 0.2)
                        }
                    }
                } else if (autoJoinRoomId.length == 6 && network.isAlive()) {
                    showLoading("正在自动加入房间: " + autoJoinRoomId);
                    network.send(3002, {room_id: autoJoinRoomId});
                }
                if (getNativeVersion() >= "2.3.0") {
                    if (cc.sys.isNative) {
                        var xianLiaoJoinRoomId = XianLiaoUtils.getRoomId();
                        if (xianLiaoJoinRoomId && xianLiaoJoinRoomId.length == 6 && network.isAlive()) {
                            showLoading("正在自动加入房间: " + xianLiaoJoinRoomId);
                            network.send(3002, {room_id: xianLiaoJoinRoomId});
                            XianLiaoUtils.clearRoomId();
                        }
                    }
                }
            }
            this._time -= 250;
        }
    },
    isHotUpdate: function () {
        var native_version = getNativeVersion();
        var filename = "native_version";
        if(gameData.appId == APP_ID_QUANMINDOUPAI && window.nativeVersion <= '2.2.0'){
            filename = "native_version_2.2.0";
        }
        NetUtils.httpGet('http://penghuzi.yayayouxi.com/penghuzi/' + filename, function (response) {
            // var dates = cc.sys.localStorage.getItem('updatetime') || "0-0";
            // var today = new Date();
            // var month = today.getMonth() + 1;
            // var day = today.getDate();
            // if (dates != (month + "-" + day) && native_version < response) {
            //     cc.sys.localStorage.setItem('updatetime', month + "-" + day);
            if(native_version < response){
                alert2('发现新版本,是否前往更新？', function () {
                    cc.sys.openURL('https://www.yayayouxi.com/fydp/');
                }, false, false, false, true, true);
            }
        }, function () {

        })
    },

    //修改bug：房间满员之后，再有人加入房间，提示满员，点关闭后，再输入房间号，不显示房间号，
    onGetRoomInfoError: function (data) {
        var that = this;
        data = JSON.parse(data);
        if (data.result == -1) {
            // HUD.showMessage("房间" + this.roomId +"不存在");
            HUD.showMessageBox('提示', "房间" + this.roomId + "不存在", function () {
            }, true);
            HUD.removeLoading();
            return;
        }
        if (data.data.playList && data.data.playList.length > 0) {
            var inList = false;
            for (var i = 0; i < data.data.playList.length; i++) {
                if (data.data.playList[i] == gameData.uid) {
                    inList = true;
                    break;
                }
            }
            if (inList == false && data.data.playList.length == mRoom.getPlayerNum()) {
                HUD.showMessageBox('提示', "房间已经满员,请加入其他房间。", function () {
                }, true);
                HUD.removeLoading();
                return;
            }
        }


        if (data.result == 0 && !this.isConnect) {
            DC.wsHost = data.data.url;
            mRoom.roomId = data.data.roomid;
            gameData.roomId = mRoom.roomId;
            mRoom.oldRoom = gameData.roomId;
            var option = data.data.option;
            var obj = decodeHttpData(option);


            mRoom.rounds = obj.rounds;
            mRoom.getWanfa(obj);
            mRoom.ownner = data.data.ownner;
            this.isConnect = true;
            DC.wsConnect(this);
        } else {
        }
    },

    onMessageList: function (data) {
        if (data && data.result && parseInt(data.result) == 0) {
            this.noticeData = data.data;
            var notReadNum = 0;
            for (var i = 0; i < data.data.length; i++) {
                var hasread = cc.sys.localStorage.getItem("notice" + data.data[i]["TimeInMillionSecond"]);
                if (hasread == undefined || hasread == null || hasread == "") {
                    notReadNum++;
                }
            }
            this.setMessageNum(notReadNum);
        }

        // if(gameData.pluginNum == 1){
        //     this.showNoPluginLayer();
        //     gameData.pluginNum = 0;
        // }
        // gameData.opt_conf['chongfan'] = 1;
        if(window.inReview == false && gameData.lotteryNum == 1 && gameData.opt_conf['chongfan'] == 1){
            var notice = new ActivityMsgLayer(this.noticeData || []);
            this.addChild(notice, 1000);
            gameData.lotteryNum = 0;
        }
        var lastShowDay = cc.sys.localStorage.getItem("lastShowDay") || null;
        // 不是今天就行
        if (new Date().getDate() != lastShowDay) {
            cc.sys.localStorage.setItem("lastShowDay", new Date().getDate());
        }
    },
    setMessageNum: function (num) {
        if (num && num > 0) {
            this.message_numbg.setVisible(true);
            this.messagenum.setString(1);
        } else {
            this.message_numbg.setVisible(false);
            this.messagenum.setString("");
        }
        if (window.inReview) {
            var btn7 = getUI(this.nBTN, "btn_msg");
            btn7.setVisible(false);
        }

    },

    getUserInfo: function () {

        if (window.inReview) {
            this.btn_yaoqing.setVisible(false);
            this.lottery.setVisible(false);
        }

        if (gameData.numOfCards && gameData.numOfCards[1] >= 0) {
            //gameData.cardnum = data.numof_cards_2;//房卡数量
            gameData.cardnum = gameData.numOfCards[1];
            this.txtCount.setString(gameData.cardnum || "0");
        }
    },

    onUserInfo: function (info) {
        var data = info.data;
        if (window.inReview) {
            this.btn_yaoqing.setVisible(false);
            this.lottery.setVisible(false);
        }
    },
    setCardNum: function (numof_cards) {
        var that = this;
        var txtCount = getUI(that, "txtCount");
        txtCount.setString(gameData.cardnum || "0");
    },
    //重新加入房间
    onGetRoomInfo: function (data) {
        if (data.result == -1) {
            // HUD.showMessage("房间" + this.roomId + "不存在");
            return;
        }
        if (data.result == 0 && !this.isConnect) {
            DC.wsHost = data.data.url;
            mRoom.roomId = data.data.roomid;
            gameData.roomId = mRoom.roomId;
            var option = data.data.option;
            var obj = decodeHttpData(option);

            mRoom.rounds = obj.rounds;
            mRoom.getWanfa(obj);
            mRoom.ownner = data.data.ownner;
            this.isConnect = true;

            DC.wsConnect(this);
        }
    },
    //加入房间接口
    onUserJoin: function (event) {
        var data = event.getUserData();
        // console.log(data);
        var Result = null;
        if (data.Head) {
            Result = data.Head.Result;
        }
        if (data.Result) {
            Result = data.Result;
        }
        if (Result != null && Result != 0) {
            var ErrorMsg = (data.Head) ? data.Head.ErrorMsg : data.ErrorMsg;
            HUD.showMessage(ErrorMsg);
            this.scheduleOnce(function () {
                DC.closeByClient = true;
                //DC.socket.close();
            }, 1);
        } else if (Result != null && Result == -1) {
            var msg = (data.Head) ? data.Head.ErrorMsg : data.ErrorMsg;
            HUD.showMessageBox('提示', msg, function () {
                HUD.showScene(HUD_LIST.Login, null);
            }, true);
        } else {
            //加入房间要收到确切的加入房间消息才能加入,断线重连直接进入房间
            mRoom.roomId = data.RoomID;
            gameData.roomId = mRoom.roomId;
            var option = data.Option;
            var obj = decodeHttpData(option);
            mRoom.rounds = obj.rounds;
            mRoom.getWanfa(obj);
            mRoom.ownner = data.Owner;

            if (mRoom.wanfatype == "dn") {
                gameData.players = data['Users'];
            } else {
                DD[T.PlayerList] = data['Users'];
            }
            network.stop();
            if (mRoom.wanfatype == mRoom.YOUXIAN) {
                HUD.showScene(HUD_LIST.Room, this);
            }
        }
    },
    //验证登录
    onRoleLoginOK: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        var Result = 0;
        if (data.Head) {
            Result = data.Head.Result;
        } else {
            Result = data.Result;
        }
        if (Result == 0) {
            mRoom.setRoomType(2);
            if (mRoom.roomType == 1) {
            } else if (mRoom.roomType == 2) {
                //加入房间要收到确切的加入房间消息才能加入,断线重连直接进入房间
                var cmd = "JoinRoom/" + mRoom.roomId;//Continue
                network.wsData(cmd, true);
                network.stop();
                if (mRoom.wanfatype == mRoom.YOUXIAN) {
                    HUD.showScene(HUD_LIST.Room, this);
                }
            }
        } else if (Result == ERR_CODE.VERSION_ERR) {
            if (cc.sys.isNative) {
                HUD.showMessageBox('提示', '系统检测到有新的游戏版本，为避免影响您的游戏体验，请尽快大退游戏进行更新。', function () {
                    if (cc.sys.os == cc.sys.OS_ANDROID) {
                        cc.director.end();
                    }
                }, true);
            }
        } else {
            HUD.showMessage("登录失败");
        }
    },

    //跑马灯
    onMaDeng: function (event) {
        var that = this;
        var interval = null;
        var func = function () {
            if (!that || !cc.sys.isObjectValid(that)) {
                if (interval) {
                    clearInterval(interval);
                    interval = null;
                }
                return;
            }
            var content = (window.inReview) ? "文明游戏,欢乐人生" : gameData.Content;
            var speaker = getUI(that, 'speaker');
            speaker.setVisible(true);
            speaker.setLocalZOrder(100);
            var speakerPanel = getUI(that, 'speakepanel');
            speaker.runAction(cc.fadeIn(0.2));
            var text = new ccui.Text();
            text.setFontSize(26);
            text.setColor(cc.color(255, 255, 255));
            text.setAnchorPoint(cc.p(0, 0));
            text.enableOutline(cc.color(0, 0, 0), 1);
            speakerPanel.removeAllChildren();
            speakerPanel.addChild(text);
            text.setString(content);
            text.setPositionX(speakerPanel.getContentSize().width);
            text.setPositionY(5);
            text.runAction(cc.sequence(
                cc.delayTime(0.2),
                cc.moveTo((content.length * 0.3 <= 10) ? 10 : content.length * 0.3, -text.getVirtualRendererSize().width, 5),
                cc.delayTime(0.3),
                cc.callFunc(function () {
                    speaker.runAction(cc.fadeOut(0.2))
                })
            ));
        };
        if (gameData.Content != null && gameData.Content != undefined && gameData.Content != "") {
            func();
            var t = (gameData.Content.length * 0.3 <= 30) ? 30 : (gameData.Content.length * 0.3 + 5);
            interval = setInterval(func, t * 1000);
        }
    },
    onYaoQing: function (sender, type) {
        var that = this;
        //邀请
        var ok = touch_process(sender, type);
        if (ok) {
            that.addChild(new YaoQingLayer());
        }
    },
    setCardFont: function () {

    },
    createRoomLayer: function (isDaikai, gameType, club_id, isSetWanfa) {
        var that = this;
        var pos3X = {
            1: 480,
            2: 720,
            3: 960,
        };
        var pos4X = {
            1: 480,
            2: 640,
            3: 800,
            4: 960,
        };
        var createRoomLayer = new CreateRoomLayer(0, (function () {
            var t = [
                ['mapid', [
                    ['攸县碰胡子', MAP_ID_PHZ, 2000, 2000, false, true, false],
                    ['双十上庄', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['通比玩法', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['抢庄玩法', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['明牌抢庄', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['九人明牌', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['抢庄推注', MAP_ID_DN, 2000, 2000, true, true, false],


                    ['转转麻将', MAP_ID_ZHUANZHUAN, -1000, -1000, true, true, false],
                    ['长沙麻将', MAP_ID_CHANGSHA, -1000, -1000, false, true, false],
                    ['红中麻将', MAP_ID_HONGZHONG, -1000, -1000, false, true, false],

                    ['跑得快', MAP_ID_PDK, -1000, -1000, true, true, false],
                    ['拼三张', MAP_ID_ZJH, -1000, -1000, true, true, false],

                    ['无花双十', MAP_ID_DN, 2000, 2000, true, true, false],
                    ['疯狂双十', MAP_ID_DN, 2000, 2000, true, true, false]
                ]],
                ['AA',
                    [['房主支付', false, 480, 580, true, true, false, null, ['mapid_0', 'mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_7', 'mapid_8', 'mapid_9', 'mapid_10', 'mapid_11', 'mapid_12', 'mapid_13']],
                        ['AA支付', true, 720, 580, false, true, false, null, ['mapid_0', 'mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_7', 'mapid_8', 'mapid_9', 'mapid_10', 'mapid_11', 'mapid_12', 'mapid_13']]
                    ]],

                ['rounds',
                    [['8局', 8, 480, 525, true, true, false, null, 'mapid_0'],
                        ['16局', 16, 720, 525, false, true, false, null, 'mapid_0'],
                        ['24局', 24, 960, 525, false, true, false, null, 'mapid_0']
                    ]],
                ['rounds_nn',
                    [['10局', 10, 480, 525, true, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                        ['20局', 20, 720, 525, false, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                        ['30局', 30, 960, 525, false, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']]
                    ]],
                ['zhongzhuang', [['连中', true, 480, 470, true, true, false, null, 'mapid_0'],
                    ['中庄', false, 720, 470, false, true, false, null, 'mapid_0']]],
                ['ZhuangMode', [
                    ['双十上庄', "Niuniu", 2000, 595, true, true, false, null, 'mapid_1']
                ]],
                ['ZhuangMode_nn', [
                    ['通比玩法', "Tongbi", 2000, 595, true, true, false, null, 'mapid_2']
                ]],
                ['ZhuangMode_nnqz', [
                    ['抢庄玩法', "Qiang", 2000, 595, true, true, false, null, 'mapid_3']
                ]],
                ['ZhuangMode_mznn', [
                    ['明牌抢庄', "Qiang", 2000, 595, true, true, false, null, ['mapid_4']]
                ]],
                ['ZhuangMode_jrmp', [
                    ['九人明牌', "Qiang", 2000, 595, true, true, false, null, ['mapid_5']]
                ]],
                ['ZhuangMode_qztz', [
                    ['抢庄推注', "Qiang", 2000, 595, true, true, false, null, ['mapid_6']]
                ]],
                ['ZhuangMode_whsz', [
                    ['无花双十', "Qiang", 2000, 595, true, true, false, null, ['mapid_12', 'mapid_13']]
                ]],
                ['Preview', [
                    ['全扣', "ling", 480, 195, true, true, false, null, ['mapid_1']],
                    ['扣1张', "si", 720, 195, false, true, false, null, ['mapid_1']],
                    ['扣2张', "san", 960, 195, false, true, false, null, ['mapid_1']]
                ]],
                ['Preview_mp', [
                    ['扣1张', "si", 2000, 300, true, true, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']]
                ]],
                ['AlwaysTui', [
                    ['抢庄推注', true, 2000, 300, true, true, false, null, ['mapid_6']]
                ]],
                // ['Xiaobeilv', [
                //     ['双十x3  十带九x2  十带八x2  十带七x2', '3222', 480, 470, true, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12']],
                //     ['双十x4  十带九x3  十带八x2  十带七x2', '4322', 480, 415, false, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12']]
                // ]],
                ['Xiaobeilv', [
                    ['双十x3 十带九x2 十带八x2 十带七x2', '3222', 480, 470, true, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12'], null,
                        [['双十x3 十带九x2 十带八x2 十带七x2', '3222'], ['双十x4 十带九x3 十带八x2 十带七x2', '4322']]]
                ]],
                ['kuozhan1', [
                    ['五花/炸弹x6  五小x8', true, 480, 420, true, true, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6']]
                ]],
                ['kuozhan2', [
                    ['顺子/葫芦/同花x5', true, 870, 420, true, false, false, null, ['mapid_1', 'mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12']]
                ]],
                ['kuozhanwuhua1', [
                    ['炸弹x8 四十大/十小x6', true, 480, 420, true, true, false, null, ['mapid_12']]
                ]],
                ['tieban', [
                    ['铁板牛', true, 480, 360, false, false, false, null, ['mapid_12']]
                ]],
                ['noColor', [
                    ['无花', true, 2000, 2000, true, true, false, null, ['mapid_12']]
                ]],
                ['crazy', [
                    ['疯狂双十', true, 2000, 2000, true, true, false, null, ['mapid_13']]
                ]],
                ['isztjr', [
                    ['禁止中途加入', true, 720, 140, false, false, false, null, ['mapid_2', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']]
                ]],
                ['isztjr_sznn', [
                    ['禁止中途加入', true, 480, 140, false, false, false, null, ['mapid_1']]
                ]],
                ['Cuopai', [
                    ['禁止搓牌', true, 960, 140, false, false, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']]
                ]],
                ['Cuopai_sznn', [
                    ['禁止搓牌', true, 720, 140, false, false, false, null, ['mapid_1']]
                ]],
                ['Chipin', [
                    ['1分', 1, 480, 305, true, true, false, null, 'mapid_2'],
                    ['2分', 2, 720, 305, false, true, false, null, 'mapid_2'],
                    ['5分', 5, 960, 305, false, true, false, null, 'mapid_2']
                ]],
                ['Difen', [
                    ['1/2', "1,2", 480, 305, true, true, false, null, ['mapid_1', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                    ['2/4', "2,4", 640, 305, false, true, false, null, ['mapid_1', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6','mapid_12', 'mapid_13']],
                    ['4/8', "4,8", 800, 305, false, true, false, null, ['mapid_1', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6','mapid_12', 'mapid_13']],
                    ['5/10', "5,10", 960, 305, false, true, false, null, ['mapid_1', 'mapid_3', 'mapid_4', 'mapid_5', 'mapid_6']]
                ]],
                ['DisableHeiqiang', [
                    ['下注限制', true, 480, 180, false, false, false, null, ['mapid_3', 'mapid_4', 'mapid_5', 'mapid_12']]
                ]],
                ['MaxTuizhu', [
                    ['0倍', 0, 480, 250, false, true, false, null, ['mapid_3', 'mapid_4', 'mapid_5', 'mapid_12']],
                    ['5倍', 5, 640, 250, false, true, false, null, ['mapid_3', 'mapid_4', 'mapid_5', 'mapid_12']],
                    ['10倍', 10, 800, 250, true, true, false, null, ['mapid_3', 'mapid_4', 'mapid_5', 'mapid_12']],
                    ['15倍', 15, 960, 250, false, true, false, null, ['mapid_3', 'mapid_4', 'mapid_5', 'mapid_12']]
                ]],
                ['MaxTuizhu_qztzadd', [
                    ['3倍', 3, 480, 250, false, true, false, null, ['mapid_6']],
                    ['5倍', 5, 640, 250, false, true, false, null, ['mapid_6']],
                    ['8倍', 8, 800, 250, true, true, false, null, ['mapid_6']]
                ]],
                ['BeiShu_mznn', [
                    ['1倍', 1, 480, 250, false, true, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                    ['2倍', 2, 640, 250, false, true, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                    ['3倍', 3, 800, 250, false, true, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']],
                    ['4倍', 4, 960, 250, true, true, false, null, ['mapid_4', 'mapid_5', 'mapid_6', 'mapid_12', 'mapid_13']]
                ]],
                ['ChipInType', [
                    ['首局下注', '1', 480, 250, true, true, false, null, ['mapid_1']],
                    ['闲家推注', '2', 720, 250, false, true, false, null, ['mapid_1']]
                ]],
                ['Meiniuxiazhuang', [
                    ['没十下庄', true, 960, 250, false, false, false, null, ['mapid_1']]
                ]],
                ['Players', [
                    ['九人场', 'jiu', 2000, 2000, true, true, false, null, ['mapid_5']]
                ]],
                // ['AA_mj', [['房主支付', false, 480, 580, true, true, false, null, ['mapid_7', 'mapid_8', 'mapid_9', 'mapid_10', 'mapid_11']],
                //     ['AA支付', true, 720, 580, false, true, false, null, ['mapid_7', 'mapid_8', 'mapid_9', 'mapid_10', 'mapid_11']]
                // ]],

                ['jushu', [
                    ['8局', 8, pos3X[1], 525, true, true, false, null, ['mapid_7','mapid_8', 'mapid_9', 'mapid_10', 'mapid_11']],
                    ['16局', 16, pos3X[2], 525, false, true, false, null, ['mapid_7','mapid_8', 'mapid_9', 'mapid_10', 'mapid_11']]
                ]],

                ['qiangganghu', [['可抢杠胡', true, pos3X[1], 470, true, false, false, 'onlyzimo', ['mapid_7', 'mapid_9']]]],
                ['onlyzimo', [['只能自摸胡', true, pos3X[2], 470, false, false, false, 'qiangganghu', ['mapid_7', 'mapid_9']]]],
                ['hongzhong', [['红中赖子', true, pos3X[3], 470, false, false, false, null, ['mapid_7']]]],

                ['zhuangxian', [['庄闲分', true, pos3X[1], 470, true, false, false, null, 'mapid_8']]],
                ['piao', [['飘分', -1, pos3X[2], 470, true, false, false, null, 'mapid_8']]],
                ['zhongniaofanbei', [['抓码翻倍', true, pos3X[3], 470, false, false, false, null, ['mapid_8']]]],

                ['buzhuama', [['不抓码', true, pos3X[1], 415, true, true, false, ['zhuama159_0', 'zhuamajingdian_0'], ['mapid_8']]]],
                ['zhuama159', [['159抓码', true, pos3X[3], 415, false, true, false, ['zhuamajingdian_0', 'buzhuama_0'], ['mapid_8']]]],
                ['zhuamajingdian', [['经典抓码', true, pos3X[2], 415, false, true, false, ['zhuama159_0', 'buzhuama_0'], ['mapid_8']]]],

                ['bubugao', [['步步高', true, pos3X[1], 360, false, false, false, null, 'mapid_8']]],
                ['yizhihua', [['一枝花', true, pos3X[2], 360, false, false, false, null, 'mapid_8']]],
                ['santong', [['三同', true, pos3X[3], 360, false, false, false, null, 'mapid_8']]],

                ['jintongyunv', [['金童玉女', true, pos3X[1], 305, false, false, false, null, 'mapid_8']]],
                ['zhongtusixi', [['中途四喜', true, pos3X[3], 305, false, false, false, null, 'mapid_8']]],
                ['jiaganghu', [['假将胡', true, pos3X[2], 305, false, false, false, null, 'mapid_8']]],

                ['zhongtuliuliushun', [['中途六六顺', true, pos3X[1], 250, false, false, false, null, 'mapid_8']]],


                ['qidui', [['可胡七对', true, pos3X[1], 415, true, false, false, null, ['mapid_7', 'mapid_9']]]],
                ['zuojiang258', [['258做将', true, pos3X[2], 415, false, false, false, null, ['mapid_7','mapid_9']]]],

                ['hongzhong_hz', [['红中赖子', true, 2000, 2000, true, true, false, null, ['mapid_9']]]],

                ['liangrenwan', [['2人', true, pos3X[3], 195, false, true, false, ['sanrenwan_0', 'siren_0'], ['mapid_7']]]],
                ['sanrenwan', [['3人', true, pos3X[2], 195, false, true, false, ['liangrenwan_0', 'siren_0'], ['mapid_7']]]],
                ['siren', [['4人', true, pos3X[1], 195, true, true, false, ['sanrenwan_0', 'liangrenwan_0'], ['mapid_7']]]],

                ['sanrenwan_cs', [['3人', true, pos3X[2], 195, false, true, false, ['siren_cs_0'], ['mapid_8','mapid_9']]]],
                ['siren_cs', [['4人', true, pos3X[1], 195, true, true, false, ['sanrenwan_cs_0'], ['mapid_8','mapid_9']]]],

                ['zhaniao', [
                    ['2个', 2, pos4X[1], 140, false, false, false, null, ['mapid_7','mapid_9']],
                    ['4个', 4, pos4X[2], 140, false, false, false, null, ['mapid_7','mapid_9']],
                    ['6个', 6, pos4X[3], 140, false, false, false, null, ['mapid_7','mapid_9']],
                    ['摸几奖几', 100, pos4X[4], 140, false, false, false, null, ['mapid_7','mapid_9']]
                ]],

                ['zhaniao_cs', [
                    ['2个', 2, pos3X[1], 140, true, true, false, null, ['mapid_8']],
                    ['4个', 4, pos3X[2], 140, false, true, false, null, ['mapid_8']],
                    ['6个', 6, pos3X[3], 140, false, true, false, null, ['mapid_8']]
                ]],
                ['zhaniao_csfanbei', [
                    ['1个', 1, pos3X[1], 140, true, true, false, null, ['mapid_8']]
                ]],

                //跑得快
                ['sanrenwan_pdk', [
                    ['三人玩', true, pos3X[1], 470, true, true, false,['liangren_pdk_0'],'mapid_10']
                ]],
                ['liangren_pdk', [
                    ['二人玩', true, pos3X[2], 470, false, true, false, ['zhuaniao_0','sanrenwan_pdk_0'],'mapid_10']
                ]],
                ['pdk3Abomb', [
                    ['3A当炸弹', true, pos3X[2], 305, false, false, false, null,['mapid_10']]
                ]],
                ['pdkNumofCardsPerUser', [
                    ['16张', 16, 480, 415, true, true, false,null,'mapid_10'],
                    ['15张', 15, 720, 415, false, true, false, null,'mapid_10']
                ]],
                ['zhuaniao', [
                    ['抓鸟(红桃10)', true, pos3X[1], 360, false, false, false,null,'mapid_10']
                ]],
                ['heisanzhuang', [
                    ['黑桃3先出', true, pos3X[2], 360, false, false, false,null, 'mapid_10']
                ]],
                ['sidai2or3', [
                    ['允许4带3', 2, pos3X[1], 250, true, false, false, null, 'mapid_10']
                ]],

                ['xianshipai', [
                    ['显示余牌', true, pos3X[1], 305, true, false, false,null, 'mapid_10']
                ]],
                ['anticheating', [
                    ['防作弊', true, pos3X[3], 305, false, false, false,null, 'mapid_10']
                ]],
                //拼三张
                ['menround', [
                    ['不闷', 0, 480, 195, true, true, false, null, 'mapid_11'],
                    ['1轮', 1, 480+130, 195, false, true, false, null, 'mapid_11'],
                    ['2轮', 2, 480+260, 195, false, true, false, null, 'mapid_11'],
                    ['3轮', 3, 480+390, 195, false, true, false, null, 'mapid_11'],
                    ['5轮', 5, 480+520, 195, false, true, false, null, 'mapid_11']
                ]],
                ['biround', [
                    ['1轮', 1, pos3X[1], 250, true, true, false, null, 'mapid_11'],
                    ['2轮', 2, pos3X[2], 250, false, true, false, null, 'mapid_11'],
                    ['3轮', 3, pos3X[3], 250, false, true, false, null, 'mapid_11']
                ]],
                ['genround', [
                    ['5轮', 5, pos3X[1], 305, true, true, false, null, 'mapid_11'],
                    ['10轮', 10, pos3X[2], 305, false, true, false, null, 'mapid_11'],
                    ['15轮', 15, pos3X[3], 305, false, true, false, null, 'mapid_11']
                ]],
                ['bipai', [
                    ['比大小', 'daxiao', pos3X[1], 470, false, true, false, null, 'mapid_11', '同牌型最大单牌大小相同时，依次\n比较剩余牌的大小'],
                    ['比花色', 'huase', pos3X[2], 470, false, true, false, null, 'mapid_11', '同牌型最大单牌大小相同时，最大单张\n牌比较花色，黑桃>红桃>梅花>方片'],
                    ['全比', 'quanbi', pos3X[3], 470, true, true, false, null, 'mapid_11', '先"比大小"，大小相同再"比花色"']
                ]],
                ['baoziewai', [
                    ['豹子额外奖励', true, pos3X[1], 415, false, false, false, null, 'mapid_11']
                ]],
                ['bipaishuangbei', [
                    ['比牌双倍开', true, pos3X[2], 415, false, false, false, null, 'mapid_11']
                ]],
                ['jiesuansuanfen', [
                    ['解散局算分', true, pos3X[1], 360, false, false, false, null, 'mapid_11']
                ]],
                ['zidongqipai', [
                    ['超时自动弃牌(180秒)', true, pos3X[2], 360, false, false, false, null, 'mapid_11']
                ]],

            ];
            if(gameData.opt_conf['zjkztjr'] == 1){
                t.push( ['yunxujiaru', [
                        ['禁止中途加入', false, pos3X[1], 140, false, false, false, null, ['mapid_11']]
                    ]]);
                t.push(  ['withOnLookers', [
                    ['允许观看', true, 2000, 2000, true, true, false, null, ['mapid_11']]
                ]]);
            }
            return t;
        })(), {
            btn_0: {
                click: 'mapid_0',
                show: [],
                hide: []
            },
            btn_1: {
                click: 'mapid_1',
                show: [],
                hide: []
            },
            btn_2: {
                click: 'mapid_2',
                show: [],
                hide: []
            },
            btn_3: {
                click: 'mapid_3',
                show: [],
                hide: []
            },
            btn_4: {
                click: 'mapid_4',
                show: [],
                hide: []
            },
            btn_5: {
                click: 'mapid_5',
                show: [],
                hide: []
            },
            btn_6: {
                click: 'mapid_6',
                show: [],
                hide: []
            },
            btn_7: {
                click: 'mapid_7',
                show: [],
                hide: []
            }
            ,
            btn_8: {
                click: 'mapid_8',
                show: [],
                hide: []
            },
            btn_9: {
                click: 'mapid_9',
                show: [],
                hide: []
            },
            btn_10: {
                click: 'mapid_10',
                    show: [],
                    hide: []
            },
            btn_11: {
                click: 'mapid_11',
                show: [],
                hide: []
            },
            btn_12: {
                click: 'mapid_12',
                show: [],
                hide: []
            },
            btn_13: {
                click: 'mapid_13',
                show: [],
                hide: []
            }
        }, 14, isDaikai, gameType, club_id, isSetWanfa);
        createRoomLayer.setName('createRoomLayer');
        that.addChild(createRoomLayer);
    },

    onStatusChange: function (event) {
        if (this.checkNoRunning()) return;
        var data = event.getUserData();
        HUD.showMessage(data.Status);

        //LOGIN OK
    },
    showShareGames: function () {
        if (window.inReview) {
            return;
        }
        var that = this;
        var games = getShareGames();
        if (games.length > 0)
            games.push('all');
        var dis = 700 / (games.length + 1);
        for (var i = 0; i < games.length; i++) {
            (function () {
                var id = games[i];
                var btn = new cc.Sprite("res/image/ui/games/" + id + ".png");
                that.addChild(btn);
                btn.setScale(0.8);
                btn.y = 47;
                btn.x = (i + 1) * dis;
                TouchUtils.setOnclickListener(btn, function () {
                    shareMoreGame(id);
                })
            })(i);
        }
    },
    startParticles: function () {
        this.partical_huaban = cc.ParticleSystem.create(res.huaban_plist);
        this.partical_huaban.setPosition(cc.winSize.width / 2, cc.winSize.height);
        // huaban.setAutoRemoveOnFinish(true);
        this.addChild(this.partical_huaban);
        // $('node_huaban').addChild(this.partical_huaban);

        // var bianpao = $('bianpao');
        // var bianpao_size = bianpao.getContentSize();
        // this.partical_bianpao_diao = cc.ParticleSystem.create(res.bianpao_diao_plist);
        // this.partical_bianpao_diao.setPosition(bianpao_size.width / 2, 10);
        // // bianpao_diao.setAutoRemoveOnFinish(true);
        // bianpao.addChild(this.partical_bianpao_diao);
        // this.partical_bianpao_zha = cc.ParticleSystem.create(res.bianpao_zha_plist);
        // this.partical_bianpao_zha.setPosition(bianpao_size.width / 2, 10);
        // // bianpao_zha.setAutoRemoveOnFinish(true);
        // bianpao.addChild(this.partical_bianpao_zha);


        var yanhua_node = this;//$('node_yanhua');
        var COLORS = [
            cc.color(15, 63, 251),
            cc.color(169, 122, 70),
            cc.color(3, 252, 254),
            cc.color(0, 247, 44),
            cc.color(254, 75, 252),
            cc.color(254, 146, 37),
            cc.color(147, 40, 144),
            cc.color(255, 42, 26),
            cc.color(253, 249, 53)
        ];
        var playYanhua = function (delay) {
            yanhua_node.runAction(cc.sequence(
                cc.delayTime(delay || Math.random() * 2),
                cc.callFunc(function () {
                    var yanhua_fly = cc.ParticleSystem.create(res.yanhua_fly_plist);
                    yanhua_fly.setPosition(Math.floor(Math.random() * 720) + 280, 0);
                    yanhua_fly.setScale(0.5);
                    yanhua_fly.setAutoRemoveOnFinish(true);
                    yanhua_node.addChild(yanhua_fly);
                    var fly_time = Math.random() + 1;
                    yanhua_fly.runAction(cc.sequence(
                        cc.moveBy(fly_time, 0, fly_time * 180 + 320),
                        cc.callFunc(function () {
                            var yanhua_zha = cc.ParticleSystem.create(res.yanhua_zha_plist);
                            yanhua_zha.setStartColor(COLORS[Math.floor(Math.random() * COLORS.length)]);
                            yanhua_zha.setLifeVar(Math.random() * 1.3 + 0.7);
                            yanhua_zha.setPosition(yanhua_fly.getPosition());
                            yanhua_zha.setAutoRemoveOnFinish(true);
                            yanhua_node.addChild(yanhua_zha);
                            yanhua_fly.removeFromParent(true);
                        })
                    ));
                    playYanhua();
                })
            ))
        };
        playYanhua(1);
    },

    setFangkaNum: function (numof_cards) {
        gameData.cardnum = numof_cards;
        this.txtCount.setString(gameData.cardnum || "0");
    }
};