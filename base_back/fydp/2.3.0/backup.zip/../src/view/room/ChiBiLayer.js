var ChiBiLayer = {
    init:function () {
        var that = this;
        this.bg = getUI(this, "bg");
        this.back = getUI(this, "back");
        this.chibi = getUI(this, "chibi");
        this.guo = getUI(this, "guo");
        this.chiIndex = -1;
        this.lastChiList = [];
        this.chiIndexArray = [0,0,0];
        this.cards = [];

        TouchUtils.setOnclickListener(this.back, function (node) {
            var chi = that.getChildByName('chiList' + that.chiIndex);
            if(chi){
                chi.removeFromParent();
            }
            that.chiIndex --;
            if(that.chiIndex < 0) {
                that.removeAllChildren();
            }else if(that.chiIndex == 0){
                that.chibi.setTexture(res.room_chi_png);
                that.setData(that.chibiData, that.showNo);
                that.cards = [];
            }else{
                that.cards.splice(that.cards.length-3, 3);
                that.chibi.setTexture(res.room_bi_png);
                that.showBiCard(that.chiIndex, that.lastChiList, that.cards);
            }
        });
        TouchUtils.setOnclickListener(this.guo, function (node) {
            that.parent.userAct(GUO, that.showNo);
        });
        return true;
    },
    setData:function(data, showNo, parent){
        this.chibiData = data;
        this.showNo = showNo;
        if(parent){
            this.parent = parent;
        }
        for(var i=0;i<10;i++){
            var cardS = this.getChildByName('cardSelect' + i);
            if(cardS){
                cardS.removeFromParent();
            }
        }
        for(var i=0;i<this.chibiData.length;i++){
            var cardSelect = HUD.showLayer(HUD_LIST.CardSelect, this);
            cardSelect.setData(this.showNo, this.chibiData[i], this, 0, [], i);
            cardSelect.setPosition(SW/2 + (i-1) * 100 + 40,  250);
            cardSelect.setName('cardSelect' + i);
        }
        this.lastChiList = this.chibiData;
    },
    showBiCard:function(level, chiList, cards, index){
        this.cards = cards;
        this.chibi.setTexture(res.room_bi_png);
        var rowIndex = level;
        for(var i=0;i<10;i++){
            var cardS = this.getChildByName('cardSelect' + i);
            if(cardS){
                cardS.removeFromParent();
            }
        }
        for(var i=0;i<chiList.length;i++){
            var cardSelect = HUD.showLayer(HUD_LIST.CardSelect, this);
            cardSelect.setData(this.showNo, chiList[i], this, level, cards, i);
            cardSelect.setPosition(SW/2 + (i-1) * 100 + 40,  250);
            cardSelect.setName('cardSelect' + i);
        }
        this.addChiLayer(cards, level);
        if(index != undefined){
            this.chiIndexArray[level] = index;
        }
        if(level == 1){
            this.lastChiList = this.chibiData[this.chiIndexArray[1]][3];
        }
    },
    addChiLayer:function(chiArray, index){
        for(var i=0;i<10;i++){
            var cardS = this.getChildByName('chiList' + i);
            if(cardS){
                cardS.removeFromParent();
            }
        }
        var hang = Math.floor((chiArray.length+2)/3);
        for(var i=0;i<hang;i++){
            var chinum = [chiArray[i*3], chiArray[i*3+1], chiArray[i*3+2]];
            var cardSelect = HUD.showLayer(HUD_LIST.CardSelect, this);
            cardSelect.setChiData(this.showNo, chinum);
            cardSelect.setPosition((i) * 70,  300);
            cardSelect.setScale(0.8);
            cardSelect.setTouchEnableStatus(false);
            cardSelect.setName('chiList' + (i+1));
        }
        this.chiIndex = index;
    },
    sendChi:function(cards){
        // console.log(cards);
        this.parent.userAct(CHI, this.showNo, false, cards);
        this.hide(true);
    },
};