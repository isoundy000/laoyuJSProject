/**
 * Created by dengwenzhong on 2017/9/21.
 */
(function () {
    var exports = this;

    var $ = null;

    var HUTYPE_LIUJU = 0;
    var HUTYPE_ZIMO = 1;
    var HUTYPE_DIANPAO = 2;

    var PokerJieSuanLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
            AgoraUtil.hideAllVideo();
        },
        onExit: function () {
            cc.Layer.prototype.onExit.call(this);
            AgoraUtil.showAllVideo();
        },
        ctor: function (data,isReplay) {
            this._super();

            var that = this;

            var size = cc.winSize;

            var scene = ccs.load(res.PokerJieSuan_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            // var title = (data['map_id'] ? (gameData.mapId2Name[data['map_id']] + '\n') || '' : '');

            var btnFenxiang = $('root.btn_share');
            var btnStart = $('root.btn_again');
            var btnChakan = $('root.btn_chakan');

            // if (gameData.loginType == 'yk') {
            //     btnFenxiang.setVisible(false);
            //     btnStart.setPositionX(btnStart.getParent().getContentSize().width / 2);
            // }

            var isWin = true;
            var players =[];
            var base = $('info0');
            var myScore = 0;

            //两人玩 BUG
            var players = [];
            for (var i = 0; i < data.players.length; i++) {
                var player = data.players[i];
                if (player.uid != 0) {
                    players.push(player);
                }

            }
            if(players.length == 2){
                $('info2').setVisible(false);
            }

            for (var i = 0; i < players.length; i++) {
                var player = players[i];
                base = $('info'+i);

                if (player['uid'] == 0) {
                    base.setVisible(false);
                    continue;
                }else{
                    var lb_nickname = $('txt_name', base);
                    var lb_uid = $('txt_id', base);
                    var lb_left = $('lb_left', base);
                    // var lb_score = $('row' + i + '.lb_score', base);
                    var head = $('head', base);
                    var niao = $('niao', base);
                    var spring = $('spring', base);
                    var lb_score = $('txt_score', base);

                    lb_nickname.setString(ellipsisStr(gameData.playerMap[player.uid].nickname || '', 6));
                    lb_uid.setString('' + player.uid);
                    lb_left.setString(player['pai_arr'].length + '张');
                    lb_score.setString('' + player['score']);
                    if (player['score'] > 0) {
                        lb_score.setTextColor(cc.color(255, 249, 142));
                    } else {
                        lb_score.setTextColor(cc.color(103, 220, 255));
                    }
                    if (player.uid == gameData.uid) {
                        myScore = player['score'];
                        lb_nickname.setTextColor(cc.color(255, 249, 142));
                        lb_uid.setTextColor(cc.color(255, 249, 142));
                    }
                    // lb_score.setString('' + player['score']);
                    loadImageToSprite(gameData.playerMap[player.uid].headimgurl, head);
                    niao.setVisible(player.uid == data.zhuaniao_uid);
                    spring.setVisible(player.uid == data.chuntian_uid);

                    if (gameData.uid == player.uid && player['score'] < 0)
                        isWin = false;
                }

            }
            if (myScore >= 0) {
                $('root.pic_win').setVisible(true);
                $('root.pic_lose').setVisible(false);
                $('root.losebg').setVisible(false);
                $('root.winbg').setVisible(false);
                if(cc.sys.isNative) {
                    var spNode = playSpAnimation('shenglijiesuan', undefined, false);
                    spNode.setEndListener(function () {
                        setTimeout(function () {
                            //spNode.removeFromParent();
                        }, 1)
                    })
                    spNode.setPosition(cc.winSize.width / 2, cc.winSize.height * 0.65 + 115);
                    this.addChild(spNode);
                }
            } else if (myScore < 0) {
                $('root.pic_win').setVisible(false);
                $('root.pic_lose').setVisible(true);
                $('root.losebg').setVisible(false);
                $('root.winbg').setVisible(false);
            }

            // $('root.panel.bg_base').setVisible(isWin);

            $('root.lb_ts').setString(timestamp2time(data['ts'], "yyyy-mm-dd HH:MM:ss"));
            // $('root.panel.lb_title').setString(title);
            $('root.lb_roomid').setString('房号' + gameData.roomId);
            $('root.lb_jushu').setString('局数' + data['cur_round'] + '/' + data['total_round']);

            TouchUtils.setOnclickListener(btnFenxiang, function () {
                if (!cc.sys.isNative)
                    return;

                WXUtils.captureAndShareToWX(that, 0x88F0);
            });

            TouchUtils.setOnclickListener(btnStart, function () {
                // ready
                network.send(3004, {room_id: gameData.roomId});
                window.maLayer.onJiesuanClose(true);
                that.removeFromParent(true);
            });

            var closeFunc = function () {
                // if(isReplay){
                //     gameData.roomId = 0;
                //     HUD.showScene(HUD_LIST.Home, null);
                // }else{
                //     // ready
                //     window.maLayer.onJiesuanClose(false);
                //     that.removeFromParent(true);
                // }
                window.maLayer.onJiesuanClose(false);
                that.removeFromParent(true);

            };
            TouchUtils.setOnclickListener($('root.btn_close'), closeFunc);
            TouchUtils.setOnclickListener(btnChakan, function () {
                window.maLayer.zongJiesuan();
                that.removeFromParent(true);
            });

            if (data['is_last']) {
                btnStart.setVisible(false);
                btnChakan.setVisible(true);
                btnFenxiang.setVisible(false);
                $('root.btn_close').setVisible(false);
            }else{
                $('root.btn_close').setVisible(false);
                btnChakan.setVisible(false);
            }
            if(isReplay){
                $('root.btn_close').setVisible(true);
                btnStart.setVisible(false);
                btnChakan.setVisible(false);
            }

            return true;
        },
        onEnter: function () {
            this._super();
            AgoraUtil.hideAllVideo();
        },
        onExit: function () {
            this._super();
            AgoraUtil.showAllVideo();
        }
    });

    exports.PokerJieSuanLayer = PokerJieSuanLayer;
})(window);

