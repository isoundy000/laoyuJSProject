/**
 * Created by scw on 2018/5/28.
 */

var BaseMessage = (function () {

    var startReceive=function(mcode){

        network.addListener(mcode, function (data) {
            cc.eventManager.dispatchCustomEvent("custom_listener_"+mcode, data);
        });
    }

    return{
        startReceive:startReceive
    }
})();
