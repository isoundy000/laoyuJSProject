var compareTwoNumbers = function (a, b) {
    return a - b
};

var equleTo0 = function (n) {
    return n == 0;
};

var getCurTimestamp = function () {
    return Math.round((new Date()).getTime() / 1000);
};

var time2timestamp = function (time) {

};

var getPaiLR = function (paiId) {
    if (paiId >= 1 && paiId <= 9)
        return [1, 9];
    if (paiId >= 10 && paiId <= 18)
        return [10, 18];
    if (paiId >= 19 && paiId <= 27)
        return [19, 27];
    return null;
};

var isSameColor = function (paiIdA, paiIdB) {
    if (paiIdA >= 1 && paiIdA <= 9)
        return paiIdB >= 1 && paiIdB <= 9;
    if (paiIdA >= 10 && paiIdA <= 18)
        return paiIdB >= 10 && paiIdB <= 18;
    if (paiIdA >= 19 && paiIdA <= 27)
        return paiIdB >= 19 && paiIdB <= 27;
    if (paiIdA >= 28 && paiIdA <= 34)
        return paiIdB >= 28 && paiIdB <= 34;
    return false;
};

var timestamp2time = function (timestamp, format) {
    format = format || "yyyy-mm-dd HH:MM:ss";
    var date = new Date(parseInt(timestamp) * 1000);
    return dateFormat(date, format);
};

var vibrate = function () {
    if (cc.sys.os == cc.sys.OS_IOS) {
        cc.Device.vibrate(1);
    }else if (cc.sys.os == cc.sys.OS_ANDROID) {
        cc.Device.vibrate(1);
    }
};
var setPokerFrameByName = function (sprite, name) {
    var frame = cc.spriteFrameCache.getSpriteFrame(name);
    if (!frame) {
        cc.spriteFrameCache.addSpriteFrames(res.poker_b_pdk_plist);
        frame = cc.spriteFrameCache.getSpriteFrame(name);
    }
    sprite.setSpriteFrame(frame);
};

var regBakBtn = function () {
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD, onKeyReleased: function (keyCode, event) {
                if (keyCode == cc.KEY.back) {
                    // alert2('确定退出游戏吗?', function () {
                    //     cc.director.end();
                    // }, null, false, true, true);
                    HUD.showMessageBox('提示', '确定退出游戏吗?', function () {
                        cc.director.end();
                    });
                }
                else if (keyCode == cc.KEY.menu) {

                }
            }
        }, this);
    }
};

var playAnimScene = function (distNode, res, posx, posy, loop, func) {
    var cacheNode = distNode.getChildByName(res);
    if (!cacheNode) {
        var animScene = ccs.load(res, "res/");
        cacheNode = animScene.node;
        if (cacheNode){
            cacheNode.setName(res);
            distNode.addChild(cacheNode);
            cacheNode.runAction(animScene.action);
            cacheNode.setPosition(posx, posy);

            var userdata = cacheNode.getUserData() || {};
            userdata.action = animScene.action;
            cacheNode.setUserData(userdata);
        } else{
           alert1('load' + res +"failed") ;
        }

    }

    var userdata = cacheNode.getUserData();
    userdata.action.play('action', loop);

    if(func){
        userdata.action.setLastFrameCallFunc(func);
    }
    return cacheNode;
};

var getPaiLR = function (paiId) {
    var t = [1, 9, 10, 18, 19, 27];
    var a = 0, b = 0;
    for (var i = 0; i < t.length; i += 2) {
        var l = t[i];
        var r = t[i + 1];
        if (paiId >= l && paiId <= r) {
            a = l;
            b = r;
            break;
        }
    }
    return {l:a,r:b};
};

var ellipsisStr = function (str, n) {
    if (str.length > n)
        str = str.substr(0, n - 1) + '..';
    return str;
};

// var playMusic = (function () {
//     var curBg = null;
//     return function (filename, isRepeate) {
//         filename = 'vbg';
//         if (!cc.sys.isNative)
//             return;
//         if (curBg == filename)
//             return;
//         curBg = filename;
//
//         var t = filename;
//         if (res[t])
//             cc.audioEngine.playMusic(res[t], !!isRepeate);
//         else if (res[filename])
//             cc.audioEngine.playMusic(res[filename], !!isRepeate);
//         else
//             cc.log("sound not found: " + filename);
//     }
// })();

var playMusic = (function () {
    return function (filename, isRepeate, enforce) {
        if (!filename) {
            filename = 'vbg' + (cc.sys.localStorage.getItem('setting_bgm') || "1");
        }
        if (!isRepeate) {
            isRepeate = true;
        }
        if (gameData && gameData.voiceFlag == false) {
            return;
        }
        var musicvoice = cc.sys.localStorage.getItem("musicvoice") || "1";
        if(musicvoice == "0"){
            return;
        }
        if (window.curBg == filename && !enforce)
            return;
        window.curBg = filename;
        if (!_.isUndefined(window.musicID)) {
            jsb.AudioEngine.stop(window.musicID);
            window.musicID = null;
        }
        var t = filename;
        if (_.isUndefined(window.musicVolume)) {
            resetVolume();
        }
        if(cc.sys.isNative) {
            if (res[t]) {
                window.musicID = jsb.AudioEngine.play2d(res[t], isRepeate, window.musicVolume);
            } else if (res[filename]) {
                window.musicID = jsb.AudioEngine.play2d(res[filename], isRepeate, window.musicVolume);
            } else {
                cc.log("sound not found: " + filename);
            }
        }else{
            if(res[t]) cc.audioEngine.playEffect(res[t], true);
        }
    }
})();

var pauseMusic = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (!_.isUndefined(window.musicID)) {
        jsb.AudioEngine.pause(window.musicID);
    }
};

var resumeMusic = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (!_.isUndefined(window.musicID)) {
        jsb.AudioEngine.resume(window.musicID);
    }
};

var stopMusic = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (!_.isUndefined(window.musicID)) {
        jsb.AudioEngine.stop(window.musicID);
        window.musicID = null;
    }
};

var resetVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    resetMusicVolume();
    resetEffectVolume();
};

var resetMusicVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        window.musicVolume = (cc.sys.localStorage.getItem('yinyuePrecent') || 1) / 300;
    } else {
        window.musicVolume = (cc.sys.localStorage.getItem('yinyuePrecent') || 1) / 1000;
    }
    if (window.musicID || window.musicID == 0) {
        jsb.AudioEngine.setVolume(window.musicID, window.musicVolume);
    }
};

var resetEffectVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        window.effectVolume = (cc.sys.localStorage.getItem('yinxiaoPrecent') || 1) / 200;
    } else {
        window.effectVolume = (cc.sys.localStorage.getItem('yinxiaoPrecent') || 1) / 800;
    }
};

var muteVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    jsb.AudioEngine.stopAll();
};

var playEffect = function (filename, sex, city) {
    if (!gameData)
        return;
    if (gameData.voiceFlag == false) {
        return;
    }
    var yinxiaovoice = cc.sys.localStorage.getItem("yinxiaovoice") || "1";
    if(yinxiaovoice == "0"){
        return;
    }
    if (_.isUndefined(window.effectVolume)) {
        resetVolume();
    }
    var soundName = "";
    if(window.paizhuo == "majiang" || window.paizhuo == "pdk" || window.paizhuo == "zjh")
    {
        var t = filename + '_' + (typeof sex === 'undefined' ? gameData.sex : sex);
        var soundRes = res;
        if (gameData.speakCSH) {
            soundRes = cs_res;
        }
        soundName = soundRes[t] || soundRes[filename] || res[t] || res[filename];
        if (_.isArray(soundName)) {
            soundName = soundName[Math.floor(Math.random() * soundName.length)]
        }
    } else{
        var t =  (sex == 1 ? 'n' : 'v') + filename;
        if(city){
            t = city + "_" + t;
        }

        if(city && gameData.isPutonghua && parseInt(gameData.isPutonghua) == 1 && mRoom.wanfatype == mRoom.YOUXIAN){
            var ptht = "pth_" + (sex == 1 ? 'n' : 'v') + filename;
            soundName = res[ptht];
            if(soundName == undefined){
                var pthnosex = "pth_" + filename;
                soundName = res[pthnosex];
            }
        }else {
            soundName = res[t];
            if (soundName == undefined) {
                soundName = res[filename];
            }
        }
    }

    if (!soundName) {
        cc.log("sound not found: " + filename);
        return;
    }
    if (!cc.sys.isNative) {
        cc.audioEngine.playEffect(soundName, false);
    } else {
        jsb.AudioEngine.play2d(soundName, false, window.effectVolume);
    }
};

var playNorEffect = function (filename) {
    if (!cc.sys.isNative) {
        return;
    }
    var volume = 1;
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        volume = 1.5;
    }
    jsb.AudioEngine.play2d(filename, false, volume);
};

var captureAndShareToWX = function (node) {
    var winSize = cc.director.getWinSize();
    var texture = new cc.RenderTexture(winSize.width, winSize.height);
    if (!texture)
        return;

    texture.retain();

    texture.setAnchorPoint(0, 0);
    texture.begin();
    node.visit();
    texture.end();
    
    var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
    time = time.replace(/[\s:-]+/g, '_');
    var namePNG = "ss-" + time + ".png";
    var nameJPG = "ss-" + time + ".jpg";
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
            texture.release();
            jsb.reflection.callStaticMethod(
                "org/cocos2dx/javascript/AppActivity",
                "sharePic",
                "(Ljava/lang/String;Z)V",
                nameJPG,
                false
            );
        });
    }
    else if (cc.sys.os == cc.sys.OS_IOS) {
        texture.saveToFile(namePNG, cc.IMAGE_FORMAT_PNG, true, function (renderTexture, str) {
            texture.release();
            jsb.reflection.callStaticMethod(
                "AppController",
                "sharePic:imageName:sceneType:",
                jsb.fileUtils.getWritablePath(),
                namePNG,
                0
            );
        });
    }

};

var getNativeVersion = function () {
    if (!cc.sys.isNative)
        return '2.2.0';
    return window.nativeVersion;
};

var downloadAndInstallApk = function (url) {
    if (!cc.sys.isNative)
        return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        // return jsb.reflection.callStaticMethod(
        //     "org/cocos2dx/javascript/AppActivity",
        //     "getVersionName",
        //     "()Ljava/lang/String;"
        // );
        return window.nativeVersion;
    }
};

var fetchUDID = function () {
    if (!cc.sys.isNative) {
        return "0123456789abcdef";
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(
            "AppController",
            "fetchUDID"
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "fetchUDID",
            "()Ljava/lang/String;"
        );
    }
};
var setPokerFrameByName = function (sprite, name) {
    var frame = cc.spriteFrameCache.getSpriteFrame(name);
    sprite.setSpriteFrame(frame);
};
////1方片 2梅花 3红桃 4黑桃
var getBigCardName = function(id){
    var name = "clubs_1.png";
    var huaseArr = ['diamonds', 'clubs', 'hearts', 'spades'];
    var huase = huaseArr[(id - 1) % 4];
    var id = Math.floor((id + 3) / 4);
    return huase + "_" + id + ".png";
};
var getBigCardJiaoName = function(id){
    var name = "clubs_1.png";
    var huaseArr = ['diamonds', 'clubs', 'hearts', 'spades'];
    var huase = huaseArr[(id - 1) % 4];
    var id = Math.floor((id + 3) / 4);
    return huase + "_num_" + id + ".png";
};
var getBigCardName2 = function(id){
    var name = "DN_pai_fangpian01";
    var huaseArr = ['fangpian', 'meihua', 'hongtao', 'heitao'];
    var huase = huaseArr[(id - 1) % 4];
    var id = Math.floor((id + 3) / 4);
    if(id < 10){
        id = '0' + id;
    }else if(id == 11){
        id = 'J';
    }else if(id == 12){
        id = 'Q';
    }else if(id == 13){
        id = 'K';
    }
    return "DN_pai_" + huase + id;
};
var setPokerFrameByNameNN = function (sprite, name) {
    for (var i = 0; i < 3; i++) {
        var frame = cc.spriteFrameCache.getSpriteFrame(name);
        if (!frame) {
            cc.spriteFrameCache.addSpriteFrames(res.poker_b_plist);
        } else {
            sprite.setSpriteFrame(frame);
            return;
        }
    }
    if (!cc.sys.isNative)
        throw new Error("getSpriteFrame(" + name + ") == null");
    else
        alert1("getSpriteFrame(" + name + ") == null");
};

var setSpriteFrameByName = function (sprite, name, plist) {
    for (var i = 0; i < 3; i++) {
        var frame = cc.spriteFrameCache.getSpriteFrame(name);
        if (!frame) {
            cc.spriteFrameCache.addSpriteFrames('res/image/ui/' + plist + '.plist');
        } else {
            sprite.setSpriteFrame(frame);
            return;
        }
    }
    if (!cc.sys.isNative)
        throw new Error("getSpriteFrame(" + name + ") == null");
    else
        alert1("getSpriteFrame(" + name + ") == null");
};
var setUIImageFrameByName = function (sprite, name, plist) {
    for (var i = 0; i < 3; i++) {
        var frame = cc.spriteFrameCache.getSpriteFrame(name);
        if (!frame) {
            cc.spriteFrameCache.addSpriteFrames('res/image/ui/' + plist + '.plist');
        } else {
            sprite.loadTexture(name, ccui.Widget.PLIST_TEXTURE);
            return;
        }
    }
    if (!cc.sys.isNative)
        throw new Error("getSpriteFrame(" + name + ") == null");
    else
        alert1("getSpriteFrame(" + name + ") == null");
};
var resetVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    resetMusicVolume();
    resetEffectVolume();
};

var resetMusicVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        window.musicVolume = (cc.sys.localStorage.getItem('yinyuePrecent') || 1) / 300;
    } else {
        window.musicVolume = (cc.sys.localStorage.getItem('yinyuePrecent') || 1) / 1000;
    }
    if (window.musicID || window.musicID == 0) {
        jsb.AudioEngine.setVolume(window.musicID, window.musicVolume);
    }
};

var resetEffectVolume = function () {
    if (!cc.sys.isNative) {
        return;
    }
    if (cc.sys.os == cc.sys.OS_ANDROID) {
        window.effectVolume = (cc.sys.localStorage.getItem('yinxiaoPrecent') || 1) / 200;
    } else {
        window.effectVolume = (cc.sys.localStorage.getItem('yinxiaoPrecent') || 1) / 800;
    }
};

var playThrowDice = function (sprite, k, endCb) {
    cc.spriteFrameCache.addSpriteFrames('res/table/dice.plist');

    var animFrames = [];
    for (var i = 0; i < 4; i++) {
        var frame = cc.spriteFrameCache.getSpriteFrame('dice_Action_' + i + '.png');
        animFrames.push(frame);
    }
    var animation = new cc.Animation(animFrames, 0.04);

    var action = cc.animate(animation);
    sprite.runAction(cc.sequence(
        action.repeat(2),
        cc.callFunc(function () {
            setSpriteFrameByName(sprite, 'dice_' + k + '.png', 'majiang/dice')
        }),
        cc.delayTime(0.4),
        cc.callFunc(function () {
            if (endCb)
                endCb();
        })
    ));
};
var playFrameAnim = function (plistFilePath, prefix, frameCnt, speed, isLoop, sprite, endCb) {
    playFrameAnim2(plistFilePath, prefix, 0, frameCnt, speed, isLoop, sprite, endCb);
};

var playFrameAnim2 = function (plistFilePath, prefix, beginFrame, frameCnt, speed, isLoop, sprite, endCb) {
    cc.spriteFrameCache.addSpriteFrames(plistFilePath);

    var animFrames = [];
    for (var i = beginFrame; i < beginFrame + frameCnt; i++) {
        var frame = cc.spriteFrameCache.getSpriteFrame(prefix + i + '.png');
        animFrames.push(frame);
    }
    var animation = new cc.Animation(animFrames, speed);

    var action = cc.animate(animation);
    sprite.stopAllActions();
    if (isLoop) {
        sprite.runAction(action.repeatForever());
    }
    else {
        sprite.runAction(cc.sequence(action, cc.callFunc(function () {
            if (endCb)
                endCb();
        })));
    }
};

var shareText = function (text, sceneType, transaction) {
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "shareText:sceneType:",
            text,
            (sceneType ? 1 : 0)
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "shareText",
            "(Ljava/lang/String;ZLjava/lang/String;)V",
            text,
            (sceneType ? true : false),
            transaction
        );
    }
};

var shareUrl = function (url, title, description, sceneType, transaction) {
    if (!cc.sys.isNative)
        return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "shareUrl:title:description:sceneType:",
            url,
            title,
            description,
            (sceneType ? 1 : 0)
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "shareUrl",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V",
            url,
            title,
            description,
            (sceneType ? true : false),
            transaction
        );
    }
};

var checkAllNodesValid = function (node) {
    if (!cc.sys.isObjectValid(node))
        return false;
    var children = node.getChildren();
    if (children.length) {
        for (var i = 0; i < children.length; i++)
            if (!checkAllNodesValid(children[i]))
                return false;
    }
    return true;
};

var getTransResult = function (key) {
    if (!cc.sys.isNative)
        return;

    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(
            "AppController",
            "getTransResult:",
            key
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "getTransResult",
            "(Ljava/lang/String;)Ljava/lang/String;",
            key
        );
    }
};

var isFileOpened = function (filename) {
    if (!cc.sys.isNative)
        return;

    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "isFileOpened:",
            jsb.fileUtils.getWritablePath() + filename
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "isFileOpened",
            "(Ljava/lang/String;)Z",
            filename
        );
    }
};

var startVoiceRecord = function (filename) {
    if (!cc.sys.isNative)
        return;

    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "startVoiceRecord:",
            jsb.fileUtils.getWritablePath() + filename
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "startVoiceRecord",
            "(Ljava/lang/String;)V",
            filename
        );
    }
};

var stopVoiceRecord = function (filename) {
    if (!cc.sys.isNative)
        return;

    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "stopVoiceRecord:",
            jsb.fileUtils.getWritablePath() + filename
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "stopVoiceRecord",
            "(Ljava/lang/String;)V",
            filename
        );
    }
};

var playVoiceByUrl = function (url) {
    if (!cc.sys.isNative)
        return;

    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "playVoiceByUrl:",
            url
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "playVoiceByUrl",
            "(Ljava/lang/String;)V",
            url
        );
    }
};

var uploadFileToOSS = function (readFilename, uploadFilename, cbSucc, cbFail) {
    if (!cc.sys.isNative)
        return;

    var filePath = jsb.fileUtils.getWritablePath() + readFilename;

    if (jsb.fileUtils.isFileExist(filePath)) {
        var data = jsb.fileUtils.getDataFromFile(filePath);

        var accessid = ALOV[gameData.appId][2];
        var arr = ALOV[gameData.appId][3];
        var host = ALOV[gameData.appId][1];
        var url = host + "/" + uploadFilename;

        var flag = false;
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.open("PUT", url);
        xhr.setRequestHeader("Content-Length", data.length);
        var date = new Date().toGMTString();
        var contentMd5 = '';
        var contentType = 'application/x-www-form-urlencoded';
        var canonicalizedOSSHeaders = '';
        var canonicalizedResource = '/' + ALOV[gameData.appId][0] + '/' + uploadFilename;
        var authStr = "PUT\n"
            + contentMd5 + "\n"
            + contentType + "\n"
            + date + "\n"
            + canonicalizedOSSHeaders
            + canonicalizedResource;
        var auth = Crypto.util.bytesToBase64(Crypto.HMAC(Crypto.SHA1, authStr, arr.join(''), {asBytes: true}));
        xhr.setRequestHeader("Date", date);
        xhr.setRequestHeader("Content-Type", contentType);
        xhr.setRequestHeader("Authorization", "OSS " + accessid + ":" + auth);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    console.log("success");
                    if (cbSucc)
                        cbSucc(url);
                }
                else {
                    // console.log(xhr.responseText);
                    if (!flag) {
                        flag = true;
                        if (cbFail)
                            cbFail(xhr.statusText, xhr.responseText);
                    }
                }
            }
        };
        xhr.onerror = function () {
            console.log("error");
            if (!flag) {
                flag = true;
                if (cbFail)
                    cbFail(xhr.status, null);
            }
        };
        xhr.send(data);
    }
};

var httpGet = function (url, cbSucc, cbFail) {
    var flag = false;
    var xhr = cc.loader.getXMLHttpRequest();
    xhr.open("GET", url);
    if (cc.sys.isNative) {
        // xhr.setRequestHeader("Accept", "*/*");
        xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");
        // xhr.setRequestHeader("User-Agent", "curl/7.27.0");
        // xhr.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36");
    }
    // xhr.setRequestHeader("User-Agent", "curl/7.27.0");
    // xhr.setRequestHeader("Accept-Encoding", "gzip, deflate");
    // xhr.setRequestHeader("Accept-Encoding", "deflate");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                // cc.log(xhr.responseText);
                cbSucc(xhr.responseText);
            }
            else {
                if (!flag) {
                    flag = true;
                    cbFail(xhr.statusText, xhr.responseText);
                }
            }
        }
    };
    xhr.onerror = function () {
        if (!flag) {
            flag = true;
            cbFail(xhr.status, null);
        }
    };
    xhr.send();
};

var httpGetPolling = function (params, cbSucc, cbFail, headerType, retryCnt) {
    if (gameData.ipList.length == 0) {
        cbFail();
        return;
    }
    retryCnt = typeof retryCnt === 'undefined' ? 0 : retryCnt;
    httpRequest("GET", gameData.ipList[0] + params, cbSucc, function () {
        if (retryCnt < gameData.ipList.length - 1) {
            var temp = gameData.ipList[0];
            gameData.ipList.splice(0, 1);
            gameData.ipList.push(temp);
            httpGetPolling(params, cbSucc, cbFail, headerType, retryCnt + 1);
        } else {
            // cbFail();
            if (gameData._add_ul > 5) {
                gameData._add_ul = 0;
                cbFail();
            } else {
                gameData._add_ul += 1;
                gameData.ipList = null;
                IIL();
                httpGetPolling(params, cbSucc, cbFail, headerType);
            }
        }
    }, headerType);
};
var httpRequest = function (method, url, cbSucc, cbFail, data, headerType) {
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "http://" + url;
    }
    // cc.log(method + ':' + url);
    var flag = false;
    var xhr = cc.loader.getXMLHttpRequest();
    xhr.open(method, url);
    if (cc.sys.isNative) {
        headerType = headerType || 'gzip';
        if (headerType == 'gzip') {
            xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");
        } else if (headerType == 'json') {
            xhr.setRequestHeader("Content-Type", "application/json");
        }
    }
    // xhr.setRequestHeader("User-Agent", "curl/7.27.0");
    // xhr.setRequestHeader("Accept-Encoding", "gzip, deflate");
    // xhr.setRequestHeader("Accept-Encoding", "deflate");
    // xhr.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                // cc.log(xhr.responseText);
                if (!flag) {
                    flag = true;
                    cbSucc(xhr.responseText);
                }
            }
            else {
                if (!flag) {
                    flag = true;
                    cbFail(xhr.statusText, xhr.responseText);
                }
            }
        }
    };
    xhr.onerror = function () {
        if (!flag) {
            flag = true;
            cbFail(xhr.status, null);
        }
    };
    setTimeout(function () {
        if (!flag) {
            flag = true;
            cc.log('timeout, abort http request');
            cbFail(xhr.status, null);
        }
    }, 4000);
    if (data) {
        xhr.send(data);
    } else {
        xhr.send();
    }
};
var httpPost = function (url, data, ajaxSuccess, ajaxError, noBase64) {
    data = _.isString(data) ? data : JSON.stringify(data);
    var xhr = cc.loader.getXMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    // xhr.setRequestHeader("Content-Length", data.length);
    xhr.onreadystatechange = function () {
        var result, error = false;
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304 || xhr.status == 0) {
                var dataType = xhr.getResponseHeader('content-type');
                result = xhr.responseText;
                console.log(result);
                try {
                    if (dataType.indexOf('json')) result = JSON.parse(result);
                } catch (e) {
                    error = e
                }

                if (error) ajaxError(error, 'parsererror', xhr);
                else ajaxSuccess(result, xhr)
            } else {
                ajaxError(xhr.statusText || null, xhr.status ? 'error' : 'abort', xhr)
            }
        }
    };
    xhr.onerror = function () {
        ajaxError(xhr.statusText || null);
    };
    if(noBase64){
        xhr.send(data);
    }else{
        xhr.send(Base64.encode(data));
    }
};
var create$ = function (sceneNode) {
    var func = function (query, rootNode) {
        var arr = query.split(/\./g);
        var t = rootNode || sceneNode;
        for (var i = 0; i < arr.length; i++)
            if (t) {
                if (!cc.sys.isObjectValid(t)) {
                    cc.log("-- not a valid object " + query);
                    return null;
                }
                t = t.getChildByName(arr[i]);
            }
            else {
                return null;
            }
        return t;
    };
    var retFunc = null;
    if (_.isArray(sceneNode)) {
        retFunc = function (query, rootNode) {
            if (rootNode)
                return func(query, rootNode);
            else {
                for (var i = 0; i < sceneNode.length; i++) {
                    var ret = func(query, sceneNode[i]);
                    if (ret)
                        return ret;
                }
                return null;
            }
        };
    }
    else
        retFunc = func;
    retFunc.get = httpGet;
    return retFunc;
};

var duplicateSprite = function (sprite, isCopyUserdata) {
    var newSprite = null;
    if (sprite instanceof cc.Sprite) {
        newSprite = new cc.Sprite(sprite.getSpriteFrame());
        newSprite.setBlendFunc(sprite.getBlendFunc());
    }
    else if (sprite instanceof ccui.CheckBox) {
        if (cc.sys.isNative)
            newSprite = sprite.clone();
        else {
            newSprite = new ccui.CheckBox();
            newSprite._copySpecialProperties(sprite);
        }
    }
    else if (sprite instanceof ccui.Text) {
        //newSprite = sprite.clone();
        newSprite = new ccui.Text();
        newSprite.setFontName(sprite.getFontName());
        newSprite.setTextColor(sprite.getTextColor());
        newSprite.setFontSize(sprite.getFontSize());
        newSprite.setTextHorizontalAlignment(sprite.getTextHorizontalAlignment());
        newSprite.setTextVerticalAlignment(sprite.getTextVerticalAlignment());
    } else if (sprite instanceof ccui.ImageView) {
        newSprite = sprite.clone();
        return newSprite;
    }
    // else if (sprite instanceof ccui.LabelBMFont) {
    //     newSprite = sprite.clone();
    //     return newSprite;
    // }
    else if (sprite instanceof ccui.TextAtlas) {
        newSprite = sprite.clone();
        newSprite.setString(sprite.getString());
        return newSprite;
    }
    else if (sprite instanceof ccui.TextBMFont) {
        newSprite = new ccui.TextBMFont();
        newSprite.setString(sprite.getString());
        newSprite.setFntFile(newSprite._fntFileName);
        return newSprite;
    }
    newSprite.setAnchorPoint(sprite.getAnchorPoint());
    newSprite.setScale(sprite.getScaleX(), sprite.getScaleY());
    newSprite.setPosition(sprite.getPosition());
    newSprite.setContentSize(sprite.getContentSize());
    newSprite.setColor(sprite.getColor());
    newSprite.setOpacity(sprite.getOpacity());
    newSprite.setVisible(sprite.isVisible());
    newSprite.setName(sprite.getName());
    if (sprite instanceof cc.Sprite) {
        var children = sprite.getChildren();
        for (var i = 0; i < children.length; i++) {
            var node = duplicateSprite(children[i], true);
            newSprite.addChild(node);
        }
    }
    if (isCopyUserdata)
        newSprite.setUserData(_.clone(sprite.getUserData()));
    return newSprite;
};

var getCurrentTimeMills = function () {
    var date = new Date();
    var yy = date.getYear();
    var MM = date.getMonth() + 1;
    var dd = date.getDay();
    var hh = date.getHours();
    var mm = date.getMinutes();
    var ss = date.getSeconds();
    var sss = date.getMilliseconds();
    return Date.UTC(yy, MM, dd, hh, mm, ss, sss);
};
var duplicateOnlyNewLayer = function (layout) {
    var newLayout = null;
    newLayout = new ccui.Layout();
    newLayout.setSize(layout.getSize());
    newLayout.setLayoutType(layout.getLayoutType());
    newLayout.setBackGroundColorType(layout.getBackGroundColorType());
    newLayout.setBackGroundColor(layout.getBackGroundColor());
    newLayout.setBackGroundColorOpacity(layout.getBackGroundColorOpacity());
    var children = layout.getChildren();
    for (var i = 0; i < children.length; i++) {
        var node = duplicateSprite(children[i], true);
        newLayout.addChild(node);
    }
    return newLayout;
}
var duplicateLayout = function (layout) {
    var newLayout = null;
    if (layout instanceof cc.Sprite)
        newLayout = duplicateSprite(layout);
    else if (layout instanceof ccui.Layout) {
        newLayout = layout.clone();
        //newLayout = new ccui.Layout();
        //newLayout.setSize(layout.getSize());
        //newLayout.setLayoutType(layout.getLayoutType());
        //newLayout.setBackGroundColorType(layout.getBackGroundColorType());
        //newLayout.setBackGroundColor(layout.getBackGroundColor());
        //newLayout.setBackGroundColorOpacity(layout.getBackGroundColorOpacity());
    }
    else if (layout instanceof cc.Node)
        newLayout = new cc.Node();
    newLayout.setPosition(layout.getPosition());
    newLayout.setScale(layout.getScale());
    newLayout.setAnchorPoint(layout.getAnchorPoint());
    newLayout.setOpacity(255);
    newLayout.setVisible(true);
    var children = layout.getChildren();
    for (var i = 0; i < children.length; i++) {
        var node = duplicateSprite(children[i], true);
        newLayout.addChild(node);
    }
    return newLayout;
};

var showLoading = function (content) {
    HUD.showLoading();
};

var hideLoading = function () {
    HUD.removeLoading();
};

// var setTimeout = function (func, time) {
//     cc.sys.isObjectValid(cc.director.getRunningScene()) && cc.director.getRunningScene().scheduleOnce(function () {
//         func();
//     }, time / 1000.0);
// };

// var setInterval = function (func, time) {
//     cc.sys.isObjectValid(cc.director.getRunningScene()) && cc.director.getRunningScene().schedule(function () {
//         func();
//     }, time / 1000.0, cc.REPEAT_FOREVER);
// };

var alert0 = function (title, content, isAutoHideLoading) {
    // isAutoHideLoading = _.isUndefined(isAutoHideLoading) ? true : isAutoHideLoading;
    // if (isAutoHideLoading)
    //     hideLoading();
    // cc.sys.isObjectValid(cc.director.getRunningScene()) && cc.director.getRunningScene().scheduleOnce(function () {
    //     var tishiLayer = new TishiLayer('alert0', title, content, null, null, true);
    //     cc.director.getRunningScene().addChild(tishiLayer, 1000);
    // }, 0);
    var layer = HUD.showLayer(HUD_LIST.MessageBox, HUD.getTipLayer(), null, true);
    layer.setName("MessageBox");
    layer.setData(title, content, function(){}, true);
    return layer;
};

var alert1 = function (content, onOk, canCancel, isAutoHideLoading, isHCenter, isVCenter) {
    // isAutoHideLoading = _.isUndefined(isAutoHideLoading) ? true : isAutoHideLoading;
    // if (isAutoHideLoading)
    //     hideLoading();
    // cc.director.getRunningScene().scheduleOnce(function () {
    //     var tishiLayer = new TishiLayer('alert1', '提示', content, function () {
    //         if (onOk)
    //             onOk();
    //     }, null, !!canCancel, isHCenter, isVCenter, null, null);
    //     cc.director.getRunningScene().addChild(tishiLayer, 1000);
    // }, 0);
    var tipLayer = HUD.getTipLayer();
    if(!tipLayer){
        tipLayer =  new cc.Layer();
        display.getRunningScene().addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;
    }
    var layer = HUD.showLayer(HUD_LIST.MessageBox, tipLayer, null, true);
    layer.setName("MessageBox");
    layer.setData("提示", content, onOk, true);
    return layer;
};

var alert2 = function (content, onOk, onCancel, canCancel, isAutoHideLoading, isHCenter, isVCenter) {
    // isAutoHideLoading = _.isUndefined(isAutoHideLoading) ? true : isAutoHideLoading;
    // if (isAutoHideLoading)
    //     hideLoading();
    // cc.sys.isObjectValid(cc.director.getRunningScene()) && cc.director.getRunningScene().scheduleOnce(function () {
    //     var tishiLayer = new TishiLayer('alert2', '提示', content, function () {
    //         if (onOk)
    //             onOk();
    //     }, function () {
    //         if (onCancel)
    //             onCancel();
    //     }, !!canCancel, isAutoHideLoading, isHCenter, isVCenter);
    //     cc.director.getRunningScene().addChild(tishiLayer, 1000);
    // }, 0);
    var tipLayer = HUD.getTipLayer();
    if(!tipLayer){
        tipLayer =  new cc.Layer();
        display.getRunningScene().addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;
    }
    var layer = HUD.showLayer(HUD_LIST.MessageBox, tipLayer, null, true);
    layer.setName("MessageBox");
    if(canCancel == null || canCancel == undefined)  canCancel = false;
    layer.setData("提示", content, onOk, canCancel);
    return layer;
};

var preloadMascene1 = function () {
    window.ccsCache = window.ccsCache || {};
    // if (window.ccsCache[res.MaScene1_json]) {
    //     window.ccsCache[res.MaScene1_json].release();
    //     delete window.ccsCache[res.MaScene1_json];
    // }
    if (!window.ccsCache[res.MaScene1_json]) {
        window.ccsCache[res.MaScene1_json] = ccs.load(res.MaScene1_json).node;
        window.ccsCache[res.MaScene1_json].retain();
    }
};


var addCachedCCSChildrenTo = function (res, distNode) {
    window.ccsCache = window.ccsCache || {};
    var isRelease = !!window.ccsCache[res];
    window.ccsCache[res] = window.ccsCache[res] || ccs.load(res, "res/").node;
    var parent = window.ccsCache[res];
    var arr = [];
    for (var i = 0; i < parent.children.length; i++)
        arr.push(parent.children[i]);
    for (var i = 0; i < arr.length; i++) {
        arr[i].retain();
        arr[i].removeFromParent(false);
    }
    for (var i = 0; i < arr.length; i++) {
        distNode.getChildByName("Scene").addChild(arr[i]);
        arr[i].release();
    }
    if (isRelease)
        window.ccsCache[res].release();
    delete window.ccsCache[res];
};

var batchSetChildrenZorder = function (node, map) {
    for (var k in map)
        if (map.hasOwnProperty(k)) {
            var child = node.getChildByName(k);
            if (child)
                child.setLocalZOrder(map[k]);
        }
};

var loadCCSTo = function (res, distNode, rootName, moreArr) {
    moreArr = moreArr || [];
    var mainscene =  null;
    if (window.ccsCache && window.ccsCache[res]) {
        mainscene = window.ccsCache[res];
        window.ccsCache[res] = null;
        distNode.addChild(mainscene.node);
        mainscene.node.release();
    }
    else {
        mainscene = ccs.load(res, "res/");
        distNode.addChild(mainscene.node);
    }

    var interval = null;
    var checkFunc = function () {
        if (!checkAllNodesValid(distNode.getChildByName(rootName)))
            return;
        var rootNode = distNode.getChildByName(rootName);
        for (var i = 0; i < moreArr.length; i++) {
            var node = rootNode.getChildByName(moreArr[i]);
            if (!node || !cc.sys.isObjectValid(node))
                return;
        }
        clearInterval(interval);
        interval = null;

        var ret = true;
        if (distNode.getBeforeOnCCSLoadFinish && distNode.getBeforeOnCCSLoadFinish())
            ret = distNode.getBeforeOnCCSLoadFinish()();
        if (ret && distNode.onCCSLoadFinish) {
            distNode.onCCSLoadFinish.call(distNode);
        }
    };
    interval = setInterval(checkFunc, 1);
    checkFunc();
};

var crash = function () {
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "crash"
        );
    }
    else {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "crash",
            "(Z)V",
            true
        );
    }
};

var calcPos = function (edgeWidth, partWidth, intervalWidth, num, cb) {
    //var left = totalWidth - (num - 1) * intervalWidth - edgeWidth * num;
    for (var i = 0; i < num; i++) {
        cb(i, edgeWidth + partWidth * i + intervalWidth * i);
    }
};
var loadCircleConorToSprite = function ( url, headBg, r,  w_off, h_off, x_off, y_off) {
    var headBgScaleBak = headBg.getScale();
    headBg.setScale(1);
    w_off = w_off || 0;
    h_off = h_off || 0;
    x_off = x_off || 0;
    y_off = y_off || 0;
    r = r || 6;

    var clipNode = headBg.getChildByName("head_clip");
    if (!clipNode) {
        var headBgBoundingBox = headBg.getBoundingBox();
        var headBgSize = cc.size(headBgBoundingBox.width, headBgBoundingBox.height);
        var clipNodeSize = cc.size(headBgSize.width , headBgSize.height );
        clipNode = cc.ClippingNode.createRoundRect(headBgSize.width+w_off, headBgSize.height+h_off, r);
        clipNode.setScale(clipNodeSize.width / headBgSize.width);
        clipNode.setPosition(x_off - w_off/2, y_off - h_off/2);
        clipNode.setName('head_clip');
        headBg.addChild(clipNode);
    }

    headBg.setScale(headBgScaleBak);

    var head = clipNode.getChildByName('head');
    if (head)
        head.removeFromParent(true);
    head = new cc.Sprite(headBg.getTexture());
    head.setAnchorPoint(0, 0);
    head.setName('head');
    // head.hide();
    head.setVisible(false);
    clipNode.addChild(head);
    if(url.startsWith('res/')){
        head.setTexture(cc.textureCache.addImage(url));
        head.setVisible(true);
    }else{
        NetUtils.downloadHeadImgToSprite(url, head, function () {
            head.setVisible(true);
        });
    }

}
var loadImageToSprite = function (url, targetSprite, isclip) {
    if (!url)
        return;
    var clipNodeDeltaSize = {x: 4, y: 4}; // 14
    if (false && !cc.sys.isNative) {
        if (window.location.href.indexOf("localhost") >= 0)
            url = "http://localhost:63342/ma2/head.jpg";
        else
            url = res.defaultHead;
    }
    if (url.charAt(url.length - 2) == '/' &&
        url.charAt(url.length - 1) == '0')
        url = url.substr(0, url.length - 2) + '/132';

    var userData = targetSprite.getUserData() || {};
    if (userData.url == url)
        return;


    var headBg = targetSprite;
    var headBgScaleBak = headBg.getScale();
    headBg.setScale(1);

    if (isclip) {
        var clipNode = headBg.getChildByName("head_clip");
        if (!clipNode) {
            var headBgBoundingBox = headBg.getBoundingBox();
            var headBgSize = cc.size(headBgBoundingBox.width, headBgBoundingBox.height);
            var clipNodeSize = cc.size(headBgSize.width - clipNodeDeltaSize.x, headBgSize.height - clipNodeDeltaSize.y);
            clipNode = cc.ClippingNode.createRoundRect(headBgSize.width, headBgSize.height, 6);
            clipNode.setScale(clipNodeSize.width / headBgSize.width);
            clipNode.setName('head_clip');
            clipNode.setPosition(clipNodeDeltaSize.x / 2, clipNodeDeltaSize.y / 2);
            headBg.addChild(clipNode);
        }
    }

    headBg.setScale(headBgScaleBak);

    if (!clipNode)
        clipNode = headBg;
    var head = clipNode.getChildByName('head');
    if (head)
        head.removeFromParent(true);
    head = new cc.Sprite(headBg.getTexture());
    head.setAnchorPoint(0, 0);
    head.setName('head');
    head.setVisible(false);
    head.retain();
    clipNode.addChild(head);

    var sprite = head;
    cc.textureCache.addImageAsync(url, function (texture) {
        if (!sprite)
            sprite = new cc.Sprite(texture);
        sprite.setTexture(texture);

        var scaleX = targetSprite.getContentSize().width / sprite.getContentSize().width;
        var scaleY = targetSprite.getContentSize().height / sprite.getContentSize().height;
        sprite.setScale(scaleX, scaleY);
        sprite.setAnchorPoint(0, 0);
        sprite.setName('head');
        if (!clipNode.getChildByName('head')) {
            clipNode.addChild(sprite);
            head.release();
        }

        userData.url = url;
        head.setVisible(true);
        targetSprite.setUserData(userData);
    }, null);

    return;

    var sprite = null;
    var children = targetSprite.getChildren();
    for (var i = 0; i < children.length; i++) {
        var child = children[i];
        if (child.getName() == 'head') {
            sprite = child;
            break;
        }
    }

    if (sprite)
        sprite.setTexture(cc.textureCache.addImage('res/transparent/transparent.png'));
    if (!url)
        return;
};
var loadImageToSprite2 = function (url, targetSprite) {
    if (url.charAt(url.length - 2) == '/' &&
        url.charAt(url.length - 1) == '0')
        url = url.substr(0, url.length - 2) + '/132';

    var userData = targetSprite.getUserData() || {};
    if (userData.url == url)
        return;

    var sprite = null;
    var children = targetSprite.getChildren();
    for (var i = 0; i < children.length; i++) {
        var child = children[i];
        if (child.getName() == 'head') {
            sprite = child;
            break;
        }
    }

    if (sprite)
        sprite.setTexture(cc.textureCache.addImage('res/image/ui/transparent/transparent.png'));
    if (!url)
        return;

    cc.textureCache.addImageAsync(url, function (texture) {
        if (!sprite)
            sprite = new cc.Sprite(texture);
        sprite.setTexture(texture);

        var scaleX = targetSprite.getContentSize().width / sprite.getContentSize().width;
        var scaleY = targetSprite.getContentSize().height / sprite.getContentSize().height;
        sprite.setScale(scaleX, scaleY);
        sprite.setAnchorPoint(0, 0);
        sprite.setName('head');
        if (!targetSprite.getChildByName('head'))
            targetSprite.addChild(sprite);

        userData.url = url;
        targetSprite.setUserData(userData);
    }, null);
};

var getPositionRelativeToParent = function (node, level) {
    var t = node;
    var a = 0, b = 0;
    for (var i = 0; i < level; i++) {
        if (!t)
            return null;
        a += t.getPositionX();
        b += t.getPositionY();
        t = t.getParent();
    }
    if (t) {
        return cc.p(a, b);
    }
    return null;
};

var getPositionRelativeToSibling = function (node, sibling) {
    var p0 = node.getPosition();
    var p1 = sibling.getPosition();
    p0.x -= p1.x;
    p0.y -= p1.y;
    return p0;
};

// var TouchFilter = {
//     programs: {},
//     grayScale: function (sprite) {
//         var program = TouchFilter.programs["grayScale"];
//         if (!program) {
//             program = new cc.GLProgram((cc.sys.isNative ? res.default_native_vsh : res.default_vsh), res.gray_scale_fsh);
//             //program.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
//             // program.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
//             program.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);
//             program.link();
//             program.updateUniforms();
//             TouchFilter.programs["grayScale"] = program;
//         }
//         gl.useProgram(program.getProgram());
//         sprite.shaderProgram = program;
//     },
//     grayMask: function (sprite) {
//         var program = TouchFilter.programs["grayMask"];
//         if (!program) {
//             program = new cc.GLProgram((cc.sys.isNative ? res.default_native_vsh : res.default_vsh), res.gray_mask_fsh);
//             //program.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
//             // program.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
//             program.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);
//             program.link();
//             program.updateUniforms();
//             program.use();
//             TouchFilter.programs["grayMask"] = program;
//         }
//         gl.useProgram(program.getProgram());
//         sprite.shaderProgram = program;
//     },
//     sepia: function (sprite, degree) {
//         var program = TouchFilter.programs["sepia" + degree];
//         if (!program) {
//             program = new cc.GLProgram((cc.sys.isNative ? res.default_native_vsh : res.default_vsh), res.sepia_fsh);
//             //program.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
//             // program.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
//             program.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);
//             program.link();
//             program.updateUniforms();
//             program.use();
//             program.setUniformLocationWith1f(program.getUniformLocationForName('u_degree'), degree);
//             TouchFilter.programs["sepia" + degree] = program;
//         }
//
//         if (cc.sys.isNative) {
//             var glProgram_state = cc.GLProgramState.getOrCreateWithGLProgram(program);
//             glProgram_state.setUniformFloat("u_degree", degree);
//             sprite.setGLProgramState(glProgram_state);
//         }
//         else {
//             sprite.shaderProgram = program;
//         }
//     },
//     remove: function (sprite) {
//         var program = TouchFilter.programs[cc.SHADER_POSITION_TEXTURECOLOR];
//         if (!program) {
//             program = new cc.GLProgram((cc.sys.isNative ? res.default_native_vsh : res.default_vsh), res.position_texture_color_fsh);
//             program.addAttribute(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION);
//             program.addAttribute(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR);
//             program.addAttribute(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS);
//             program.link();
//             program.updateUniforms();
//             TouchFilter.programs[cc.SHADER_POSITION_TEXTURECOLOR] = program;
//         }
//         sprite.shaderProgram = program;
//         //sprite.shaderProgram = (cc.shaderCache.programForKey(cc.SHADER_POSITION_TEXTURECOLOR));
//     }
// };

var addAction = function (node, action) {
    action.retain();
    setTimeout(function () {
        var interval = setInterval(function () {
            if (!node || !cc.sys.isObjectValid(node)) {
                action.release();
                return clearInterval(interval);
            }
            if (node.getNumberOfRunningActions() == 0) {
                node.runAction(cc.sequence(action, cc.callFunc(function () {
                    action.release();
                })));
                clearInterval(interval);
            }
        }, 16);
    }, 66);
};

// var TouchUtils = {
//     effects: {
//         NONE: "NONE"
//         , SEPIA: "SEPIA"
//         , ZOOM: "ZOOM"
//     },
//     isTouchMe: function (target, touch, event, deltaSize) {
//         deltaSize = deltaSize || cc.size(0, 0);
//
//         //Get the position of the current point relative to the button
//         var locationInNode = target.convertToNodeSpace(touch.getLocation());
//         var s = target.getContentSize();
//         var rect = cc.rect(-deltaSize.width / 2, -deltaSize.height / 2, s.width + deltaSize.width, s.height + deltaSize.height);
//
//         //Check the click area
//         if (cc.rectContainsPoint(rect, locationInNode)) {
//             var flag = true;
//             var t = target;
//             while (true) {
//                 if (t == null)
//                     break;
//                 if (!t.isVisible() || t.getOpacity() == 0) {
//                     flag = false;
//                     break;
//                 }
//                 t = t.getParent();
//             }
//             return !!flag;
//         }
//         return false;
//     },
//     _setOnTouchListener: function (node, options) {
//         //if (!node)
//         //    return;
//
//         if (typeof options['swallowTouches'] === 'undefined')
//             options['swallowTouches'] = true;
//
//         if (!node.getUserData())
//             node.setUserData({});
//         var userData = node.getUserData();
//
//         if (userData.listener)
//             cc.eventManager.removeListener(userData.listener);
//
//         var delta = 0;
//
//         var sepiaVal = 0.7;
//
//         var zoomDuration = 0.2;
//         var zoomVal = 1.06;
//
//         var isStillInside = false;
//
//         userData.listener = cc.EventListener.create({
//             event: cc.EventListener.TOUCH_ONE_BY_ONE,
//             swallowTouches: options['swallowTouches'],
//             onTouchBegan: function (touch, event) {
//                 if (TouchUtils.isTouchMe(node, touch, event, cc.size(delta, delta))) {
//                     if (options.effect === TouchUtils.effects.SEPIA)
//                         TouchFilter.sepia(node, sepiaVal);
//                     else if (options.effect === TouchUtils.effects.ZOOM)
//                         node.runAction(cc.scaleTo(zoomDuration, zoomVal, zoomVal));
//                     if (options.onTouchBegan)
//                         options.onTouchBegan(node, touch, event);
//                     isStillInside = true;
//                     playEffect(_.isUndefined(options['sound']) ? 'vButtonClick' : options['sound']);
//                     return true;
//                 }
//                 return false;
//             },
//             onTouchMoved: function (touch, event) {
//                 if (options.onTouchMoved && options.onTouchMoved(node, touch, event))
//                     return true;
//                 var ret = TouchUtils.isTouchMe(node, touch, event, cc.size(delta, delta));
//                 if (ret && !isStillInside) {
//                     if (options.effect === TouchUtils.effects.SEPIA)
//                         TouchFilter.sepia(node, sepiaVal);
//                     else if (options.effect === TouchUtils.effects.ZOOM)
//                         addAction(node, cc.scaleTo(zoomDuration, zoomVal, zoomVal));
//                     isStillInside = true;
//                     if (options.onTouchMoveIn)
//                         options.onTouchMoveIn(node, touch, event);
//                 }
//                 else if (!ret && isStillInside) {
//                     if (options.effect === TouchUtils.effects.SEPIA)
//                         TouchFilter.remove(node);
//                     else if (options.effect === TouchUtils.effects.ZOOM)
//                         addAction(node, cc.scaleTo(zoomDuration, 1, 1));
//                     isStillInside = false;
//                     if (options.onTouchMoveOut)
//                         options.onTouchMoveOut(node, touch, event);
//                 }
//             },
//             onTouchEnded: function (touch, event) {
//                 if (options.onTouchEndedWithoutCheckTouchMe)
//                     options.onTouchEndedWithoutCheckTouchMe(node, touch, event);
//                 if (TouchUtils.isTouchMe(node, touch, event, cc.size(delta, delta))) {
//                     if (options.effect === TouchUtils.effects.SEPIA)
//                         TouchFilter.remove(node);
//                     else if (options.effect === TouchUtils.effects.ZOOM)
//                         addAction(node, cc.scaleTo(zoomDuration, 1, 1));
//                     if (options.onTouchEnded)
//                         options.onTouchEnded(node, touch, event);
//                     return true;
//                 }
//                 return false;
//             }
//         });
//
//         cc.eventManager.addListener(userData.listener, node);
//     },
//     setOnlickListener: function (node, cb, options) {
//         TouchUtils._setOnTouchListener(node, _.extend({
//             effect: TouchUtils.effects.SEPIA
//             , onTouchEnded: cb
//         }, options || {}));
//     },
//     setOntouchListener: function (node, cb, options) {
//         TouchUtils._setOnTouchListener(node, _.extend({
//             effect: TouchUtils.effects.SEPIA
//             , onTouchBegan: cb
//         }, options || {}));
//     },
//     setListeners: function (node, options) {
//         TouchUtils._setOnTouchListener(node, _.extend({
//             effect: TouchUtils.effects.NONE
//         }, options || {}));
//     },
//     removeListeners: function (node) {
//         var userData = node.getUserData() || {};
//         if (userData.listener) {
//             cc.eventManager.removeListener(userData.listener);
//             delete userData.listener;
//         }
//     }
// };

// var getBatteryLevel = function () {
//     var level = "100";
//     if (cc.sys.os == cc.sys.OS_IOS) {
//         level = jsb.reflection.callStaticMethod(
//             "AppController",
//             "getBatteryLevel"
//         );
//     } else if (cc.sys.os == cc.sys.ANDROID) {
//         level = jsb.reflection.callStaticMethod(
//             "org/cocos2dx/javascript/AppActivity",
//             "getBatteryLevel",
//             "()Ljava/lang/String;"
//         );
//     }
//     return Math.floor(Number(level));
// };

function clone(obj){
    var o;
    switch(typeof obj){
        case 'undefined': break;
        case 'string'   : o = obj + '';break;
        case 'number'   : o = obj - 0;break;
        case 'boolean'  : o = obj;break;
        case 'object'   :
            if(obj === null){
                o = null;
            }else{
                if(obj instanceof Array){
                    o = [];
                    for(var i = 0, len = obj.length; i < len; i++){
                        o.push(clone(obj[i]));
                    }
                }else{
                    o = {};
                    for(var k in obj){
                        o[k] = clone(obj[k]);
                    }
                }
            }
            break;
        default:
            o = obj;break;
    }
    return o;
}

var getNextIp = function () {
    if (!cc.sys.isNative) {
        return null;
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        try {
            return jsb.reflection.callStaticMethod(
                "AppController",
                "ni"
            );
        } catch (e) {
            console.log(e.toString());
        }
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "ni",
            "()Ljava/lang/String;"
        );
    }
};

// var getNextIp2 = function (group, sk) {
//     if (!cc.sys.isNative)
//         return null;
//     if (getNativeVersion() < '1.2.0')
//         return null;
//     if (cc.sys.os == cc.sys.OS_IOS) {
//         try {
//             return jsb.reflection.callStaticMethod(
//                 "AppController",
//                 "ni2:n:",
//                 sk,
//                 group
//             );
//         } catch (e) {
//             // console.log(e.toString());
//         }
//     }
//     else {
//         return jsb.reflection.callStaticMethod(
//             "org/cocos2dx/javascript/AppActivity",
//             "ni2",
//             "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
//             sk,
//             group
//         );
//     }
// };
// var getNextIp2 = function (address) {
//     if (!cc.sys.isNative) {
//         return null;
//     }
//     if(window.inReview){
//         return null;
//     }
//     if (cc.sys.os == cc.sys.OS_IOS) {
//         try {
//             return jsb.reflection.callStaticMethod(
//                 "AppController",
//                 "ni2:n:",
//                 "aIllmg6BQuQfi0nYS59BsAlx+m+nhz-JQx7bMPrE+x2INaOSQESeDq-9RMpGDh2uzr-HISE1jgecwKcrgy61Pv_+Cbcyr2YIwK+8F-2ev15apqyNpHUwG1MN7ETEgz3l7urfUcMj1WVDfTzOlQxgQ_CMFEnzgwyDFRMN1GIepIxUDYnUq1+y5lTNX9RgkZPaBPuv+FilyikQxZwyiTCCSjCEAwCvq4RTApksUwJi8I2SaCLvlpVM9kqHzwFZvulqmNM2GUsVhQjph5hmwnKW3HtwEXNRoQvemZehZyPUfz4Ml_iZXQZoFputNFMNIdmm7Lug86gguAY582kFJwMM7lUEn6UB",
//                 address
//             );
//         } catch (e) {
//             cc.log(e.toString());
//         }
//     }
//     else {
//         return jsb.reflection.callStaticMethod(
//             "org/cocos2dx/javascript/AppActivity",
//             "ni2",
//             "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
//             "aIllmg6BQuQfi0nYS59BsAlx+m+nhz-JQx7bMPrE+x2INaOSQESeDq-9RMpGDh2uzr-HISE1jgecwKcrgy61Pv_+Cbcyr2YIwK+8F-2ev15apqyNpHUwG1MN7ETEgz3l7urfUcMj1WVDfTzOlQxgQ_CMFEnzgwyDFRMN1GIepIxUDYnUq1+y5lTNX9RgkZPaBPuv+FilyikQxZwyiTCCSjCEAwCvq4RTApksUwJi8I2SaCLvlpVM9kqHzwFZvulqmNM2GUsVhQjph5hmwnKW3HtwEXNRoQvemZehZyPUfz4Ml_iZXQZoFputNFMNIdmm7Lug86gguAY582kFJwMM7lUEn6UB",
//             address
//         );
//     }
// };


var getNextIp2 = function (group, sk) {
    if (!cc.sys.isNative) {
        return null;
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        try {
            return jsb.reflection.callStaticMethod(
                "AppController",
                "ni2:n:",
                YunCengKey_ios,
                group
            );
        } catch (e) {
        }
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "ni2",
            "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
            YunCengKey_android,
            group
        );
    }
};

//0x70,0x68,0x7a,0x31,0x2e,0x36,0x32,0x77,0x62,0x6f,0x73,0x35,0x62,0x31,0x6e,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d
//0x70,0x68,0x7a,0x32,0x2e,0x36,0x6b,0x62,0x74,0x32,0x68,0x61,0x79,0x6b,0x68,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d
//0x70,0x68,0x7a,0x33,0x2e,0x6f,0x66,0x6c,0x71,0x6e,0x64,0x68,0x34,0x66,0x73,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d
//0x70,0x68,0x7a,0x34,0x2e,0x69,0x73,0x6b,0x75,0x35,0x34,0x39,0x68,0x35,0x66,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d
var UL = {
    '0': {
        'yxd': String.fromCharCode.apply(null, [0x70,0x68,0x7a,0x31,0x2e,0x36,0x32,0x77,0x62,0x6f,0x73,0x35,0x62,0x31,0x6e,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d]),
        'ym': 'http://phz.yygameapi.com',
        'gf': '116.211.166.201'//高防'phz.xcve1xafe.com'
    },
    '1': {
        'yxd': String.fromCharCode.apply(null, [0x70,0x68,0x7a,0x32,0x2e,0x36,0x6b,0x62,0x74,0x32,0x68,0x61,0x79,0x6b,0x68,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d]),
        'ym': 'http://phz.yygameapi.com',
        'gf': '116.211.166.201'//高防'phz.xcve1xafe.com'
    },
    '2': {
        'yxd': String.fromCharCode.apply(null, [0x70,0x68,0x7a,0x33,0x2e,0x6f,0x66,0x6c,0x71,0x6e,0x64,0x68,0x34,0x66,0x73,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d]),
        'ym': 'http://phz.yygameapi.com',
        // 'gf': {
        //     'dx': String.fromCharCode.apply(null, [49, 49, 54, 46, 50, 49, 49, 46, 49, 54, 55, 46, 52, 52]),
        //     'lt': String.fromCharCode.apply(null, [50, 49, 56, 46, 49, 49, 46, 49, 46, 49, 48, 53])
        // }
        'gf': '116.211.166.201'//高防'phz.xcve1xafe.com'
    },
    '3': {
        'yxd': String.fromCharCode.apply(null, [0x70,0x68,0x7a,0x34,0x2e,0x69,0x73,0x6b,0x75,0x35,0x34,0x39,0x68,0x35,0x66,0x2e,0x61,0x6c,0x69,0x79,0x75,0x6e,0x67,0x66,0x2e,0x63,0x6f,0x6d]),
        'ym': 'http://phz.yygameapi.com',
        // 'gf': {
        //     'dx': String.fromCharCode.apply(null, [49, 49, 54, 46, 50, 49, 49, 46, 49, 54, 55, 46, 52, 52]),
        //     'lt': String.fromCharCode.apply(null, [50, 49, 56, 46, 49, 49, 46, 49, 46, 49, 48, 53])
        // }
        'gf': '116.211.166.201'//高防'phz.xcve1xafe.com'
    }
};

var IIL = function (ts) {
    var _ul;
    do {
        if (_.isUndefined(ts)) {
            ts = cc.sys.localStorage.getItem(gameData.clientId + 'dnts');
            if (!ts || ts.length != 13) {
                ts = '1487473786031';
            }
            ts = (Math.round(new Date().getTime() / 1000) + 1).toString() + ts.substring(10);
        }
        if (_.isNumber(ts)) ts = ts.toString();
        if (ts.length != 13) {
            _ul = '0';
            break;
        }
        var sec1 = _.parseInt(ts.substring(0, 10));
        var sec2 = Math.round(new Date().getTime() / 1000);
        if (Math.abs(sec1 - sec2) > 86400) {
            _ul = '0';
            break;
        }
        _ul = ts.substring(10, 11);
    } while (false);

    if (_.isNumber(_ul)) _ul = _ul.toString();
    if (!UL[_ul]) _ul = '0';
    if (_.isArray(gameData.ipList) && gameData.userLevel == _ul) {
        return;
    }
    gameData.ipList = [];
    gameData.ipList.splice(0, 0, UL[_ul].ym);

    if (!window.inReview) {
        var _tmp_ul = (_.parseInt(_ul) + (gameData._add_ul || 0)) % 4;
        _tmp_ul = _tmp_ul.toString();
        if (!gameData.ipType || gameData.ipType == 'other' || !UL[_tmp_ul]['gf'][gameData.ipType]) {
            gameData.ipList.splice(0, 0, 'http://' + UL[_tmp_ul]['gf']['dx']);
            gameData.ipList.splice(0, 0, 'http://' + UL[_tmp_ul]['gf']['lt']);
        } else {
            gameData.ipList.splice(0, 0, 'http://' + UL[_tmp_ul]['gf'][gameData.ipType]);
        }

        var sdkIp = getNextIp2(UL[_ul].yxd);
        // console.log("sdkIp = " + sdkIp);
        if (sdkIp && /\d+\.\d+\.\d+\.\d+/.test(sdkIp)) {
            if (!sdkIp.startsWith("http://") && !sdkIp.startsWith("https://")) {
                sdkIp = "http://" + sdkIp;
            }
            gameData.ipList.splice(0, 0, sdkIp);
        }
    }
    gameData.userLevel = _ul;
    cc.sys.localStorage.setItem(gameData.clientId + 'dnts', ts);
};
var startLocate = function () {
    if (!cc.sys.isNative) {
        return null;
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(
            "AppController",
            "startLocation"
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "startLocate",
            "()Ljava/lang/String;"
        );
    }
};

var getCurLocation = function () {
    if (!cc.sys.isNative) {
        return null;
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(
            "AppController",
            "getCurLocation"
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "getCurLocation",
            "()Ljava/lang/String;"
        );
    }
};

var clearCurLocation = function () {
    if (!cc.sys.isNative) {
        return null;
    }
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(
            "AppController",
            "clearCurLocation"
        );
    }
    else {
        return jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "clearCurLocation",
            "()Ljava/lang/String;"
        );
    }
};
var deepCopy = function(source) {
    var result = [];
    for (var key in source) {
        result[key] = typeof source[key]==='object'? deepCopy(source[key]): source[key];
    }
    return result;
};


//复制到剪切板
var savePasteBoard = function(text){
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(
            "AppController",
            "savePasteBoard:",
            text
        );
    } else if(cc.sys.os == cc.sys.OS_ANDROID){
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/AppActivity",
            "copyToClipboard",//pasteFromClipboard
            "(Ljava/lang/String;)Ljava/lang/String;",
            text
        );
    }
};

/**
 * 数字转换 例如1转①
 * @param txtstring 数字
 * @returns {string} 转换后的数字
 */
var ToDBC = function (txtstring) {
    var tmp = "";
    if (typeof txtstring != 'string') {
        txtstring = "" + txtstring;
    }
    for (var i = 0; i < txtstring.length; i++) {
        if (txtstring.charCodeAt(i) == 32) {
            tmp = tmp + String.fromCharCode(12288);
        }
        if (txtstring.charCodeAt(i) < 127) {
            tmp = tmp + String.fromCharCode(txtstring.charCodeAt(i) + 65248);
        }
    }
    return tmp;
};

//提示框
//@data{color,fontName,fontSize,swallowTouch...}
var showMessage = function (message, data) {
    var currScene = cc.director.getRunningScene();
    if (currScene) {
        var layer = new MessageLayer(message, data);
        if (data && data.swallowTouch)
            TouchUtils.setOnclickListener(layer, function () {
            });
        currScene.addChild(layer, 9999);
    }
};

//定位
/**
 * approx distance between two points on earth ellipsoid
 * @param {Object} lat1
 * @param {Object} lng1
 * @param {Object} lat2
 * @param {Object} lng2
 */
var EARTH_RADIUS = 6378137.0;    //单位M
var PI = Math.PI;
function getRad(d) {
    return d * PI / 180.0;
}
function getFlatternDistance(lat1, lng1, lat2, lng2) {
    lat1 = parseFloat(lat1);
    lng1 = parseFloat(lng1);
    lat2 = parseFloat(lat2);
    lng2 = parseFloat(lng2);
    var f = getRad((lat1 + lat2) / 2);
    var g = getRad((lat1 - lat2) / 2);
    var l = getRad((lng1 - lng2) / 2);

    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);

    var s, c, w, r, d, h1, h2;
    var a = EARTH_RADIUS;
    var fl = 1 / 298.257;

    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;

    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;

    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    var ret = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    return _.isNaN(ret) ? 0 : ret.toFixed(1);
}
var getCurLocationInfo = function (cb) {
    if (window.inReview)
        return;
    if (gameData.location) {
        var coordtype = 'wgs84ll';
        if (cc.sys.os == cc.sys.OS_IOS) {
            coordtype = 'wgs84ll';
        } else {
            coordtype = 'bd09ll';
        }
        httpGet('http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&coordtype=' + coordtype + '&location=' + gameData.location + '&output=json&pois=0&ak=WIVhGkuCRHrD57PnqK3hqZYpMjgavx9p',
            function (str) {
                str = str.substring(29, str.length - 1);
                var jsonData = JSON.parse(str);
                var status = jsonData.status;
                if (status == 0) {
                    cb(jsonData.result['formatted_address'], jsonData.result.location['lng'], jsonData.result.location['lat']);
                } else {
                    // alert1("失败, 请检查网络连接");
                }
            }, function () {

            }, {
                'Accept-Encoding': 'deflate'
            });
    }
};

var isNetwork = function () {
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod("NetManager", "isNetwork");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        return jsb.reflection.callStaticMethod(packageUri + "/utils/NetManager", "isNetwork", "()Z");
    }
};

var beginNetListener = function () {
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod("NetManager", "beginNetListener");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        return jsb.reflection.callStaticMethod(packageUri + "/utils/NetManager", "beginNetListener", "()V");
    }
};

var stopNetListener = function () {
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod("NetManager", "stopNetListener");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        return jsb.reflection.callStaticMethod(packageUri + "/utils/NetManager", "stopNetListener", "()V");
    }
};

var randomString = function (len) {
    len = len || 32;
    var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz0123456789';
    var maxPos = $chars.length;
    var pwd = '';
    for (i = 0; i < len; i++) {
        pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd;
};
var getCurTimeMillisecond = function () {
    return Math.round((new Date()).getTime());
};

var MaScene = cc.Scene.extend({
    replayData: null,
    reconnectData: null,
    maLayer: null,
    replayLayer: null,
    ctor: function (data) {
        this._super();

        var isReplay = !!(data && data['3002']);
        var isReconnect = !!(data && !isReplay);

        if (isReplay)
            this.replayData = data || null;
        if (isReconnect)
            this.reconnectData = data || null;

        var layer =new MaLayer((isReplay ? null : this.reconnectData), isReplay);
        this.addChild(layer);
        this.maLayer = layer;

        window.maLayer = layer;
        window.paizhuo ="majiang";

        if (isReplay) {
            var playLayer = new Ma_PlayBackLayer(data);
            layer.addChild(playLayer, 999);
        }

        var tipLayer = new cc.Layer();
        layer.addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;

        var loadingLayer = new cc.Layer();
        layer.addChild(loadingLayer, 2000);
        HUD.loadingLayer = loadingLayer;
    },
    getMalayer: function () {
        return this.maLayer;
    },
    onEnter: function () {
        cc.Scene.prototype.onEnter.call(this);
    },
    onExit: function () {
        cc.Scene.prototype.onExit.call(this);
    }
});


var NiuNiuScene = cc.Scene.extend({
    replayData: null,
    reconnectData: null,
    niuniuLayer: null,
    replayLayer: null,
    ctor: function (data) {
        this._super();

        var layer = null;
        if(gameData.mapId == MAP_ID_CRAZYNN){
            layer = new NiuniuZJNLayer(data);
        }else{
            layer = new NiuniuLayer(data);
        }
        this.addChild(layer);
        this.niuniuLayer = layer;

        window.niuniuLayer = layer;
        window.paizhuo ="niuniu";

        var tipLayer = new cc.Layer();
        layer.addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;

        var loadingLayer = new cc.Layer();
        layer.addChild(loadingLayer, 2000);
        HUD.loadingLayer = loadingLayer;

    },
    getMalayer: function () {
        return this.niuniuLayer;
    },
    onEnter: function () {
        cc.Scene.prototype.onEnter.call(this);
    },
    onExit: function () {
        cc.Scene.prototype.onExit.call(this);
    }
});

var PuKeScene = cc.Scene.extend({
    replayData: null,
    reconnectData: null,
    maLayer: null,
    replayLayer: null,
    ctor: function (data) {
        this._super();

        var isReplay = !!(data && data['3002']);
        var isReconnect = !!(data && !isReplay);

        if (isReplay)
            this.replayData = data || null;
        if (isReconnect)
            this.reconnectData = data || null;

        var layer = new PokerLayer((isReplay ? null : this.reconnectData), isReplay);
        this.addChild(layer);
        this.maLayer = layer;

        var tipLayer = new cc.Layer();
        layer.addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;

        var loadingLayer = new cc.Layer();
        layer.addChild(loadingLayer, 2000);
        HUD.loadingLayer = loadingLayer;

        window.maLayer = layer;
        window.paizhuo ="pdk";

        if (isReplay) {
            var playLayer = new PokerPlayBackLayer(data);
            window.maLayer.addChild(playLayer, 500);
        }
    },

    getMalayer: function () {
        return this.maLayer;
    },
    onEnter: function () {
        cc.Scene.prototype.onEnter.call(this);
    },
    onExit: function () {
        cc.Scene.prototype.onExit.call(this);
    }
});
var ZJHScene = cc.Scene.extend({
    replayData: null,
    reconnectData: null,
    maLayer: null,
    replayLayer: null,
    ctor: function (data) {
        this._super();

        var isReplay = !!(data && data['3002']);
        var isReconnect = !!(data && !isReplay);

        if (isReplay)
            this.replayData = data || null;
        if (isReconnect)
            this.reconnectData = data || null;


        var layer = new MaLayer_zjh((isReplay ? null : this.reconnectData), isReplay);
        this.addChild(layer);
        this.maLayer = layer;

        var tipLayer = new cc.Layer();
        layer.addChild(tipLayer, 1000);
        HUD.tipLayer = tipLayer;

        var loadingLayer = new cc.Layer();
        layer.addChild(loadingLayer, 2000);
        HUD.loadingLayer = loadingLayer;

        window.maLayer = layer;
        window.paizhuo ="zjh";

        if (isReplay) {
            var playLayer = new PokerPlayBackLayer(data);
            window.maLayer.addChild(playLayer, 500);
        }
    },

    getMalayer: function () {
        return this.maLayer;
    },
    onEnter: function () {
        cc.Scene.prototype.onEnter.call(this);
    },
    onExit: function () {
        cc.Scene.prototype.onExit.call(this);
    }
});
var getPaiNameById = function (id) {
    if(id<0)return["b/poker_back.png"];
    if (id >= 0 && id <= 12) return ["b/red_" + (id - 0) % 13 + ".png", "b/bigtag_2.png"];//红桃
    if (id >= 13 && id <= 25) return ["b/black_" + (id - 13) % 13 + ".png", "b/bigtag_3.png"];//黑桃
    if (id >= 26 && id <= 38) return ["b/black_" + (id - 26) % 13 + ".png", "b/bigtag_1.png"];//梅花
    if (id >= 39 && id <= 51) return ["b/red_" + (id - 39) % 13 + ".png", "b/bigtag_0.png"];//方块
    if (id == 52) return ["b/smalltag_4.png"];
    if (id == 53) return ["b/smalltag_5.png"];
};
//牛牛 红桃0-12 黑桃13-25 梅花26-38 方片39-51   后端给的数据  1-4 A 5-8 2  //1方片 2梅花 3红桃 4黑桃
var getPaiNameByIdNN = function (id) {
    var color = (id - 1) % 4;
    var value = Math.floor((id - 1) / 4);
    var cardAdd = [39, 26, 0, 13];
    var card = cardAdd[color] + value;
    return "poker_" + card + ".png";
};
var getZhuangMode = function(data){
    if(data.ZhuangMode == "Niuniu"){
        return "双十上庄";
    }else if(data.ZhuangMode == "Tongbi"){
        return "通比玩法";
    }else if(data.ZhuangMode == "Qiang" && (data.Preview || data.Preview_mp)){
        if(data.Players == "jiu"){
            return "九人明牌";
        }else{
            if(data.AlwaysTui){
                return "抢庄推注";
            }else {
                return "明牌抢庄";
            }
        }
    }else{
        return "抢庄玩法";
    }
}
var UTF8ArrayToUTF16Array = function (s) {
    if (!s)
        return;
    var i, codes, bytes, ret = [], len = s.length;
    for (i = 0; i < len; i++) {
        codes = [];
        codes.push(s[i]);
        if (((codes[0] >> 7) & 0xff) == 0x0) {
            //单字节  0xxxxxxx
            ret.push(s[i]);
        } else if (((codes[0] >> 5) & 0xff) == 0x6) {
            //双字节  110xxxxx 10xxxxxx
            codes.push(s[++i]);
            bytes = [];
            bytes.push(codes[0] & 0x1f);
            bytes.push(codes[1] & 0x3f);
            ret.push((bytes[0] << 6) | bytes[1]);
        } else if (((codes[0] >> 4) & 0xff) == 0xe) {
            //三字节  1110xxxx 10xxxxxx 10xxxxxx
            codes.push(s[++i]);
            codes.push(s[++i]);
            bytes = [];
            bytes.push((codes[0] << 4) | ((codes[1] >> 2) & 0xf));
            bytes.push(((codes[1] & 0x3) << 6) | (codes[2] & 0x3f));
            ret.push((bytes[0] << 8) | bytes[1]);
        }
    }
    return ret;
}

var clearGameMWRoomId= function(){
    if (getNativeVersion() < '2.0.0') {
        return;
    }
    var roomId = MWUtil.getRoomId();
    if (_.isString(roomId) && roomId.length == 6) {
        MWUtil.clearRoomId();
    }
}
//1方片 2梅花 3红桃 4黑桃
var setCardBigUI = function(node, val){
    var createS = function(name){
        var s = new cc.Sprite();
        s.setName(name);
        node.addChild(s);
        return s;
    };
    var nodeW = node.getContentSize().width;
    var nodeH = node.getContentSize().height;

    var arr = getPaiNameById(val);

    var c = node.getChildByName("c");
    if(c)  c.setVisible(false);

    var a = node.getChildByName("a");
    if(!a) {
        a = createS("a");
    }
    a.setScale(0.6);
    a.setPosition(cc.p(17, nodeH - 8));
    setPokerFrameByNameNN(a, arr[0]);

    var b = node.getChildByName("b");
    if(!b) {
        b = createS("b");
    }
    b.setScale(0.5);
    b.setPosition(cc.p(17, nodeH - 40));
    setPokerFrameByNameNN(b, arr[1]);

    var a1 = node.getChildByName("a1");
    if(!a1) {
        a1 = createS("a1");
    }
    a1.setScale(0.6);
    a1.setRotation(-180);
    a1.setPosition(cc.p(nodeW - 17,  22));
    setPokerFrameByNameNN(a1, arr[0]);

    var b1 = node.getChildByName("b1");
    if(!b1) {
        b1 = createS("b1");
    }
    b1.setRotation(-180);
    b1.setScale(0.5);
    b1.setPosition(cc.p(nodeW - 17, 43));
    setPokerFrameByNameNN(b1, arr[1]);

    var huaPosArr = [
        //10
        cc.p(37, nodeH/2 + 42),
        cc.p(nodeW - 37, nodeH/2 + 42),
        cc.p(nodeW/2, nodeH/2 + 28),
        cc.p(37, nodeH/2 + 14),
        cc.p(nodeW - 37, nodeH/2 + 14),
        cc.p(37, nodeH/2 - 14),
        cc.p(nodeW - 37, nodeH/2 - 14),
        cc.p(nodeW/2, nodeH/2 - 28),
        cc.p(37, nodeH/2 - 42),
        cc.p(nodeW - 37, nodeH/2 - 42),

        //1   ---10
        cc.p(nodeW/2, nodeH/2),
        //8   ---11
        cc.p(nodeW/2, nodeH/2 + 21),
        cc.p(37, nodeH/2),
        cc.p(nodeW - 37, nodeH/2),
        cc.p(nodeW/2, nodeH/2 - 21),
        //2    -----15
        cc.p(nodeW/2, nodeH/2 + 42),
        cc.p(nodeW/2, nodeH/2 - 42),
        //JQK    ---17
        cc.p(nodeW/2 - 17, nodeH/2 + 24),
        cc.p(nodeW/2 + 17, nodeH/2 - 24)
    ];
    var huaNum = 1;
    if(val >= 5 && val <= 40){
        huaNum = Math.floor((val+3)/4);
    }else if(val >= 41  && val <= 52){
        huaNum = 2;
    }
    var huaPosConfig = [];
    switch (huaNum) {
        case 1:
            huaPosConfig.push([huaPosArr[10]]);
            break;
        case 2:
            if(val >= 41  && val <= 52){     //JQK
                huaPosConfig.push([huaPosArr[17], huaPosArr[18]]);
            }else {
                huaPosConfig.push([huaPosArr[15], huaPosArr[16]]);
            }
            break;
        case 3:
            huaPosConfig.push([huaPosArr[15], huaPosArr[10], huaPosArr[16]]);
            break;
        case 4:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[8], huaPosArr[9]]);
            break;
        case 5:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[10], huaPosArr[8], huaPosArr[9]]);
            break;
        case 6:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[12], huaPosArr[13], huaPosArr[8], huaPosArr[9]]);
            break;
        case 7:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[11], huaPosArr[12], huaPosArr[13], huaPosArr[8], huaPosArr[9]]);
            break;
        case 8:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[11], huaPosArr[12],
                huaPosArr[13], huaPosArr[14], huaPosArr[8], huaPosArr[9]]);
            break;
        case 9:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[3], huaPosArr[4], huaPosArr[10],
                huaPosArr[5], huaPosArr[6], huaPosArr[8], huaPosArr[9]]);
            break;
        case 10:
            huaPosConfig.push([huaPosArr[0], huaPosArr[1], huaPosArr[2], huaPosArr[3], huaPosArr[4], huaPosArr[5],
                huaPosArr[6], huaPosArr[7], huaPosArr[8], huaPosArr[9]]);
            break;
        default:
            break;
    }
    for(var i=0;i<huaNum;i++){
        var hua = node.getChildByName("hua" + i);
        if(!hua)  {
            hua = createS("hua" + i);
        }
        if(val >= 41  && val <= 52){
            setPokerFrameByNameNN(hua, arr[3]);
            hua.setScale(0.5);
            hua.setRotation((i == 1) ? -180 : 0);
        }else {
            setPokerFrameByNameNN(hua, arr[1]);
            // hua.setScale(0.9);
            hua.setRotation(0);
            hua.setScale((val >= 1 && val <= 4) ? 1.5:0.8);
        }
        hua.setVisible(true);
        hua.setPosition(huaPosConfig[0][i]);
    }
    for(i;i<10;i++){
        var hua = node.getChildByName("hua" + i);
        if(hua)  hua.setVisible(false);
    }
};

var layerShowAni = function(layer){
    var mask = null;

    var parent = layer.getParent();
    if (parent) {
        mask = new cc.LayerColor(cc.color(0, 0, 0, 255 / 2), cc.winSize.width, cc.winSize.height);
        mask.setName('mask');
        mask.setPosition(0, 0);
        parent.addChild(mask, -1);
    }

    if(mask) {
        var chupaiListener = cc.EventListener.create({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function (touch, _) {
                return true;
            },
            onTouchMoved: function (touch, _) {
            },
            onTouchEnded: function (touch, _) {
            }
        });
        cc.eventManager.addListener(chupaiListener, mask);
    }


    layer.setScale(0);
    layer.runAction(
        cc.scaleTo(0.1, 1).easing(cc.easeIn(0.1))
    );
}
var layerHideAni = function(layer, func){
    var parent = layer.getParent();
    if (parent) {
        var mask = parent.getChildByName('mask');
        if (mask) {
            mask.runAction(cc.sequence(
                cc.scaleTo(0.1, 0),
                cc.removeSelf()
            ));
        }
    }

    layer.runAction(cc.sequence(
        cc.scaleTo(0.1, 0),
        cc.callFunc(function(){
            func()
        })
    ));
}
//界面动画
var popShowAni = function(layer, noMask){
    if(!noMask) {
        //加背景蒙版
        var mask = new cc.LayerColor(cc.color(0, 0, 0, 255 / 2), cc.winSize.width, cc.winSize.height);
        mask.setName('mask');
        mask.setPosition(0, 0);
        layer.getParent().addChild(mask, -1);

        var chupaiListener = cc.EventListener.create({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: function (touch, _) {
                return true;
            },
            onTouchMoved: function (touch, _) {
            },
            onTouchEnded: function (touch, _) {
            }
        });
        cc.eventManager.addListener(chupaiListener, mask);
    }

    layer.setScale(0);
    layer.runAction(cc.sequence(
        cc.scaleTo(0.1, 1.05, 1.05),
        cc.scaleTo(0.08, 0.95, 0.95),
        // cc.scaleTo(0.05, 0.95, 1.05),
        cc.scaleTo(0.05, 1, 1)
    ));
}
var popHideAni = function(layer, func){
    layer.runAction(cc.sequence(
        cc.scaleTo(0.2, 0),
        cc.callFunc(function(){
            var parent = layer.getParent();
            if(parent) {
                var mask = parent.getChildByName('mask');
                if (mask) {
                    mask.runAction(cc.sequence(
                        cc.scaleTo(0.1, 0),
                        cc.removeSelf()
                    ));
                }
            }
            func();
        })
    ));
}

//红包雨活动
var activityRedRain = function (create_time, area) {
    showLoading('正在加载中...')
    var data = {
        playerId: gameData.uid,
        unionId: gameData.unionid, //
        area: area,
        roomId : gameData.roomId,
        timestamp: create_time//getCurTimestamp(),
    };
    data.sign = Crypto.MD5(data.playerId + data.unionId + data.area + data.roomId + data.timestamp + "012E3456879aBCDFgHIjLNOPQRSUVWXYzAbcKdefMGhiJklmnopqrstTuvwxyZ+/");
    console.log(JSON.stringify(data));
    httpPost("http://pay.yayayouxi.com/fyactivity/activity/draw/redRain", data,
    // httpPost("http://118.31.169.179:8086/fyactivity/activity/draw/redRain", data,
        function (response) {
            hideLoading();
            console.log(JSON.stringify(response));
            if(response.status==6){
                // alert1('抱歉，您未中奖！');
                cc.director.getRunningScene().addChild(new RedRainLayer("未获得红包"));
            }else if(response.status==7){
                //不在活动时间内
            }else if(response.data && response.data.playerId == gameData.uid){
                cc.director.getRunningScene().addChild(new RedRainLayer(response.message));
            }
        },function (response) {
            hideLoading();
            alert1('抱歉，系统繁忙！');
        }
    );

}
var getSortFlag = function () {
    var flag = -1;
    var sortFlag = cc.sys.localStorage.getItem('sortFlag');
    if (sortFlag) {
        flag = parseInt(sortFlag);
    }
    return flag;
};
var track_idx = 0;
var createSp = function (res_name) {
    if (!res['sp_' + res_name + '_json'] || !res['sp_' + res_name + '_atlas']) {
        cc.log("spine files not exist, res_name = " + res_name);
        return null;
    }
    return new sp.SkeletonAnimation(res['sp_' + res_name + '_json'], res['sp_' + res_name + '_atlas']);
};
var playSpAnimation = function (sp_anim, animation_name, isLoop) {
    if (typeof sp_anim === 'string') {
        sp_anim = createSp(sp_anim);
    }
    if (sp_anim instanceof sp.SkeletonAnimation) {
        sp_anim.setAnimation(track_idx++,
            _.isUndefined(animation_name) ? 'animation' : animation_name,
            _.isUndefined(isLoop) ? true : isLoop);
        return sp_anim;
    }
    return null;
};