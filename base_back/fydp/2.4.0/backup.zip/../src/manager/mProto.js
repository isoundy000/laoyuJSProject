
var mProto = {
    initProtoTypes: function () {
        for (var key in P) {
            var strNewKey = P[key].toString();
            if(ProtoTypes[strNewKey] == null){
                //ProtoTypes[strNewKey] = key.slice(4);
                ProtoTypes[strNewKey] = key + "_MSG";
            }else{
                ProtoTypes[strNewKey] = key + "_MSG";
            }
        }
        //cc.log("get proto types +++++", ProtoTypes.length);
    },

    EntityType:{},
    init:function(){
        this.EntityType = mProto.builder.build("G2.Protocol.EntityType");
    }
};

