/**
 * Created by hjx on 2018/2/7.
 */
(function () {
    var exports = this;
    var $ = null;

    var clubid = null;
    var currentWanfaIdx = 0;
    var targetWanfaIdx = 0;
    var isHasWanfaIdx = function (clubInfo, idx) {
        if(!clubInfo.wanfas) {//不存在玩法设置
            return false;
        }else{
            for(var i=0; i<clubInfo.wanfas.length; i++){
                var room = clubInfo.wanfas[i];
                if(room.pos == idx){
                    return room;
                }
            }
        }
        return false;
    }
    var clubRoomMap = null;
    var tablesCount = 12;

    var ClubTablesLayer = cc.Layer.extend({
        onCCSLoadFinish: function () {
        },
        checkCurrentWanfaIdx:function () {
            currentWanfaIdx = cc.sys.localStorage.getItem('club_pos_' + clubid) || '0';
            var clubInfo = getClubData(clubid);
            if (!parseInt(currentWanfaIdx) && clubInfo && clubInfo.wanfas && clubInfo.wanfas.length>=1) {
                currentWanfaIdx = clubInfo.wanfas[0].pos;
            }else if(currentWanfaIdx){
                if(!isHasWanfaIdx(clubInfo, currentWanfaIdx)){
                    if(clubInfo && clubInfo.wanfas && clubInfo.wanfas.length>=1){
                        currentWanfaIdx = clubInfo.wanfas[0].pos;
                    }
                }
            }else{
                currentWanfaIdx = 1;
            }
            cc.sys.localStorage.setItem('club_pos_' + clubid , currentWanfaIdx);
        },
        ctor: function (_id, isShowWanfa) {
            this._super();
            var that = this;
            var mainscene = ccs.load(res.ClubTablesLayer_json, "res/");
            this.addChild(mainscene.node);

            $ = create$(this.getChildByName("Layer"));

            clubid = _id;
            var clubInfo = getClubData(clubid);
            this.checkCurrentWanfaIdx();


            TouchUtils.setOnclickListener($('root'), function () {

            });

            TouchUtils.setOnclickListener($('btn_close'), function () {
                that.removeFromParent(true);
                //
                var clayer = window.maLayer.getChildByName('ClubTablesLayer');
                if(!clayer){

                }
            });

            var wanfaState = 1;
            TouchUtils.setOnclickListener($('wanfasp.node.root'),function () {
                $('wanfasp').onclickCallBack();
            });
            TouchUtils.setOnclickListener($('wanfasp'),function () {
                if(wanfaState){
                    console.log("up----");
                    wanfaState = 0;
                    $('wanfasp.node').setVisible(true);
                    //设置玩法列表内容
                    that.showWanfaBtns();
                }else{
                    console.log("down----");
                    wanfaState = 1;
                    $('wanfasp.node').setVisible(false);
                }
            });
            $('wanfasp.node').setVisible(false);
            if(isShowWanfa){
                wanfaState = 0;
                $('wanfasp.node').setVisible(true);
                that.showWanfaBtns();
            }
            for(var i=1; i<=5; i++){
                (function (idx) {
                    var btn = $('wanfasp.node.list.btn_' + idx);
                    TouchUtils.setOnclickListener(btn, function () {
                        console.log("选择玩法 " + idx);

                        var _clubInfo = getClubData(clubid);
                        if(isHasWanfaIdx(_clubInfo, idx)){
                            currentWanfaIdx = idx;
                            cc.sys.localStorage.setItem('club_pos_' + clubid, idx);
                            if(currentWanfaIdx>=1){
                                $('icon_wanfa').setVisible(true);
                                $('icon_wanfa').setTexture('res/image/ui/club/icon_wanfa' + currentWanfaIdx + '.png');
                                $('club_bg_1').setTexture('res/image/ui/club/club_wanfabg' + currentWanfaIdx + '.jpg');
                            }
                            that.showRooms(_clubInfo.wanfas, idx);
                        }else{
                            if(_clubInfo['owner_uid']==gameData.uid || (_clubInfo['admins']&&clubInfo['admins'].indexOf(gameData.uid)>=0)){
                                targetWanfaIdx = idx;
                                // window.maLayer.createRoom(false, 0, clubid, idx);
                                that.addChild(new ClubSelectGameLayer(clubid, idx));
                            }else{
                                alert1('只有群主与管理员才有设置玩法权限')
                            }
                        }
                        $('wanfasp').onclickCallBack();
                    })

                    var btn_clear = $('wanfasp.node.list.btn_' + idx + ".btn_clear");
                    TouchUtils.setOnclickListener(btn_clear, function () {
                        alert2('是否确定删除玩法设置？', function(){
                            console.log("清除玩法 " + idx);
                            network.send(2103, {
                                cmd:'delWanfa',
                                club_id: clubid,
                                pos:idx
                            });
                        })
                    })
                })(i);
            }

            //玩法设置
            TouchUtils.setOnclickListener($('wanfa_bg'),function () {
            }, {swallowTouches:true, effect:TouchUtils.effects.NONE});
            TouchUtils.setOnclickListener($('wanfa_bg.btn_wanfa'), function () {
                // window.maLayer.createRoom(false, 0, clubid, currentWanfaIdx);
                that.addChild(new ClubSelectGameLayer(clubid, currentWanfaIdx));
            }, {swallowTouches:true});
            if(!clubInfo.wanfas){//不存在玩法设置
                $('meinv').setVisible(true);
                $('wanfa_bg').setVisible(false);
            }else{
                $('meinv').setVisible(false);
                $('wanfa_bg').setVisible(true);
            }

            //邀请
            TouchUtils.setOnclickListener($('btn_invite'), function () {
                // that.addChild(new ClubInviteLayer(getClubData(clubid)));
                var clubData = getClubData(clubid);
                that.getParent().addChild(new ClubInputLayer('invite', clubData));
            });

            //分享
            TouchUtils.setOnclickListener($('btn_share'), function () {
                // alert1('暂未开放')
                that.addChild(new ShareTypeLayer(undefined, undefined,undefined, undefined, getClubData(clubid)));
            });

            //管理btn_sys
            TouchUtils.setOnclickListener($('btn_sys'), function () {
                alert1('暂未开放')
            });
            var refreshTime = 0;
            TouchUtils.setOnclickListener($('btn_refresh'), function () {
                // network.send(2103, {cmd:'queryClub'});

                if(new Date().getTime() - refreshTime<2000){
                    alert1('您的刷新频率过于频繁，请稍后再试');
                    return;
                }
                refreshTime = new Date().getTime();

                network.send(2103, {cmd:'flushClub', club_id:clubid});
                network.send(2103, {cmd:'listClubRoom', club_id:clubid});
                network.send(2103, {cmd: 'queryMSG', club_id: clubid});
            });
            TouchUtils.setOnclickListener($('btn_xiaoxi'), function () {
                that.addChild(new ClubMsgLayer(clubid));
            });

            TouchUtils.setOnclickListener($('btn_zhanji'), function () {
                // that.addChild(new DaiKai(clubid));
                that.addChild(new ClubZhanjiLayer(clubid));
            });

            //设置
            TouchUtils.setOnclickListener($('btn_set'), function () {
                that.addChild(new ClubSettingLayer(clubid));
            });
            that.refreshView();

            var versiontxt = window.curVersion;
            var version = new ccui.Text();
            version.setFontSize(18);
            version.setTextColor(cc.color(255, 255, 255));
            version.setPosition(cc.p(1280 - 10, 10));
            version.setAnchorPoint(cc.p(1, 0.5));
            version.setString(versiontxt);
            this.addChild(version, 2);

            return true;
        },
        getIsOpenState:function(stime,etime){
            var myDate=new Date();
            var nh=myDate.getHours();
            var nm=myDate.getMinutes();
            var arr1=stime.split(':');
            var arr2=etime.split(':');
            var sh=parseInt(arr1[0]);
            var sm=parseInt(arr1[1]);

            var eh=parseInt(arr2[0]);
            var em=parseInt(arr2[1]);

            if(sh<eh){//非跨天
                if(nh>sh&&nh<eh){
                    return true;
                }else if(nh==sh&&nm>=sm){
                    return true;

                }else if(nh==eh&&nm<=em){
                    return true;
                }
            }else if(sh==eh){

                if(sm<em){// 非跨天
                    if(nh==sh&&nm>=sm&&nm<=em){
                        return true;
                    }
                }else if(sm>em){//跨天
                    if(nh>sh){
                        return true;
                    }else if(nh==sh&&nm>=sm){
                        return true;
                    }else if(nh==sh&&nm<=em){
                        return true;
                    }
                }else if(sm==em){//完全一致认为全营业
                    return true;
                }
            }else if(sh>eh){//跨天
                if(nh==sh&&nm>=sm){
                    return true;

                }else if(nh>sh){
                    return true;
                }else if(nh<eh){
                    return true;
                }else if(nh==eh&&nm<=em){
                    return true;
                }
            }
            return false;
        },
        showWanfaBtns : function (wanfas) {
            var clubInfo = getClubData(clubid);
            for(var i=1; i<=5; i++){
                var info =isHasWanfaIdx(clubInfo, i);
                var parent = $('wanfasp.node.list.btn_' + i);
                if(info){
                    var option = JSON.parse(info.options);
                    // console.log("玩法里面信息 ： " + JSON.stringify(info));
                    var wanfa = gameData.mapId2Name(info['map_id']);
                    if(info['map_id'] == MAP_ID['DN'] || info['map_id'] ==MAP_ID['NN'] || info['map_id'] >= 4000){
                        wanfa = getZhuangMode(option);
                    }
                    $('lb_name',parent).setString(wanfa);//info.desc.split(',')[0]);
                    $('lb_jushu',parent).setString('局数：' + option.jushu || option.rounds);
                    //群主扣卡
                    $('lb_jushu_0', parent).setVisible(true);
                    $('lb_jushu_0', parent).setString((option && option['AA'])?'AA支付':'群主支付');

                    $('lb_jushu',parent).setVisible(true);
                    $('btn_clear',parent).setVisible(this.isSelfAdministration());
                }else{
                    $('lb_jushu_0', parent).setVisible(false);
                    $('lb_jushu',parent).setVisible(false);
                    $('lb_name',parent).setString('请点击设置玩法');
                    $('btn_clear',parent).setVisible(false);
                }
            }
        },
        showRooms : function (wanfas, pos) {
            var rooms = _.filter(wanfas, function (obj) {
                return obj.pos == pos;
            });
            // console.log("选取玩法信息：" + JSON.stringify(rooms));
            $('wanfa_bg.lb_wanfa').setString(decodeURIComponent(rooms[0].desc).replace(/,/g, '\n') || '');
            $('wanfa_bg').setVisible(true);
            $('meinv').setVisible(false);

            network.send(2103, {cmd: 'listClubRoom', club_id: clubid});
        },
        isSelfAdministration:function () {
            var clubInfo = getClubData(clubid);
            if(clubInfo['owner_uid']==gameData.uid || (clubInfo['admins']&&clubInfo['admins'].indexOf(gameData.uid)>=0)) {
                return true;
            }
            return false;
        },
        refreshView : function () {
            var clubInfo = getClubData(clubid);
            // $('wanfa_bg.lb_wanfa').setString(clubInfo.desc);
            $('lb_name').setString("" + clubInfo.name);
            $('lb_id').setString("ID:" +clubInfo._id);
            $('lb_num').setString("人数:" + (clubInfo.players_count||'' ));
            if(isHasWanfaIdx(clubInfo, currentWanfaIdx)){
                this.showRooms(clubInfo.wanfas, currentWanfaIdx);
            }else{
                $('meinv').setVisible(true);
                this.scrollView = $('scrolView');
                this.scrollView.removeAllChildren(true);
                $('wanfa_bg').setVisible(false);
            }

            if(this.isSelfAdministration()) {
                $('btn_invite').setVisible(true)
                Filter.remove($('btn_invite'));
                TouchUtils.setClickDisable($('btn_invite'), false);
            }else{
                Filter.grayScale($('btn_invite'));
                TouchUtils.setClickDisable($('btn_invite'), true);
                $('btn_xiaoxi').setVisible(false);
                $('wanfa_bg.btn_wanfa').setVisible(false);
            }

            if(currentWanfaIdx>=1 && isHasWanfaIdx(clubInfo, currentWanfaIdx)){
                $('icon_wanfa').setTexture('res/image/ui/club/icon_wanfa' + currentWanfaIdx + '.png');
                $('club_bg_1').setTexture('res/image/ui/club/club_wanfabg' + currentWanfaIdx + '.jpg');
                $('icon_wanfa').setVisible(true);
            }else{
                $('icon_wanfa').setVisible(false);
            }

        },
        onEnter : function () {
            this._super();
            var that = this;

            network.send(2103, {cmd: 'updateLocal', club_id: clubid, location: 1});

            this.lis1 = cc.eventManager.addCustomListener('flushClub', function (event) {
                var data=event.getUserData();
                that.checkCurrentWanfaIdx();
                console.log("tttttttt==  flushClub")
                that.refreshView();
            })

            this.lis2 = cc.eventManager.addCustomListener('addWanfa', function (event) {
                var data=event.getUserData();
                if(data.result==0){
                    // maLayer.removeCreateRoom();
                    alert1(data.msg);
                    network.send(2103, {cmd:'flushClub', club_id:clubid});
                    if(targetWanfaIdx){
                        currentWanfaIdx = targetWanfaIdx;
                        cc.sys.localStorage.setItem('club_pos_' + clubid, targetWanfaIdx);
                        targetWanfaIdx = 0;
                    }
                }
            })
            this.lis3 = cc.eventManager.addCustomListener('listClubRoom', function (event) {
                var data=event.getUserData();
                var listClubRoom = data['arr'];
                clubRoomMap = {};
                for(var i=0; i<listClubRoom.length; i++){
                    var room = listClubRoom[i];
                    if(room.option){
                        if(_.isString(room.option)){
                            room.option = JSON.parse(room.option);
                        }
                        if(room.option.pos){
                            var idx = room.option.pos;
                            if(!clubRoomMap[idx]){
                                clubRoomMap[idx] = [];
                            }
                            clubRoomMap[idx].push(room);
                        }
                    }
                }
                var showRooms = clubRoomMap[currentWanfaIdx] ;
                that.refreshClubRooms(showRooms);
            })
            this.lis4 = cc.eventManager.addCustomListener('leaveClub', function (event) {
                var data=event.getUserData();
                if(data.result==0){
                    alert1('成功离开俱乐部');
                    that.removeFromParent();
                }
            })
            this.lis5 = cc.eventManager.addCustomListener('deleteClub', function (event) {
                var data=event.getUserData();
                if(data.result==0){
                    alert1('成功解散俱乐部');
                    that.removeFromParent();
                }
            })
            this.lis6 = cc.eventManager.addCustomListener('queryMSG', function (event) {
                var data=event.getUserData();
                if(data['arr']){
                    var youyongData = [];
                    for (var i = 0; i < data['arr'].length; i++) {
                        var obj = data['arr'][i];
                        if(obj.club_id == clubid){
                            youyongData.push(obj);
                        }
                    }
                    that.setWeiduMegNum(youyongData.length || 0);
                }else{
                    that.setWeiduMegNum(0);
                }
            })
            this.lis7 = cc.eventManager.addCustomListener('queryClub', function (event) {
                var data=event.getUserData();
                console.log("tttttttt==  refreshView")
                that.refreshView();
            })
            this.lis8 = cc.eventManager.addCustomListener('delWanfa', function (event) {
                var data=event.getUserData();
                if(data.result==0){
                    alert1(data.msg);
                    network.send(2103, {cmd:'flushClub', club_id:clubid});
                    currentWanfaIdx =0;
                    cc.sys.localStorage.setItem('club_pos_' + clubid, 0);
                    targetWanfaIdx = 0;
                    $('wanfasp').onclickCallBack();
                }
            });

            network.addListener(3003, function () {
                alert1('房间已解散')
                network.send(2103, {cmd:'listClubRoom', club_id:clubid});
            })
            network.send(2103, {cmd: 'queryMSG', club_id: clubid});
            network.send(2103, {cmd: 'flushClub', club_id: clubid});
        },
        onExit : function () {
            this._super();

            cc.eventManager.removeListener(this.lis1);
            cc.eventManager.removeListener(this.lis2);
            cc.eventManager.removeListener(this.lis3);
            cc.eventManager.removeListener(this.lis4);
            cc.eventManager.removeListener(this.lis5);
            cc.eventManager.removeListener(this.lis6);
            cc.eventManager.removeListener(this.lis7);
            cc.eventManager.removeListener(this.lis8);

            network.send(2103, {cmd: 'updateLocal', club_id: clubid, location: 0});
        },
        //消息列表
        setWeiduMegNum: function (num) {
            if (num > 0) {
                $("btn_xiaoxi.numbg").setVisible(true);
                $("btn_xiaoxi.numbg.num").setString(num);
            } else {
                $("btn_xiaoxi.numbg").setVisible(false);
            }
        },
        refreshClubRooms: function (dataArr) {
            var clubInfo = getClubData(clubid)
            if(!clubInfo.wanfas || (clubInfo.wanfas && clubInfo.wanfas.length==0)){
                return;
            }

            dataArr = dataArr || [];
            dataArr.unshift(undefined);
            this.scrollView = $('scrolView');
            this.scrollView.removeAllChildren(true);

            this.layout = new ccui.Layout();
            this.totalWidth = 0;
            var wanfaObj = isHasWanfaIdx(clubInfo, currentWanfaIdx);
            var playerCount = getWanfaPlayerCountByMapId(wanfaObj ? wanfaObj['map_id'] : 0, wanfaObj.desc);
            for (var i = 0; i < tablesCount; i+=2) {
                this.initItem(dataArr[i], dataArr[i+1], playerCount);
            }

            this.scrollView.setInnerContainerSize(cc.size(this.totalWidth, this.scrollView.getContentSize().height));
            this.scrollView.addChild(this.layout);
            this.layout.setPositionX(0);
        },
        initItem: function (data1, data2, count) {
            var item = new ClubTableItem(data2, currentWanfaIdx, count, this);
            this.layout.addChild(item);
            var itemWidth = item.getLayerWidth();
            item.setPositionX(this.totalWidth );

            item = new ClubTableItem(data1, currentWanfaIdx, count, this);
            this.layout.addChild(item);
            item.setPositionX(this.totalWidth);
            item.setPositionY(260);
            this.totalWidth += itemWidth;
        }
    });
    exports.ClubTablesLayer = ClubTablesLayer;
    exports.getClubCurrentWanfaInfo = function () {
        var club = getClubData(clubid);
        var info = isHasWanfaIdx(club, currentWanfaIdx);
        return info;
    }
})(window);
