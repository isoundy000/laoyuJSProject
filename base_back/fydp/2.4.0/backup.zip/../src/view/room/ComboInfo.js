var ComboInfo = {
    init:function () {
        this.imgTag = getUI(this, "imgTag");
        this.txtHx = Card.getCom(this, "txtHx");

        return true;
    },

    setData:function(data, comboList) {
        this.cardSprite = [];
        var cards = data.cards;
        for (var i = 0; i < cards.length; i++) {
            var cardNo = cards[i];
            var card = HUD.showLayer(HUD_LIST.Card, this);
            card.setData(cardNo, null, 2);
            card.setPosition(-25, (3 - i) * 45 + 10);

            this.cardSprite[i] = card;
        }

        var comboType = data.typ;
        if (comboType != mCard.comboTypes.dui) {
            var imgName = mCard.comboImg[comboType - 1];
            if(mRoom.wanfatype == mRoom.GUILIN &&
                (imgName == "wei" || imgName == "chouwei" || imgName == "pao" || imgName == "ti")){
                imgName = imgName + "_guilin";
                this.imgTag.setContentSize(45, 25);
            }else{
                this.imgTag.setContentSize(28, 28);
            }
            var src = res["c_" + imgName + "_png"]; //"res/image/ui/result/c_" + imgName + ".png";
            if (imgName == null) {
                cc.log("check imgName error !");
            }
            this.imgTag.setTexture(src);
            this.imgTag.setVisible(true);
            var hx = 0;
            if(mRoom.wanfatype == mRoom.WEIMAQUE){
                hx = mCard.getComboHuXiWeiMaQue(data, comboList);
            }else {
                hx = mCard.getComboHuXi(data);
            }
            this.txtHx.setString(hx);
        } else {
            this.imgTag.setVisible(false);
            this.txtHx.setString("0");
            if(mRoom.wanfatype == mRoom.WEIMAQUE) {
                var hx = mCard.getComboHuXiWeiMaQue(data, comboList);
                this.txtHx.setString(hx);
            }
            if(mRoom.wanfatype == mRoom.WEIMAQUE){
                this.imgTag.setVisible(true);
                this.imgTag.setTexture(res.c_jiang_png);
            }
        }
        if(mRoom.wanfatype == mRoom.YOUXIAN) this.txtHx.setVisible(false);
    },
    getCardSprite:function(){
        return this.cardSprite;
    },

    /** @returns ComboInfo */
    getCom: function (p, name) {return getCom(p, name, this);}
};