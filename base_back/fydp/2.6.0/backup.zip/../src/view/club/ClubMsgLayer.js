/**
 * Created by hjx on 2018/2/8.
 */

(function () {
    var exports = this;

    var $ = null;
    var club_id = null;
    var ClubMsgLayer = cc.Layer.extend({
        ctor: function (id) {
            this._super();

            var that = this;
            club_id = id;

            var scene = ccs.load(res.ClubMsgLayer_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            that.clubInfo = getClubData(club_id);
            TouchUtils.setOnclickListener($('btn_close'), function () {
                that.removeFromParent();
            });
            return true;
        },
        initMsgLayer:function(data){
            var that = this;
            that.msgList = data || [];
            this.club_id = that.clubInfo['_id'];
            if(that.tableview){
                tableViewRefresh(that.tableview);
            }else{
                var tableviewLayer = $('tableviewLayer');
                var tableview = new cc.TableView(that, cc.size(tableviewLayer.getContentSize().width, tableviewLayer.getContentSize().height));
                tableview.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                tableview.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
                tableview.x = 0;
                tableview.y = 0;
                tableview.setDelegate(that);
                tableview.setBounceable(true);
                tableviewLayer.addChild(tableview);
                that.tableview = tableview;
            }
        },
        initMsgCell:function (cell, i) {
            var that = this;
            var node = cell.getChildByName('cellrow');
            if (!node) {
                return;
            }
            var userInfo = this.msgList[i];
            var setData = function(ref){
                $("name", ref).setString(ellipsisStr(userInfo['name'], 6));
                $("id", ref).setString("ID:" + userInfo['uid']);

                if (userInfo['head'] == null || userInfo['head'] == undefined || userInfo['head'] == "") {
                    userInfo['head'] = res.defaultHead;
                }
                loadImageToSprite2(decodeURIComponent(userInfo['head']), $('head', ref));
            };
            var row = $('row', node);
            setData(row);
            if(gameData.uid == this.clubInfo['owner_uid'] || (this.clubInfo['admins'] &&  (this.clubInfo['admins'].indexOf(gameData.uid)>=0))) {
                var btn_pingbi = row.getChildByName('btn_pingbi');
                btn_pingbi.setVisible(false);
                var btn_jujue = row.getChildByName('btn_jujue');
                var btn_tongyi = row.getChildByName('btn_tongyi');
                TouchUtils.setOnclickListener(btn_pingbi, function () {
                    network.send(2103, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['_id'], name: userInfo['name'], head:userInfo['head'], value:'ignore'});
                });
                TouchUtils.setOnclickListener(btn_jujue, function () {
                    network.send(2103, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['_id'], name: userInfo['name'], head:userInfo['head'], value:'reject'});
                });
                TouchUtils.setOnclickListener(btn_tongyi, function () {
                    network.send(2103, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['_id'], name: userInfo['name'], head:userInfo['head'], value:'accept'});
                });
            }
        },
        tableCellTouched: function (table, cell) {
        },
        tableCellSizeForIndex: function (table, idx) {
            return cc.size(1152, 85);
        },
        tableCellAtIndex: function (table, idx) {
            var cell = table.dequeueCell();
            if(cell == null) {
                cell = new cc.TableViewCell();
                var row0 = ccs.load(res.ClubMsgItem_json, 'res/').node;
                row0.setName('cellrow');
                cell.addChild(row0);
            }
            this.initMsgCell(cell, idx);
            return cell;
        },
        numberOfCellsInTableView: function (table) {
            return this.msgList.length;
        },
        onEnter : function () {
            this._super();
            var that = this;
            that.msgList = [];
            this.lis1 = cc.eventManager.addCustomListener('queryMSG', function (event) {
                var data=event.getUserData();
                that.msgList = [];
                for (var i = 0; i < data['arr'].length; i++) {
                    var obj = data['arr'][i];
                    if(obj.club_id == club_id){
                        that.msgList.push(obj);
                    }
                }
                that.initMsgLayer(that.msgList);
            })
            this.lis2 = cc.eventManager.addCustomListener('agreeClub', function(event) {
                var data=event.getUserData();
                if(data.result == 0){
                    alert1('操作成功');
                }
                network.send(2103, {cmd: 'queryMSG', club_id: club_id});
            })
            //agreeClub
            network.send(2103, {cmd: 'queryMSG', club_id: club_id});
        },
        onExit : function () {
            this._super();
            cc.eventManager.removeListener(this.lis1);
            cc.eventManager.removeListener(this.lis2);
        }
    });

    exports.ClubMsgLayer = ClubMsgLayer;
})(window);