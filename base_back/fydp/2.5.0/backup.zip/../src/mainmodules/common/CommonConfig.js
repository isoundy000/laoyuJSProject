var common_res = {
    LoginBoard_json: 'res/mainmodules/common/ccs/LoginBoard.json'
};

var common_src = [
    'src/mainmodules/common/views/boards/LoginBoard.js'
];