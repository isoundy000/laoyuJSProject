/**
 * 定位相关操作
 * Created by zhangluxin on 2017/2/8.
 */
var LocationUtils = {};

/**
 * 地球长轴(单位M)
 * @type {number}
 */
var EARTH_RADIUS = 6378137.0;
/**
 * π
 * @type {number}
 */
var PI = Math.PI;
/**
 * 角度转弧度
 * @param {Number} d 角度
 * @returns {Number} 弧度
 */
var getRad = function (d) {
    return d * PI / 180.0;
};

/**
 * 开启定位
 */
LocationUtils.startLocation = function () {
    if (window.inReview) return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod("LocationManager", "startLocation");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        jsb.reflection.callStaticMethod(packageUri + "/utils/LocationManager", "startLocation", "()V");
    }
};

/**
 * 停止定位
 */
LocationUtils.stopLocation = function () {
    if (window.inReview) return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod("LocationManager", "stopLocation");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        jsb.reflection.callStaticMethod(packageUri + "/utils/LocationManager", "stopLocation", "()V");
    }
};

/**
 * 清除定位信息
 */
LocationUtils.clearCurLocation = function () {
    if (window.inReview) return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod("LocationManager", "clearCurLocation");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        jsb.reflection.callStaticMethod(packageUri + "/utils/LocationManager", "clearCurLocation", "()V");
    }
};

/**
 * 取得定位经纬度
 * @returns {String} 经纬度(String,String)
 */
LocationUtils.getCurLocation = function () {
    if (window.inReview) return;
    if (cc.sys.os == cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod("LocationManager", "getCurLocation");
    } else if (cc.sys.os == cc.sys.OS_ANDROID) {
        return jsb.reflection.callStaticMethod(packageUri + "/utils/LocationManager", "getCurLocation", "()Ljava/lang/String;");
    }
};

/**
 * 获得具体地址信息
 * @param {Function} cb 返回处理
 */
LocationUtils.getCurLocationInfo = function (cb) {
    if (window.inReview) return;
    if (gameData.location) {
        var coordtype = 'wgs84ll';
        if (cc.sys.os == cc.sys.OS_IOS) {
            coordtype = 'wgs84ll';
        } else {
            coordtype = 'bd09ll';
        }
        NetUtils.httpGet('http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&coordtype=' + coordtype + '&location=' + gameData.location + '&output=json&pois=0&ak=WIVhGkuCRHrD57PnqK3hqZYpMjgavx9p',
            function (str) {
                str = str.substring(29, str.length - 1);
                var jsonData = JSON.parse(str);
                var status = jsonData.status;
                if (status == 0) {
                    cb(jsonData.result['formatted_address'], jsonData.result.location['lng'], jsonData.result.location['lat']);
                } else {
                    // alert1("失败, 请检查网络连接");
                }
            }, function () {

            }, {
                'Accept-Encoding': 'deflate'
            });
    }
};

/**
 * approx distance between two points on earth ellipsoid
 * @param lat1
 * @param lng1
 * @param lat2
 * @param lng2
 * @returns {Number} distance
 */
LocationUtils.getFlatternDistance = function (lat1, lng1, lat2, lng2) {
    lat1 = parseFloat(lat1);
    lng1 = parseFloat(lng1);
    lat2 = parseFloat(lat2);
    lng2 = parseFloat(lng2);
    var f = getRad((lat1 + lat2) / 2);
    var g = getRad((lat1 - lat2) / 2);
    var l = getRad((lng1 - lng2) / 2);

    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);

    var s, c, w, r, d, h1, h2;
    var a = EARTH_RADIUS;
    var fl = 1 / 298.257;

    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;

    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;

    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    var ret = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    return _.isNaN(ret) ? 0 : ret.toFixed(1);
};
