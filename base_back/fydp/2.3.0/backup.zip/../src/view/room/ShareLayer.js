/**
 * Created by zhangluxin on 16/8/22.
 */
(function () {
    var exports = this;

    var $ = null;

    var ShareLayer = cc.Layer.extend({
        ctor: function () {
            var that = this;
            this._super();

            var scene = ccs.load(res.ShareLayer_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            popShowAni($('root.main'));

            TouchUtils.setOnclickListener($('root.main.bg.share_friend'), function () {
                if (cc.sys.isNative) {
                    WXUtils.shareUrl("http://www.yayayouxi.com/fydp/", "【风云全民斗牌】",
                        "全民斗牌--风云邀您来斗牌，碰胡拼十任您挑，日进斗金不是梦，盆满钵盈笑开怀！", 0, getCurTimestamp() + gameData.uid);
                }
            });
            TouchUtils.setOnclickListener($('root.main.bg.share_round'), function () {
                if (cc.sys.isNative) {
                    WXUtils.shareUrl("http://www.yayayouxi.com/fydp/", "风云斗牌--风云邀您来斗牌，碰胡拼十任您挑，日进斗金不是梦，盆满钵盈笑开怀！", "", 1, getCurTimestamp() + gameData.uid);
                }
            });

            TouchUtils.setOnclickListener($('root.main.bg.share_xianLIao'), function () {
                if(getNativeVersion() < "2.2.0"){
                    alert1('请先升级最新版本');
                    return;
                }
                if (cc.sys.isNative) {
                    XianLiaoUtils.shareGame("99999", "全民风云斗牌邀您来斗牌，碰胡拼十任您挑，日进斗金不是梦，盆满钵盈笑开怀！", "全民风云斗牌邀您来斗牌，碰胡拼十任您挑，日进斗金不是梦，盆满钵盈笑开怀", 0, getCurTimestamp() + gameData.uid);
                }
            });

            $('root').addTouchEventListener(function (sender, type) {
                if (type == ccui.Widget.TOUCH_ENDED) {
                    popHideAni($('root.main'), function(){
                        that.removeFromParent(true);
                    });
                }
            });
            return true;
        },
        waitResult: function () {
            var that = this;
            // cc.sys.localStorage.removeItem(gameData.uid + "_lastShareDay");
            var lastShareDay = cc.sys.localStorage.getItem(gameData.uid + "_lastShareDay") || null;
            // 不是今天就行
            if (new Date().getDate() != lastShareDay) {
                var sch = setInterval(function () {
                    var result = getTransResult(gameData.uid);
                    if (result) {
                        clearInterval(sch);
                        if (result == 'ok') {
                            var data = {
                                playerid: gameData.uid,
                                area: 'hn',
                                timestamp: getCurTimestamp(),
                                appid: gameData.appId,
                                type: 0
                            };
                            data.sign = Crypto.MD5(data.appid + data.area + data.playerid + data.timestamp + data.type + FANGKA_KEY);
                            httpPost(FENXIANG_URL, data,
                                function (response) {
                                    if (response.result_code == 0) {
                                        cc.sys.localStorage.setItem(gameData.uid + "_lastShareDay", new Date().getDate());
                                        HUD.showMessageBox('提示', '分享成功，获得一张房卡奖励！退出重新登录可看到房卡更新。', function(){}, true);
                                        that.tip.setString('您今日已经分享过朋友圈了');
                                    }
                                }, function () {
                                    HUD.showMessageBox('提示', '网络请求失败，请检查网络', function(){}, true);
                                }
                            );
                        }
                    }
                }, 1000);

            }
        }
    });

    exports.ShareLayer = ShareLayer;
})(window);
