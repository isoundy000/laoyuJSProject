'use strict';
(function (exports) {
    var $ = null;

    var RoomQuit = cc.Layer.extend({
        getRootNode: function () {
            return this.getChildByName("Scene");
        },

        ctor: function () {
            this._super();
            var that = this;
            var scene = ccs.load(res.PhzRoomQuit_json, "res/");
            this.addChild(scene.node);

            this.isJiesanFinish = false;

            $ = create$(this.getRootNode());

            this.bt1 = $("root.btn_confirm");
            TouchUtils.setOnclickListener(this.bt1, function () {
                var isDone = network.wsData("Vote/quit/1/0/0");
                that.isVote = true;
                that.updateBT();
            });
            this.bt2 = $("root.btn_cancel");
            TouchUtils.setOnclickListener(this.bt2, function () {
                var isDone = network.wsData("Vote/quit/2/0/0");
                that.isVote = true;
                that.updateBT();
            });

            this.t0 = $("root.t0");
            this.txtTime2 = $("root.txtTime2");

            this.result = $("root.result");
            this.btn_ok = $("root.btn_ok");
            this.result.setVisible(false);
            this.btn_ok.setVisible(false);

            mRoom.isPause = true;
            this.timeLeft = 90;
            this.txtTime2.setString(this.getTimeGeshi());
            this.schedule(this.onTimer, 1);

            this.isVote = false;
            this.updateBT();

            cc.eventManager.addCustomListener(P.GS_Vote, this.onGameVote.bind(this));

            var pList = DD[T.PlayerList];

            var baseGapX = $('root.info1').getPositionX() - $('root.info0').getPositionX();

            for (var i = 0; i < 9; i++) {
                this['t' + (i+1)] = $("root.info" + i + ".status");
                this['statusicon' + (i+1)] = $("root.info" + i + ".statusicon");
                $('root.info' + i).setVisible(false);
                if ((i+1) <= pList.length) {
                    $('root.info' + i).setVisible(true);
                    $('root.info' + i).setPositionX(1280 / 2 - (pList.length / 2 - i - 0.5) * baseGapX);

                    var player = pList[i];
                    //头像
                    var avator = $("root.info" + (i) + ".head");
                    var url = decodeURIComponent(player.HeadIMGURL);
                    if (url == undefined || (url.length == 0)) url = res.defaultHead;
                    loadImageToSprite(url, avator);//头像
                }
            }
            return true;
        },

        updateBT: function () {
            this.bt1.setVisible(!this.isVote);
            this.bt2.setVisible(!this.isVote);
        },
        getTimeGeshi: function () {
            // var showtimeMinute = Math.floor(this.timeLeft / 60);
            // var showtimeSecond = this.timeLeft % 60;
            // if(showtimeSecond < 10){
            //     showtimeSecond = "0" + showtimeSecond;
            // }
            // return "(00:0"+showtimeMinute+":"+showtimeSecond+")";

            return "剩余时间：" + this.timeLeft;
        },
        onTimer: function (dt) {
            this.timeLeft -= 1;
            if (this.timeLeft <= 0) {
                this.timeLeft = 0;
                if (this.isVote == false) {
                    this.isVote = true;
                    var isDone = network.wsData("Vote/quit/2/0/0");
                }
            }
            this.txtTime2.setString(this.getTimeGeshi());
        },

        onGameVote: function (event) {
            //出牌
            var data = event.getUserData();
            if (data.Content){
                var p = data.Content.split("/");
                if(this.isJiesanFinish && p[3] == 1){
                    this.setData(data.Content, true);
                }else {
                    this.setData(data.Content, false);
                }
            }
        },

        setData: function (data, isCreate, parent) {
            var that = this;
            if (parent) {
                this.parentlayer = parent;
            }
            var p = data.split("/");

            var userId = parseInt(p[0]);
            var vote = parseInt(p[3]);

            if (isCreate == true) {
                this.result.setVisible(false);
                this.bt1.setVisible(true);
                this.bt2.setVisible(true);
                this.txtTime2.setVisible(true);
                this.btn_ok.setVisible(false);
                this.players = {};

                var pList = DD[T.PlayerList];
                for (var i = 0; i < pList.length; i++) {
                    var player = pList[i];

                    var info = {};
                    info.id = player.ID;
                    info.name = player.NickName;
                    info.vote = 0;
                    var txt = this["t" + (i + 1)];
                    var icon = this["statusicon" + (i + 1)];
                    info.txt = txt;
                    info.icon = icon;
                    txt.setString("未选择");
                    icon.setTexture(res.roomjiesan_wait_png);
                    this.players[info.id] = info;

                    if (info.id == userId) {
                        this.t0.setString("玩家［" + ellipsisStr(info.name, 6) + "］申请解散房间，请问是否同意？");
                        txt.setString("已同意");
                        icon.setTexture(res.roomjiesan_ok_png);
                        info.vote = 1;
                    }
                }

                if (userId == gameData.uid) {
                    this.isVote = true;
                    this.updateBT();
                }
            } else {
                var info = this.players[userId];
                var txt = info.txt;
                var icon = info.icon;
                info.vote = vote;
                if (info.vote == 1) {
                    txt.setString("已同意");
                    icon.setTexture(res.roomjiesan_ok_png);
                } else if (info.vote == 2) {
                    txt.setString("已拒绝");
                    icon.setTexture(res.roomjiesan_no_png);
                }
            }

            var acceptCount = 0;
            var rejectCount = 0;
            for (var key in this.players) {
                var info = this.players[key];

                if (info.vote == 1) {
                    acceptCount++;
                } else if (info.vote == 2) {
                    rejectCount++;
                }
            }

            if (acceptCount >= mRoom.getPlayerNum()) {
                this.result.setVisible(true);
                this.result.setString("投票结果为: 解散房间");
                this.isJiesanFinish = true;
                this.btn_ok.setVisible(true);
                TouchUtils.setOnclickListener(this.btn_ok, function () {
                    if (that.parentlayer) {
                        that.parentlayer.showRoomClean();
                    }
                    that.removeFromParent();
                });
                this.bt1.setVisible(false);
                this.bt2.setVisible(false);
                this.txtTime2.setVisible(false);
            } else if (rejectCount >= 1) {
                this.result.setVisible(true);
                this.result.setString("投票结果为: 不解散房间");
                this.isJiesanFinish = true;
                this.btn_ok.setVisible(true);
                TouchUtils.setOnclickListener(this.btn_ok, function () {
                    that.removeFromParent();
                    mRoom.isPause = false;
                });
                this.bt1.setVisible(false);
                this.bt2.setVisible(false);
                this.txtTime2.setVisible(false);
            }else{
                this.isJiesanFinish = false;
            }
        },
    });
    exports.RoomQuit = RoomQuit;
})(window);
