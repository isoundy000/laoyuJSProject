'use strict';
var RoomCleanFpf = {
    init:function () {
        var that = this;
        this.bt1 = getUI(this, "bt1");
        this.bt1.addTouchEventListener(this.onShareWx, this);
        this.close = getUI(this, "close");

        this.title = getUI(this, "title");
        this.txtTime = getUI(this, "txtTime");
        this.txtRoomId = getUI(this, "txtRoomId");
        this.txtRounds = getUI(this, "txtRounds");
        this.title.setString(mRoom.getWanfaName(mRoom.wanfatype) + "--牌局结束");

        playEffect('yin_win');
        mRoom.isClean = true;

        //关闭按钮 5秒后 才可以点击
        this.leftSecond = 3;
        this.closelabel = getUI(this.close, "closelabel");
        that.closelabel.setString("关闭");
        TouchUtils.setOnclickListener(that.close, function (node) {
            mRoom.isClean = false;
            //cc.eventManager.removeAllListeners(););
            DC.closeByClient = true;
            //DC.socket.close();
            clearGameMWRoomId();
            HUD.showScene(HUD_LIST.Home, that);
        });


        // TouchFilter.grayScale(this.close);
        // this.schedule(function () {
        //     that.leftSecond--;
        //     if(that.leftSecond == 0){
        //         TouchFilter.remove(that.close);
        //         that.closelabel.setString("关闭");
        //         TouchUtils.setOnclickListener(that.close, function (node) {
        //             if(that.leftSecond > 0) return;
        //             mRoom.isClean = false;
        //             //cc.eventManager.removeAllListeners(););
        //             DC.closeByClient = true;
        //             DC.socket.close();
        //             HUD.showScene(HUD_LIST.Home, that);
        //         });
        //     }else if(that.leftSecond > 0){
        //         that.closelabel.setString(that.leftSecond + "秒后关闭");
        //     }
        // }, 1);

        return true;
    },

    setRoom:function(resultlayer, gameOverData){
        this.gameOverData = gameOverData;
        this.setData();
    },
    setData:function(){
        //格式化时间
        this.txtTime.setString(this.gameOverData.EndTime);
        this.txtRoomId.setString("房间号:"+this.gameOverData.RoomID || '');
        this.txtRounds.setString("局数:"+this.gameOverData.CurrentRound + "局");

        var maxScore = -100;
        if (this.gameOverData.Users[0].Score == 0
            && this.gameOverData.Users[1].Score == 0
            && this.gameOverData.Users[2].Score == 0){
            maxScore = 9999;//都是0,没有赢家
        }else{
            for(var s = 0; s < this.gameOverData.Users.length; s++){
                var score = this.gameOverData.Users[s].Score;
                if(score > maxScore){
                    maxScore = score;
                }
            }
        }

        var pList = this.gameOverData.Users;
        for(var i=0;i<pList.length;i++){
            var player = pList[i];

            var info = getUI(this, "info" + (i+1));
            var name = getUI(info, "name");
            var id = getUI(info, "id");
            var score = getUI(info, "score");
            var winner = getUI(info, "winner");
            var zn = getUI(info, "zn");
            var zndf = getUI(info, "zndf");
            var hx = getUI(info, "hx");
            var hxdf = getUI(info, "hxdf");

            name.setString(ellipsisStr(player.UserName, 7) || '');
            id.setString(player.UserID || '');
            score.setString(player.Score || '0');
            zn.setString(player.ZhuaNiao || '0');
            zndf.setString(player.ZhuaNiaoFen || '0');
            hx.setString(player.Huxi || '0');
            hxdf.setString(player.HuxiFen || '0');
            //头像
            var avator = getUI(this, "avator" + (i+1));
            var url = decodeURIComponent(player.HeadImgURL);
            if (url == undefined || (url.length == 0)) url = res.defaultHead;
            loadImageToSprite(url, avator);//头像

            if(player.Score >= maxScore){
                winner.setVisible(true);
            }else{
                winner.setVisible(false);
            }
        }
    },
    onOk: function (sender, type) {
        var ok = touch_process(sender, type);
        if(ok){

        }
    },
    onShareWx:function(sender, type){
        var that = this;
        var ok = touch_process(sender, type);
        if(ok){
            //先隐藏按钮  在现实
            that.bt1.setVisible(false);
            that.close.setVisible(false);
            that.scheduleOnce(function(){
                that.bt1.setVisible(true);
                that.close.setVisible(true);
            }, 1);
            if (!cc.sys.isNative)
                return;
            WXUtils.captureAndShareToWX(that);
        }
    }
};