
(function () {
    var exports = this;

    var $ = null;

    var Loading = cc.Layer.extend({
        ctor: function (content) {
            this._super();

            var scene = ccs.load(res.Loading_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            var anim = playAnimScene(this, res.PhzLoading_json, cc.winSize.width/2, cc.winSize.height/2,true);
            anim.setScale(1);

            return true;
        },
        dismiss: function () {
            this.removeFromParent(true);
        },
        setContent: function (content) {
            // $('root.content').setString(content || "游戏加载中...");
        }
    });

    exports.Loading = Loading;
})(window);
