(function (exports) {

    var $ = null;
    var room = null;
    var huInfo = null;
    var gameOverData = null;
    var isReplay = null;

    var nCombos = null;
    var roomid;
    var time;
    var twin = null;

    var n0;
    var n1;
    var n2;
    var n3;
    var nArr = [];

    var nHu = null;
    var nCards0;
    var nCards1;
    var nCards2;
    var nCards3;
    var nCardArr = [];

    var index = 0;

    var GameResultLayer = cc.Layer.extend({


        ctor: function (room1, huInfo1, gameOverData1, isReplay1) {
            var that = this;
            this._super();

            room = room1;
            huInfo = huInfo1;
            gameOverData = gameOverData1;
            isReplay = isReplay1;


            var scene = ccs.load(res.GameResultLayer_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));


            TouchUtils.setOnclickListener($("close"), this.onClose);

            roomid = $("roomid");
            time = $("time");

            nCombos = $("nCombos");
            twin = $("twin");

            n0 = $("nContent.n0");
            n1 = $("nContent.n1");
            n2 = $("nContent.n2");
            n3 = $("nContent.n3");
            nArr = [];
            nArr.push(n0);
            nArr.push(n1);
            nArr.push(n2);
            nArr.push(n3);

            nHu = $("nContent.nHu");

            nCards0 = $("nContent.nCards0");
            nCards1 = $("nContent.nCards1");
            nCards2 = $("nContent.nCards2");
            nCards3 = $("nContent.nCards3");
            nCardArr = [];
            nCardArr.push(nCards0);
            nCardArr.push(nCards1);
            nCardArr.push(nCards2);
            nCardArr.push(nCards3);

            //关闭按钮 5秒后 才可以点击
            this.leftSecond = 3;
        },

        setRoomInfo: function () {

            // console.log(huInfo);

            time.setString(gameOverData.EndTime);
            roomid.setString("房号:" + mRoom.roomId);
            if (!mRoom.zhongzhuang) {
                $("room_type1").setString("中庄");
            } else {
                $("room_type1").setString("连中");
            }
            // $("room_type1").setString();
            if (isReplay) {
                $("room_jushu").setString("");
            } else {
                $("room_jushu").setString("局数:" + mRoom.getRound(mRoom.curRound));
            }

            if (isReplay) {
                $("close").setVisible(true);
            } else {
                $("close").setVisible(false);
            }

            setData();
        },
        onClose: function () {
            if (mRoom.isReplay) {
                mRoom.isReplay = false;
                clearInterval(mRoom.interval);
                clearGameMWRoomId();
                HUD.showScene(HUD_LIST.Home);
            } else {
                room.showRoomClean();
                room.showReadyJiesuan(true);
                this.removeFromParent();
            }
        }


    });

    var setData = function () {
        index = 0;

        var titleImg = "";
        var isHuang = false;
        playEffect('getw');
        if (huInfo != null) {
            this.winCards = [];
            var comListArray = [];
            if (huInfo.openList) {
                for (var i = 0; i < huInfo.openList.length; i++) {
                    comListArray.push(huInfo.openList[i])
                }
            }
            if (huInfo.kanList) {
                for (var i = 0; i < huInfo.kanList.length; i++) {
                    comListArray.push(huInfo.kanList[i])
                }
            }
            if (huInfo.huList) {
                if (mRoom.wanfatype == mRoom.WEIMAQUE) {
                    for (var s = 0; s < huInfo.huList.length; s++) {
                        //偎麻雀
                        var onelist = huInfo.huList[s];
                        if (onelist.typ == 12 && onelist.cards.length > 4) {
                            var t = {typ: 12};
                            t.cards = [];
                            for (var i = 0; i < onelist.cards.length; i++) {
                                if (onelist.cards[i]) {
                                    t['cards'].push(onelist.cards[i]);
                                    if (t.cards.length == 3 || i == onelist.cards.length - 1) {
                                        comListArray.push(t);
                                        t = {typ: 12};
                                        t['cards'] = [];
                                    }
                                }
                            }
                        } else {
                            comListArray.push(onelist);
                        }
                    }
                } else {
                    for (var i = 0; i < huInfo.huList.length; i++) {
                        comListArray.push(huInfo.huList[i])
                    }
                }
            }
            // addComboList(comListArray, winCards);

            if (this.winCards && this.winCards.length > 0) {
                for (var s = this.winCards.length - 1; s >= 0; s--) {
                    var card = this.winCards[s];
                    if (gameOverData.ByCard && gameOverData.ByCard == card.data) {
                        var huicon = new cc.Sprite(res.back_png);
                        huicon.setAnchorPoint(cc.p(0.5, 0.5));
                        huicon.setPosition(cc.p(card.getContentSize().width / 2, card.getContentSize().height / 2));
                        huicon.setOpacity(160);
                        card.addChild(huicon, 2);
                        break;
                    }
                }
            }
            if (gameOverData.Winner == gameData.uid) {
                titleImg = "twin";
            } else {
                titleImg = "tlose";
            }
        } else {
            titleImg = "thuang";
            isHuang = true;
        }

        twin.setTexture(res["result_" + titleImg + "_png"]);

        if (mRoom.getPlayerNum() == 3) {
            for (var i = 0; i < 3; i++) {
                var n = this["n" + i];
                n.setPosition(cc.p(-540, 385 - i * 170));
                n.setScale(0.95);
            }
            n3.setVisible(false);
        }
        for (var i = 0; i < gameOverData.Users.length; i++) {
            var gr = gameOverData.Users[i];
            setPlayerInfo(i, gr, gameOverData.Winner, isHuang);
        }

        if (mRoom.wanfatype == mRoom.LEIYANG) {
            //耒阳
            // this.kuang2_ly.setVisible(true);
            // this.kuang2.setVisible(false);
            // this.kuang2_sy.setVisible(false);
            // this.zhx_ly.setVisible(true);
            // this.thx_ly.setVisible(true);
            // this.zhx_ly.setString(gameOverData.WinnerXi);
            for (var i = 0; i < gameOverData.Users.length; i++) {
                var gr = gameOverData.Users[i];
                var pos = mRoom.getUserPosIndex(gr.UserID);
                // var name = $(this.kuang2_ly, "name_" + (pos));
                // var scoreS = $(this.kuang2_ly, "score_" + (pos));
                // var scoreB = $(this.kuang2_ly, "score_b" + (pos));
                // name.setString(ellipsisStr(gr.UserName, 7));
                // scoreS.setString(gr.SmallTiLong || 0);
                // scoreB.setString(gr.BigTiLong || 0);
            }
            for (var i = 0; i < 3; i++) {
                var n = nArr[i];
                var t = $("nContent.n" + i + ".t" + i);
                t.setString("得分:");
            }
        } else if (mRoom.wanfatype == mRoom.SHAOYANGBOPI) {
            //邵阳剥皮
            // this.kuang2_ly.setVisible(false);
            // this.kuang2.setVisible(false);
            // this.kuang2_sy.setVisible(true);
            // this.zhx_ly.setVisible(false);
            // this.thx_ly.setVisible(false);
            for (var i = 0; i < gameOverData.Users.length; i++) {
                var gr = gameOverData.Users[i];
                var pos = mRoom.getUserPosIndex(gr.UserID);
                // var name = $(this.kuang2_sy, "name" + (pos));
                // var scoreS = $(this.kuang2_sy, "score" + (pos));
                name.setString(ellipsisStr(gr.UserName, 7));
                var score = mRoom.scoreInfo[gr.UserID] || 0;
                scoreS.setString(score || 0);
            }
        } else if (mRoom.wanfatype == mRoom.YOUXIAN) {
            // this.kuang2_ly.setVisible(false);
            // this.kuang2.setVisible(false);
            // this.kuang2_sy.setVisible(false);
            // this.zhx_ly.setVisible(false);
            // this.thx_ly.setVisible(false);
        } else if (mRoom.wanfatype == mRoom.GUILIN) {
            // console.log(gameOverData);
            // this.kuang2_ly.setVisible(false);
            // this.kuang2.setVisible(false);
            // this.kuang2_sy.setVisible(false);
            // this.thx_ly.setVisible(true);
            // this.thx_ly.setTexture("res/image/ui/result/thx.png");
            // this.zhx_ly.setVisible(true);
            // this.zhx_ly.setString(gameOverData.WinnerXi);
            if (gameOverData.XingCard && gameOverData.XingCard > 0) {
                // // this.xingcard.setVisible(true);
                // var cardimg = "res/image/ui/card/dx" + (gameOverData.XingCard) + ".png";
                // if (gameOverData.XingCard > 10)
                //     cardimg = "res/image/ui/card/dd" + (gameOverData.XingCard - 10) + ".png";
                // var action = cc.sequence(
                //     cc.scaleTo(0.5, -0.8, 0.8)
                //     , cc.callFunc(function (card) {
                //         card.setTexture(cardimg);
                //         card.setFlippedX(true);
                //     })
                // );
                // this.xingcard.runAction(action);
                //
                // this.xingcount.setVisible(true);
                // this.xingcount.setString(gameOverData.XingCount + "醒");
            }
        } else {
            // this.txt1 = $(this.kuang2, "txt1");
            // this.txt2 = $(this.kuang2, "txt2");
            // this.txt3 = $(this.kuang2, "txt3");
            // this.t1 = $(this.kuang2, "t1");
            // this.t2 = $(this.kuang2, "t2");
            // this.t3 = $(this.kuang2, "t3");

            // this.kuang2_ly.setVisible(false);
            // this.kuang2.setVisible(true);
            // this.kuang2_sy.setVisible(false);
            // this.zhx_ly.setVisible(false);
            // this.thx_ly.setVisible(false);
            if (mRoom.wanfatype == mRoom.FANGPAOFA ||
                mRoom.wanfatype == mRoom.XIANGXIANG) {
                // this.t1.setTexture("res/image/ui/result/hx.png");
                // this.t2.setTexture("res/image/ui/result/tfan.png");
                // this.t3.setTexture("res/image/ui/result/thx.png");
                // this.txt1.setString(this.gameOverData.WinnerXi);
                // this.txt2.setString(this.gameOverData.WinnerFan);
                // this.txt3.setString(this.gameOverData.WinnerJi);
            } else if (mRoom.wanfatype == mRoom.CHENZHOU) {
                //tunshu
                // this.t1.setTexture("res/image/ui/result/hx.png");
                // this.t2.setTexture("res/image/ui/result/tfan.png");
                // this.t3.setTexture("res/image/ui/result/tunshu.png");
                // this.txt1.setString(this.gameOverData.WinnerXi);
                // this.txt2.setString(this.gameOverData.WinnerFan);
                // this.txt3.setString(this.gameOverData.WinnerJi);
            } else if (mRoom.wanfatype == mRoom.HENGDONG) {
                //衡东  蚂蚁上树只显示胡息
                // this.t1.setTexture("res/image/ui/result/hx.png");
                // this.t2.setTexture("res/image/ui/result/tfan.png");
                // this.t3.setTexture("res/image/ui/result/tji.png");
                // this.txt1.setString(this.gameOverData.WinnerXi);
                // this.txt2.setString(this.gameOverData.WinnerFan);
                // this.txt3.setString(this.gameOverData.WinnerJi);
                // this.t2.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                // this.t3.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                // this.txt2.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                // this.txt3.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
            } else if (mRoom.wanfatype == mRoom.WEIMAQUE) {
                // this.t1.setTexture("res/image/ui/result/tyingxi.png");
                // this.t2.setTexture("res/image/ui/result/tzongxi.png");
                // this.t3.setVisible(false);
                // this.txt1.setString(this.gameOverData.WinnerXi);
                // this.txt2.setString(this.gameOverData.WinnerJi);
                // this.txt3.setVisible(false);
            } else {
                // //全名堂   胡   番数  级数
                // this.t1.setTexture("res/image/ui/result/hx.png");
                // this.t2.setTexture("res/image/ui/result/tfan.png");
                // this.t3.setTexture("res/image/ui/result/tji.png");
                // this.txt1.setString(this.gameOverData.WinnerXi);
                // this.txt2.setString(this.gameOverData.WinnerFan);
                // this.txt3.setString(this.gameOverData.WinnerJi);
            }
            //长沙显示分数,不是胡息
            for (var i = 0; i < 3; i++) {
                var n = this["n" + i];
                var t = $("nContent.n" + i + ".t" + i);
                t.setString("分数:");
            }
        }

        //setHuInfo(gameOverData.FanFlag, gameOverData.FanFlag2);

        // var kuang3 = $('kuang3');
        // var kuang4 = $('kuang4');
        if (mRoom.wanfatype == mRoom.YOUXIAN || mRoom.wanfatype == mRoom.GUILIN) {
            // kuang3.setVisible(false);
            // kuang4.setVisible(true);
            // for (var i = 0; i < this.gameOverData.LeftCards.length; i++) {
            //     var card = HUD.showLayer(HUD_LIST.Card, kuang4);
            //     card.setData(this.gameOverData.LeftCards[i], null, 2);
            //     card.setPosition(cc.p(-10 + 52 * (i % 15), 30 - 50 * (Math.floor(i / 15))));
            // }
        } else {
            // kuang3.setVisible(true);
            // kuang4.setVisible(false);
            // for (var i = 0; i < this.gameOverData.LeftCards.length; i++) {
            //     var card = HUD.showLayer(HUD_LIST.Card, kuang3);
            //     card.setData(this.gameOverData.LeftCards[i], null, 2);
            //     card.setPosition(cc.p(-10 + 44 * (i % 12), 30 - 50 * (Math.floor(i / 12))));
            // }
        }
    };

    var setPlayerInfo = function (index1, gr, winner, isHuang) {
        var pos = mRoom.getUserPosIndex(gr.UserID);
        //var n = nArr[pos];
        var txtUserName = $("nContent.n" + pos + ".txtUserName");
        var txtUserId = $("nContent.n" + pos + ".txtUserId");
        var txtScore = $("nContent.n" + pos + ".txtScore");
        var img_score = $("nContent.n" + pos + ".img_score");
        var dianpao = $("nContent.n" + pos + ".dianpao");
        // var huPaiLeiXing = $("nContent.n" + pos + ".huPaiLeiXing");
        var t = $("nContent.n" + pos + ".t" + pos);
        var dianpao_bg = $("nContent.n" + pos + ".dianpao_bg");
        dianpao_bg.setVisible(false);

        if (mRoom.wanfatype == mRoom.GUILIN) {
            t.setString("总舵数:");
        }
        //点炮
        // console.log(this.gameOverData);
        if (gameOverData.ByWho && gameOverData.ByWho != null && gameOverData.ByWho == gr.UserID) {
            dianpao.setVisible(true);
            dianpao_bg.setVisible(false);
        }
        else{
            dianpao.setVisible(false);
            dianpao_bg.setVisible(false);
        }
        //赢家
        $("nContent.n" + pos + ".bg").setVisible(false);
        if (gameOverData.Winner && gameOverData.Winner != null && gameOverData.Winner == gr.UserID) {
            dianpao.setVisible(true);
            dianpao_bg.setVisible(false);
            $("nContent.n" + pos + ".bglose").setVisible(false);
            $("nContent.n" + pos + ".bg").setVisible(true);

            var img = "";
            if (gameOverData.HuType >= 0) {
                if (gameOverData.HuType == 0x200) { //调将胡
                    img = "diaojiaohu";
                } else if (gameOverData.HuType == 0x40) { //跑胡
                    img = "paohu";
                } else if (gameOverData.HuType == 0x20) { //平胡
                    img = "pinghu";
                } else if (gameOverData.HuType == 0x80) { //碰胡
                    img = "penghu";
                } else if (gameOverData.HuType == 0x8) { //扫胡,畏
                    img = "saohu";
                } else if (gameOverData.HuType == 0x4) { //提胡
                    img = "tihu";
                } else if (gameOverData.HuType == 0x1) {  //天胡
                    img = "tianhu";
                } else if (gameOverData.HuType == 0x2) {  //地胡
                    img = "dihu";
                } else if (gameOverData.HuType == 0x100) {  //吃胡
                    img = "pinghu";
                } else {
                    img = "pinghu"
                }
                // console.log(gameOverData + ":" + img);
                // if (img != ""){
                //     dianpao.setTexture("res/image/ui/result/" + img + ".png");
                // } else {
                if (gameOverData.FanRemark != "") {
                    if (gameOverData.FanRemark == "7对") {
                        img = "xiaoqidui";
                    } else if (gameOverData.FanRemark == "五福连胡") {
                        img = "wuhulianhu";
                    } else if (gameOverData.FanRemark == "双龙") {
                        img = "shuanglong";
                    } else if (gameOverData.FanRemark == "碰三大连胡") {
                        img = "pengsandalianhu";
                    } else if (gameOverData.FanRemark == "碰四清连胡") {
                        img = "pengsiqinglianhu";
                    } else if (gameOverData.FanRemark == "碰五福连胡") {
                        img = "pengwuhulianhu";
                    } else if (gameOverData.FanRemark == "扫三大连胡") {
                        img = "saosandalianhu";
                    } else if (gameOverData.FanRemark == "扫四清连胡") {
                        img = "saosiqinglianhu";
                    } else if (gameOverData.FanRemark == "扫五福连胡") {
                        img = "saowufulianhu";
                    }

                }
                // else {
                //     dianpao.setTexture("res/image/ui/result/pinghu.png");
                // }
                // }
                //dianpao.setTexture("res/image/ui/result/" + img + ".png");
                dianpao.setTexture(res[img + "_png"]);


                // if(gameOverData.FanRemark != ""){
                //     dianpao.setVisible(false);
                //     // huPaiLeiXing.setVisible(false);
                //     // huPaiLeiXing.setString(gameOverData.FanRemark);
                // } else {
                //     dianpao.setVisible(true);
                //     // huPaiLeiXing.setVisible(false);
                // }
            } else {
                dianpao.setVisible(false);
                dianpao_bg.setVisible(false);
            }
        }

        //头像
        var avatorbg = $("nContent.n" + pos + ".head");
        var avator = $("nContent.n" + pos + ".head._head");
        var url = (mRoom.getUserByUserId(gr.UserID) == null ? null : mRoom.getUserByUserId(gr.UserID).HeadIMGURL);
        url = decodeURIComponent(url);
        if (url == undefined || (url.length == 0)) url = res.defaultHead;
        loadImageToSprite(url, avator);//头像

        //庄家头像，连庄
        if (gameOverData.Banker == gr.UserID) {  //设置该玩家的庄

            var zhuang = null;
            var offset = 10;
            if (!mRoom.zhongzhuang) {
                zhuang = new cc.Sprite(res.zhongzhuang_png);
                zhuang.setPosition(-avatorbg.getContentSize().width / 2 + offset, avatorbg.getContentSize().height / 2);
                //zhuang.setScale(1);
                avatorbg.addChild(zhuang);
            } else {
                if (!gameOverData.Lianzhuang) {
                    zhuang = new cc.Sprite(res.zhuang1_png);
                    // var _sizeInfo = zhuang.getContentSize();
                    zhuang.setPosition(-avatorbg.getContentSize().width / 2 + offset, avatorbg.getContentSize().height / 2);
                    //zhuang.setScale(1);
                    avatorbg.addChild(zhuang);
                } else {
                    if (gameOverData.Lianzhuang > 9) {
                        gameOverData.Lianzhuang = 0;
                    }
                    zhuang = new cc.Sprite(res['zhuang' + (gameOverData.Lianzhuang) + '_png']);
                    zhuang.setPosition(-avatorbg.getContentSize().width / 2 + offset, avatorbg.getContentSize().height / 2);
                    //zhuang.setScale(1);
                    avatorbg.addChild(zhuang);
                }
            }

            //荒 庄
            if (isHuang) {
                dianpao.setTexture(res.chouzhuang_png);
                dianpao.setVisible(true);
            }
        }

        txtUserName.setString(ellipsisStr(gr.UserName, 7));  //修改名字为七个字
        txtUserId.setString("ID:" + gr.UserID);
        if (gr.Result) {
            if (gr.Result >= 0) {
                txtScore.setFntFile(res.jiafenhuang_fnt);
                txtScore.setString("+" + gr.Result);
                img_score.setVisible(true);
                img_score.setTexture(res.icon_jiafenhuang_png);
            } else {
                txtScore.setFntFile(res.koufen_hong_fnt);
                txtScore.setString(gr.Result);
                img_score.setVisible(true);
                img_score.setTexture(res.icon_koufen_hong_png);
            }
        } else {
            txtScore.setFntFile(res.jiafenhuang_fnt);
            img_score.setVisible(false);
            txtScore.setString("0");
        }
        var score = mRoom.scoreInfo[gr.UserID] || 0;
        // mRoom.scoreInfo[gr.UserID] = score + gr.Result + 0;
        mRoom.scoreInfo[gr.UserID] = gr.Score;

        // var win = $("nContent.n" + pos + ".win");
        // if (gr.Result > 0) {
        //     win.setTexture('res/image/ui/result/win.png');
        // } else if (gr.Result == 0) {
        //     win.setTexture('res/image/ui/result/ping.png');
        // } else {
        //     win.setTexture('res/image/ui/result/lose.png');
        // }
        //显示得分
        room.updateScore(pos);

        //显示手牌
        // var cardList = mCard.getCardList(gr.AllCards.Hands);
        var cardsHand = gr.AllCards.Hands;
        //排序
        var newCardList = [[], [], [], [], [], [], [], [], [], [], []];
        var key = 0;

        if (cardsHand) {
            for (var i = 0; i < cardsHand.length; i++) {
                var pai = cardsHand[i];
                if (cardsHand[i] > 10) {
                    newCardList[cardsHand[i] - 10].push(cardsHand[i]);
                }
            }
            for (var i = 0; i < cardsHand.length; i++) {
                var pai = cardsHand[i];
                if (cardsHand[i] <= 10) {
                    newCardList[cardsHand[i]].push(cardsHand[i]);
                }
            }
            //四个分成两列，即分成两个数组
            for (var i = 0; i < newCardList.length; i++) {
                var pai = newCardList[i];
                var arr = [];
                if (pai.length == 4) {
                    for (var j = 0; j < 2; j++) {
                        arr.push(pai[2]);
                        pai.pop();
                    }
                    newCardList.push(arr);
                }
            }
        }


        var cardList = newCardList;
        var isHasAdded = false;
        //var cardList = room.cardList;
        var cardScale = 0.44;  //小牌的缩放系数
        var cardBigScale = 0.52; //长牌的缩放系数
        var cardBigDx = 12;//调整x偏差为12，具体误差如何产生没有弄清楚
        var cardBigDy = 50;//调整y误差为50，具体误差如何产生没有弄清楚
        var cardChinkDx = 4;//牌之间的缝隙调整距离为4
        var cardChinkDy = 46;//摞牌调整缝隙距离为46
        var CardGroupDx = 20;//调整亮牌和胡牌间距为20
        var CardGroupMinDx = 10;//一句话之间的距离为10
        var length = 0;
        for (var i = 0; i < cardList.length; i++) {
            var cards = cardList[i];
            if (cards.length == 0) {
                continue;
            }
            length++;
            for (var j = cards.length - 1; j >= 0; j--) {
                var card = HUD.showLayer(HUD_LIST.Card, nCardArr[pos]);
                card.setData(cards[j], this);
                card.setRowColumn(j, i);
                card.setScale(cardScale);
                //ruru
                card.setPositionX((length - 1) * (room.cardSize.w - cardChinkDx) * cardScale);  //调整间距为4
                card.setPositionY(j * (room.cardSize.h - cardChinkDy) * cardScale);//摞牌调整上下误差为46
                var tag = (length - 1 + 1) * 100 + j + 1;
                card.setTag(tag);

                // if(gameOverData.HuType >= 256 && cards[j] == gameOverData.ByCard && !isHasAdded && gameOverData.Winner == gr.UserID){
                //     // console.log("::::::::::::::::::::::::::::::" + card);
                //     isHasAdded = true;
                //     var huicon = new cc.Sprite('res/image/ui/card/back.png');
                //     huicon.setAnchorPoint(cc.p(0.5, 0.5));
                //     huicon.setScaleY(2.9);
                //     huicon.setScaleX(2.5);
                //     huicon.setPosition(cc.p(card.getContentSize().width/2, card.getContentSize().height/2));
                //     huicon.setOpacity(160);
                //     card.addChild(huicon, 2);
                // }

            }
        }
        //var posLenX = (length - 1) * (room.cardSize.w * cardScale - 2) + 60;
        var posLenX = length * (room.cardSize.w - cardChinkDx) * cardScale + CardGroupDx;   //手牌和亮牌之间的距离是10
        //显示 碰杠跑扫
        //手牌到的位置为 之后开始放碰杠跑扫 cardList.length * (room.cardSize.w * cardScale - 2)
        var menziList = gr.AllCards.Menzi;

        if (menziList) {
            //吃 6张 9张拆分成
            // var menziList = [{Cards:[2,3,4,2,3,4,5,6,7,6,7,8],Type:"吃",Chi:3},{Cards:[5,5,5],Type:"碰",Chi:1112}];
            for (var i = 0; i < menziList.length; i++) {
                var cards = menziList[i];
                if (cards.Type == "吃") {
                    while (cards.Cards.length > 5) {
                        var arr = {};
                        arr.Cards = [];
                        for (var j = 0; j < 3; j++) {
                            arr.Cards.push(cards.Cards[3]);
                            cards.Cards.splice(3, 1);
                        }
                        arr.Type = "吃";
                        arr.Chi = cards.Chi;
                        menziList[menziList.length] = arr;
                    }
                }
            }
            for (var i = 0; i < menziList.length; i++) {
                var cards = menziList[i];
                var cardLen = cards.Cards.length;
                for (var j = 0; j < cards.Cards.length; j++) {
                    var card = HUD.showLayer(HUD_LIST.Card, nCardArr[pos]);
                    card.setData(cards.Cards[j], this, 1);
                    card.setScale(cardBigScale);
                    card.setRowColumn(j, 0);
                    //长牌的定位是有问题的，所以做了误差处理
                    card.setPositionX(posLenX + j * (room.cardBigSize.w - cardChinkDx) * cardBigScale - cardBigDx * cardBigScale);//调整x偏差为12，具体误差如何产生没有弄清楚
                    card.setPositionY(cardBigDy * cardBigScale);//调整y误差为50，具体误差如何产生没有弄清楚
                    var tag = (i + 1) * 1000 + j + 1;
                    card.setTag(tag);

                    // var isAddHuIcon = false;
                    //
                    // if(cards.Type == "碰" && gameOverData.HuType == 0x80 && cards.Cards[j] == gameOverData.ByCard){
                    //     isAddHuIcon = true;
                    // }
                    // else if( cards.Type == "偎" && gameOverData.HuType == 0x8 && cards.Cards[j] == gameOverData.ByCard ){
                    //     isAddHuIcon = true;
                    // }
                    // else if( cards.Type == "跑" && gameOverData.HuType == 0x40 && cards.Cards[j] == gameOverData.ByCard ){
                    //     isAddHuIcon = true;
                    // }
                    // else if( cards.Type == "提" && gameOverData.HuType == 0x4 && cards.Cards[j] == gameOverData.ByCard ){
                    //     isAddHuIcon = true;
                    // }
                    //
                    // if(gameOverData.Winner != gr.UserID){
                    //     isAddHuIcon = false;
                    // }
                    //
                    // if(isAddHuIcon && j == 0 && !isHasAdded && gameOverData.Winner == gr.UserID){
                    //     isHasAdded = true;
                    //     var huicon = new cc.Sprite('res/image/ui/card/backbig.png');
                    //     huicon.setAnchorPoint(cc.p(0.5, 0.5));
                    //     huicon.setPosition(cc.p(card.getContentSize().width/2, card.getContentSize().height/2));
                    //     huicon.setOpacity(160);
                    //     card.addChild(huicon, 2);
                    // }
                }

                // 操作类型
                var spriteType = null;
                if (cards.Type == "吃") {
                    spriteType = new cc.Sprite(res.u_chi_png);
                } else if (cards.Type == "提") {
                    spriteType = new cc.Sprite(res.u_ti_png);
                } else if (cards.Type == "跑") {
                    spriteType = new cc.Sprite(res.u_pao_png);
                } else if (cards.Type == "偎") {
                    spriteType = new cc.Sprite(res.u_sao_png);
                } else if (cards.Type == "臭偎") {
                    spriteType = new cc.Sprite(res.u_sao_png);
                } else if (cards.Type == "碰") {
                    spriteType = new cc.Sprite(res.u_peng_png);
                } else if (cards.Type == "坎") {
                    spriteType = new cc.Sprite(res.u_kan_png);
                } else if (cards.Type == "绞") {
                    spriteType = new cc.Sprite(res.u_chi_png);
                } else if (cards.Type == "一句话") {
                    spriteType = new cc.Sprite(res.u_chi_png);
                }
                //ruru
                spriteType.setPositionX(posLenX + room.cardBigSize.w * cardBigScale * cardLen * 0.5);
                spriteType.setPositionY((room.cardBigSize.h - 20) * cardBigScale);
                spriteType.setAnchorPoint(0.5, 0.5);
                nCardArr[pos].addChild(spriteType);


                posLenX = posLenX + (room.cardBigSize.w - cardChinkDx) * cardBigScale * cardLen + CardGroupMinDx;
            }
            posLenX = posLenX + CardGroupDx - CardGroupMinDx;
        }

        var cardHu = gameOverData.ByCard;
        // 最后一张是胡牌,放到最后
        if (gameOverData.Winner == gr.UserID) {
            if (!cardHu) {
                // console.log(cardHu);
                return;
            }
            var card = HUD.showLayer(HUD_LIST.Card, nCardArr[pos]);
            card.setData(cardHu, this, 1);
            card.setScale(cardBigScale);
            card.setRowColumn(1, 0);
            //ruru
            card.setPositionX(posLenX - cardBigDx * cardBigScale);//调整x偏差为12，具体误差如何产生没有弄清楚
            card.setPositionY(cardBigDy * cardBigScale);//调整y误差为50，具体误差如何产生没有弄清楚
            card.setTag(9299);
            if (gameOverData.ByWho && gameOverData.ByWho != null) {
                card.setMo(false);
            } else {
                card.setMo(true);
            }
        }
    };

    var setHuInfo = function (flag, flag2) {
        var index = 0;
        var imgs = ["h_hong2", "h_hei2", "h_zimo", "h_tian2", "h_di2", "h_yidian", "h_hw", "h_ddh", "h_wudh"];
        var fans = ["", "", "", "", "", "", "", "", ""];
        if (mRoom.isallmt == true) {  //全名堂
            var info = mCard.getHuCardCountInfo(huInfo);
            var big = info.big;
            var small = info.small;
            var red = info.red;

            imgs = ["h_hong2", "h_zdh", "h_jdh", "h_hw", "h_wh", "h_ddh", "h_big", "h_small",
                "h_hdh", "h_zimo", "h_tian2", "h_di2", "h_myjh"];
            //海底胡	玩家所胡的牌是墩中最后的一只牌（平胡加1番，名堂胡加2番）
            var isPingHu = true;
            for (var i = 0; i < imgs.length; i++) {
                var isOk = mAction.checkOpen(flag, 1 << i);
                if (isOk && i < 8) {
                    isPingHu = false;
                    break;
                }
            }
            var hdx_fan = 2;

            fans = ["", "", "", "", "", "", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.FANGPAOFA) {
            // 一点红 0x1 1
            // 自摸 0x2  2
            // 一块匾 0x4  4
            // 乌胡 0x8  8
            // 海底胡 0x10   16
            // 红胡 0x20   32
            // 卡胡 0x40   64
            // 天胡 0x80    128
            // 地胡 0x100   256
            // 10红 0x200 10红  512
            imgs = ["h_yidian", "h_zimo", "h_bian", "h_wh", "h_hdh", "h_hong2",
                "h_ka", "h_tian2", "h_di2", "h_shi"];
            fans = ['', '', '', '', '', '', '', '', '', ''];
        }
        //天地红黑  无全名堂
        if (mRoom.subWanfa != undefined && (mRoom.subWanfa == 'tiandihonghei' || mRoom.subWanfa == 'wumingtang')) {
            imgs = ["h_hong2", "h_hei2", "h_zimo", "h_tian2", "h_di2"];
            // fans = [2, 2, 1, 2, 2];
            fans = ["", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.LEIYANG) {
            // 1		2		4		8 		16		32     64   128     256
            // 红胡		黑胡		无胡		卡胡		天胡		举手   自摸   一点红  地胡
            imgs = ["h_hong2", "h_hei2", "h_wuh", "h_ka", "h_tian2", "h_jz", "h_zimo", "h_yidian", "h_di2"];
            fans = ["", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.CHANGSHA) {
            // 红胡		点胡		红乌		黑胡		天胡		地胡		对对胡		大胡		小胡
            // 1		2		4		8		16		32		64			128		256
            // 十红		一点红	十八小	十八大	二比		三比		四比		双飘		海底胡  自摸
            // 512		1024	2048	4096	8192	16384	32768	65536	131072  262144
            imgs = ["h_hong2", "h_dianh", "h_wh", "h_hei2", "h_tian2", "h_di2", "h_ddh", "h_dah", "h_xiaoh",
                "h_shi", "h_yidian", "h_small", "h_big", "h_ebh", "h_sbh", "h_sibh", "h_sph", "h_hdh", "h_zimo"];
            fans = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.SHAOYANG) {
            imgs = ["h_hong2", "h_hei2", "h_tian2", "h_di2"];
            fans = ["", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.SHAOYANGBOPI) {
            //天胡 地胡 自摸 中庄
            imgs = ["h_tian2", "h_di2", "h_zimo", "h_zhh"];
            fans = ["+10", "+10", "+10", ""];
        }
        if (mRoom.wanfatype == mRoom.HONGGUAIWAN) {
            //天湖	地胡		点胡		红胡		乌胡		碰碰胡		十八大		十六小		海底胡	自摸
            //1		2		4		8		16		 32			64			128			256		512
            imgs = ["h_tian2", "h_di2", "h_dianh", "h_hong2", "h_wh", "h_pph", "h_big", "h_small", "h_hdh", "h_zimo"];
            fans = ["", "", "", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.XIANGXIANG) {
            // 自摸	黑胡	红乌	红胡	 30胡	30红 	天胡 	地胡
            // 1	2	4	8	 16	     32	    64	    128
            imgs = ["h_zimo", "h_hei2", "h_wh", "h_hong2", "h_30huh", "h_30hongh", "h_tian2", "h_di2"];
            fans = ["", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.YOUXIAN) {
            //天胡  地胡  中庄 跑双 双龙 7对 五福  "" ""  "" 连中(X1)
            // 1     2    4    8  16   32  64 128 256 512 1024 2048
            imgs = ["h_tian2", "h_di2", "h_zhh", "h_psh", "h_slh", "h_qdh", "h_wfh", "", "", "",
                "h_lzh2", "h_lzh3", "h_lzh4", "h_lzh5", "h_lzh6", "h_lzh7", "h_lzh8", "h_lzh9", "h_lzh10"];
            fans = ["", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.GUILIN) {
            //天胡  地胡  自摸
            // 1     2    4    8
            imgs = ["h_tian2", "h_di2", "h_zimo", ""];
            fans = ["", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.CHENZHOU || mRoom.wanfatype == mRoom.MAOHUZI) {
            //天胡 自摸  红胡 黑胡 毛胡
            //1     2    4    8   16
            imgs = ["h_tian2", "h_zimo", "h_hong2", "h_hei2", "h_maoh"];
            fans = ["", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.HENGYANG) {
            //自摸，大红，小红，一点红，黑胡
            //1 ，  2，   4，    8，   16
            imgs = ["h_zimo", "h_dahong", "h_xiaohong", "h_yidian", "h_hei2"];
            fans = ["", "", "", "", ""];
        }
        if (mRoom.subWanfa == 'bashifan') {
            //     自摸 红胡 真点胡  乌胡  对对胡  大 小  听胡  天胡  地胡  耍猴  海底  大团圆  行行息  背靠背  魅一级
            //1 ，  2，  4，   8，   16    32   64 128 256   512  1024 2048 4096 8192   16384   32768  65536
            //多黄单番 一黄一番  两黄两番  三黄三番  多黄多番
            //131072   261072
            imgs = ["", "h_zimo", "h_hong2", "h_zdh", "h_wh", "h_ddh", "h_dah", "h_xiaoh", "h_th",
                "h_tian2", "h_di2", "h_sh", "h_hdh", "h_dty", "h_xxx", "h_bkb", "h_myjh",
                "h_dhdf", "h_yhyf", "h_lhlf", "h_shsf", "h_dhdf2"];
            fans = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
        }
        if (mRoom.wanfatype == mRoom.HENGDONG) {
            //自摸，天胡，地胡，红胡，黑胡，小胡 碰碰胡，
            //1     2    4     8    16   32 64
            imgs = ["h_zimo", "h_tian2", "h_di2", "h_hong2", "h_hei2", "h_xiaoh", "h_pph"];
            fans = ["", "", "", "", "", ""];
        }
        var imgs2 = [];
        if (mRoom.wanfatype == mRoom.WEIMAQUE) {
            //大小卓通用：
            //自摸： 0x1 红胡：0x2 多红：0x4 对子胡：0x8 乌对：0x10 乌胡：0x20 点胡：0x40 满园花：0x80 大字胡：0x100 小字胡：0x200
            //海底胡：0x400 单吊：0x800 卡偎：0x1000 天胡:0x2000 地胡：0x4000 全求人：0x8000 项对：0x10000 飘对：0x20000 鸡丁:0x40000 上下五千年:0x80000
            imgs = ["h_zimo", "h_hong2", "h_dred", "h_dzhu", "h_wdui", "h_wh", "h_dianh", "h_myhua", "h_dazi", "h_xiaozihu",
                "h_hdh", "h_dand", "h_kw", "h_tian2", "h_di2", "h_qqr", "h_xdui", "h_piaod", "h_jd", "h_sxwqn"];
            //印胡 0x1  纯印 0x2  卓胡 0x4  姊妹卓 0x8  三乱卓 0x10  姊妹卓带拖 0x20  祖孙卓 0x40  四乱卓 0x80  祖孙卓带拖 0x100  八碰头 0x200
            //假八碰头 0x400  背靠背 0x800  手牵手 0x1000  龙摆尾 0x2000
            //全黑  0x4000 无息 0x8000 六队红 0x10000 九队 0x20000 四边对 0x40000 边坎 0x80000 真背靠背 0x10000 凤摆尾 0x200000 卡胡 0x400000
            imgs2 = ["h_yinh", "h_chunyin", "h_zhuoh", "h_zmz", "h_sanlz", "h_zmzdt", "h_zsz", "h_szll", "h_zszdt", "h_bapengtou",
                "h_jbpt", "h_bkb", "h_sqs", "h_lbw",
                "h_quanhei", "h_wuxi", "h_liuduihong", "h_jiudui", "h_sibiandui", "h_biankan", "h_beikaobei", "h_fengbaiwei", "h_ka"];

        }
        for (var i = 0; i < imgs.length; i++) {
            var isOk = mAction.checkOpen(flag, 1 << i);
            if (isOk && imgs[i] != "") {
                var spr = new cc.Sprite(res[imgs[i] + "_png"]);//("res/image/ui/result/" + imgs[i] + ".png");
                spr.setAnchorPoint(0, 0.5);
                nHu.addChild(spr);
                spr.setPosition(10, -20 - index * 50);
                index++;
            }
        }
        for (var i = 0; i < imgs2.length; i++) {
            var isOk2 = mAction.checkOpen(flag2, 1 << i);
            if (isOk2 && imgs2[i] != "") {
                var spr = new cc.Sprite(res[imgs2[i] + "_png"]);//("res/image/ui/result/" + imgs2[i] + ".png");
                spr.setAnchorPoint(0, 0.5);
                nHu.addChild(spr);
                spr.setPosition(10, -20 - index * 50);
                index++;
            }
        }
    };
    var addComboList = function (comboList, winCards) {
        var hasDui = null;
        for (var i = 0; i < comboList.length; i++) {
            var comboInfo = comboList[i];
            if (comboInfo.typ != mCard.comboTypes.dui) {
                var ci = HUD.showLayer(HUD_LIST.ComboInfo, nCombos);
                ci.setData(comboInfo, comboList);
                ci.setPosition(10 + index * 60, 5);
                index++;

                var cardSprite = ci.getCardSprite();
                for (var s = 0; s < cardSprite.length; s++) {
                    winCards[winCards.length] = cardSprite[s];
                }
            } else {
                hasDui = comboInfo;
            }
        }
        if (hasDui != null) {
            var ci = HUD.showLayer(HUD_LIST.ComboInfo, nCombos);
            ci.setData(hasDui, comboList);
            ci.setPosition(10 + index * 60, 5);

            var cardSprite = ci.getCardSprite();
            for (var s = 0; s < cardSprite.length; s++) {
                this.winCards[this.winCards.length] = cardSprite[s];
            }
        }
    };


    var recSucess = function (data) {
        var newdata = JSON.parse(data);
        var penghzData = null;
        var users = null;
        for (var i = 0; i < newdata.length; i++) {
            if (newdata[i].cmd == 105) {
                penghzData = newdata[i].data.Changes;
                users = newdata[i].data.Users;
                break;
            }
        }
        var gameresultPhz = HUD.showLayer(HUD_LIST.GameResultPenghz, this);
        gameresultPhz.setData(penghzData, users);
    };
    var recFail = function () {
        HUD.showMessage('获取结果失败');
    };


    exports.GameResultLayer = GameResultLayer;

})(this);