(function () {
    var exports = this;
    var $ = null;
    var CuoPaiLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        setPaiHua: function (pai, val) {
            var that = this;
            var arr = getPaiNameByIdNN(val);
            setSpriteFrameByName(pai, arr, 'niuniu/card/poker');
        },
        ctor: function (typ, cuodata, handcards) {
            this._super();
            // cuodata = [35, 35];
            // handcards = [37,38,39,40];
            this.data = cuodata;
            this.handcards = handcards || [];
            this.cardList = [];

            var that = this;
            var scene = ccs.load(res.CuopaiLayer_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            var touchLayer = new cc.LayerColor(cc.color(0, 0, 0, 0), cc.winSize.width, cc.winSize.height);
            touchLayer.setName("touchLayer");
            touchLayer.setAnchorPoint(0, 0);
            this.addChild(touchLayer);
            this.touchLayer = touchLayer;

            TouchUtils.setOnclickListener($('root.close'), function () {
                that.getParent().showHandCard(false, null, true);
                that.removeFromParent();
            });

            this.initUI();
        },
        initUI: function(){
            var that = this;

            // 2 5张
            if(this.handcards){
                for(var i=0;i<this.handcards.length;i++){
                    $('root.top.a' + i).setVisible(true);
                    // $('root.top.a' + i).setPositionX((i - 2)*140);
                    this.setPaiHua($('root.top.a' + i), this.handcards[i]);
                }
                for(i;i<4;i++){
                    $('root.top.a' + i).setVisible(false);
                }
            }
            for (var j = 0; j < this.data.length; j++) {
                var node = $("root.pai.a" + j);
                if(!node){
                    node = duplicateSprite($("root.pai.a0"));
                    node.setName("a" + j);
                    $("root.pai.a0").getParent().addChild(node);
                }
                node.setRotation(90);
                node.setVisible(true);
                node.setAnchorPoint(cc.p(1, 0));
                node.setAnchorPoint(cc.p(0, 0));
                node.setPosition(cc.p(0 - node.getBoundingBox().width/2 + j*10, -300));
                // setCardBigUI(node, this.data[j]);
                // setSpriteFrameByName(node, getBigCardName(this.data[j]), "niuniu/card/bigcard");
                var src = "res/image/ui/niuniu/cuocard/" + getBigCardName(this.data[j]);
                node.setTexture(src);
                this.cardList.push(node);
                //角
                var jiao1 = node.getChildByName('jiao1');
                if(jiao1) {
                    jiao1.setRotation(-90);
                    setSpriteFrameByName(jiao1, getBigCardJiaoName(this.data[j]), "niuniu/cuocard/cuocard_big");
                }
                var jiao2 = node.getChildByName('jiao2');
                if(jiao2) {
                    jiao2.setRotation(90);
                    setSpriteFrameByName(jiao2, getBigCardJiaoName(this.data[j]), "niuniu/cuocard/cuocard_big");
                }

                var nodeW = node.getBoundingBox().width/2;
                node.runAction(cc.sequence(
                    cc.moveTo(0.2, cc.p(0 - nodeW + j*10, 500 - 3*(this.data.length - j - 1)))
                    , cc.rotateTo(0.2, 90 - 2 * (this.data.length - j - 1))
                ));
            }
            this.enableCuoPai(this.touchLayer);
        },
        enableCuoPai:function(touchLayer){
            var that = this;
            var moveNode = null;
            var moveNodeRotateBak = 0;
            var touchPos = null;
            var canMove = true;
            var cuoIndex = that.data.length - 1;
            var chupaiListener = cc.EventListener.create({
                event: cc.EventListener.TOUCH_ONE_BY_ONE,
                swallowTouches: false,
                onTouchBegan: function (touch, event) {
                    if(canMove == false)  return;
                    for(var i=that.cardList.length - 1;i >= 0;i--) {
                        if (TouchUtils.isTouchMe(that.cardList[i], touch, event, null)) {
                            touchPos = touch.getLocation();
                            moveNode = that.cardList[i];
                            return true;
                        }
                    }
                    return false;
                },
                onTouchMoved: function (touch, event) {
                    var p = touch.getLocation();
                    var movexy = {x:(p.x - touchPos.x), y:(p.y - touchPos.y)};
                    touchPos = p;
                    if(moveNode){
                        moveNode.setPosition(cc.p(moveNode.getPositionX() + movexy.x, moveNode.getPositionY() + movexy.y));
                    }
                },
                onTouchEnded: function (touch, event) {
                    if(moveNode){
                        moveNode.runAction(cc.sequence(
                            cc.callFunc(function () {
                                //翻完了 动画
                                var isMoveFinish = true;
                                for(var i=0;i<that.cardList.length;i++) {
                                    var card = that.cardList[i];
                                    for(var j=0;j<that.cardList.length;j++){
                                        if(i != j){
                                            var duibicard = that.cardList[j];
                                            if(Math.abs(card.getPositionX() - duibicard.getPositionX()) <= 35 &&
                                                Math.abs(card.getPositionY() - duibicard.getPositionY()) <= 35){
                                                isMoveFinish = false;
                                                break;
                                            }
                                        }
                                    }
                                }
                                if(isMoveFinish == true) {
                                    canMove = false;
                                    for (var i = 0; i < that.cardList.length; i++) {
                                        var card = that.cardList[i];
                                        //
                                        card.runAction(cc.sequence(
                                            cc.rotateTo(0.1, 90 + (i - (that.data.length - 1) / 2) * 5)
                                            , cc.moveTo(0.3, cc.p(i*70 + ((that.data.length == 5) ? -300:-240),
                                                500 + (i - (that.data.length - 1) / 2) * 20))
                                            , cc.delayTime(0.5)
                                            , cc.spawn(cc.moveTo(0.1, cc.p((that.data.length == 5)?-250:-190, 500)), cc.rotateTo(0.1, 90))
                                            , cc.moveBy(0.2, cc.p(0, -600))
                                            , cc.callFunc(function () {
                                                var cardArr = deepCopy(that.handcards);
                                                for (var k = 0; k < that.data.length; k++) {
                                                    cardArr.push(that.data[k]);
                                                }
                                                that.getParent().showHandCard(true, cardArr);
                                                that.removeFromParent();
                                            })
                                        ))
                                    }
                                }
                                moveNode = null;
                                touchPos = null;
                            })
                        ));
                    }
                }
            });
            return cc.eventManager.addListener(chupaiListener, touchLayer);
        },
        // setPaiZiVisible:function(node, flag){
        //     var clipper = function () {  //创建剪切区域
        //         var clipper = new cc.ClippingNode();
        //         var gameTitle = new cc.Sprite('res/image/ui/niuniu/card/zhezhao.png');
        //         clipper.setStencil(gameTitle);
        //         clipper.setAlphaThreshold(0);
        //         clipper.setContentSize(cc.size(gameTitle.getContentSize().width, gameTitle.getContentSize().height));
        //         return clipper;
        //     };
        //     //28 264  185 49  0.45
        //     var clip = node.getChildByName('clip');
        //     var clip2 = node.getChildByName('clip2');
        //     var avator = null;
        //     var avator2 = null;
        //     if(!clip){
        //         clip = clipper();
        //         clip.setScale(0.45);
        //         clip.setPosition(cc.p(28, 264));
        //         clip.setName('clip');
        //         node.addChild(clip);
        //         avator = new cc.Sprite('res/image/ui/niuniu/card/zhezhao.png');
        //         avator.setScale(1);
        //         avator.setName('avator');
        //         avator.setPosition(cc.p(0, 0));
        //         clip.addChild(avator);
        //
        //         clip2 = clipper();
        //         clip2.setScale(0.45);
        //         clip2.setPosition(cc.p(185, 49));
        //         clip2.setName('clip2');
        //         node.addChild(clip2);
        //         avator2 = new cc.Sprite('res/image/ui/niuniu/card/zhezhao.png');
        //         avator2.setScale(1);
        //         avator2.setName('avator2');
        //         avator2.setPosition(cc.p(0, 0));
        //         clip2.addChild(avator2);
        //     }
        //     avator = clip.getChildByName('avator');
        //     avator2 = clip2.getChildByName('avator2');
        //     if(!flag){
        //         avator.runAction(cc.sequence(
        //             cc.fadeOut(0.5)
        //         ));
        //         avator2.runAction(cc.sequence(
        //             cc.fadeOut(0.5)
        //         ));
        //     }else{
        //         clip.setVisible(true);
        //         clip2.setVisible(true);
        //     }
        // },

        onExit: function () {
            if(this.interval){
                clearInterval(this.interval);
                this.interval = null;
            }
            cc.Layer.prototype.onExit.call(this);
        }
    });


    exports.CuoPaiLayer = CuoPaiLayer;
})(window);
