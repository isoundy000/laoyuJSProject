var NiuniuHistoryCell = {
    init: function () {
        this.txt_house = getUI(this, "t1");
        this.txt_time = getUI(this, "t2");
        this.id = getUI(this, "id");
        this.flag = getUI(this, "flag");
        this.bg_cell = getUI(this, "bg_cell");
        this.roominfo = getUI(this, "roominfo");
        this.score = getUI(this, "score");
        this.tjushu = getUI(this, "tjushu");
        this.tdifen = getUI(this, "tdifen");
        this.twanfa = getUI(this, "twanfa");
        this.btn_fenxiang = getUI(this, "btn_fenxiang");

        this.highestScore = 0;
        this.lowestScore = 0;
    },

    setIndex: function (index, data) {
        var that = this;
        var itemSize = cc.size(1200, 520);

        this.id.setString(index + 1);
        this.index = index;
        this.txt_time.setString(data.ctime);
        this.txt_house.setString("房间:" + data.room_id);
        if(data['nickname7'] && data['nickname7'].length > 0) {
            this.bg_cell.setContentSize(cc.size(1200, 15 + 390 + 75));
            this.roominfo.setPositionY(15 + 390);
            this.score.setPositionY(15);
        }else if(data['nickname4'] && data['nickname4'].length > 0) {
            this.bg_cell.setContentSize(cc.size(1200, 15 + 260 + 75));
            this.roominfo.setPositionY(15 + 260);
            this.score.setPositionY(15);
        }else{
            this.bg_cell.setContentSize(cc.size(1200, 15 + 130 + 75));
            this.roominfo.setPositionY(15 + 130);
            this.score.setPositionY(15);
        }
        //分享
        var setData = function (ref, data) {
            var wanfaArr = JSON.parse(data.optionstring);

            getUI(ref, "id").setString(index + 1);
            getUI(ref, "t1").setString("房间:" + data.room_id);
            getUI(ref, "tjushu").setString("局数："+wanfaArr.rounds);
            getUI(ref, "tdifen").setString("底分：" + wanfaArr.basescore);
            getUI(ref, "twanfa").setString("玩法："+wanfaArr.name);
            getUI(ref, "t2").setString(data.ctime);
            var wanfa2str = "";
            if(wanfaArr.Xiaobeilv == "3222"){
                wanfa2str += '双十x3 十带九x2 十带八x2 十带七x2 ';
            }
            if(wanfaArr.Xiaobeilv == "4322"){
                wanfa2str += '双十x4 十带九x3 十带八x2 十带七x2 ';
            }
            if(wanfaArr.kuozhan1){
                wanfa2str += '五花/炸弹x6 五小x8 ';
            }
            if(wanfaArr.kuozhan2){
                wanfa2str += '顺子/葫芦/同花x5';
            }
            getUI(ref, "wanfa2").setString(wanfa2str);
            for (var i = 1; i <= 9; i++) {
                if (data["nickname" + i]) {
                    if (data.resultscore[i-1] > that.highestScore) {
                        that.highestScore = data.resultscore[i-1];
                    }
                    if(data.resultscore[i-1] < that.lowestScore){
                        that.lowestScore = data.resultscore[i-1];
                    }

                    var bg = getUI(ref, "bg_" + i);
                    var posY = 0;
                    if(data['nickname7'] && data['nickname7'].length > 0) {
                        posY = (3 - Math.floor((i+2)/3))*130;
                    }else if(data['nickname4'] && data['nickname4'].length > 0){
                        posY = (2 - Math.floor((i+2)/3))*130;
                    }else{
                        posY = 0;
                    }
                    bg.setPositionY(posY);
                    bg.setVisible(true);
                    bg.setTexture((data.resultscore[i - 1]) >= 0 ? res.jiesuan_item_red : res.jiesuan_item_blue);
                    getUI(bg, "name").setString(ellipsisStr(data["nickname" + i], 6) + "");
                    if (useTilongResult) {
                        getUI(bg, "score").setString((data.tilongscore[i - 1].small == undefined || data.tilongscore[i - 1].small == null)
                            ? '0' : data.tilongscore[i - 1].small);
                    } else {
                        //得分
                        getUI(bg, "score").setFntFile((data.resultscore[i - 1] >= 0) ? res.score_yellow_fnt : res.score_blue_fnt);

                        getUI(bg, "score").setString((data.resultscore == undefined || data.resultscore == null)
                            ? '0' : data.resultscore[i - 1]);
                    }
                    //头像
                    var url = decodeURIComponent(data["heads"][i - 1]);
                    if (url == undefined || (url.length == 0)) url = res.defaultHead;
                    loadImageToSprite(url, getUI(bg, "head"));//头像

                } else {
                    var bg = getUI(ref, "bg_" + i);
                    bg.setVisible(false);
                }
            }
            for (var i = 1; i <= 9; i++) {
                if (data["nickname" + i]) {
                    var bg = getUI(ref, "bg_" + i);
                    getUI(bg, 'icon_dyj').setVisible(that.highestScore > 0 && data.resultscore[i-1] == that.highestScore);
                    getUI(bg, 'icon_thl').setVisible(that.lowestScore < 0 && data.resultscore[i-1] == that.lowestScore);
                }
            }
        };
        TouchUtils.setOnclickListener(this.btn_fenxiang, function () {
            if (!cc.sys.isNative)
                return;
            var nodeForShare = ccs.load(res.NiuniuHistoryCell_json, "res/").node;
            // nodeForShare.setPosition(cc.p(itemSize.width / 2, itemSize.height / 2));
            setData(nodeForShare, data);
            nodeForShare.setPosition((1280-itemSize.width)/2, (720-itemSize.height)/2);
            // that.addChild(nodeForShare);
            var bg = new cc.Sprite(res.jiesuan_bg_png);
            bg.setPosition(cc.p(nodeForShare.getContentSize().width/2, nodeForShare.getContentSize().height/2));
            nodeForShare.addChild(bg, -1);
            WXUtils.captureAndShareToWX(nodeForShare, 0x88F0);//0x88F0
        });

        var wanfaArr = JSON.parse(data.optionstring);
        this.tjushu.setString("局数："+wanfaArr.rounds);
        if(wanfaArr.basescore) {
            this.tdifen.setVisible(true);
            this.tdifen.setString("底分：" + wanfaArr.basescore);
        }else{
            this.tdifen.setVisible(false);
        }
        this.twanfa.setString("玩法："+wanfaArr.name);
        var useTilongResult = false;
        if (wanfaArr.wanfa == mRoom.FANGPAOFA || wanfaArr.wanfa == mRoom.XIANGXIANG
            || wanfaArr.wanfa == mRoom.SHAOYANGBOPI) {
            useTilongResult = true;
        }
        for (var i = 1; i <= 9; i++) {
            setData(this, data);
        }
        //是不是自己赢了
        var myscore = 0;
        var fangzhuIndex = 1;
        for (var i = 1; i <= 9; i++) {
            if (data["uid" + i] && data["uid" + i] == gameData.uid) {
                if (data.resultscore[i - 1]) myscore = data.resultscore[i - 1];
                break;
            }
        }
        for (var i = 1; i <= 9; i++) {
            //谁是房主
            if (data["uid" + i] && data.owner_uid == data["uid" + i]) {
                fangzhuIndex = i;
                break;
            }
        }
        for (var i = 1; i <= 9; ++i) {
            var bg = getUI(this, "bg_" + i);
            getUI(bg, 'fangzhu').setVisible((i == fangzhuIndex) ? true : false);
        }
    }
};