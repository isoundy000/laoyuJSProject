/**
 * Created by wangchangchun on 16/7/11.
 */
var WanfaDesc = {
    init: function () {
        this.arrow = getUI(this, "arrow");
        this.panel = getUI(this, "panel");
        this.scrollview = getUI(this, 'scrollview');
        this.arrow = getUI(this, 'arrow');
        this.arrowH = 160;
        this.panel.setPosition(-570, this.arrowH);

        var that = this;
        var touchPosX = null;
        var cancelOrSend = false;
        if(window.inReview == false){
            TouchUtils.setListeners(this.arrow, {
                onTouchBegan: function (node, touch, event) {
                    cancelOrSend = true;
                    touchPosX = touch.getLocation().x;
                },
                onTouchMoved: function (node, touch, event) {
                    var moveposx = touch.getLocation().x - touchPosX;
                    if((that.panel.getPositionX() + moveposx) > 0 || (that.panel.getPositionX() + moveposx) < -570) {
                    }else{
                        touchPosX = touch.getLocation().x;
                        that.panel.setPositionX(that.panel.getPositionX() + moveposx);
                    }
                },
                onTouchMoveOut: function (node, touch, event) {
                    if (cancelOrSend) {
                        cancelOrSend = false;
                    }
                },
                onTouchEndedWithoutCheckTouchMe: function (node, touch, event) {
                    var wanfaposx = that.panel.getPositionX();
                    if (wanfaposx <= -570/2){
                        if(wanfaposx <= -570 + 10){
                            that.panel.runAction(
                                cc.sequence(cc.moveTo(0.5 ,cc.p(0, that.arrowH)).easing(cc.easeIn(0.3)))
                            )
                        }else{
                            that.panel.runAction(
                                cc.sequence(cc.moveTo(0.5 ,cc.p(-570, that.arrowH)).easing(cc.easeIn(0.3)))
                            )
                        }
                    }else{
                        if(wanfaposx >= -10){
                            that.panel.runAction(
                                cc.sequence(cc.moveTo(0.5 ,cc.p(-570, that.arrowH)).easing(cc.easeIn(0.3)))
                            )
                        }else{
                            that.panel.runAction(
                                cc.sequence(cc.moveTo(0.5 ,cc.p(0, that.arrowH)).easing(cc.easeIn(0.3)))
                            )
                        }
                    }
                }
            });
        }
        return true;
    },
    setData:function() {
        var showimg = "res/image/ui/room/fpf.png";
        var scale = 1;
        if (mRoom.wanfatype == mRoom.FANGPAOFA) {
            showimg = "res/image/ui/room/fpf.png";
        } else if (mRoom.wanfatype == mRoom.YAYA) {
            showimg = "res/image/ui/room/yyphz.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.LEIYANG) {
            showimg = "res/image/ui/room/lyphz.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.CHANGSHA){
            showimg = "res/image/ui/room/csphz.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.SHAOYANG){
            showimg = "res/image/ui/room/syzp.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.SHAOYANGBOPI) {
            showimg = "res/image/ui/room/sybp.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.HONGGUAIWAN){
            showimg = "res/image/ui/room/hhhgw.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.XIANGXIANG) {
            showimg = "res/image/ui/room/xxghz.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.CHANGDE) {
            showimg = "res/image/ui/room/cdphz.png";
            scale = 0.92;
        }else if(mRoom.wanfatype == mRoom.YOUXIAN){
            showimg = "res/image/ui/room/yxphz.png";
        }else if(mRoom.wanfatype == mRoom.GUILIN){
            showimg = "res/image/ui/room/glzp.png";
        }else if(mRoom.wanfatype == mRoom.CHENZHOU || mRoom.wanfatype == mRoom.MAOHUZI) {
            showimg = "res/image/ui/room/czzp.png";
        }else if(mRoom.wanfatype == mRoom.HENGYANG) {
            showimg = "res/image/ui/room/hylhq.png";
        }
        var descsprite = new cc.Sprite(showimg);
        descsprite.setScale(scale);
        descsprite.setAnchorPoint(cc.p(0, 1));
        this.scrollview.setInnerContainerSize(cc.size(530, descsprite.getBoundingBox().height));
        descsprite.setPosition(cc.p(0, descsprite.getBoundingBox().height));
        this.scrollview.addChild(descsprite);
    }
};
