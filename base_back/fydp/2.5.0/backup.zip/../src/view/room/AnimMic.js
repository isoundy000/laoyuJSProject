var AnimMic = {
    init:function () {
        
        return true;
    },

    /** @returns AnimMic */
    getCom: function (p, name) {return getCom(p, name, this);}
};