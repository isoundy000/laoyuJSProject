
(function () {
    var exports = this;
    var $ = null;

    var WanfaLayer = cc.Layer.extend({
        onCCSLoadFinish: function () {
        },
        ctor: function () {
            this._super();
            var that = this;

            var mainscene = ccs.load(res.WanfaLayer_json, 'res/');
            this.addChild(mainscene.node);

            $ = create$(this.getChildByName("Layer"));


            TouchUtils.setOnclickListener($('root'), function () {

            });

            TouchUtils.setOnclickListener($('btn_close'), function () {
                that.removeFromParent();
            });
            var wanfaWord = decodeURIComponent(gameData.wanfaDesp);
            $('wanfa').setString(wanfaWord);

            var arr = wanfaWord.split(",");
            console.log(wanfaWord);
            var nameArr = ['jsxz','mpls', 'bpls', 'fdkp'];
            for(var i=0; i<nameArr.length; i++){
                $('word_'+nameArr[i]+'_0').setString(arr[i]);
            }
            //玩法选择
            var wordWanfaStr = "";
            for(var i=nameArr.length; i<arr.length; i++){
                if(arr[i]=='切牌' || arr[i]=='视频' || arr[i]=='搓牌')continue;

                if(i==nameArr.length){
                    wordWanfaStr += (arr[i] + '\n');
                    continue;
                }

                wordWanfaStr += (arr[i] + (i%2==0?'  \n':'\t\t\t'));
            }
            $('word_wfxz_0').setString(wordWanfaStr);
            //其他选项
            var wordOtherStr = "";
            if(wanfaWord.indexOf("切牌")>=0){
                wordOtherStr += "切牌"
            }
            if(wanfaWord.indexOf("搓牌")>=0){
                if(wordOtherStr!=''){
                    wordOtherStr+='\t'
                }
                wordOtherStr += "搓牌"
            }
            if(wanfaWord.indexOf("视频")>=0){
                if(wordOtherStr!=''){
                    wordOtherStr+='\t'
                }
                wordOtherStr += "视频"
            }
            if(wordOtherStr==""){
                wordOtherStr = "无";
            }
            $('word_qtxx_0').setString(wordOtherStr);

            return true;
        }
    });
    exports.WanfaLayer = WanfaLayer;
})(window);
