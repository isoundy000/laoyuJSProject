(function () {
    var exports = this;
    var $ = null;

    var ClubUserMsgLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        ctor: function (clubInfo, data, typ, parent) {
            this._super();
            this.parentLayer = parent;
            var that = this;
            var scene = ccs.load(res.ClubUserMsgLayer_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            $('root').addTouchEventListener(function (sender, type) {
                if (type == ccui.Widget.TOUCH_ENDED) {
                    that.removeFromParent(true);
                }
            });

            this.clubInfo = clubInfo;
            this.typ = typ;
            if(typ == 'msgs') {
                this.initMsgLayer(data);
            }else if(typ == 'users'){
                this.showDeleteBtn = false;
                this.initUserLayer(data);
            }else if(typ == 'addorcreate') {
                this.initAddCreateLayer();
            }else{
                this.initSetLayer();
            }
        },
        initAddCreateLayer:function(){
            var that = this;
            $('addorcreateClub').setVisible(true);
            $('setlayer').setVisible(false);
            $('usersLayer').setVisible(false);
            $('msgLayer').setVisible(false);

            TouchUtils.setTouchRect($("addorcreateClub.addclub"), cc.rect(-40, -15, 210, 60));//130  30
            TouchUtils.setOnclickListener($("addorcreateClub.addclub"), function () {
                that.getParent().showCreateOrAddClubLayer("add");
                that.removeFromParent();
            });

            TouchUtils.setTouchRect($("addorcreateClub.createclub"), cc.rect(-40, -15, 210, 60));
            TouchUtils.setOnclickListener($("addorcreateClub.createclub"), function () {
                that.getParent().showCreateOrAddClubLayer("create");
                that.removeFromParent();
            });

        },
        initSetLayer:function(){
            var that = this;
            $('addorcreateClub').setVisible(false);
            $('setlayer').setVisible(true);
            $('usersLayer').setVisible(false);
            $('msgLayer').setVisible(false);
            TouchUtils.setTouchRect($("setlayer.jiesan"), cc.rect(-40, -15, 210, 60));//100  30
            TouchUtils.setOnclickListener($("setlayer.jiesan"), function () {
                that.removeFromParent();
                alert2('确定解散该俱乐部？', function(){
                    var club_id = that.clubInfo['id'];
                    network.send(2101, {cmd:'deleteClub', club_id:club_id});
                });
            });
            TouchUtils.setTouchRect($("setlayer.changename"), cc.rect(-40, -15, 210, 60));//130  30
            TouchUtils.setOnclickListener($("setlayer.changename"), function () {
                that.removeFromParent();

                var club_id = that.clubInfo['id'];
                var confirm = new ClubConfirm(club_id);
                that.parentLayer.addChild(confirm);
            });
            // gameData.opt_conf['addClubMember'] = 0;
            if(gameData.opt_conf && gameData.opt_conf['addClubMember'] < 0){
                TouchUtils.setClickDisable($("setlayer.adduser"), true);
                $("setlayer.adduser").setOpacity(100);
            }
            TouchUtils.setTouchRect($("setlayer.adduser"), cc.rect(-40, -15, 210, 60));//130  30
            TouchUtils.setOnclickListener($("setlayer.adduser"), function () {
                that.removeFromParent();

                var club_id = that.clubInfo['id'];
                var confirm = new ClubConfirm(club_id, "adduser");
                that.parentLayer.addChild(confirm);
            });
            //设置玩法
            TouchUtils.setTouchRect($("setlayer.setwanfa"), cc.rect(-40, -15, 210, 60));//130  30
            TouchUtils.setOnclickListener($("setlayer.setwanfa"), function () {
                that.removeFromParent();

                var club_id = that.clubInfo['id'];
                that.parentLayer.getParent().createRoomLayer(true, "all", club_id, true);
            });
        },

        //tableview  begin
        tableCellTouched: function (table, cell) {
        },
        tableCellSizeForIndex: function (table, idx) {
            if(this.typ == 'users'){
                return cc.size(310, 90);
            }else{
                return cc.size(520, 90);
            }
        },
        tableCellAtIndex: function (table, idx) {
            var cell = table.dequeueCell();
            if(this.typ == 'users'){
                if(cell == null) {
                    cell = new cc.TableViewCell();
                    var row0 = ccs.load(res.UserItem_json, "res/").node;
                    row0.setName('cellrow');
                    cell.addChild(row0);
                }
                this.initUserCell(cell, idx);
            }else{
                if(cell == null) {
                    cell = new cc.TableViewCell();
                    var row0 = ccs.load(res.MsgItem_json, "res/").node;
                    row0.setName('cellrow');
                    cell.addChild(row0);
                }
                this.initMsgCell(cell, idx);
            }
            return cell;
        },
        numberOfCellsInTableView: function (table) {
            if(this.typ == 'users'){
                return this.usersList.length;
            }else{
                return this.msgList.length;
            }
        },
        //tableview  end
        initUserLayer:function(data){
            var that = this;
            that.usersList = data || [];
            $('addorcreateClub').setVisible(false);
            $('setlayer').setVisible(false);
            $('usersLayer').setVisible(true);
            $('msgLayer').setVisible(false);

            this.owner_uid = that.clubInfo['owner_uid'];
            //排序 房主永远是第一个
            for(var i=0;i<this.usersList.length;i++){
                if(this.usersList[i]['uid'] == this.owner_uid){
                    var tmp = this.usersList[i];
                    for(var j=i;j>0;j--){
                        this.usersList[j] = this.usersList[j-1];
                    }
                    this.usersList[0] = tmp;
                    break;
                }
            }

            $("usersLayer.bg.btn_bianji").setVisible(gameData.uid == this.owner_uid);
            $("usersLayer.bg.btn_tuichu").setVisible(gameData.uid != this.owner_uid);

            TouchUtils.setOnclickListener($("usersLayer.bg.btn_bianji"), function () {
                that.showDeleteBtn = !that.showDeleteBtn;
                tableViewRefresh(that.tableview);
            });
            TouchUtils.setOnclickListener($("usersLayer.bg.btn_tuichu"), function () {
                alert2('确定退出该俱乐部？', function() {
                    that.removeFromParent();
                    var club_id = that.clubInfo['id'];
                    network.send(2101, {cmd: 'leaveClub', club_id: club_id, obj_id: gameData.uid});
                })
            });

            var usersLayer = $('usersLayer');
            usersLayer.setVisible(true);
            usersLayer.setPosition(cc.p(870, 100));

            if(that.tableview){
                tableViewRefresh(that.tableview);
            }else{
                var tableviewLayer = $('usersLayer.tableviewLayer');
                var tableview = new cc.TableView(that, cc.size(tableviewLayer.getContentSize().width,
                    tableviewLayer.getContentSize().height));
                tableview.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                tableview.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
                tableview.x = 0;
                tableview.y = 0;
                tableview.setDelegate(that);
                tableview.setBounceable(true);
                tableviewLayer.addChild(tableview);
                that.tableview = tableview;
                that.showDeleteBtn = false;
            }
        },
        initUserCell:function(cell, i){
            var that = this;
            var node = cell.getChildByName('cellrow');
            if(!node)  return;
            var userInfo = this.usersList[i];
            var setData = function(ref){
                $("name", ref).setString(ellipsisStr(userInfo['name'], 6));
                $("id", ref).setString("ID:" + userInfo['uid']);

                if (userInfo['head'] == null || userInfo['head'] == undefined || userInfo['head'] == "") {
                    userInfo['head'] = res.defaultHead;
                }
                loadImageToSprite2(decodeURIComponent(userInfo['head']), $('head', ref));
                $('qunzhu', ref).setVisible(i == 0);
            };
            var row = $('row', node);
            setData(row);

            var deletebtn = row.getChildByName('delete');
            if(!deletebtn){
                deletebtn = new cc.Sprite('res/image/ui/club/btn_delete.png');
                deletebtn.setName('delete');
                row.addChild(deletebtn);
            }
            if(this.showDeleteBtn && i != 0 && gameData.uid == this.owner_uid){
                deletebtn.setVisible(true);
                deletebtn.stopAllActions();
                deletebtn.runAction(cc.sequence(
                    cc.moveTo(0.1, cc.p(270, 42))
                ));
            }else{
                deletebtn.setVisible(false);
                deletebtn.setPosition(cc.p(270 + 50, 42));
            }
            TouchUtils.setOnclickListener(deletebtn, function () {
                //removeClubMember
                alert2('确定要删除该群友？', function(){
                    var club_id = that.clubInfo['id'];
                    network.send(2101, {cmd:'removeClubMember', club_id:club_id, obj_id:userInfo['uid']});
                })
            });
        },
        initMsgLayer:function(data){
            var that = this;
            $('addorcreateClub').setVisible(false);
            $('setlayer').setVisible(false);
            $('usersLayer').setVisible(false);
            $('msgLayer').setVisible(true);
            that.msgList = data || [];
            this.club_id = that.clubInfo['id'];
            var msgLayer = $('msgLayer');
            msgLayer.setPosition(cc.p(500, 100));
            $('msgLayer.bg.nomsgtitle').setVisible((this.msgList.length == 0));

            if(that.tableview){
                tableViewRefresh(that.tableview);
            }else{
                var tableviewLayer = $('msgLayer.tableviewLayer');
                var tableview = new cc.TableView(that, cc.size(tableviewLayer.getContentSize().width,
                    tableviewLayer.getContentSize().height));
                tableview.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                tableview.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
                tableview.x = 0;
                tableview.y = 0;
                tableview.setDelegate(that);
                tableview.setBounceable(true);
                tableviewLayer.addChild(tableview);
                that.tableview = tableview;
            }
        },
        initMsgCell:function (cell, i) {
            var that = this;
            var node = cell.getChildByName('cellrow');
            if (!node) {
                return;
            }
            var userInfo = this.msgList[i];
            var setData = function(ref){
                $("name", ref).setString(ellipsisStr(userInfo['name'], 6));
                $("id", ref).setString("ID:" + userInfo['uid']);

                if (userInfo['head'] == null || userInfo['head'] == undefined || userInfo['head'] == "") {
                    userInfo['head'] = res.defaultHead;
                }
                loadImageToSprite2(decodeURIComponent(userInfo['head']), $('head', ref));
            };
            var row = $('row', node);
            setData(row);
            if(gameData.uid == this.clubInfo['owner_uid']) {
                var btn_pingbi = row.getChildByName('btn_pingbi');
                if (!btn_pingbi) {
                    btn_pingbi = new cc.Sprite('res/image/ui/club/btn_pingbi.png');
                    btn_pingbi.setPosition(cc.p(280, 43));
                    btn_pingbi.setName('btn_pingbi');
                    row.addChild(btn_pingbi);
                }
                var btn_jujue = row.getChildByName('btn_jujue');
                if (!btn_jujue) {
                    btn_jujue = new cc.Sprite('res/image/ui/club/btn_jujue.png');
                    btn_jujue.setPosition(cc.p(375, 43));
                    btn_jujue.setName('btn_jujue');
                    row.addChild(btn_jujue);
                }
                var btn_tongyi = row.getChildByName('btn_tongyi');
                if (!btn_tongyi) {
                    btn_tongyi = new cc.Sprite('res/image/ui/club/btn_tongyi.png');
                    btn_tongyi.setPosition(cc.p(470, 43));
                    btn_tongyi.setName('btn_tongyi');
                    row.addChild(btn_tongyi);
                }
                TouchUtils.setOnclickListener(btn_pingbi, function () {
                    network.send(2101, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['msg_id'], name: userInfo['name'], head:userInfo['head'], value:'ignore'});
                });
                TouchUtils.setOnclickListener(btn_jujue, function () {
                    network.send(2101, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['msg_id'], name: userInfo['name'], head:userInfo['head'], value:'reject'});
                });
                TouchUtils.setOnclickListener(btn_tongyi, function () {
                    network.send(2101, {cmd:'agreeClub', club_id:that.club_id, obj_id:userInfo['uid'],
                        msg_id:userInfo['msg_id'], name: userInfo['name'], head:userInfo['head'], value:'accept'});
                });
            }
        }
    });
    exports.ClubUserMsgLayer = ClubUserMsgLayer;
})(window);

