"use strict";
(function (exports) {

    var zjh_signal1 = res.signal1;
    var zjh_signal2 = res.signal2;
    var zjh_signal3 = res.signal3;
    var zjh_signal4 = res.signal4;

    var wifi_signal1 = res.signal1;
    var wifi_signal2 = res.signal2;
    var wifi_signal3 = res.signal3;
    var wifi_signal4 = res.signal4;

    var TEXTURE_STATUS = {
        'kan': "res/image/ui/zjh/unit/yikanpai.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/yikanpai.png"),
        'qi': "res/image/ui/zjh/unit/yiqipai.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/yiqipai.png"),
        'shu': "res/image/ui/zjh/unit/bipaishu.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/bipaishu.png")
    };
    var TEXTURE_SELF_STATUS = {
        'kan': "res/image/ui/zjh/unit/yikanpai2.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/yikanpai2.png"),
        'qi': "res/image/ui/zjh/unit/yiqipai2.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/yiqipai2.png"),
        'shu': "res/image/ui/zjh/unit/bipaishu2.png",//cc.textureCache.addImage("res/image/ui/zjh/unit/bipaishu2.png")
    };
    var BUTTON_COMMON_RES = {
        'disable1' : "res/image/ui/zjh/table/btn_hui.png",
        'blue1' : "res/image/ui/zjh/table/btn_lan.png",
        'orange1' : "res/image/ui/zjh/table/btn_cheng.png",
        'red1' : "res/image/ui/zjh/table/btn_red.png"
    }
    //后期优化牌桌 加入筹码按钮
    var chipsArr = [2,3,4,5,6,8,10];
    for(var i=0; i<chipsArr.length; i++){
        BUTTON_COMMON_RES['chip'+chipsArr[i]] = "res/image/ui/zjh/unit/btn_chip" +chipsArr[i]+ ".png";
    }
    var BUTTON_COMMON_FONT_COLOR = {
        'blue' : cc.color(49, 83, 168),
        'orange': cc.color(152, 78, 24),
        'red': cc.color(152,24,24),
        'green' : cc.color(6,118,0)
    }

    var $ = null;

    var PAIID2CARD = [];

    var initPaiNum = 20;

    var g_kanpai = false;

    for (var i = 0; i < 54; i++)
        PAIID2CARD[i] = new pokerRule.Card(i);

    // CONST
    var FAPAI_ANIM_DELAY = 0.04;
    var FAPAI_ANIM_DURATION = 0.2;

    var LAIZI_TEXTURE = cc.textureCache.addImage("res/image/ui/poker/character/lai_star.png");

    var ROOM_STATE_CREATED = 1;
    var ROOM_STATE_ONGOING = 2;
    var ROOM_STATE_ENDED = 3;

    var cardScale = 1;

    var posConf = {
        headPosBak: {}
        , paiTouchRect: null
        , paiASize: {}
        , paiA0PosBak: {}
        , paiA0ScaleBak: {}
        , paiADistance: {}
        , paiALiangDistance: [0.5, 3.5, 0, -3.5]
        , paiMopaiDistance: {0: 16, 1: 40, 2: 34, 3: 40}
        , paiGDistance: []
        , paiUsedDistance: []
        , paiUsedZOrder: {
            0: {0: -1, 10: 0}
            , 1: {0: -1, 10: -1}
            , 2: {0: 0, 10: -1}
            , 3: {0: 0, 10: 1}
        }
        , opsPositionX: {4: [288, 538, 788, 1038], 3: [386, 636, 886]}
        , upPaiPositionY: null
        , downPaiPositionY: null
        , groupWidth: {}
        , groupHeight: {}
        , groupDistance: {0: 4, 1: 4, 2: 16, 3: 4}
        , groupToFirstPaiDistance: {0: 10, 1: -14, 2: 26, 3: -14}

        , paiPos: {}

        , ltqpPos: {}
        , ltqpRect: {}
        , ltqpCapInsets: {
            3: {
                0: cc.rect(44, 25, 1, 1)
                , 1: cc.rect(26, 31, 1, 1)
                , 2: cc.rect(44, 25, 1, 1)
                , 3: cc.rect(42, 26, 1, 1)
            },
            5: {
                1: cc.rect(26, 31, 1, 1)
                , 2: cc.rect(44, 25, 1, 1)
                , 3: cc.rect(42, 23, 1, 1)
                , 4: cc.rect(42, 23, 1, 1)
                , 5: cc.rect(26, 31, 1, 1)
            }
        }
        , ltqpEmojiPos: {
            3: {
                0: cc.p(40, 28)
                , 1: cc.p(40, 28)
                , 2: cc.p(60, 40)
                , 3: cc.p(40, 28)
            },
            5: {
                1: cc.p(40, 28)
                , 2: cc.p(60, 40)
                , 3: cc.p(40, 28)
                , 4: cc.p(40, 28)
                , 5: cc.p(40, 28)
            }
        }
        , ltqpVoicePos: {
            3: {
                0: cc.p(40, 28)
                , 1: cc.p(37, 28)
                , 2: cc.p(42, 40)
                , 3: cc.p(58, 40)
            },
            5: {
                1: cc.p(37, 28)
                , 2: cc.p(42, 40)
                , 3: cc.p(58, 40)
                , 4: cc.p(58, 30)
                , 5: cc.p(37, 28)
            }
        }
        , ltqpEmojiSize: {}
        , ltqpTextDelta: {
            3: {
                0: cc.p(0, -4)
                , 1: cc.p(-7, 2)
                , 2: cc.p(-1, 7)
                , 3: cc.p(3, 5)
            },
            5: {
                1: cc.p(-7, 2)
                , 2: cc.p(-1, 7)
                , 3: cc.p(3, 5)
                , 4: cc.p(3, 5)
                , 5: cc.p(-7, 2)
            }
        }
    };

    var data;
    var isReconnect;

    var roomState = null;
    var mapId = 2;
    var playerNum = 5;
    var rowBegin = 1;

    var isCCSLoadFinished = false;

    var uid2position = {};
    var uid2playerInfo = {};
    var position2uid = {};
    var position2sex = {};
    var position2playerArrIdx = {};

    var turnRow = null;


    var isReplay = null;

    var forRows = null;

    var laiziValue = [];
    var resultTypes = [];

    var isInitShipin = false;
    var fapaiLayer = null;
    var selfCurrentBtnStates = {};
    var isCuopaiOps = false;

    var clearVars = function () {
        roomState = null;
        mapId = gameData.mapId;
        playerNum = 5;
        rowBegin = 1;
        isCCSLoadFinished = false;
        uid2position = {};
        uid2playerInfo = {};
        position2uid = {};
        position2sex = {};
        position2playerArrIdx = {};
        turnRow = null;
        isReplay = null;
        forRows = null;

        isInitShipin = false;
        fapaiLayer = null;
        isCuopaiOps = false;
    };

    var MaLayer_zjh = cc.Layer.extend({
        chatLayer: null,
        chiLayer: null,
        throwDiceLayer: null,
        kaigangLayer: null,
        beforeOnCCSLoadFinish: null,
        afterGameStart: null,
        interval: null,
        content: null,

        updateCardStatusZJH: function (row, status) {

            var cardStatusSp = $('row' + row + 'b.status');

            if (!cardStatusSp || cardStatusSp == null || cardStatusSp == undefined)
                return;

            if (cardStatusSp && !cc.sys.isObjectValid(cardStatusSp))
                return;

            if (!status || !TEXTURE_STATUS[status]) {

                if (cardStatusSp && cc.sys.isObjectValid(cardStatusSp))
                    cardStatusSp.setVisible(false);

            } else {

                if (row == 2) {

                    if (cardStatusSp && cc.sys.isObjectValid(cardStatusSp))
                        cardStatusSp.setVisible(true);

                    if (cardStatusSp && cc.sys.isObjectValid(cardStatusSp))
                        cardStatusSp.setTexture(TEXTURE_SELF_STATUS[status]);

                } else {

                    if (cardStatusSp && cc.sys.isObjectValid(cardStatusSp))
                        cardStatusSp.setVisible(true);

                    if (cardStatusSp && cc.sys.isObjectValid(cardStatusSp))
                        cardStatusSp.setTexture(TEXTURE_STATUS[status]);

                }

            }
        },
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        getRootNode: function () {
            return this.getChildByName("Scene");
        },
        initExtraMapData: function (data) {
            var that = this;
        },
        onCCSLoadFinish: function () {
            var that = this;

            $ = create$(this.getRootNode());

            this.getPai = this.getPai();
            this.addUsedPai = this.addUsedPai();
            this.countDown = this.countDown();

            this.calcPosConf();
            mRoom.voiceMap = {};

            EFFECT_EMOJI.init(this, $);
            MicLayer.init($('btn_mic'), this);


            $('btn_copy').setVisible(!window.inReview);
            $("btn_list_bg").setLocalZOrder(999);


            if (isReconnect) {
                gameData.zhuangUid = data["zhuang_uid"];
                gameData.leftRound = data["left_round"];
                gameData.totalRound = data["total_round"];
                gameData.players = data["players"];
                gameData.wanfaDesp = data["desp"];
                gameData.shipin = data['shipin'] || 0;
                var status = data["room_status"] || ROOM_STATE_ONGOING;
                if (status == ROOM_STATE_ENDED) {
                    this.setRoomState(ROOM_STATE_ONGOING);
                    this.setRoomState(ROOM_STATE_ENDED);
                }
                else {
                    this.setRoomState(status);
                }

                this.initExtraMapData(data);
            }
            else
                this.setRoomState(ROOM_STATE_CREATED);

            //this.initWanfa();

            this.clearTable4StartGame(isReconnect, isReconnect, data);

            this.startTime();

            this.startSignal();

            TouchUtils.setOnclickListener($('bg'), function () {
                that.onListBtnAni(true);
            },{effect: TouchUtils.effects.NONE, sound:'no'});
            TouchUtils.setOnclickListener($('chat'), function () {
                // if (!that.chatLayer) {
                //     that.chatLayer = new ChatLayer();
                //     that.chatLayer.retain();
                // }
                that.addChild(new ChatLayer());
            });
            TouchUtils.setOnclickListener($('btn_help'), function () {
                that.addChild(new WanfaLayer());
            });
            $('btn_help').setVisible(false);
            $('lb_wanfa').setString(gameData.wanfaDesp);

            TouchUtils.setOnclickListener($("btn_zhunbei"), function () {
                network.send(3004, {room_id: gameData.roomId});
                $("btn_zhunbei").setVisible(false);
            });

            TouchUtils.setOnclickListener($("kan.kan"), function () {
                network.send(4503, {room_id: gameData.roomId, op: 5});
                $("kan").setVisible(false);
                // that.setBtnEnableState('ops.kan',false);
            });

            TouchUtils.setOnclickListener($('jia.jiabg'), function () {

            }, {effect: TouchUtils.effects.NONE});

            TouchUtils.setOnclickListener($("btn_invite"), function () {
                // if (!cc.sys.isNative)
                //     return;
                var title = COMPANYNAME[gameData.appId]+"拼三张-" + gameData.roomId + ",已有" + gameData.players.length + "人";
                var content = gameData.wanfaDesp;
                WXUtils.shareUrl(MWINDOWURL[gameData.appId] + '?roomid=' + gameData.roomId, title, content, 0, getCurTimestamp() + gameData.uid);

            });

            $('btn_copy').setVisible(false);
            TouchUtils.setOnclickListener($('btn_copy'), function () {
                if (getNativeVersion() < "2.0.0") {
                    alert1("请下载最新版本使用新功能");
                    return;
                }
                var parts = decodeURIComponent(gameData.wanfaDesp).split(',');
                var appname = "株洲斗牌";
                if(gameData.appId == APP_ID_QUANMINDOUPAI){
                    appname = "全民风云斗牌";
                }
                var shareText = appname + "\n房号: " + ToDBC(gameData.roomId) + "\n"
                    + (parts.length ? parts.join(', ') + ', ' : "") + "速度来啊！";
                savePasteBoard(shareText);
                console.log(shareText);
                showMessage("您的房间信息已复制，请粘贴至微信处分享", {fontName: "res/fonts/FZZY.TTF"});
            });

            TouchUtils.setOnclickListener($("location_btn"), function () {
                if (position2playerArrIdx[1] >= gameData.players.length)
                    return;

                that.addChild(new PlayerLocationInfoLayer(position2playerArrIdx, 1));
            });
            TouchUtils.setOnclickListener($("btn_list_bg.location2_btn"), function () {

                // that.showPlayerInfoPanel(1);
                if (position2playerArrIdx[1] >= gameData.players.length)
                    return;

                that.addChild(new PlayerLocationInfoLayer(position2playerArrIdx, 1));
            });

            TouchUtils.setOnclickListener($("info1"), function () {
                that.showPlayerInfoPanel(1);
            });

            TouchUtils.setOnclickListener($("info2"), function () {
                that.showPlayerInfoPanel(2);
            });
            TouchUtils.setOnclickListener($("info3"), function () {
                that.showPlayerInfoPanel(3);
            });

            TouchUtils.setOnclickListener($("info4"), function () {
                that.showPlayerInfoPanel(4);
            });
            TouchUtils.setOnclickListener($("info5"), function () {
                that.showPlayerInfoPanel(5);
            });

            TouchUtils.setOnclickListener($('btn_fanhui'), function () {
                if (window.inReview)
                    network.send(3003, {room_id: gameData.roomId});
                else {
                    if(that.getRoomState()==ROOM_STATE_CREATED){
                        if (gameData.uid != gameData.ownerUid || gameData.clubCreater) {
                            alert2('确定要退出房间吗?', function () {
                                network.send(3003, {room_id: gameData.roomId});
                            }, null, false, true, true);
                        }else{
                            alert2('解散房间不扣房卡，是否确定解散？', function () {
                                network.send(3003, {room_id: gameData.roomId});
                            }, null, false, false, true, true);
                        }
                    }else{
                        alert2('确定要申请解散房间吗?', function () {
                            network.send(3009, {room_id: gameData.roomId, is_accept: 1});
                        }, null, false, true, true);
                    }
                }
            });

            TouchUtils.setOnclickListener($('btn_jiesan'), function () {
                if (window.inReview)
                    network.send(3003, {room_id: gameData.roomId});
                else
                    alert2('解散房间不扣房卡，是否确定解散？', function () {
                        network.send(3003, {room_id: gameData.roomId});
                    }, null, false, false, true, true);
            });

            TouchUtils.setOnclickListener($('btn_begin'), function () {
                network.send(3005, {room_id: gameData.roomId});
            });


            TouchUtils.setOnclickListener($('btn_list_bg.setting'), function () {
                // var settingsLayer = new SettingsLayer('申请解散房间', function () {
                // });
                // that.addChild(settingsLayer);

                var setting = HUD.showLayer(HUD_LIST.Settings, that);
                setting.setSetting(that, "zjh");//大厅里面打开界面
                setting.setSettingLayerType({hidejiesan: that});
            });
            TouchUtils.setOnclickListener($('btn_list_bg.btn_exit'), function () {
                alert2('确定要申请解散房间吗?', function () {
                    network.send(3009, {room_id: gameData.roomId, is_accept: 1});
                }, null, false, true, true);
            });
            TouchUtils.setOnclickListener($('btn_list'), function () {
                that.onListBtnAni();
            });

            // this.changeVoice();
            network.addListener(3002, function (data) {
                gameData.last3002 = data;
                if (isReplay) {
                    gameData.wanfaDesp = data['desp'];
                    mapId = gameData.mapId = data["map_id"];
                    var wanfa = $("word_wanfa_" + gameData.mapId);
                    if (wanfa)
                        wanfa.setVisible(true);
                }
                if (that.getRoomState() == ROOM_STATE_CREATED) {
                    gameData.ownerUid = data["owner"];
                    gameData.players = data["players"];
                    that.onPlayerEnterExit();
                }
                gameData.daikaiPlayer = data['daikai_player'];
                gameData.clubCreater = data['is_club'];
                pokerRule.changeAvailableCardTypes(gameData.mapId);
            });
            network.addListener(3003, function (data) {
                var uid = data["uid"];
                if (uid == gameData.uid) {
                    HUD.showScene(HUD_LIST.Home, null);
                    if (data['is_kick']) {
                        setTimeout(
                            function () {
                                alert1("您被【" + uid2playerInfo[gameData.ownerUid].nickname + "】踢出房间");
                            }, 100
                        );
                    }
                    return;
                }
                if (data['is_kick']) {
                    if (gameData.uid != gameData.ownerUid) {
                        setTimeout(
                            function () {
                                alert1("【" + uid2playerInfo[uid].nickname + "】被【" + uid2playerInfo[gameData.ownerUid].nickname + "】踢出房间");
                            }, 100
                        );
                    }
                }
                if (that.getRoomState() == ROOM_STATE_ONGOING)
                    return;
                if (data["del_room"]) {
                    var owner = uid2playerInfo[gameData.ownerUid];
                    if (owner) {
                        alert1("房主" + owner.nickname + "已解散房间", function () {
                            HUD.showScene(HUD_LIST.Home, null);
                        });
                    }else{
                        alert1("房主已解散房间", function () {
                            HUD.showScene(HUD_LIST.Home, null);
                        });
                    }
                }
                else {
                    var uid = data["uid"];
                    _.remove(gameData.players, function (player) {
                        return player.uid == uid;
                    });
                    that.onPlayerEnterExit();
                }
            });
            network.addListener(3004, function (data) {
                if (that.getRoomState() != ROOM_STATE_ENDED || !data)
                    return;
                var uid = data["uid"];
                that.setReady(uid);
            });
            network.addListener(3013, function (data) {
                gameData.numOfCards = data["numof_cards"];
            });
            network.addListener(3005, function (data) {
            });
            network.addListener(3008, function (data) {
                var uid = data["uid"];
                var type = data["type"];
                var voice = data["voice"];
                var content = decodeURIComponent(data["content"]);
                that.showChat(uid2position[uid], type, content, voice, uid);
            });
            network.addListener(3009, function (data) {
                var arr = data["arr"];
                var isJiesan = data["is_jiesan"];
                var refuseUid = data["refuse_uid"];
                var leftSeconds = data["left_sec"];
                leftSeconds = (leftSeconds < 0 ? 0 : leftSeconds);
                if (isJiesan) {
                    var nicknameArr = [];
                    for (var i = 0; i < arr.length; i++) {
                        nicknameArr.push("【" + gameData.playerMap[arr[i].uid].nickname + "】");
                    }
                    var shenqingjiesanLayer = $("shenqingjiesan", that);
                    if (shenqingjiesanLayer)
                        shenqingjiesanLayer.removeFromParent();
                    alert1("经玩家" + nicknameArr.join(",") + "同意, 房间解散成功", function () {
                    });

                    that.scheduleOnce(function(){
                        var tipLayer = HUD.getTipLayer();
                        if(tipLayer){
                            var MessageBox = tipLayer.getChildByName('MessageBox');
                            if(MessageBox)  MessageBox.removeFromParent();
                        }
                    }, 2);
                }
                else if (refuseUid) {
                    var shenqingjiesanLayer = $("shenqingjiesan", that);
                    if (shenqingjiesanLayer)
                        shenqingjiesanLayer.removeFromParent();
                    alert1("由于玩家【" + gameData.playerMap[refuseUid].nickname + "】拒绝，房间解散失败，游戏继续");
                }
                else {
                    var byUserId = data['arr'][0].uid;

                    var shenqingjiesanLayer = $("shenqingjiesan", that);
                    if (!shenqingjiesanLayer) {
                        shenqingjiesanLayer = new ShenqingjiesanLayer();
                        shenqingjiesanLayer.setName("shenqingjiesan");
                        that.addChild(shenqingjiesanLayer);
                    }
                    shenqingjiesanLayer.setArrMajiang(leftSeconds, arr, byUserId,data);
                }
            });
            network.addListener(4500, function (data) {
                $("btn_zhunbei").setVisible(false);
                var uid = data["uid"];
                var row = uid2position[uid];
                that.ZJHthrowTurn(row, data);
            });

            network.addListener(3502, function (data) {
                $('btn_begin').setVisible(true);
                // lightButton($('btn_begin'), 0, 0, res.Btn_StartGame_stencil_png);
            });
            network.addListener(4503, function (data) {
                $("btn_zhunbei").setVisible(false);
                $('top_panel.chipnum').setString(data['total_chip']);
                var uid = data["uid"];
                var arr = data["pai_arr"];
                var op = data['op'];
                var cardtype = data['card_type'];
                // NONE, QI, GEN, JIA, BI, KAN
                // var NONE = op[0];
                var QI = op[0];
                var GEN = op[1];
                var JIA = op[2];
                var BI = op[3];
                var KAN = op[4];
                var row = uid2position[data.from_uid];
                // if (row == 2) {
                //     if (!data['has_xia']) {
                //         $('top_panel_mine').setVisible(false);
                //     } else {
                //         $('top_panel_mine').setVisible(true);
                //         $('top_panel_mine.yixianum').setString(data['has_xia']);
                //     }
                // }
                if (!data['has_xia']) {
                    $('info' + row + '.minexia').setVisible(false);
                }else{
                    $('info' + row + '.minexia').setVisible(true);
                    $('info' + row + '.minexia.yixianum').setString(data['has_xia']);
                }
                if (!isReplay) {
                    if (row == 2) {
                        if (cardtype && cardtype != '' ) {
                            $('row2.cardtype').setVisible(true);
                            $('row2.cardtype').loadTexture('res/image/ui/zjh/character/cardtype' + cardtype + '.png');
                        } else {
                            $('row2.cardtype').setVisible(false);
                        }
                    }
                    $("kan").setVisible(!!data['kan']);
                    // that.setBtnEnableState('ops.kan',!!data['kan']);
                }
                if (QI) {
                    //扔牌动画
                    if (!isReplay) {
                        if (row == 2) {
                            $("kan").setVisible(false);
                            // that.setBtnEnableState('ops.kan',false);
                            $('jia').setVisible(false);
                            var delay = that.checkPaiAnim(2, arr) ? 1000 : 0;
                            setTimeout(function () {
                                $('row' + row + 'b').setVisible(true);
                                for (var i = 0; i < 3; i++) {
                                    $('row' + row + 'b.b' + i).setVisible(false);
                                }
                                that.updateCardStatusZJH(row, 'qi');
                            }, delay);
                        } else {
                            $('row' + row + '.a0').setVisible(false);
                            $('row' + row + '.a1').setVisible(false);
                            $('row' + row + '.a2').setVisible(false);
                            $('row' + row + '.cardtype').setVisible(false);
                            that.updateCardStatusZJH(row, 'qi');
                        }
                    } else {
                        $('row' + row).setVisible(false);
                        $('row' + row + 'b').setVisible(true);
                        $('row' + row + 'b.b0').setVisible(true);
                        $('row' + row + 'b.b1').setVisible(true);
                        $('row' + row + 'b.b2').setVisible(true);
                        that.updateCardStatusZJH(row, 'qi');
                    }
                    playEffect('vgive_up_bg');
                    playEffect('vgive_up', position2sex[row]);
                    for (var i = 0; i < 3; i++) {
                        $('row' + row + 'b.b' + i).setTexture('res/image/ui/zjh/unit/pai_backhui.png');
                    }
                    that.wordsFly(row, '弃拍');
                }
                if (GEN) {
                    //筹码动画
                    playEffect('vfollow_chip_bg');
                    var idx = 0;
                    if (that.gen_round && that.gen_round > 1) {
                        idx = Math.floor(Math.random() * 2) + 1;
                    }
                    playEffect('vfollow_chip' + idx, position2sex[row]);
                    that.throwCMAnim(row, data['needchip']);
                    that.wordsFly(row, '跟注' + data['needchip']);
                }
                if (JIA) {
                    //筹码动画
                    playEffect('vadd_chip_bg');
                    playEffect('vadd_chip', position2sex[row]);
                    that.throwCMAnim(row, data['needchip']);
                    that.wordsFly(row, '加注' + data['needchip']);
                    if (!isReplay) {
                        $('ops.gen.txt').setString(''+data.genchip);//('跟注x' + data.genchip);
                        $('ops.bi.txt').setString(''+(data.genchip*that.getBipaiRate()));
                    }
                }
                if (BI) {
                    data['zhu_shu'] = data['zhu_shu'] || 1;
                    for (var i = 0; i < data['zhu_shu']; i++) {
                        that.throwCMAnim(row, data['needchip']);
                    }
                    if (!isReplay) {
                        network.stop();
                        for (var i = 1; i < 6; i++) {
                            //头像变正常
                            // if ($('info' + i + '.head_bg_anmi').isVisible()) {
                            //     $('info' + i + '.head_bg_anmi').stopAllActions();
                            //     $('info' + i + '.head_bg_anmi').setVisible(false);
                            // }
                            // (function (idx) {
                            //     TouchUtils.setOnclickListener($('info' + idx), function () {
                            //         that.showPlayerInfoPanel(idx);
                            //     });
                            // })(i);
                            if($('row'+i+'b.bi_rect_sp')){
                                $('row'+i+'b.bi_rect_sp').setVisible(false);
                                $('row'+i+'b.bi_rect_sp').removeAllChildren();
                                TouchUtils.removeListeners($('row'+i+'b.bi_rect_sp'));
                            }
                        }
                        $('choose_player_bi').setVisible(false);
                        $('ops.qi').setVisible(true);
                        $('ops.gen').setVisible(true);
                        $('ops.jia').setVisible(true);
                        $("ops.bi").setVisible(true);
                        $("ops.kan").setVisible(true);
                        $("ops.canclebi").setVisible(false);
                        TouchUtils.removeListeners($('ops.shield'));
                    }
                    playEffect('vcompare_bg');
                    playEffect('vcompare', position2sex[row]);
                    that.biPaiAnim(row, uid2position[data['win_uid']], uid2position[data['lose_uid']], function () {
                        network.start();
                        if (isReplay) {
                            $('row' + uid2position[data['lose_uid']]).setVisible(false);
                            $('row' + uid2position[data['lose_uid']] + 'b').setVisible(true);
                            $('row' + uid2position[data['lose_uid']] + 'b.b0').setVisible(true);
                            $('row' + uid2position[data['lose_uid']] + 'b.b1').setVisible(true);
                            $('row' + uid2position[data['lose_uid']] + 'b.b2').setVisible(true);
                            that.updateCardStatusZJH(uid2position[data['lose_uid']], 'shu');
                        }
                        for (var i = 0; i < 3; i++) {
                            $('row' + uid2position[data['lose_uid']] + 'b.b' + i).setTexture('res/image/ui/zjh/unit/pai_backold.png');
                        }
                        if (!isReplay) {
                            if (uid2position[data['lose_uid']] != 2) {
                                $('row' + uid2position[data['lose_uid']] + '.a0').setVisible(false);
                                $('row' + uid2position[data['lose_uid']] + '.a1').setVisible(false);
                                $('row' + uid2position[data['lose_uid']] + '.a2').setVisible(false);
                                $('row' + uid2position[data['lose_uid']] + '.cardtype').setVisible(false);
                                that.updateCardStatusZJH(uid2position[data['lose_uid']], 'shu');
                            }
                            if (_.isArray(data['pai_arr']) && data['pai_arr'].length > 0) {
                                var delay = that.checkPaiAnim(2, data['pai_arr']) ? 1000 : 0;
                                if (data.card_type && data.card_type != '' && data.card_type != "0") {
                                    $('row2.cardtype').setVisible(true);
                                    $('row2.cardtype').loadTexture('res/image/ui/zjh/character/cardtype' + data.card_type + '.png');
                                }
                                if (uid2position[data['lose_uid']] == 2) {
                                    setTimeout(function () {
                                        $('row2b').setVisible(true);
                                        for (var i = 0; i < 3; i++) {
                                            $('row2b.b' + i).setVisible(false);
                                        }
                                        that.updateCardStatusZJH(2, 'shu');
                                    }, delay);
                                }
                            }
                        }
                        if (isReplay && that.operateFinishCb) {
                            that.operateFinishCb();
                        }
                    });
                }
                if (KAN) {
                    if (!isReplay && row == 2) {
                        g_kanpai = true;
                        var kanpaiFunc = function () {
                            that.checkPaiAnim(2, arr);
                            // for (var k = 2; k <= 5; k++) {
                            //     $('jia.jia' + k + '.txt').setString('x ' + (2 * k));
                            // }
                            that.jiaBtnTextureShow(2);
                            $('ops.gen.txt').setString(''+data.needchip);//('跟注x' + data['needchip'])
                            $('ops.bi.txt').setString(''+(data.needchip*that.getBipaiRate()));

                        }
                        if(isCuopaiOps){
                            that.addChild(new CuopaiLayer(arr, kanpaiFunc));
                        }else{
                            kanpaiFunc();
                        }
                    }

                    if (row != 2) {
                        playEffect('vlook_card_bg');
                        playEffect('vlook_card', position2sex[row]);
                        that.wordsFly(row, '看牌');
                        that.updateCardStatusZJH(row, 'kan');
                    }
                    if (isReplay) {
                        $('row' + row + 'b').setVisible(true);
                        $('row' + row + 'b.b0').setVisible(false);
                        $('row' + row + 'b.b1').setVisible(false);
                        $('row' + row + 'b.b2').setVisible(false);
                        that.updateCardStatusZJH(row, 'kan');
                    }
                    that.wordsFly(row, '看牌');
                    if(row==2){
                        selfCurrentBtnStates['kan']=false;
                    }
                }
                if (isReplay && !BI && that.operateFinishCb) {
                    that.operateFinishCb();
                }
            });
            network.addListener(4504, function (data) {
                $('ops.qi').setVisible(false);
                $('ops.bi').setVisible(false);
                $('ops.gen').setVisible(false);
                $('ops.jia').setVisible(false);
                $("ops.kan").setVisible(false);
                $('ops.canclebi').setVisible(true);
                TouchUtils.removeListeners($('ops.shield'));
                for (var i = 0; i < data['canbi_arr'].length; i++) {
                    //头像变亮
                    $('choose_player_bi').setVisible(true);
                    var row = uid2position[data['canbi_arr'][i]];
                    if(cc.sys.isNative) {
                        var anim = playSpAnimation('vs1', row == 1 || row == 5 ? 'kuang2' : 'kuang', true);
                        anim.x = 98;
                        anim.y = 74;
                        $('row' + row + 'b.bi_rect_sp').addChild(anim);
                        $('row' + row + 'b.bi_rect_sp').setVisible(true);
                        (function (idx) {
                            TouchUtils.setOnclickListener($('row' + uid2position[data['canbi_arr'][idx]] + "b.bi_rect_sp"), function () {
                                network.send(4503, {room_id: gameData.roomId, op: 4, bi_uid: data['canbi_arr'][idx]});
                            });
                        })(i);
                    }
                }
            });
            network.addListener(3200, function (data) {
                return;
                // that.content = decodeURIComponent(data['content']);
                // var func = function () {
                //     if (!that || !cc.sys.isObjectValid(that)) {
                //         return;
                //     }
                //     var _speaker = $('speaker');
                //     if (_speaker.isVisible()) {
                //         return;
                //     }
                //     _speaker.setVisible(true);
                //     var speakerPanel = $('speaker.panel');
                //     var text = new ccui.Text();
                //     text.setFontSize(26);
                //     text.setColor(cc.color(254, 245, 92));
                //     text.setAnchorPoint(cc.p(0, 0));
                //     text.enableOutline(cc.color(0, 0, 0), 1);
                //     speakerPanel.removeAllChildren();
                //     speakerPanel.addChild(text);
                //     text.setString(that.content);
                //     text.setPositionX(speakerPanel.getContentSize().width);
                //     text.setPositionY((speakerPanel.getContentSize().height - text.getContentSize().height) / 2);
                //     text.runAction(cc.sequence(
                //         cc.moveTo(20, -text.getVirtualRendererSize().width, 0),
                //         cc.callFunc(function () {
                //             $('speaker').setVisible(false);
                //         })
                //     ));
                // };
                // func();
                // if (this.interval == null) {
                //     this.interval = setInterval(func, 25000);
                // }
            });
            network.addListener(4008, function (data) {
                network.start()
                that.setRoomState(ROOM_STATE_ENDED);
                that.jiesuan(data);
            });
            network.addListener(4009, function (data) {
                network.start()
                that.zongJiesuan(data);
                MWUtil.clearRoomId();//用于清空房间id
            });
            network.addListener(4010, function (data) {
                var msg = data.msg;
                that.showToast(decodeURIComponent(msg));
            });
            network.addListener(4020, function (data) {
                var uid = data["uid"];
                var isOffline = data["is_offline"];
                that.playerOnloneStatusChange(uid2position[uid], isOffline);
            });
            /**
             * 服务器广播切牌状态
             */
            network.addListener(4110, function (data) {
                //{'code':4111,'data':{'room_id':%d,'qiepai_uid':%d,'pai_index':%d}}
                //{'code':4110,'data':{'room_id':%d,'qiepai_uid':%d}
                // if(data['qiepai_uid']== gameData.uid){
                //     console.log("自己切牌中 ");
                // }else{
                //     console.log("等待别人切牌----");
                // }
                $('chipnode').removeAllChildren();
                $('top_panel.chipnum').setString('0');
                if (!isReplay) {
                    for (var i = 1; i < 6; i++) {
                        for (var j = 0; j < 3; j++) {
                            $('row' + i + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_back3.png');
                            $('row' + i + 'b.b' + j).setVisible(false);
                        }
                    }
                    gameData.totalRound = data["total_round"];
                }
                gameData.leftRound = data["left_round"];
                that.setRoomState(ROOM_STATE_ONGOING);
                that.clearTable4StartGame(true);
                // $('top_panel_mine').setVisible(true);
                // $('top_panel_mine.yixianum').setString(0);
                for (var i = 0; i < gameData.players.length; i++) {
                    var rowid = uid2position[gameData.players[i].uid];
                    $("row" + rowid + 'b').setVisible(true);
                    $("row" + rowid).setVisible(false);
                    $('info'+rowid+'.minexia').setVisible(true);
                    $('info'+rowid+'.minexia.yixianum').setString('0');
                }
                for (var i = 1; i < 6; i++) {
                    that.updateCardStatusZJH(i);
                }
                $("kan").setVisible(false);
                // that.setBtnEnableState('ops.kan',false);

                //切牌
                fapaiLayer = fapaiLayer || new FapaiUpdateLayer(
                        that.calcPaisInfo(data),
                        function () {
                            network.start();
                        }
                    );
                network.stop([3009,3008,4111,4020,4008,4009,3004,4990]);
                if(!fapaiLayer.getParent()){
                    that.addChild(fapaiLayer);
                }
                fapaiLayer.wholeProcess(that.calcPaisInfo(data));
            });
            network.addListener(4111, function (data) {
                //{'code':4111,'data':{'room_id':%d,'qiepai_uid':%d,'pai_index':%d}}
                // if(data['qiepai_uid']== gameData.uid){
                //     console.log("自己切牌中 ");
                //     setTimeout(function () {
                //         network.send(4111, {'qiepai_uid':gameData.uid,'pai_index':25});
                //     }, 50);
                // }else{
                //     console.log("等待别人切牌----");
                // }
                if(fapaiLayer){
                    fapaiLayer.choosePaiForCut(data['pai_index']);
                }
            });
            /**
             * 发牌
             */
            network.addListener(4200, function (data) {
                g_kanpai = false;
                $('chipnode').removeAllChildren();
                $('top_panel.chipnum').setString('0');
                if (!isReplay) {
                    for (var i = 1; i < 6; i++) {
                        for (var j = 0; j < 3; j++) {
                            $('row' + i + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_back3.png');
                            $('row' + i + 'b.b' + j).setVisible(false);
                        }
                    }
                    gameData.totalRound = data["total_round"];
                }
                gameData.leftRound = data["left_round"];

                that.setRoomState(ROOM_STATE_ONGOING);
                that.clearTable4StartGame(true);
                // $('top_panel_mine').setVisible(true);
                // $('top_panel_mine.yixianum').setString(0);
                for (var i = 0; i < gameData.players.length; i++) {
                    var rowid = uid2position[gameData.players[i].uid];
                    $("row" + rowid + 'b').setVisible(true);
                    $("row" + rowid).setVisible(false);
                    $('info'+rowid+'.minexia').setVisible(true);
                    $('info'+rowid+'.minexia.yixianum').setString('0');
                }
                for (var i = 1; i < 6; i++) {
                    that.updateCardStatusZJH(i);
                }

                var fapaiOverCb = function () {
                    //原来函数里面必须执行函数
                    var row_list = [2, 1, 5, 4, 3];
                    for (var i = 0; i < gameData.players.length; i++) {
                        var row = row_list[i];
                        // if (!$('row' + row + 'b').isVisible()) break;
                        for (var j = 0; j < 3; j++) {
                            var pai = $('row' + row + 'b.b' + j);
                            pai.setVisible(true);
                        }
                    }

                    // $('top_panel_mine.yixianum').setString(1);
                    for (var i = 0; i < gameData.players.length; i++) {
                        that.throwCMAnim(uid2position[gameData.players[i].uid], 1);
                        $('info'+uid2position[gameData.players[i].uid]+'.minexia.yixianum').setString('1');
                    }
                    if (!isReplay) {
                        $('ops').setVisible(true);
                        $('ops.gen.txt').setString('1');//('跟注x1');
                        $('ops.bi.txt').setString('' + that.getBipaiRate());
                    } else {
                        for (var _uid in data.pai_arr) {
                            if (data.pai_arr.hasOwnProperty(_uid) && _uid && _uid != '0') {
                                var _row = uid2position[parseInt(_uid)];
                                if (_row) {
                                    that.checkPaiAnim(_row, data.pai_arr[_uid].pai);
                                    (function (__row, __uid) {
                                        if(data.pai_arr[__uid].cardtype && data.pai_arr[__uid].cardtype!='0'){
                                            $('row' + __row + '.cardtype').setVisible(true);
                                            $('row' + __row + '.cardtype').loadTexture('res/image/ui/zjh/character/cardtype' + data.pai_arr[__uid].cardtype + '.png');
                                        }
                                    })(_row, _uid);
                                }
                            }
                        }
                        setTimeout(function () {
                            if (that.operateFinishCb) {
                                that.operateFinishCb();
                            }
                        }, 1000);
                    }

                    network.start();
                }

                if(decodeURIComponent(gameData.wanfaDesp).indexOf('切牌')>=0 || isReplay){
                    fapaiOverCb();
                }else{
                    fapaiLayer = fapaiLayer || new FapaiUpdateLayer(
                            that.calcPaisInfo(data),
                            fapaiOverCb
                        );
                    network.stop([3008,4020]);
                    if(!fapaiLayer.getParent()){
                        that.addChild(fapaiLayer);
                    }
                    fapaiLayer.sendPai();
                }

            });

            network.start();
            isCCSLoadFinished = true;
            playMusic("vbg6");

            pokerRule.changeAvailableCardTypes(gameData.mapId);
            if (isReplay) {
                $("top_panel").setVisible(false);
            }
            if (!isReplay) {
                var wanfa = $("word_wanfa_" + gameData.mapId);
                if (wanfa)
                    wanfa.setVisible(true);
            }
            // $('speaker').setVisible(false);

            that.showFangzhu();
        },
        onListBtnAni:function(hide){
            var view = $('btn_list_bg');
            if(hide){
                if (view.isVisible()) {
                    view.stopAllActions();
                    view.runAction(cc.sequence(cc.scaleTo(0.15, 1, 0).easing(cc.easeOut(3)), cc.callFunc(function () {
                        view.setVisible(false);
                    })));
                }
            }else {
                if (view.isVisible()) {
                    view.stopAllActions();
                    view.runAction(cc.sequence(cc.scaleTo(0.15, 1, 0).easing(cc.easeOut(3)), cc.callFunc(function () {
                        view.setVisible(false);
                    })));
                } else {
                    view.setVisible(true);
                    view.stopAllActions();
                    view.runAction(cc.sequence(cc.scaleTo(0.15, 1, 1).easing(cc.easeIn(3)), cc.callFunc(function () {
                        view.setVisible(true);
                    })));
                }
            }
        },
        getUserHeaderData: function () {
            var data = {};
            var players = gameData.players;
            var scale = cc.view.getFrameSize().width / cc.director.getWinSize().width;
            var theight = cc.view.getFrameSize().height / scale;
            var boardHeight = (theight - cc.director.getWinSize().height) / 2;
            // console.log("boardHeight = " + boardHeight);
            for (var i = 0; i < players.length; i++) {
                var player = players[i];
                var pos = uid2position[player.uid];
                var header = $('info' + pos + '.head');
                var headerPos = header.convertToWorldSpace(cc.p(0, 0));
                var width = header.getBoundingBox().width;
                var height = header.getBoundingBox().height;
                var x = headerPos.x;
                var y = headerPos.y + height - boardHeight;
                data[player.uid] = {
                    x: x-1,
                    y: y-1,
                    width: width+2,
                    height: height+2
                };
            }
            return JSON.stringify(data);
        },
        showFangzhu: function () {
            if (gameData.daikaiPlayer) {
                $('fangzhuheader').setVisible(true);
                loadImageToSprite(gameData.daikaiPlayer['headimgurl'], $('fangzhuheader.header'));
                $('fangzhuheader.name').setString(ellipsisStr(gameData.daikaiPlayer['nickname']));
            } else {
                $('fangzhuheader').setVisible(false);
            }
        },
        onExit: function () {
            if (this.chatLayer)
                this.chatLayer.release();
            if (this.chiLayer)
                this.chiLayer.release();
            if (this.throwDiceLayer)
                this.throwDiceLayer.release();
            if (this.kaigangLayer)
                this.kaigangLayer.release();
            if (this.interval) {
                clearInterval(this.interval);
                this.interval = null;
            }
            network.removeListeners([
                3002, 3003, 3004, 3005, 3008, 3200,
                4000, 4001, 4002, 4003, 4004, 4008, 4009, 4020, 4200, 4888, 4889, 4890
            ]);
            AgoraUtil.closeVideo();
            cc.Layer.prototype.onExit.call(this);
        },
        onPlayerEnterExit: function () {
            var that = this;
            var players = gameData.players;
            for (var i = 0; i < players.length; i++) {
                var player = players[0];
                if (player.uid != gameData.uid) {
                    players.splice(0, 1);
                    players.push(player);
                }
                else {
                    gameData.location = player.loc;
                    break;
                }

            }
            $("timer").setUserData({delta: i});
            uid2position = {};
            position2playerArrIdx = {};
            for (var i = 0, j = 2; i < players.length; i++, j++) {
                var player = players[i];
                var k = {
                    5: {0: 4, 1: 3, 2: 2, 3: 1, 4: 5},
                    4: {0: 0, 1: 3, 2: 2, 3: 1},
                    3: {0: 1, 1: 3, 2: 2}
                }[playerNum][j % playerNum];

                $("info" + k).setVisible(true);
                $("info" + k + ".lb_nickname").setString(ellipsisStr(player["nickname"], (k == 0 || k == 2 ? 7 : 5)));
                $("info" + k + ".lb_score").setString((roomState == ROOM_STATE_CREATED) ? 0 : player["score"]);
                //此处服务器传输数据错误 前端强制修改
                // if (data && data['player_pai'] && (roomState == ROOM_STATE_CREATED) ? 0 : player["score"]==-1) {
                //     var _idx = -1;
                //     for(var z=0; z<data['player_pai'].length; z++){
                //         if(data['player_pai'][z].uid == player.uid){
                //             _idx = z;
                //         }
                //     }
                //     if (_idx!=-1)
                //         $("info" + k + ".lb_score").setString(data['player_pai'][_idx]["total_score"]);
                // }

                if (roomState == ROOM_STATE_CREATED)
                    $("info" + k + ".ok").setVisible(!!player["ready"]);
                loadCircleConorToSprite(player["headimgurl"], $("info" + k + ".head"));

                uid2position[player.uid] = k;
                uid2playerInfo[player.uid] = player;
                position2uid[k] = player.uid;
                position2sex[k] = player.sex;
                position2playerArrIdx[k] = i;
            }

            for (; i < playerNum; i++, j++) {
                var k = {
                    4: {0: 0, 1: 3, 2: 2, 3: 1},
                    5: {0: 4, 1: 3, 2: 2, 3: 1, 4: 5},
                    3: {0: 1, 1: 3, 2: 2}
                }[playerNum][j % playerNum];
                $("info" + k).setVisible(false);
            }

            if (players.length >=2 && roomState == ROOM_STATE_ONGOING && gameData.shipin>0 && !isInitShipin && !isReplay) {
                AgoraUtil.initVideoView(this.getUserHeaderData());
                setTimeout(function () {
                    AgoraUtil.openVideo(gameData.roomId.toString(), gameData.uid.toString());
                }, 1000);
                setTimeout(function () {
                    var perVal = PermissionUtils.isHasAudioPermission() && PermissionUtils.isHasVideoPermission();
                    if(!perVal){
                        alert2("请在手机系统设置面板开启摄像头、麦克风权限", function () {
                            PermissionUtils.settingPermissionBySystem();
                        }, function () {

                        });
                    }
                }, 2000);
                isInitShipin = true;
            }

            // if (players.length >= playerNum && roomState == ROOM_STATE_CREATED) {
            //     setTimeout(function () {
            //         if (that && cc.sys.isObjectValid(that) && players.length >= playerNum && !isReplay && roomState == ROOM_STATE_CREATED) {
            //             network.disconnect();
            //         }
            //     }, 4000);
            // }
        },
        calcPosConf: function () {
            // if (window.posConf) {
            //     posConf = window.posConf;
            //     return;
            // }
            posConf.paiADistance[0] = 0;
            var arr =  [1, 2, 3, 4, 5];
            for (var i = 0; i < arr.length; i++) {
                var row = arr[i];

                var ltqp = $("info" + row + ".qp");
                if (ltqp) {
                    posConf.ltqpPos[row] = ltqp.getPosition();
                    posConf.ltqpRect[row] = cc.rect(0, 0, ltqp.getContentSize().width, ltqp.getContentSize().height);
                    posConf.ltqpEmojiSize[row] = cc.size({
                        3: {
                            0: 80,
                            1: 90,
                            2: 84,
                            3: 100
                        },
                        5: {
                            1: 90,
                            2: 84,
                            3: 100,
                            4: 100,
                            5: 90
                        }
                    }[playerNum][row], posConf.ltqpRect[row].height);
                    ltqp.removeFromParent();
                }
            }
            // window.posConf = posConf;
        },
        ctor: function (_data, _isReplay) {
            this._super();

            clearVars();

            var that = this;
            forRows = function (cb) {
                cb.call(that, 1);
                cb.call(that, 2);
                if (gameData.players.length >= 3) {
                    cb.call(that, 3);
                }
                if (gameData.players.length >= 4) {
                    cb.call(that, 4);
                }
                if (gameData.players.length >= 5) {
                    cb.call(that, 5);
                }
            };

            data = _data;
            isReconnect = !!_data;
            isReplay = !!_isReplay;

            network.stop();


            loadCCSTo(res.PkSceneZJH_json, this, "Scene");


            return true;
        },
        startSignal: function () {
            var that = this;
            var interval = null;
            var lastDealy = -1;
            var func = function () {
                if (!that || !cc.sys.isObjectValid(that))
                    return clearInterval(interval);
                var delay = network.getLastPingInterval();
                if (delay == lastDealy)
                    return;
                //console.log("delay " + delay);
                lastDealy = delay;
                if (NetUtils.isWAN()) {
                    if (delay < 200) $("signal").setTexture(zjh_signal4);
                    else if (delay < 400) $("signal").setTexture(zjh_signal3);
                    else if (delay < 600) $("signal").setTexture(zjh_signal2);
                    else $("signal").setTexture(zjh_signal1);
                } else if(NetUtils.isWifi()) {
                    if (delay < 200) $("signal").setTexture(wifi_signal4);
                    else if (delay < 400) $("signal").setTexture(wifi_signal3);
                    else if (delay < 600) $("signal").setTexture(wifi_signal2);
                    else $("signal").setTexture(wifi_signal1);
                }
            };
            func();
            interval = setInterval(func, 200);

            //如果视频房判断网络 并提示玩家
            if(NetUtils.isWAN() && gameData.shipin>0){
                alert1("您当前为移动网络，已经进入视屏房，耗费流量较大。");
            }
        },
        startTime: function () {
            var interval = null;
            var flag = true;
            var lbTime = $("lb_time");
            var battery = $("battery_bg.battery");
            if (isReplay)
                return;
            var updTime = function () {
                var date = new Date();
                var minutes = (date.getMinutes() < 10 ? "0" : "") + date.getMinutes();
                var hours = (date.getHours() < 10 ? "0" : "") + date.getHours();
                if (cc.sys.isObjectValid(lbTime))
                    lbTime.setString(hours + ":" + minutes);
                else if (interval)
                    clearInterval(interval);
                var level = DeviceUtils.getBatteryLevel();
                if (cc.sys.isObjectValid(battery)) {
                    battery.setPercent(level);
                }
            };
            updTime();
            interval = setInterval(updTime, 1000);
        },
        isMyTurn: function () {
            return turnRow == 2;
        },
        throwTurnByUid: function (uid) {
            this.throwTurn(uid2position[uid]);
        },
        shakePais : function (isStop) {
            for(var i=0; i<3; i++){
                var pai = $('row2b.b' + i);
                if(isStop){
                    pai.stopAllActions();
                    pai.setRotation(0);
                    continue;
                }
                var isReverse = 0.7;
                if(i==1){
                    isReverse = -0.7;
                }
                pai.runAction(cc.sequence(cc.delayTime(5), cc.callFunc(function (target,isReverse) {
                    target.runAction(cc.repeatForever(cc.sequence(
                        cc.rotateTo(0.18,3 * isReverse).easing(cc.easeInOut(3)),
                        cc.rotateTo(0.16, -3* isReverse).easing(cc.easeInOut(3)),
                        cc.rotateTo(0.14, 2* isReverse).easing(cc.easeInOut(2)),
                        cc.rotateTo(0.12, -2* isReverse).easing(cc.easeInOut(2)),
                        cc.rotateTo(0.09, 1* isReverse).easing(cc.easeInOut(3)),
                        cc.rotateTo(0.04, -1* isReverse).easing(cc.easeInOut(3))
                    )));
                },pai, isReverse)))

            }
        },
        ZJHthrowTurn: function (row, data) {
            var that = this;
            this.countDown(row, 12);
            $('top_panel').setVisible(true);
            $('top_panel.chipnum').setString(data['total_chip']);
            $('top_panel.gennum').setString(data['gen_round'][0] + '/' + data['gen_round'][1]);
            that.gen_round = data['gen_round'][0];
            $('top_panel.binum').setString(data['bi_round'][0] + '/' + data['bi_round'][1]);
            $('top_panel.mennum').setString(data['men_round'][0] + '/' + data['men_round'][1]);
            if (!isReplay) {
                if (row != 2) {
                    that.disableOpsBtns();
                    that.shakePais(true);
                    return;
                }else{
                    that.shakePais(!data['kan']);
                }
                $('kan').setVisible(!!data['kan']);
                // that.setBtnEnableState('ops.kan',!!data['kan']);
                $('ops.gen.txt').setString(''+ data['gen_score']);//('跟注x' + data['gen_score']);
                $('ops.bi.txt').setString(''+ (data['gen_score']*that.getBipaiRate()));

                TouchUtils.removeListeners($('ops.shield'));
                TouchUtils.setOnclickListener($("jia.jia0"), function () {
                    $('ops').setVisible(true);
                    $('jia').setVisible(false);
                });
                for (var i = 5; i > Math.max(data.jia, 1); i--) {
                    that.enableBtn('jia.jia' + i);
                    (function (idx) {
                        TouchUtils.setOnclickListener($("jia.jia" + idx), function () {
                            network.send(4503, {room_id: gameData.roomId, op: 3, bei: idx});
                            $('ops').setVisible(true);
                            $('jia').setVisible(false);
                            that.disableOpsBtns();
                        });
                    })(i)
                }
                for (var i = data['jia']; i > 1; i--) {
                    that.disableBtn('jia.jia' + i, 1);
                }
                //NONE, QI, GEN, JIA, BI, KAN
                TouchUtils.setOnclickListener($("ops.qi"), function () {
                    alert2('确定要弃牌吗?', function () {
                        network.send(4503, {room_id: gameData.roomId, op: 1});
                        that.disableOpsBtns();
                    }, null, false, true, true);
                });
                TouchUtils.setOnclickListener($("ops.gen"), function () {
                    network.send(4503, {room_id: gameData.roomId, op: 2});
                    that.disableOpsBtns();
                });
                TouchUtils.setOnclickListener($("ops.jia"), function () {
                    if($('jia').isVisible()){
                        $('jia').setVisible(false);
                        that.refreshBtnsStatus();
                        return;
                    }
                    // $('ops').setVisible(false);
                    that.disableOpsBtns("ops.jia");
                    $('jia').setVisible(true);

                    for (var k = 2; k <= 5; k++) {
                        //$('jia.jia' + k + '.txt').setString('x ' + (data['read'] ? (2 * k) : k));
                        that.jiaBtnTextureShow((data['read'] ? 2 : 1));
                        if(g_kanpai){
                            //$('jia.jia' + k + '.txt').setString('x ' +(2 * k));
                            that.jiaBtnTextureShow(2);
                        }
                    }

                });
                TouchUtils.setOnclickListener($("ops.bi"), function () {
                    TouchUtils.setOnclickListener($('ops.shield'), function () {

                    });
                    network.send(4503, {room_id: gameData.roomId, op: 4, bi_uid: 0});
                });
                TouchUtils.setOnclickListener($("ops.canclebi"), function () {
                    $('ops.qi').setVisible(true);
                    $('ops.gen').setVisible(true);
                    $('ops.jia').setVisible(true);
                    $("ops.bi").setVisible(true);
                    $("ops.kan").setVisible(true);
                    $('ops.canclebi').setVisible(false);
                    for (var i = 1; i < 6; i++) {
                        //头像变正常
                        // if ($('info' + i + '.head_bg_anmi').isVisible()) {
                        //     $('info' + i + '.head_bg_anmi').stopAllActions();
                        //     $('info' + i + '.head_bg_anmi').setVisible(false);
                        // }
                        // (function (idx) {
                        //     TouchUtils.setOnclickListener($('info' + idx), function () {
                        //         that.showPlayerInfoPanel(idx);
                        //     });
                        // })(i);
                        if($('row'+i+'b.bi_rect_sp')){
                            $('row'+i+'b.bi_rect_sp').removeAllChildren();
                            $('row'+i+'b.bi_rect_sp').setVisible(false);
                            TouchUtils.removeListeners($('row'+i+'b.bi_rect_sp'));
                        }
                    }
                    $('choose_player_bi').setVisible(false);
                });
                if (data['jia'] >= 5) {
                    that.disableBtn('ops.jia');
                } else {
                    that.enableBtn('ops.jia');
                }
                if (!data['bi']) {
                    that.disableBtn('ops.bi');
                } else {
                    that.enableBtn('ops.bi');
                }
                that.enableBtn('ops.qi');
                that.enableBtn('ops.gen');
                selfCurrentBtnStates['jia'] = !(data['jia'] >= 5);
                selfCurrentBtnStates['bi'] = data['bi'];
                selfCurrentBtnStates['kan'] = data['kan'];
                selfCurrentBtnStates['read'] = data['read'];
                selfCurrentBtnStates['qi'] = data['qi'] || true;
                selfCurrentBtnStates['gen'] = true;
            }
        },
        setPai: function (row, idx, val, isVisible) {
            var pai = this.getPai(row, idx);
            var userData = pai.getUserData();
            this.setPaiHua(pai, val, row);
            userData.pai = val < 100 ? val : (Math.floor(val / 100) - 1);
            if (!_.isUndefined(isVisible)) {
                if (isVisible)
                    pai.setVisible(true);
                else
                    pai.setVisible(false);
            }
            return pai;
        },
        setPaiHua: function (pai, val, row) {
            // 改扑克牌面备份
            var a = pai.getChildByName("a");
            var b = pai.getChildByName("b");
            var originValue = null;
            if (val >= 100) {
                originValue = val % 100;
                val = (val - originValue) / 100 - 1;
            }
            var arr = getPaiNameById(val);
            setPokerFrameByName(a, (originValue == null && !pokerRule.isLaizi(val, laiziValue)) ? arr[0] : "b/orange_" + val % 13 + ".png");
            if (val < 52) {
                setPokerFrameByName(b, arr[1]);
                b.setVisible(true);
            } else {
                b.setVisible(false);
            }
            // if (!row || row != 2) {
            //     b.setVisible(false);
            // }
            var c = pai.getChildByName("c");
            if (c && cc.sys.isObjectValid(c)) {
                c.setVisible(true);
                if (val > 51) {
                    c.setVisible(false);
                } else {
                    setPokerFrameByName(c, arr[1]);
                }
            }
            if (pai.getChildByTag(5001)) {
                pai.removeChildByTag(5001, true);
            }
            if (val == 52) {
                var w_1 = new cc.Sprite("res/image/ui/zjh/card/w_1.png");
                pai.addChild(w_1);
                w_1.setTag(5001);
                w_1.setPosition(cc.p(0.5 * pai.getContentSize().width, 0.5 * pai.getContentSize().height));
                w_1.setScale(0.8);
            }
            if (val == 53) {
                var w_2 = new cc.Sprite("res/image/ui/zjh/card/w_2.png");
                pai.addChild(w_2);
                w_2.setTag(5001);
                w_2.setPosition(cc.p(0.5 * pai.getContentSize().width, 0.5 * pai.getContentSize().height));
                w_2.setScale(0.8);
            }
            var laizi = pai.getChildByName('laizi');
            var originValueFrame = pai.getChildByName('origin');
            if (originValue != null) {
                if (!laizi) {
                    laizi = new cc.Sprite(LAIZI_TEXTURE);
                    laizi.setName('laizi');
                    laizi.setAnchorPoint(cc.p(0.5, 0.5));
                    laizi.setPosition(b.getPosition());
                    pai.addChild(laizi);
                }
                laizi.setVisible(true);
                if (!originValueFrame) {
                    originValueFrame = new cc.Sprite();
                    originValueFrame.setName('origin');
                    originValueFrame.setAnchorPoint(cc.p(0.5, 0));
                    originValueFrame.setPosition(cc.p(40, 25));
                    originValueFrame.setScale(0.7);
                    pai.addChild(originValueFrame);
                }
                setPokerFrameByName(originValueFrame, "b/orange_" + originValue % 13 + ".png");
                Filter.grayScale(originValueFrame);
                originValueFrame.setVisible(true);
                b.setVisible(false);
                c.setVisible(false);
            } else if (pokerRule.isLaizi(val, laiziValue)) {
                if (originValueFrame) {
                    originValueFrame.setVisible(false);
                }
                if (!laizi) {
                    laizi = new cc.Sprite(LAIZI_TEXTURE);
                    laizi.setName('laizi');
                    laizi.setAnchorPoint(cc.p(0.5, 0.5));
                    laizi.setPosition(b.getPosition());
                    pai.addChild(laizi);
                }
                laizi.setVisible(true);
                b.setVisible(false);
                c.setVisible(false);
            } else {
                if (laizi) {
                    laizi.setVisible(false);
                }
                if (originValueFrame) {
                    originValueFrame.setVisible(false);
                }
            }
            // var sp_frame_name = getPaiNameByRowAndId(val);
            // setPokerFrameByName(pai, sp_frame_name);
        },
        getPai: function () {
            var cache = {};
            return function (row, id) {
                cache[row] = cache[row] || {};
                if (cache[row][id])
                    return cache[row][id];
                var node = $("row" + row + ".a" + id);
                if (!node) {
                    var a0 = $("row" + row + ".a0");
                    node = duplicateSprite(a0, true);
                    var dis = posConf.paiADistance[row];
                    dis = dis || posConf.paiADistance[row / 10];
                    node.setPositionX(dis * id + a0.getPositionX());
                    node.setName("a" + id);
                    a0.getParent().addChild(node, row == 1 || row == 10 ? -id : id);
                }
                var userData = node.getUserData();
                if (!userData)
                    userData = {};
                userData.idx = id;
                node.setUserData(userData);
                cache[row][id] = node;
                return node;
            }
        },
        getPaiId: function (row, id) {
            var userData = this.getPai(row, id).getUserData();
            return userData.pai;
        },
        hidePlayerStatus: function (row) {
            var spStatus = $("sp_status" + row);
            if (spStatus)
                spStatus.setVisible(false);
        },
        recalcPos: function (row, paiCnt) {
            if (row != 2 && row != 20)
                return;

            if (row == 2 && _.isUndefined(paiCnt))
                paiCnt = this.getPaiArr().length;

            var distance = posConf.paiADistance[row];
            if (row == 2) {
                if (paiCnt < 19) {
                    distance = posConf.paiADistance[row] * 18 / (paiCnt - 1);
                    distance = distance <= (0.5 * posConf.paiASize[row].width) ? distance : (0.5 * posConf.paiASize[row].width);
                }
                var a0 = $("row" + row + ".a0");
                posConf.paiTouchRect = cc.rect(0, 0, distance, a0.getContentSize().height);
                for (var i = 0; i < paiCnt; i++) {
                    this.getPai(row, i).setPositionX(distance * i + a0.getPositionX());
                }
            }
            var width = (paiCnt - 1) * distance + posConf.paiASize[row].width;
            width *= $("row" + row).getScaleX();
            $("row" + row).setPositionX((cc.winSize.width - width) / 2);
        },
        hidePai: function (row, id) {
            this.getPai(row, id).setVisible(false);
        },
        getPaiArr: function () {
            var arr = [];
            for (var j = 0; j < initPaiNum; j++) {
                var pai = this.getPai(2, j);
                var userData = pai.getUserData();
                if (userData.pai >= 0 && pai.isVisible()) {
                    pai.setVisible(true);
                    arr.push(userData.pai);
                } else {
                    pai.setVisible(false);
                }
            }
            return arr;
        },
        removePaiArr: function (_arr) {
            var arr = deepCopy(_arr);
            for (var i = 0; i < arr.length; i++) {
                arr[i] = arr[i] % 100;
            }
            var paiArr = this.getPaiArr();
            var newPaiArr = [];
            for (var i = 0; i < paiArr.length; i++) {
                if (arr.indexOf(paiArr[i]) < 0)
                    newPaiArr.push(paiArr[i]);
                else
                    arr.splice(arr.indexOf(paiArr[i]), 1);
            }
            return newPaiArr;
        },
        getUpPaiArr: function () {
            var arr = [];
            for (var j = 0; j < initPaiNum; j++) {
                var pai = this.getPai(2, j);
                var userData = pai.getUserData();
                if (pai.isVisible() && userData.pai >= 0 && !userData.isDowning && (userData.isUp || userData.isUpping))
                    arr.push(userData.pai);
            }
            return arr;
        },
        addUsedPai: function () {
            var cache = {};
            return function (row, val) {
                cache[row] = cache[row] || {};
                for (var j = 0; j < 24; j++) {
                    var pai = cache[row][j] || $("row" + row + ".c0.b" + j);
                    if (!pai) {
                        var k = (j >= 0 && j < 10 ? 0 : 10);
                        var b = $("row" + row + ".c0.b" + k);
                        pai = duplicateSprite(b);
                        if (row == 0 || row == 2) pai.setPositionX(posConf.paiUsedDistance[row] * (j - k) + b.getPositionX());
                        if (row == 1 || row == 3) pai.setPositionY(posConf.paiUsedDistance[row] * (j - k) + b.getPositionY());
                        pai.setName("b" + j);
                        pai.setVisible(false);
                        b.getParent().addChild(pai, j * posConf.paiUsedZOrder[row][k]);
                        cache[row][j] = pai;
                    }

                    pai.setUserData({idx: j, pai: val});

                    if (!pai.isVisible()) {
                        //var userData = pai.getUserData();
                        var paiName = getPaiNameById(val);
                        cc.log("painame = " + paiName);
                        //userData.pai = val;
                        setSpriteFrameByName(pai, paiName, "zjh/card/poker_b");
                        pai.setVisible(true);
                        return pai;
                    }
                }
            }
        },
        getRoomState: function () {
            return roomState;
        },
        setRoomState: function (state) {
            var arr = decodeURIComponent(gameData.wanfaDesp).split(",");
            if (arr.length >= 1)
                arr = arr.slice(1);
            var wanfaStr;
            if (mapId == MAP_ID_ZJH) {
                for (var i = 0; i < 3; i++) {
                    arr.splice(0, 1);
                }
                wanfaStr = arr.join(" ");
            } else {
                wanfaStr = arr.join("\n");
            }
            if (state == ROOM_STATE_CREATED) {
                $("signal").setVisible(false);
                $("btn_list").setVisible(false);
                $("chat").setVisible(false);
                $("timer").setVisible(false);
                $("timer2").setVisible(false);
                $("location_btn").setVisible(!window.inReview);
                // $("location2_btn").setVisible(!window.inReview);
                $("btn_invite").setVisible(gameData.loginType != "yk" );
                if (mapId == MAP_ID_ZJH) {
                    $("btn_begin").setVisible(false);
                    // removeLightButton($("btn_begin"));
                }
                if (mapId == MAP_ID_DDZ_JD || mapId == MAP_ID_LAIZI_DDZ) {
                    $('bg_bei').setVisible(true);
                    $('bg_bei.lb_bei').setString('1倍');
                    $('lb_jiaofen').setVisible(true);
                    $('lb_jiaofen').setString('叫0分');
                }
                $("btn_fanhui").setVisible(gameData.uid != gameData.ownerUid || gameData.clubCreater);
                $("btn_jiesan").setVisible(gameData.uid == gameData.ownerUid && !gameData.clubCreater);
                gameData.isOpen = false;
                $("btn_zhunbei").setVisible(false);
                $("btn_mic").setVisible(false);
                $("lb_roomid").setString(gameData.roomId);
                $("lb_wanfa").setString(wanfaStr);
                // $("lb_wanfa").setPositionY(695);
                $("lb_roomid").setVisible(true);
                $("row1").setVisible(false);
                $("row2").setVisible(false);
                $("row3").setVisible(false);
                $("row1b").setVisible(false);
                $("row2b").setVisible(false);
                $("row3b").setVisible(false);
                $("row4b").setVisible(false);
                $("row5b").setVisible(false);
                $("row4").setVisible(false);
                $("row5").setVisible(false);
                $('top_panel').setVisible(false);
            }
            if (state == ROOM_STATE_ONGOING) {
                var setting = $('btn_list');
                if (!setting || !cc.sys.isObjectValid(setting))
                    return network.disconnect();
                setting.setVisible(true);
                $("signal").setVisible(!isReplay);
                $("chat").setVisible(!gameData.shipin);
                $("timer").setVisible(true);
                $("timer2").setVisible(true);
                $("btn_invite").setVisible(false);
                $('btn_copy').setVisible(false);
                $("location_btn").setVisible(false);
                if (mapId == MAP_ID_ZJH) {
                    $("btn_begin").setVisible(false);
                }
                if (mapId == MAP_ID_DDZ_JD || mapId == MAP_ID_LAIZI_DDZ) {
                    $('bg_bei').setVisible(true);
                    $('lb_jiaofen').setVisible(true);
                }
                $("btn_fanhui").setVisible(false);
                $("btn_jiesan").setVisible(false);
                gameData.isOpen = true;
                $("btn_zhunbei").setVisible(false);
                $("btn_mic").setVisible(!window.inReview && !gameData.shipin);
                $("lb_roomid").setString(gameData.roomId);
                $("lb_wanfa").setString(wanfaStr);
                // $("lb_wanfa").setPositionY(707);
                //$("lb_roomid").setVisible(false);
                $("row1").setVisible(false);
                $("row2").setVisible(false);
                $("row3").setVisible(false);

                $("row1b").setVisible(false);
                $("row2b").setVisible(false);
                $("row3b").setVisible(false);
                $("row4b").setVisible(false);
                $("row5b").setVisible(false);
                $("row4").setVisible(false);
                $("row5").setVisible(false);


                $("timer2.Text_5").setString(gameData.leftRound);
                for (var i = 1; i < 6; i++) {
                    $("info" + i + ".ok").setVisible(false);
                }

                if (isReplay) {
                    $("lb_time").setVisible(false);
                    $("btn_list").setVisible(false);
                    $("chat").setVisible(false);
                    $("btn_mic").setVisible(false);
                }
            }
            if (state == ROOM_STATE_ENDED) {
                $("timer").setVisible(false);
                $('btn_copy').setVisible(false);
                // $("timer2").setVisible(false);
                this.hideOps();
            }

            roomState = state;
        },
        clearTable4StartGame: function (isInitPai, isReconnect, reconnectData) {
            var that = this;

            this.onPlayerEnterExit();

            $("ops").setVisible(false);
            $("jia").setVisible(false);
            $("timer").setVisible(false);
            $("btn_list_bg").setVisible(false);
            $('ops.qi.down_bg').setLocalZOrder(-1);
            $('ops.kan.down_bg').setLocalZOrder(-1);
            $('ops.jia.down_bg').setLocalZOrder(-1);
            $('ops.bi.down_bg').setLocalZOrder(-1);
            $('ops.gen.down_bg').setLocalZOrder(-1);
            $('ops.canclebi.down_bg').setLocalZOrder(-1);
            isCuopaiOps = !!(decodeURIComponent(gameData.wanfaDesp).indexOf('搓牌')>=0);

            if (isReconnect) {
                var playerPaiArr = reconnectData["player_pai"] || [];
                var myPai;
                for (var i = 0; i < playerPaiArr.length; i++) {
                    var playerPai = playerPaiArr[i];
                    var paiArr = playerPai["pai_arr"];
                    var chuPaiArr = playerPai["chu_pai_arr"];
                    var curPaiNum = playerPai["cur_pai_num"];
                    var isOffline = !!playerPai["is_offline"];
                    if (isOffline)
                        this.playerOnloneStatusChange(uid2position[playerPai.uid], isOffline);
                    var row = uid2position[playerPai.uid];



                    if (row == 2 && reconnectData['turn_uid']) {
                        myPai = deepCopy(playerPai);
                        that.ZJHthrowTurn(uid2position[reconnectData['turn_uid']], {
                            gen_round: reconnectData['gen_round'],
                            men_round: reconnectData['men_round'],
                            bi_round: reconnectData['bi_round'],
                            total_chip: reconnectData['total_chip'],
                            kan: playerPai['kan'],
                            gen_score: playerPai['gen_score'],
                            jia: reconnectData['jia'],
                            bi: reconnectData['bi'],
                            read: playerPai['read'],
                            qi : playerPai['isqi']
                        });
                        //if(playerPai['read']){
                        g_kanpai = playerPai['read'];
                        //}
                        $('kan').setVisible(!!playerPai['kan']);
                        if (playerPai['card_type'] && playerPai['card_type'] != '' && playerPai['card_type'] != "0") {
                            $('row' + row + '.cardtype').setVisible(true);
                            $('row' + row + '.cardtype').loadTexture('res/image/ui/zjh/character/cardtype' + playerPai['card_type'] + '.png');
                        } else {
                            $('row' + row + '.cardtype').setVisible(false);
                        }
                    }


                    if (that.getRoomState() == ROOM_STATE_ONGOING) {
                        {
                            if (row == 2) {
                                if (playerPai['read']) {
                                    $('row2').setVisible(true);
                                    $('row2b').setVisible(false);
                                    for (var j = 0; j < playerPai['pai_arr'].length; j++) {
                                        that.setPai(2, j, playerPai['pai_arr'][j], true);
                                    }
                                    if (playerPai['isloser'] || playerPai['isqi']) {
                                        $('row2b').setVisible(true);
                                        for (var j = 0; j < 3; j++) {
                                            $('row' + row + 'b.b' + j).setVisible(false);
                                        }
                                        that.updateCardStatusZJH(2, playerPai['isqi'] ? 'qi' : 'shu');
                                    }
                                } else {
                                    $('row' + row + 'b').setVisible(true);
                                    $('row' + row).setVisible(false);
                                    if (playerPai['isloser'] ) {
                                        $('row2b').setVisible(true);
                                        for (var j = 0; j < 3; j++) {
                                            $('row' + row + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_backold.png');
                                        }
                                        that.updateCardStatusZJH(2, playerPai['isqi'] ? 'qi' : 'shu');
                                    }
                                    if ( playerPai['isqi']) {
                                        $('row2b').setVisible(true);
                                        for (var j = 0; j < 3; j++) {
                                            $('row' + row + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_backhui.png');
                                        }
                                        that.updateCardStatusZJH(2, playerPai['isqi'] ? 'qi' : 'shu');
                                    }
                                }
                                $('ops.gen.txt').setString(''+ playerPai['gen_score']);//('跟注x' + playerPai['gen_score']);
                                $('ops.bi.txt').setString(''+ (playerPai['gen_score']*that.getBipaiRate()));
                            } else {
                                $('row' + row + 'b').setVisible(true);
                                $('row' + row).setVisible(false);
                                if (playerPai['read']) {
                                    that.updateCardStatusZJH(row, 'kan');
                                }
                                if (playerPai['isloser'] ) {
                                    for (var j = 0; j < 3; j++) {
                                        $('row' + row + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_backold.png');
                                    }
                                    that.updateCardStatusZJH(row, playerPai['isqi'] ? 'qi' : 'shu');
                                }
                                if (playerPai['isqi']) {
                                    for (var j = 0; j < 3; j++) {
                                        $('row' + row + 'b.b' + j).setTexture('res/image/ui/zjh/unit/pai_backhui.png');
                                    }
                                    that.updateCardStatusZJH(row, playerPai['isqi'] ? 'qi' : 'shu');
                                }
                            }
                        }
                        if (!playerPai['has_xia']) {
                            $('info' + row + '.minexia').setVisible(false);
                        }else{
                            $('info' + row + '.minexia').setVisible(true);
                            $('info' + row + '.minexia.yixianum').setString(playerPai['has_xia']);
                        }
                    }
                }

                gameData.unused_paiArr = data["unused_card_arr"];


                if (roomState == ROOM_STATE_ONGOING) {
                    {
                        $('ops').setVisible(true);
                        for (var chipnum = 0; chipnum < data['chips'].length; chipnum++) {
                            (function (chipnum) {
                                var chip = new cc.Sprite(cc.textureCache.addImage('res/image/ui/zjh/unit/chip' + data['chips'][chipnum] + '.png'));
                                chip.setPosition((Math.random()-0.5) * 380 + 640, (Math.random()-0.5) * 150 + 420);
                                // chip.runAction(cc.moveTo(1, ).easing(cc.easeOut(5)));
                                $('chipnode').addChild(chip);
                            })(chipnum);
                        }
                    }
                } else if (roomState == ROOM_STATE_ENDED) {
                    {
                        $('kan').setVisible(false);
                        $('ops').setVisible(false);
                        for (var i = 1; i < 6; i++) {
                            that.updateCardStatusZJH(i);
                        }
                        if (myPai['read']) {
                            $('row2').setVisible(true);
                            $('row2b').setVisible(false);
                            for (var j = 0; j < myPai['pai_arr'].length; j++) {
                                that.setPai(2, j, myPai['pai_arr'][j], true);
                            }
                        } else {
                            $('row' + row + 'b').setVisible(true);
                            $('row' + row).setVisible(false);
                        }
                    }
                }
            } else if (isInitPai) {

            }
        },
        playAircraftAnim: function () {
            playEffect("vcom_airplane_the_first_time");
            var transparent = $("transparent");
            transparent.setVisible(false);
            transparent.setOpacity(255);
            // $("transparent").setVisible(true);
            transparent.setPosition(cc.winSize.width / 2, cc.winSize.height * 0.66);
            playFrameAnim(res.air_plist, "air", 3, 0.05, true, $("transparent"));
            transparent.setPositionX(cc.winSize.width * 0.25);
            transparent.runAction(cc.sequence(
                cc.spawn(cc.moveBy(1, cc.winSize.width * 0.5, 0), cc.sequence(cc.delayTime(0.8), cc.fadeOut(0.2))),
                cc.callFunc(function () {
                    $("transparent").setVisible(false);
                })));
            // transparent.runAction(cc.moveBy(1, cc.winSize.width * 0.5, 0));
            transparent.setVisible(true);
        },
        playAlarmAnim: function (row) {
            var sp = $("info" + row + ".alarm");
            sp.setVisible(true);
            var bk = $("info" + row + ".pai_back");
            bk.setVisible(false);
            playFrameAnim(res.alarm_plist, "alarm", 2, 0.2, true, sp);
        },
        countDown: function () {
            var that = this;
            var timer = null;
            return function (row, seconds) {
                if (isReplay) {
                    return;
                }

                $('timer').setVisible(true);
                var bg = $('info' + row + '.bg');
                var pos = bg.convertToWorldSpace(cc.p(0, 0));
                $('timer').setPosition(pos.x + bg.getContentSize().width / 2 * bg.getScaleX(), pos.y + bg.getContentSize().height / 2 * bg.getScaleY() + 2);

                var pt0 = $('timer').getChildByName('pt0');
                if(pt0){
                    pt0.removeFromParent();
                }

                var path = 'res/image/ui/zjh/table/head_timer_bg.png';
                if(row==2){
                    path = 'res/image/ui/zjh/table/head_timer_bg2.png'
                }
                var ptsp = new cc.Sprite(path);
                pt0 = new cc.ProgressTimer(ptsp);
                if(row==2){
                    pt0.setScale(1.2);
                }
                pt0.setName('pt0');
                pt0.setType(cc.ProgressTimer.TYPE_RADIAL);
                $('timer').addChild(pt0);

                pt0.stopAllActions();
                pt0.setPercentage(0);
                pt0.runAction(cc.progressTo(seconds, 100));
            }
        },
        setPaiArrOfRow: function (row, paiArr) {
            // if (!paiArr || paiArr.length == 0)
            //     return;
            var that = this;
            var flag = getSortFlag();
            if (row == 1 || row == 3 || row == 20)
                paiArr.sort(function (a, b) {
                    var wa = PAIID2CARD[a < 100 ? a : (Math.floor(a / 100) - 1)].weight;
                    var wb = PAIID2CARD[b < 100 ? b : (Math.floor(b / 100) - 1)].weight;
                    if (pokerRule.isLaizi(a, laiziValue) != pokerRule.isLaizi(b, laiziValue)) {
                        return pokerRule.isLaizi(a, laiziValue) ? -1 : 1;
                    }
                    return wa == wb ? that.getHuaValue(a) - that.getHuaValue(b) : wa - wb;
                });
            else if (row == 2) {
                paiArr.sort(function (a, b) {
                    var wa = PAIID2CARD[a].weight;
                    var wb = PAIID2CARD[b].weight;
                    if (pokerRule.isLaizi(a, laiziValue) != pokerRule.isLaizi(b, laiziValue)) {
                        return pokerRule.isLaizi(a, laiziValue) ? -flag : flag;
                    }
                    return wa == wb ? flag * (that.getHuaValue(a) - that.getHuaValue(b)) : flag * (wa - wb);
                });
            }
            else if (row == 10 || row == 30) {
                paiArr.sort(function (a, b) {
                    var wa = PAIID2CARD[a].weight;
                    var wb = PAIID2CARD[b].weight;
                    if (pokerRule.isLaizi(a, laiziValue) != pokerRule.isLaizi(b, laiziValue)) {
                        return pokerRule.isLaizi(a, laiziValue) ? -1 : 1;
                    }
                    return wa == wb ? that.getHuaValue(a) - that.getHuaValue(b) : wa - wb;
                });
            }
            for (var j = 0; j < paiArr.length; j++)
                this.setPai(row, j, paiArr[j], true).setOpacity(255);
            for (; j < 168; j++) {
                var pai = $("row" + row + ".a" + j);
                if (!pai)
                    break;
                pai.setVisible(false);
            }
        },
        hideOps: function () {
            $("ops").setVisible(false);
        },
        setReplayProgress: function (cur, total) {
            var progress = cur / total * 100;
            if(!total){
                progress = 100;
                this.showTip("当前牌局为解散局 未显示牌为服务器还未发牌", true);
                return;
            }
            this.showTip("进度: " + progress.toFixed(1) + "%", false);
        },
        setAllPai4Replay: function (data) {
            for (var uid in data)
                if (data.hasOwnProperty(uid)) {
                    var row = uid2position[uid];
                    var paiArr = data[uid]["pai_arr"];
                    var usedPaiArr = data[uid]["used_arr"];
                    if (row == 2) {
                        this.setPaiArrOfRow(row, paiArr);
                        $("row" + row).setVisible(true);

                        this.setPaiArrOfRow(20, usedPaiArr);
                        $("row" + 20).setVisible(true);

                        for (var _i = 0; _i < initPaiNum; _i++) {
                            Filter.grayMask(this.getPai(row, _i));
                        }
                    }
                    else {
                        this.setPaiArrOfRow(row, usedPaiArr);
                        $("row" + row).setVisible(true);

                        this.setPaiArrOfRow(row * 10, paiArr);
                        $("row" + row * 10).setVisible(true);
                    }
                    this.recalcPos(row);

                    // console.log(row);
                }
        },
        jiesuan: function (data) {
            var that = this;

            var myScore = 0;
            var players = data.players;
            var winneruid;
            for (var i = 0; i < players.length; i++) {
                var player = players[i];
                var uid = player["uid"];
                if ( player.score > 0) {
                    winneruid = uid;
                }

                gameData.players[position2playerArrIdx[uid2position[uid]]].score = player["total_score"];

                if (uid == gameData.uid) {
                    myScore = player["score"];
                }

                var row = uid2position[uid];
                var paiArr = player["pai_arr"];
                if (paiArr.length != 0 ){
                    this.setPaiArrOfRow(row, paiArr);
                    $("row" + row).setVisible(true);
                    $('row' + row + '.cardtype').setVisible(false);
                }

                if (!isReplay) {
                    if (_.isArray(paiArr) && paiArr.length > 0) {
                        that.checkPaiAnim(row, paiArr);
                        that.updateCardStatusZJH(row);
                    }
                    $('kan').setVisible(false);
                    if (player['card_type'] && player['card_type'] != '' && player['card_type'] != '0') {
                        $('row' + row + '.cardtype').setVisible(true);
                        $('row' + row + '.cardtype').loadTexture('res/image/ui/zjh/character/cardtype' + player['card_type'] + '.png');
                    } else {
                        $('row' + row + '.cardtype').setVisible(false);
                    }
                }

                (function (_row, _player) {
                    setTimeout(function () {
                        if (_player.score != 0) {
                            that.wordsFly(_row, (_player.score > 0 ? '+' : '') + _player.score, 2, 1.2);
                        }
                        $("info" + _row + ".lb_score").setString(_player["total_score"]);
                    }, 500);
                })(row, player);
            }

            if (winneruid && uid2position[winneruid]) {
                var endPos = $('info' + uid2position[winneruid]).getPosition();
                var chips = $('chipnode').getChildren();
                var tArr = [];
                if(cc.sys.isNative){
                    var spNode = createSp('button_anim2');
                    spNode.setAnimation(0, 'xuanwo', true);
                    spNode.setPosition(endPos);
                    that.addChild(spNode);
                }
                for (var i = 0; i < chips.length; i++) {
                    (function (chip, count, len) {
                        var randEndX = endPos.x + Math.random() * 30 - 15;
                        var randEndY = endPos.y + Math.random() * 30 - 15;
                        chip.runAction(cc.sequence(
                            cc.delayTime(count*0.04),
                            cc.moveTo(0.35 + Math.random() * 0.05, cc.p(randEndX,randEndY)).easing(cc.easeInOut(3)),
                            cc.callFunc(function () {
                                tArr.push(chip);
                                if(tArr.length == len){
                                    setTimeout(function () {
                                        for(var j=0; j<tArr.length; j++){
                                            tArr[j].removeFromParent();
                                        }
                                        tArr.length = 0;
                                    },100);
                                    if(cc.sys.isNative) {
                                        spNode.setAnimation(0, 'xuanwo2', false);
                                        spNode.setEndListener(function () {
                                            setTimeout(function () {
                                                spNode.removeFromParent();
                                            }, 1)
                                        })
                                    }
                                }
                            })
                        ))
                    })(chips[i], i, chips.length);
                }
            }


            if (data.is_chun) {
                $("transparent").setVisible(true);
                $("transparent").setOpacity(255);
                $("transparent").setPosition(cc.winSize.width / 2, cc.winSize.height * 0.66);
                playFrameAnim(res.spring_plist, "spring", 12, 0.05, false, $("transparent"), function () {
                    $("transparent").setVisible(false);
                });
            }

            setTimeout(function () {
                playEffect(myScore > 0 ? "vvictory" : "vfailure");
            }, 800);

            // setTimeout(function () {
            //     var layer = null;
            //     switch (gameData.mapId) {
            //         case MAP_ID_PDK:
            //             layer = new JiesuanLayer(data);
            //             break;
            //         case MAP_ID_DDZ_JD:
            //             layer = new DiZhuJieSuanLayer(data);
            //             break;
            //         case MAP_ID_XIANGYANG_PDK:
            //             layer = new JiesuanLayer(data);
            //             break;
            //         case MAP_ID_LAIZI_DDZ:
            //             layer = new DiZhuJieSuanLayer(data);
            //             break;
            //     }
            //     if (layer)
            //         that.addChild(layer);
            //     else
            //         setTimeout(function () {
            //             if (!isReplay)
            //                 that.onJiesuanClose();
            //         }, 1000);
            // }, 1580);
            setTimeout(function () {
                if (!isReplay)
                    that.onJiesuanClose();
            }, 580);
        },
        onJiesuanClose: function (isReady) {
            if (isReady) {
                $("btn_zhunbei").setVisible(false);
            } else {
                $("btn_zhunbei").setVisible(true);
            }
        },
        zongJiesuan: function (data) {
            var that = this;
            mRoom.voiceMap = {};
            setTimeout(function () {
                if (mapId == MAP_ID_ZJH) {
                    var layer = new ZongJiesuanLayerZJH(data);
                    that.addChild(layer);
                }
            }, 2000);
        },
        showPlayerInfoPanel : function (idx) {
            if (window.inReview || isReplay)
                return;

            if (position2playerArrIdx[idx] >= gameData.players.length)
                return;

            var that = this;

            var playerInfo = gameData.players[position2playerArrIdx[idx]];

            this.playerInfoLayer = new PlayerInfoLayer(playerInfo, this, 'niuniu', !(this.getRoomState() == ROOM_STATE_ONGOING));
            this.addChild(this.playerInfoLayer);
        },
        playerOnloneStatusChange: function (row, isOffline) {
            var offline = $("info" + row + ".offline");
            if (offline && cc.sys.isObjectValid(offline)) {
                offline.setVisible(!!isOffline);
            }
        },
        playUrlVoice: function (row, type, content, voice, uid) {
            var url = decodeURIComponent(content);
            var arr = null;
            if (url.indexOf('.aac') >= 0) {
                arr = url.split(/\.aac/)[0].split(/-/);
            } else if (url.indexOf('.spx') >= 0) {
                arr = url.split(/\.spx/)[0].split(/-/);
                // playVoiceByUrl(url);
            }
            mRoom.voiceMap[uid] = null;
            mRoom.voiceMap[uid] = url;
            var duration = arr[arr.length - 1] / 1000;
            window.soundQueue = window.soundQueue || [];
            window.soundQueue.push({url: url, duration: duration, row: row});
            if (window.soundQueue.length > 1) {
            } else {
                this.playVoiceQueue();
            }
        },
        playVoiceQueue: function () {
            var that = this;
            var queue = window.soundQueue[0];
            if (queue && queue.url && queue.duration && _.isNumber(queue.row)) {
                if (queue.url.indexOf('.aac') >= 0) {
                    VoiceUtils.play(queue.url);
                } else if (queue.url.indexOf('.spx') >= 0) {
                    OldVoiceUtils.playVoiceByUrl(queue.url);
                }
                var scale9sprite = this.initQP(queue.row);
                scale9sprite.setContentSize(posConf.ltqpEmojiSize[queue.row]);
                var innerNodes = this.initSpeaker(queue.row, scale9sprite);
                this.qpAction(innerNodes, scale9sprite, queue.duration);
                setTimeout(function () {
                    window.soundQueue.shift();
                    that.playVoiceQueue();
                }, queue.duration * 1000);
            }
        },
        initQP: function (row) {
            var scale9sprite = $('info' + row + '.qp9');
            if (!scale9sprite) {

                scale9sprite = new cc.Scale9Sprite((mapId == MAP_ID_ZJH ? "res/image/ui/zjh/unit/ltqp" : "res/image/etc/ltqp") + (row == 4 ? 3 : (row % 4)) + ".png", posConf.ltqpRect[row], posConf.ltqpCapInsets[playerNum][row]);
                scale9sprite.setName("qp9");
                if (mapId == MAP_ID_ZJH) {
                    var ap = cc.p(0, 0);
                    if (row == 1 || row == 5) ap = cc.p(1, 1);
                    else if (row == 2) ap = cc.p(0, 0);
                    else if (row == 3 || row == 4) ap = cc.p(0, 1);
                    scale9sprite.setAnchorPoint(ap);
                } else {
                    scale9sprite.setAnchorPoint(row == 1 ? cc.p(1, 0) : cc.p(0, 0));
                }
                scale9sprite.setPosition(posConf.ltqpPos[row]);
                $("info" + row).addChild(scale9sprite, 2);
            }

            for (var i = (cc.sys.isNative ? 0 : 1); i < scale9sprite.getChildren().length; i++)
                scale9sprite.getChildren()[i].setVisible(false);
            return scale9sprite;
        },
        initSpeaker: function (row, scale9sprite) {
            var map = {};
            var innerNodes = [];
            for (var i = 1; i <= 3; i++) {
                var sp = $('speaker' + i, scale9sprite);
                if (!sp) {
                    sp = new cc.Sprite('res/image/ui/room/speaker' + i + '.png');
                    sp.setName('speaker' + i);
                    sp.setPosition(posConf.ltqpVoicePos[playerNum][row]);
                    scale9sprite.addChild(sp);
                }
                map[i] = sp;
                map[i].setVisible(true);
                innerNodes.push(map[i]);
            }
            map[2].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.25), cc.fadeIn(0.25)).repeatForever());
            map[3].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.50), cc.fadeIn(0.50)).repeatForever());
            return innerNodes;
        },
        qpAction: function (innerNodes, scale9sprite, duration) {
            scale9sprite.stopAllActions();
            scale9sprite.setVisible(true);
            scale9sprite.setOpacity(255);
            scale9sprite.setScale(1.6, 1.6);
            scale9sprite.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5), cc.callFunc(function () {
                for (var i = 0; i < innerNodes.length; i++)
                    innerNodes[i].setVisible(false);
            })));
        },
        showChat: function (row, type, content, voice, uid) {
            var that = this;

            if (type == "voice") {
                var url = decodeURIComponent(content);
                if (url && url.split(/\.spx/).length > 2)
                    return;
                that.playUrlVoice(row, type, content, voice, uid);
                return;
            }
            $("info" + row).setLocalZOrder(1);
            var scale9sprite = $("info" + row + ".qp9");
            if (!scale9sprite) {
                scale9sprite = new cc.Scale9Sprite((mapId == MAP_ID_ZJH ? "res/image/ui/zjh/unit/ltqp" : "res/image/etc/ltqp") + (row == 4 ? 3 : (row % 4)) + ".png", posConf.ltqpRect[row], posConf.ltqpCapInsets[playerNum][row]);
                scale9sprite.setName("qp9");
                if (mapId == MAP_ID_ZJH) {
                    var ap = cc.p(0, 0);
                    if (row == 1 || row == 5) ap = cc.p(1, 1);
                    else if (row == 2) ap = cc.p(0, 0);
                    else if (row == 3 || row == 4) ap = cc.p(0, 1);
                    scale9sprite.setAnchorPoint(ap);
                } else {
                    scale9sprite.setAnchorPoint(row == 1 ? cc.p(1, 0) : cc.p(0, 0));
                }
                scale9sprite.setPosition(posConf.ltqpPos[row]);
                $("info" + row).addChild(scale9sprite, 2);
            }

            for (var i = (cc.sys.isNative ? 0 : 1); i < scale9sprite.getChildren().length; i++)
                scale9sprite.getChildren()[i].setVisible(false);

            var duration = 4;
            var innerNodes = [];
            scale9sprite.setCascadeOpacityEnabled(false);
            if (type == "emoji") {
                scale9sprite.setOpacity(0);

                //表情动画
                var index = content.substring(10, 11);
                var ccsScene = ccs.load(res['expression' + index], "res/");
                var express = ccsScene.node;
                express.setName("express");
                express.setPosition(posConf.ltqpEmojiPos[playerNum][row]);
                $('info' + row).addChild(express, 10);
                express.runAction(ccsScene.action);
                ccsScene.action.play('action', true);
                this.scheduleOnce(function () {
                    express.removeFromParent();
                }, 2);
            }
            else if (type == "text") {
                scale9sprite.setOpacity(255);
                var text = $("text", scale9sprite);
                if (!text) {
                    text = new ccui.Text();
                    text.setName("text");
                    text.setFontSize(26);
                    text.setTextColor(cc.color(106, 57, 6));
                    // text.enableShadow(cc.color.BLACK, cc.p(1, -1));
                    text.setAnchorPoint(0, 0);
                    scale9sprite.addChild(text);
                }

                text.setString(content);

                var size = cc.size(text.getVirtualRendererSize().width + posConf.ltqpRect[row].width, posConf.ltqpRect[row].height);
                text.setPosition(
                    (size.width - text.getVirtualRendererSize().width) / 2 + posConf.ltqpTextDelta[playerNum][row].x,
                    (size.height - text.getVirtualRendererSize().height) / 2 + posConf.ltqpTextDelta[playerNum][row].y
                );
                scale9sprite.setContentSize(size);
                text.setVisible(true);
                innerNodes.push(text);
            }
            else if (type == "voice") {
                scale9sprite.setOpacity(255);
                var url = decodeURIComponent(content);
                scale9sprite.setContentSize(posConf.ltqpEmojiSize[row]);
                // var arr = url.split(/\.spx/)[0].split(/-/);
                // duration = arr[arr.length - 1] / 1000;
                // playVoiceByUrl(url);

                var map = {};
                for (var i = 1; i <= 3; i++) {
                    var sp = $("speaker" + i, scale9sprite);
                    if (!sp) {
                        sp = new cc.Sprite('res/image/ui/room/speaker' + i + '.png');
                        sp.setName("speaker" + i);
                        sp.setPosition(posConf.ltqpVoicePos[playerNum][row]);
                        scale9sprite.addChild(sp);
                    }
                    map[i] = sp;
                    map[i].setVisible(true);
                    innerNodes.push(map[i]);
                }
                map[2].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.25), cc.fadeIn(0.25)).repeatForever());
                map[3].runAction(cc.sequence(cc.fadeOut(0), cc.delayTime(0.50), cc.fadeIn(0.50)).repeatForever());
            }

            scale9sprite.stopAllActions();
            scale9sprite.setVisible(true);
            scale9sprite.setScale(1.6, 1.6);
            scale9sprite.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5), cc.callFunc(function () {
                for (var i = 0; i < innerNodes.length; i++)
                    innerNodes[i].setVisible(false);
            })));
            if (type != "voice") {
                for (var i = 0; i < innerNodes.length; i++) {
                    var innerNode = innerNodes[i];
                    innerNode.stopAllActions();
                    innerNode.setVisible(true);
                    innerNode.setOpacity(255);
                    //innerNode.setScale(1.5, 1.5);
                    innerNode.runAction(cc.sequence(cc.delayTime(duration), cc.fadeOut(0.5)));
                }
            }
            if (voice && !window.inReview)
                playEffect(voice);
        },
        setBeforeOnCCSLoadFinish: function (cb) {
            this.beforeOnCCSLoadFinish = cb;
        },
        getBeforeOnCCSLoadFinish: function (cb) {
            return this.beforeOnCCSLoadFinish;
        },
        setAfterGameStart: function (cb) {
            this.afterGameStart = cb;
        },
        setReady: function (uid) {
            $("info" + uid2position[uid] + ".ok").setVisible(true);
            if (uid == gameData.uid)
                $("btn_zhunbei").setVisible(false);
        },
        showToast: function (msg) {
            var toast = $("toast");
            if (!toast) {
                toast = new cc.Sprite(res.toast_bg_png);
                toast.setName("toast");
                this.addChild(toast);

                var text = new ccui.Text();
                text.setName("text");
                text.setFontSize(30);
                text.setTextColor(cc.color(255, 255, 255));
                text.setPosition(toast.getBoundingBox().width / 2, toast.getBoundingBox().height / 2);
                text.setString(msg);
                toast.setPosition(cc.winSize.width / 2, cc.winSize.height / 2 * 4 / 5);
                toast.addChild(text);
            }
            toast.stopAllActions();
            toast.runAction(cc.sequence(cc.fadeIn(3), cc.fadeOut(0.3)));
            text = toast.getChildByName("text");
            text.runAction(cc.sequence(cc.fadeIn(3), cc.fadeOut(0.3)));
        },
        showTip: function (content, isShake) {
            isShake = _.isUndefined(isShake) ? true : isShake;
            var scale9sprite = $("top_tip");
            if (!(scale9sprite instanceof cc.Scale9Sprite)) {
                var newScale9sprite = new cc.Scale9Sprite(res.round_rect_91, cc.rect(0, 0, 91, 32), cc.rect(46, 16, 1, 1));
                newScale9sprite.setName("top_tip");
                scale9sprite.setAnchorPoint(0.5, 0.5);
                newScale9sprite.setPosition(scale9sprite.getPosition());
                scale9sprite.getParent().addChild(newScale9sprite);
                var lb = $("top_tip.lb_tip");

                text = new ccui.Text();
                text.setName("lb_tip");
                text.setFontRes(res.default_ttf);
                text.setFontSize(lb.getFontSize());
                text.setTextColor(lb.getTextColor());
                text.enableOutline(cc.color(38, 38, 38), 1);
                newScale9sprite.addChild(text);

                lb.removeFromParent(true);
                scale9sprite.removeFromParent(true);
                scale9sprite = newScale9sprite;
            }
            var text = $("top_tip.lb_tip");
            text.setString(content);
            var size = cc.size(text.getVirtualRendererSize().width + 35, scale9sprite.getContentSize().height);
            text.setPosition((text.getVirtualRendererSize().width + 35) / 2, scale9sprite.getContentSize().height / 2);
            scale9sprite.setContentSize(size);
            scale9sprite.setScale(1.2);
            scale9sprite.setVisible(true);
            if (isShake)
                scale9sprite.runAction(cc.sequence(cc.scaleTo(0.2, 1.4), cc.scaleTo(0.2, 1.2)));
        },
        hideTip: function () {
            if ($("top_tip"))
                $("top_tip").setVisible(false);
        },
        changeVoice: function () {
            if (cc.sys.localStorage.getItem('yinxiaoPrecent') > 0 || cc.sys.localStorage.getItem('yinyuePrecent') > 0) {
                $('btn_voice_on').setVisible(false);
                $('btn_voice_off').setVisible(true);
            } else {
                $('btn_voice_on').setVisible(true);
                $('btn_voice_off').setVisible(false);
            }
        },
        getHuaValue: function (id) {
            if (id >= 0 && id <= 12) return 3;
            if (id >= 13 && id <= 25) return 4;
            if (id >= 26 && id <= 38) return 2;
            if (id >= 39 && id <= 51) return 1;
            if (id >= 100) return 0;
            return id;
        },
        throwCMAnim: function (row, needchip) {
            var chip = new cc.Sprite(cc.textureCache.addImage('res/image/ui/zjh/unit/chip' + needchip + '.png'));
            chip.setPosition($('info' + row).getPosition());
            chip.runAction(cc.moveTo(0.1, (Math.random()-0.5) * 380 + 640, (Math.random()-0.5) * 150 + 420).easing(cc.easeOut(5)));
            $('chipnode').addChild(chip);
            //console.log("chip x=" + chip.x + "  y=" + chip.y);
        },
        biPaiAnim: function (fromRow, row1, row2, cb) {
            if (position2playerArrIdx[row1] >= gameData.players.length || position2playerArrIdx[row2] >= gameData.players.length)
                return;
            if (fromRow != row1 && fromRow != row2) {
                return;
            }
            var that = this;
            TouchUtils.setOnclickListener($('shield'), function () {

            });
            var loser;
            if (fromRow == row1) loser = 2;
            else loser = 1;
            var info = {};
            var cards = {};
            for (var i = 1; i <= 2; i++) {
                cards[i] = duplicateOnlyNewLayer($(i == 1 ? 'row3b' : 'row1b'));
                for (var j = 0; j < 3; j++) {
                    cards[i].getChildByName('b' + j).setVisible(true);
                    cards[i].getChildByName('b' + j).setTexture('res/image/ui/zjh/unit/pai_back3.png');
                }
                cards[i].getChildByName('status').setVisible(false);
                cards[i].setVisible(false);
                cards[i].setScale(0.5);
                cards[i].setPosition(i == 1 ? 360 : 920, i == 1 ? 385 : 330);
                that.addChild(cards[i], 2);
                var row = (i == 1 ? fromRow : (loser == 1 ? row1 : row2));
                info[i] = ccs.load(res.VS_json, "res/").node;
                info[i].setPosition($('info' + row).getPosition());
                loadImageToSprite(gameData.players[position2playerArrIdx[row]]['headimgurl'], info[i].getChildByName('info').getChildByName('head'));
                info[i].getChildByName('info').getChildByName('lb_nickname').setString(gameData.players[position2playerArrIdx[row]]['nickname']);
                that.addChild(info[i], 2);
                (function (k) {
                    setTimeout(function () {
                        info[k].runAction(cc.sequence(
                            cc.scaleTo(0.2, 2),
                            cc.scaleTo(0.05, 1.7),
                            cc.scaleTo(0.05, 2),
                            cc.delayTime(0.3),
                            cc.spawn(
                                cc.moveTo(0.4, k == 1 ? 160 : 1120, k == 1 ? 402 : 347).easing(cc.easeIn(3)),
                                cc.scaleTo(0.4, 0.7).easing(cc.easeIn(3))
                            ),
                            cc.scaleTo(0.1, 0.9),
                            cc.callFunc(function () {
                                cards[k].setVisible(true);
                            })
                        ));
                    }, 100);
                })(i);
            }

            setTimeout(function () {
                var bi_sp = playSpAnimation('vs1', 'VS', false);
                bi_sp.setPosition(640, 360);
                bi_sp.setTimeScale(0.9);
                setTimeout(function () {
                    playEffect('vcompare_effect');
                }, 400);



                setTimeout(function () {
                    var loser_sp = playSpAnimation('vs1', 'shandian', false);
                    loser_sp.setPosition(cards[loser].getPosition());
                    that.addChild(loser_sp, 999);
                    setTimeout(function () {
                        for (var i = 0; i < 3; i++) {
                            cards[loser].getChildByName('b' + i).setVisible(true);
                            cards[loser].getChildByName('b' + i).setTexture('res/image/ui/zjh/unit/pai_backold.png');
                        }
                        loser_sp.removeFromParent();
                        setTimeout(function () {
                            for (var i = 1; i <= 2; i++) {
                                cards[i].removeFromParent();
                                info[i].removeFromParent();
                            }
                            bi_sp.removeFromParent();
                            TouchUtils.removeListeners($('shield'));
                            if (typeof cb == 'function') {
                                cb();
                            }
                        }, 1600);
                    }, 400);
                }, 600);
                that.addChild(bi_sp);

            }, 800);
        },
        checkPaiAnim: function (row, paiarr) {
            network.stop();
            if (!$('row' + row + 'b').isVisible()) {
                network.start();
                return false;
            }
            var flipTime = 0.175;
            for (var j = 0; j < paiarr.length; j++) {
                this.setPai(row, j, paiarr[j], true);
                (function (j, row) {
                    $("row" + row + 'b.b' + j).setScaleX(-1);
                    $("row" + row + 'b.b' + j).runAction(cc.sequence(
                        cc.spawn(
                            cc.scaleTo(flipTime, 0, 1),
                            cc.skewTo(flipTime, 0, 30)
                        ),
                        cc.callFunc(function () {
                            $("row" + row + 'b').setVisible(false);
                        }),
                        cc.spawn(
                            cc.scaleTo(flipTime, 1, 1),
                            cc.skewTo(flipTime, 0, 0)
                        )
                    ));
                    $("row" + row + '.a' + j).setScaleX(-1);
                    $("row" + row + '.a' + j).runAction(cc.sequence(
                        cc.spawn(
                            cc.scaleTo(flipTime, 0, 1),
                            cc.skewTo(flipTime, 0, 30)
                        ),
                        cc.callFunc(function () {
                            $("row" + row).setVisible(true);
                        }),
                        cc.spawn(
                            cc.scaleTo(flipTime, 1, 1),
                            cc.skewTo(flipTime, 0, 0)
                        )
                    ));
                })(j, row);
            }
            setTimeout(function () {
                network.start();
            }, 600);
            return true;
        },
        calcPaisInfo : function (_data) {
            var data = [];
            var players = gameData.players;
            var scale = cc.view.getFrameSize().width / cc.director.getWinSize().width;
            var theight = cc.view.getFrameSize().height / scale;
            var boardHeight = (theight - cc.director.getWinSize().height) / 2;
            // console.log("boardHeight = " + boardHeight);

            for (var i = 0; i < players.length; i++) {
                var player = players[i];
                var pos = uid2position[player.uid];
                data.push({uid:player.uid});
                for(var j=0; j<3; j++){
                    var pai = $('row' + pos + '.a' +j);
                    var paiPos = pai.convertToWorldSpace(cc.p(pai.getContentSize().width/2, pai.getContentSize().height/2));
                    var x = paiPos.x;
                    var y = paiPos.y  - boardHeight;
                    var scale = pai.getScaleX() * pai.getParent().getScaleX();
                    data[i][j] = {
                        x : x, y:y, scale:scale
                    }
                    data[i].row = pos;
                }
                if(_data.qiepai_uid == player.uid){
                    data[i].qiepai = true;
                }else{
                    data[i].qiepai = false;
                }
                data[i].sec = _data.sec;
            }
            // console.log(JSON.stringify(data));
            return data;
        },
        faAllPai: function (cb) {
            var that = this;
            network.stop([3008]);
            var func = function (i, j, idx) {
                var sprite = new cc.Sprite();
                sprite.setTexture('res/image/ui/zjh/unit/pai_back3.png');
                sprite.setPosition(cc.p(cc.winSize.width / 2, cc.winSize.height / 2));
                sprite.setScale(0);
                that.addChild(sprite);
                var pai = $('row' + i + 'b.b' + j);
                pai.setVisible(false);
                var x = pai.getPositionX() * $('row' + i).getScaleX() + $('row' + i).getPositionX();
                var y = pai.getPositionY() * $('row' + i).getScaleY() + $('row' + i).getPositionY();
                sprite.runAction(cc.sequence(
                    cc.delayTime(0.45 * idx + 0.15 * j),
                    cc.callFunc(function () {
                        playEffect('vfapai_bg');
                    }),
                    cc.spawn(
                        cc.moveTo(0.3, x, y),
                        cc.scaleTo(0.3, $('row' + i).getScale())
                    ),
                    cc.callFunc(function () {
                        sprite.removeFromParent(true);
                        pai.setVisible(true);
                        if (idx == gameData.players.length - 1 && j == 2) {
                            if (typeof cb == 'function') {
                                cb();
                            }
                            network.start();
                        }
                    })
                ))
            };
            var row_list = [2, 1, 5, 4, 3];
            for (var i = 0; i < gameData.players.length; i++) {
                var row = row_list[i];
                if (!$('row' + row + 'b').isVisible()) break;
                for (var j = 0; j < 3; j++) {
                    func(row, j, i);
                }
            }
        },
        wordsFly: function (row, str, time_scale, scale) {
            time_scale = time_scale || 1;
            scale = scale || 0.9;
            var fnt = new cc.LabelBMFont(str, res.wordsfly_fnt);
            var parent = $('info' + row +".wordsNode");
            parent.addChild(fnt, 2);
            fnt.setPosition(parent.getContentSize().width / 2, parent.getContentSize().height / 2);
            fnt.setScale(0);
            fnt.runAction(cc.sequence(
                cc.scaleTo(0.1 * time_scale, scale * 1.5),
                cc.scaleTo(0.05 * time_scale, scale * 1.2),
                cc.delayTime(0.8 * time_scale),
                cc.spawn(
                    cc.moveBy(1.5 * time_scale, 0, 100),
                    cc.fadeOut(1.5 * time_scale)
                ),
                cc.callFunc(function () {
                    fnt.removeFromParent();
                })
            ));
        },
        getBipaiRate : function () {
            if(decodeURIComponent(gameData.wanfaDesp).indexOf('比牌双倍开')>=0){
                return 2;
            }
            return 1;
        },
        jiaBtnTextureShow : function (rate) {
            rate = rate || 1;
            for(var i=2;i<=5;i++){
                Filter.store($('jia.jia'+i),'jia.jia'+i);
                $('jia.jia'+i).setTexture('res/image/ui/zjh/unit/btn_chip'+(i*rate)+'.png');
                Filter.useStore($('jia.jia'+i),'jia.jia'+i);
            }
        },
        refreshBtnsStatus : function () {
            var status = selfCurrentBtnStates;
            for(var key in status){
                this.setBtnEnableState('ops.'+key, !!status[key])
            }
        },
        setBtnEnableState : function (name, val) {
            if(!$(name)){
                return;
            }
            if(val){
                this.enableBtn(name);
            }else{
                this.disableBtn(name);
            }
        },
        disableOpsBtns: function (excepts) {
            var array = ['ops.qi', 'ops.bi', 'ops.jia', 'ops.gen', 'ops.kan'];
            excepts = excepts || [];
            for(var i=0; i<array.length; i++){
                var name = array[i];
                if(excepts.indexOf(name)>=0)continue;
                this.disableBtn(name);
            }
        },
        disableBtn: function (btnname, type) {
            // console.log("disableBtn ->" + btnname);
            // $(btnname).setTexture(BUTTON_COMMON_RES['disable1']);

            // TouchUtils.removeListeners($(btnname));
            // $(btnname + '.txt').setTextColor(cc.color(255, 255, 255));
            // $(btnname + '.txt').enableOutline(cc.color(48, 57, 59), 2);
            TouchUtils.setClickDisable($(btnname),true);
            // alfa = true;
            // if(alfa){
            //Filter.grayMask2($(btnname));
            // $(btnname).setOpacity(120);
            // $(btnname).setLocalZOrder(-1);
            var resName = null;
            if(type==1){
                $(btnname).setOpacity(100);
                resName = 'res/image/ui/zjh/table/mask_circle_bg.png';
            }else{
                resName = 'res/image/ui/zjh/table/btn_up_bg.png';
            }
            var maskSp =  $('mask',$(btnname))
            if(!maskSp){
                maskSp = new cc.Sprite(resName);
                $(btnname).addChild(maskSp);
                maskSp.x = $(btnname).width/2;
                maskSp.y = $(btnname).height/2;
                maskSp.setName('mask');
            }
            // }else{
            //     Filter.grayMask2($(btnname));
            // }
            //
            var childs = $(btnname).getChildren();
            var len = $(btnname).getChildrenCount();
            for(var i=0; i<len; i++){
                var child = childs[i];
                if(child instanceof ccui.Text){
                    child.setOpacity(120);
                }
            }
        },
        enableBtn: function (btnname) {
            var maskSp =  $('mask', $(btnname))
            if(maskSp){
                maskSp.removeFromParent();
            }
            $(btnname).setOpacity(255);
            // $(btnname).setLocalZOrder(1);
            // var texture_filename = {
            //     'ops.qi': BUTTON_COMMON_RES['red1'],
            //     'ops.bi': BUTTON_COMMON_RES['blue1'],
            //     'ops.jia': BUTTON_COMMON_RES['blue1'],
            //     'ops.gen': BUTTON_COMMON_RES['orange1'],
            //     'jia.jia2': BUTTON_COMMON_RES['orange1'],
            //     'jia.jia3': BUTTON_COMMON_RES['orange1'],
            //     'jia.jia4': BUTTON_COMMON_RES['orange1'],
            //     'jia.jia5': BUTTON_COMMON_RES['orange1'],
            // };
            // var outline_color = {
            //     'ops.qi': BUTTON_COMMON_FONT_COLOR['red'],
            //     'ops.bi': BUTTON_COMMON_FONT_COLOR['blue'],
            //     'ops.jia': BUTTON_COMMON_FONT_COLOR['blue'],
            //     'ops.gen': BUTTON_COMMON_FONT_COLOR['orange'],
            //     'jia.jia2': BUTTON_COMMON_FONT_COLOR['orange'],
            //     'jia.jia3': BUTTON_COMMON_FONT_COLOR['orange'],
            //     'jia.jia4': BUTTON_COMMON_FONT_COLOR['orange'],
            //     'jia.jia5': BUTTON_COMMON_FONT_COLOR['orange']
            // };
            // // $(btnname).setTexture(texture_filename[btnname]);
            // // $(btnname + '.txt').setTextColor(cc.color(255, 255, 255));
            // // $(btnname + '.txt').enableOutline(outline_color[btnname], 2);
            // Filter.remove($(btnname));
            TouchUtils.setClickDisable($(btnname),false);
            var childs = $(btnname).getChildren();
            var len = $(btnname).getChildrenCount();
            for(var i=0; i<len; i++){
                var child = childs[i];
                if(child instanceof ccui.Text){
                    child.setOpacity(255);
                }
            }
        },
        setOperateFinishCb: function (cb) {
            this.operateFinishCb = cb;
        },
        getRowByUid: function (uid) {
            return uid2position[uid];
        }
    });
    exports.MaLayer_zjh = MaLayer_zjh;
})(window);
