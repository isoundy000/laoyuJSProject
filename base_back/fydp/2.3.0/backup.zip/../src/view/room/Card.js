var Card = {
    init:function () {
        this.img = getUI(this, "img");
        this.isSelected = false;
        this.lastClickTime = 0;

        return true;
    },
    //type 0中 1大 2小
    setData:function(data, p, typ, isWei){
        this.p = p;
        var visible = true;
        if (data == null) visible = false;
        data = parseInt(data);
        this.data = data;
        this.typ = typ;
        this.isWei = isWei;

        var cardname = "";
        if(typ == 1){
            cardname = "big_" + data;
        }else if(typ == 2){
            cardname = "small_" + data;
        }else{
            cardname = "mid_" + data;
        }
        //如果是0  显示牌背
        if (data == 0){
            var card = "backbig.png";
            this.img.loadTexture(card, ccui.Widget.PLIST_TEXTURE);
            // setUIImageFrameByName(this.img, card, 'card/card_common');
        }else{
            var imgSrc = this.getCardImg(cardname);
            if(typ == 2 && isWei == true){
                imgSrc = "back.png";
            }
            this.imgSrc = imgSrc;
            // this.img.loadTexture(imgSrc, ccui.Widget.PLIST_TEXTURE);
            setUIImageFrameByName(this.img, imgSrc, 'card_common/card_common');
        }
        if(typ == 1){
            //大牌加蓝边
            this.img.setContentSize(76, 226);
            // this.setPositionX(this.getPositionX() + 60);
        }else if(typ == 2){
            this.img.setContentSize(42*1.1, 42*1.1);
        }else{
            // this.img.setScale(100/75);
            this.img.setContentSize(98, 122);
        }
        this.img.setVisible(visible);
    },

    setRowColumn: function(row, column){// y x
        this.row = row;
        this.column = column;
    },

    setMo:function(flag){
        var light = this.img.getChildByName("light");
        if (light == null) {
            light = new cc.Sprite(res.chupai_bj_png);
            // light.setScaleX(this.img.getContentSize().width / light.getContentSize().width);
            // light.setScaleY(this.img.getContentSize().height / light.getContentSize().height);
            light.setName("light");
            light.setPosition(cc.p(this.img.getContentSize().width / 2, this.img.getContentSize().height / 2));
            this.img.addChild(light, -1);
        }
        light.setPosition(cc.p(this.img.getContentSize().width / 2, this.img.getContentSize().height / 2));
        light.setVisible(true);
        light.setTexture(flag ? res.mopai_bj_png : res.chupai_bj_png);
    },
    setSelectedCard: function (theCard) {
        this.selectedCard = theCard;

        this.img.setTouchEnabled(true);
        this.img.setSwallowTouches(true);
        if(mRoom.isReplay != true){
            this.img.addTouchEventListener(this.onSelect, this);
        }
    },
    setTouchEnableStatus:function(flag){
        if(this.img){
            this.img.setTouchEnabled(flag);
        }
    },
    setGrayCard:function(flag){
        var gray = this.img.getChildByName('gray');
        if (!gray) {
            gray = new cc.Scale9Sprite(res.gray_png, cc.rect(0, 0, 50, 50), cc.rect(20, 20, 10, 10));
            gray.setContentSize(cc.size(this.img.getContentSize().width, this.img.getContentSize().height));
            gray.setPosition(cc.p(this.img.getContentSize().width / 2, this.img.getContentSize().height / 2));
            gray.setName('gray');
            this.img.addChild(gray);
        }
        gray.setVisible(flag);
    },
    setGreenCard: function (flag) {
        var green = this.img.getChildByName('green');
        if (!green) {
            green = new cc.Scale9Sprite(res.green_png, cc.rect(0, 0, 50, 50), cc.rect(20, 20, 10, 10));
            green.setContentSize(cc.size(this.img.getContentSize().width, this.img.getContentSize().height));
            green.setPosition(cc.p(this.img.getContentSize().width / 2, this.img.getContentSize().height / 2));
            green.setName('green');
            this.img.addChild(green);
        }
        green.setVisible(flag);
    },
    setRedCard: function () {
        var red = this.img.getChildByName('red');
        if (!red) {

            // red = new cc.Scale9Sprite(res.red_png, cc.rect(0, 0, 50, 50), cc.rect(20, 20, 10, 10));
            red = new cc.LayerColor();
            red.setColor(cc.color(64, 64, 64));
            red.setOpacity(130);
            // red.setAnchorPoint(cc.p(0.5, 0.5))
            red.setContentSize(cc.size(this.img.getContentSize().width, this.img.getContentSize().height));
            red.setPosition(cc.p(0, 0));
            red.setName('red');
            this.img.addChild(red);
        }
        red.setVisible(true);
    },
    getCardImg:function(cardname){
        if(cardname.indexOf('NaN') >= 0)  return "backbig.png";

        var src = "cardcommon_" + cardname + ".png";
        if(gameData.fontType == "common"){
            src = "cardcommon_" + cardname + ".png";
        }else if(gameData.fontType == "ld"){
            src = cardname + ".png";
        }else{
            if(mRoom.wanfatype == mRoom.FANGPAOFA ||
                mRoom.wanfatype == mRoom.CHANGSHA ||
                mRoom.wanfatype == mRoom.LEIYANG ||
                mRoom.wanfatype == mRoom.SHAOYANG ||
                mRoom.wanfatype == mRoom.SHAOYANGBOPI ||
                mRoom.wanfatype == mRoom.HONGGUAIWAN ||
                mRoom.wanfatype == mRoom.XIANGXIANG ||
                mRoom.wanfatype == mRoom.GUILIN ||
                mRoom.wanfatype == mRoom.HENGYANG){
                src = cardname + ".png";
            }
        }
        return src;
    },
    resetCardImg:function(){
        var typ = this.typ;
        var data = this.data;
        var cardname = "";
        if(typ == 1){
            cardname = "big_" + data;
        }else if(typ == 2){
            cardname = "small_" + data;
        }else{
            cardname = "mid_" + data;
        }
        //如果是0  显示牌背
        if (this.data == 0){
            var card = "backbig.png";
            this.img.loadTexture(card, ccui.Widget.PLIST_TEXTURE);
            // setUIImageFrameByName(this.img, card, 'card/card_common');
        }else{
            var imgSrc = this.getCardImg(cardname);
            // console.log("imgSrc"+imgSrc);
            if(this.typ == 2 && this.isWei == true){
                imgSrc = "back.png";
            }
            // this.img.loadTexture(imgSrc, ccui.Widget.PLIST_TEXTURE);
            setUIImageFrameByName(this.img, imgSrc, 'card_common/card_common');
        }
    },

    onStatusChange:function(event){
        if(this.checkNoRunning()) return;
        var data = event.getUserData();
        //LOGIN OK
    },

    onSelect: function (sender, type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                this.isSelected = true;
                this.img.setOpacity(180);
                this.selectedCard.setData(this.data);
                var pos = sender.getTouchBeganPosition();
                this.updateSelectedCard(true, pos);

                this.p.setSameCardShow(this.data, true);
                break;

            case ccui.Widget.TOUCH_MOVED:
                var pos = sender.getTouchMovePosition();
                this.updateSelectedCard(true, pos);
                break;

            case ccui.Widget.TOUCH_ENDED:
                this.isSelected = false;
                this.img.setOpacity(255);
                var pos = sender.getTouchEndPosition();

                // var clickTime = Date.now();
                // if(clickTime - this.lastClickTime < 500){
                //     this.lastClickTime = 0;
                //     this.showCard();
                //     this.selectedCard.setVisible(false);
                //     return;
                // }

                this.lastClickTime = Date.now();
                this.updateSelectedCard(false, pos);

                this.p.setSameCardShow(this.data, false);
                break;

            case ccui.Widget.TOUCH_CANCELED:
                this.isSelected = false;
                this.img.setOpacity(255);
                var pos = sender.getTouchEndPosition();
                this.updateSelectedCard(false, pos);

                this.p.setSameCardShow(this.data, false);
                break;

            default:
                break;
        }
        return false;
    },

    updateSelectedCard:function(isShow, pos){
        this.selectedCard.setVisible(isShow);
        var px = pos.x - 30*0.8;
        var py = pos.y - 63;
        this.selectedCard.setPosition(px, py);

        if(isShow == false){
            if(py > 300)
                this.showCard();
            else{
                this.p.moveCard(this, px, py);
            }
        }
    },

    showCard: function () {
        if(this.p.isTurnOut == true){
            this.p.userShowCard(this.data, false, this.row, this.column);
        }else{
            // HUD.showMessage("未到出牌回合！");
        }
    },

    /** @returns Card */
    getCom: function (p, name) {return getCom(p, name, this);}
};