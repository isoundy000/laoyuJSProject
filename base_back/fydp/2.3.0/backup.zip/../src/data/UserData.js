var UD = {
    ServerList:{},      //服务器列表
    Account:{},         //账号信息
    RoleData:{},        //角色信息


    END:0
};
