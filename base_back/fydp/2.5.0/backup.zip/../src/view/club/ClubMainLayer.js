/**
 * Created by hjx on 2018/2/7.
 */

(function () {
    var exports = this;
    var $ = null;
    var enterRoomWithClubID= 0;
    var isInRoomLayer = false;

    /**
     *针对一堆按钮互斥 产生按钮变化的统一处理
     * @param list  传入按钮数组
     * @param options 按钮显示的互斥配置
     * {
                    btnchoose:'res/ui/newclub/img/btn_main_2.png',
                    btnnochoose:'res/ui/newclub/img/btn_main_1.png',
                    word:[
                        ['res/ui/newclub/img/word_wdjlb2.png', 'res/ui/newclub/img/word_wdjlb1.png'],
                        ['res/ui/newclub/img/word_zj2.png', 'res/ui/newclub/img/word_zj1.png'],
                        ['res/ui/newclub/img/word_xx2.png', 'res/ui/newclub/img/word_xx1.png']
                    ]
                }
     */
    var btnsMutexExecute = function (list, options) {
        for (var i = 0; i < list.length; i++) {
            (function (j) {
                var _btn = list[j];
                TouchUtils.setOnclickListener(_btn, function () {
                    for (var x = 0; x < list.length; x++) {
                        var ibtn = list[x];
                        if (x != j) {
                            ibtn.setTexture(options.btnnochoose);
                            ibtn.getChildren()[0].setTexture(options.word[x][0]);
                        } else {
                            ibtn.setTexture(options.btnchoose);
                            ibtn.getChildren()[0].setTexture(options.word[x][1]);
                        }
                    }
                });
            })(i);

        }
    };

    var clubsInfo = [];


    var msgListeners = {};

    var ClubMainLayer = cc.Layer.extend({
        onCCSLoadFinish: function () {
            // cc.eventManager.addCustomListener(2103, function (data) {
            //     var cmd = data['command'];
            //     var errorCode = data['result'];
            //     var errorMsg = data['msg'];
            //
            //     if (errorCode && errorMsg!="没有房间") {
            //         alert1(errorMsg);
            //     }
            //
            //     if (msgListeners[cmd]) {
            //         console.log("处理俱乐部消息：" + cmd + "数量：" + msgListeners[cmd].length);
            //         for(var i=0; i<msgListeners[cmd].length; i++){
            //             msgListeners[cmd][i](data);
            //         }
            //     }else{
            //         console.log("未处理俱乐部消息");// + JSON.stringify(data));
            //     }
            // });
        },
        getRootNode: function () {
            return this.getChildByName("Layer");
        },
        ctor: function (clubid) {
            this._super();
            var that = this;
            // var mainscene = ccs.load(res.ClubMainLayer_json, "res/");
            // this.addChild(mainscene.node);
            // $ = create$(this.getChildByName("Layer"));

            enterRoomWithClubID = clubid;

            loadCCSTo(res.ClubMainLayer_json, this, "Layer");
            $ = create$(this.getRootNode());

            TouchUtils.setOnclickListener($('root'), function () {
            });

            //btn_join
            TouchUtils.setOnclickListener($('btn_join'), function () {
                // that.addChild(new ClubJoinLayer());
                that.addChild(new ClubInputLayer('join'));
            });

            TouchUtils.setOnclickListener($('btn_xiaoxi'), function () {
                that.addChild(new ClubMsgLayer());
            });

            TouchUtils.setOnclickListener($('btn_help'), function () {
                that.addChild(new GuideLayer());
            });
            //btn_refresh
            var refresh = 0;
            TouchUtils.setOnclickListener($('btn_refresh'), function () {
                network.send(2103, {cmd: 'queryClub',refresh:refresh});
                refresh++;
            });

            // btnsMutexExecute([$('btn_club'), $('btn_zhanji'), $('btn_xiaoxi')],
            //     {
            //         btnchoose: 'res/ui/newclub/img/btn_main_2.png',
            //         btnnochoose: 'res/ui/newclub/img/btn_main_1.png',
            //         word: [
            //             ['res/ui/newclub/img/word_wdjlb1.png', 'res/ui/newclub/img/word_wdjlb2.png'],
            //             ['res/ui/newclub/img/word_zj1.png', 'res/ui/newclub/img/word_zj2.png'],
            //             ['res/ui/newclub/img/word_xx1.png', 'res/ui/newclub/img/word_xx2.png']
            //         ]
            //     }
            // );

            TouchUtils.setOnclickListener($('btn_close'), function () {
                enterRoomWithClubID = 0;
                gameData.enterRoomWithClubID = 0
                that.removeFromParent(true);
            });


            var versiontxt = window.curVersion;
            var version = new ccui.Text();
            version.setFontSize(18);
            version.setTextColor(cc.color(255, 255, 255));
            version.setPosition(cc.p(1280 - 10, 10));
            version.setAnchorPoint(cc.p(1, 0.5));
            version.setString(versiontxt);
            this.addChild(version, 2);

            isInRoomLayer = false;
            that.scheduleOnce(function(){
                console.log("enterRoomWithClubID"+enterRoomWithClubID);
                if(isInRoomLayer = false && enterRoomWithClubID && that.clubList){
                    for(var i=0;i<that.clubList.length;i++){
                        var item = that.clubList[i];
                        if(item && cc.sys.isObjectValid(item) && _.isFunction(item.enterClub)&& item.club_id && item.club_id == enterRoomWithClubID){
                            item.enterClub(item.club_id);
                            isInRoomLayer = true;
                            break;
                        }
                    }
                }
            }, 0.6);
            // cc.eventManager.removeCustomListeners('custom_listener_2103');
            // cc.eventManager.removeCustomListeners('queryClub');
            // cc.eventManager.removeCustomListeners('flushClub');
            //
            // cc.eventManager.removeCustomListeners('addWanfa');
            // cc.eventManager.removeCustomListeners('listClubRoom');
            // cc.eventManager.removeCustomListeners('leaveClub');
            // cc.eventManager.removeCustomListeners('deleteClub');
            // cc.eventManager.removeCustomListeners('queryMSG');
            // cc.eventManager.removeCustomListeners('delWanfa');
            //
            // cc.eventManager.removeCustomListeners('setAdmin');
            // cc.eventManager.removeCustomListeners('unsetAdmin');
            // cc.eventManager.removeCustomListeners('agreeClub');

            this.list2103 = cc.eventManager.addCustomListener("custom_listener_2103", function(event){
                var data = event.getUserData();
                if (data) {
                    console.log("main=====list2103")
                    var cmd = data['command'];
                    var errorCode = data['result'];
                    var errorMsg = data['msg'];

                    if (errorCode && errorMsg != "没有房间") {
                        alert1(errorMsg);
                    }

                    cc.eventManager.dispatchCustomEvent(cmd, data);
                }
            });
            this.list1 = cc.eventManager.addCustomListener("queryClub", function (event) {
                var data=event.getUserData();
                console.log("main=====queryClub")
                refreshClubData(data['arr']);
                that.refreshClub(clubsInfo);
            });
            this.list2 = cc.eventManager.addCustomListener("flushClub", function (event) {
                var data=event.getUserData();
                console.log("main=====flushClub")
                refreshClubData(data.info._id, data['info']);
                that.refreshClub(clubsInfo);
            });

            network.send(2103, {cmd: 'queryClub'});

            return true;
        },
        onEnter : function () {
            this._super();
            var that = this;
            // this.lis1 = cc.eventManager.addCustomListener('queryClub', function (data) {
            //     refreshClubData(data['arr']);
            //     that.refreshClub(clubsInfo);
            // })
            // this.lis2 = cc.eventManager.addCustomListener('flushClub', function (data) {
            //     refreshClubData(data.info._id, data['info']);
            //     that.refreshClub(clubsInfo);
            // })
        },
        onExit : function () {
            this._super();
            // cc.eventManager.removeListener('queryClub', this.lis1);
            // cc.eventManager.removeListener('flushClub', this.lis2);
            // cc.eventManager.removeListener('queryMSG', this.lis3);
            cc.eventManager.removeListener(this.list2103);
            cc.eventManager.removeListener(this.list1);
            cc.eventManager.removeListener(this.list2);

            console.log("ClubMainLayer === onExit")
        },

        refreshClub: function (dataArr) {
            var that = this;
            this.scrollView = $('scrolView');
            this.scrollView.removeAllChildren(true);
            this.state = 1;

            if (!dataArr || !dataArr.length || dataArr.length < 1) {
                $('meinv').setVisible(true);
                return;
            }else{
                $('meinv').setVisible(false);
            }
            this.layout = new ccui.Layout();
            this.clubList = [];
            this.totalWidth = 0;
            for (var i = 0; i < dataArr.length; i++) {
                (function(itemData, index){
                    that.initItem(itemData, index);
                })(dataArr[i], i);
            }

            this.scrollView.setInnerContainerSize(cc.size(this.totalWidth, this.scrollView.getContentSize().height));
            this.scrollView.addChild(this.layout);
            this.layout.setPositionX(0);
        },
        initItem: function (itemData, index) {
            var item = new ClubInfoItem(itemData, this);
            item.club_id = itemData._id;
            this.clubList[index] = item;
            //进去房间列表
            if(isInRoomLayer == false && item && cc.sys.isObjectValid(item) && _.isFunction(item.enterClub)&& item.club_id && item.club_id == enterRoomWithClubID){
                item.enterClub(item.club_id);
                isInRoomLayer = true;
            }

            this.layout.addChild(item);

            var itemWidth = item.getLayerWidth();
            item.setPositionX(this.totalWidth );
            this.totalWidth += itemWidth;
        }
    });
    exports.ClubMainLayer = ClubMainLayer;
    exports.getClubData = function (id) {
        if(id){
            for(var i=0; i<clubsInfo.length; i++){
                if(clubsInfo[i]._id == id){
                    return clubsInfo[i];
                }
            }
        }
        return clubsInfo;
    };
    exports.refreshClubData = function (id, data) {
        if(_.isArray(id)){
            clubsInfo = id;
        }else{
            for(var i=0; i<clubsInfo.length; i++){
                if(clubsInfo[i]._id == id){
                    clubsInfo[i] = data;
                    break;
                }
            }
        }
        return data;
    };
    // exports.addClubInfoListener = function (key, callback) {
    //     if (!msgListeners[key]) {
    //         msgListeners[key] = [];
    //     }
    //     msgListeners[key].push(callback);
    //     return callback;
    // };
    // exports.cc.eventManager.removeListener = function (key, callback) {
    //     // msgListeners[key] = undefined;
    //     if(callback && msgListeners[key]){
    //         var idx = msgListeners[key].indexOf(callback)
    //         if(idx>=0){
    //             msgListeners[key].splice(idx, 1);
    //         }
    //     }else{
    //         msgListeners[key] = undefined;
    //     }
    // };
    exports.getWanfaPlayerCountByMapId = function (id, desc) {
        switch (id){
            case MAP_ID.ZJH:
                if(desc && desc.indexOf('九人') >= 0)  return 9;
                return 5;
            case MAP_ID.EPZ:
                return 8;
            case MAP_ID.NN:
                return 5;
            case MAP_ID.DN_AL_TUI:
            case MAP_ID.DN_JIU_REN:
            case MAP_ID.DN_WUHUA_CRAZY:
            case MAP_ID.DN:
                if(desc && desc.indexOf('九人') >= 0)  return 9;
                return 6;
            case MAP_ID.PDK:
                return 3;
            case MAP_ID.DDZ_JD:
            case MAP_ID.DDZ_LZ:
                return 3;
            case MAP_ID.CP_KAOKAO:
                return 3;
        }
        return 4;
    }
})(window);