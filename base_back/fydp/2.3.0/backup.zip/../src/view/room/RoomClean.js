var RoomClean = {
    init:function () {
        var that = this;
        this.bt1 = getUI(this, "bt1");
        this.bt1.addTouchEventListener(this.onShareWx, this);
        this.close = getUI(this, "close");

        this.title = getUI(this, "title");
        this.txtTime = getUI(this, "txtTime");
        this.txtRoomId = getUI(this, "txtRoomId");
        this.txtRounds = getUI(this, "txtRounds");
        this.title.setString(mRoom.getWanfaName(mRoom.wanfatype) + "--牌局结束");

        playEffect('yin_win');
        mRoom.isClean = true;

        if(window.inReview){
            this.bt1.setVisible(false);
        }

        //关闭按钮 5秒后 才可以点击
        this.leftSecond = 3;
        this.closelabel = getUI(this.close, "closelabel");
        that.closelabel.setString("关闭");
        TouchUtils.setOnclickListener(that.close, function (node) {
            mRoom.isClean = false;
            //cc.eventManager.removeAllListeners(););
            DC.closeByClient = true;
            DD[T.PlayerList] = [];
            clearGameMWRoomId();
            HUD.showScene(HUD_LIST.Home, that);
            //DC.socket.close();
        });


        // TouchFilter.grayScale(this.close);
        // this.schedule(function () {
        //     that.leftSecond--;
        //     if(that.leftSecond == 0){
        //         TouchFilter.remove(that.close);
        //         that.closelabel.setString("关闭");
        //         TouchUtils.setOnclickListener(that.close, function (node) {
        //             if(that.leftSecond > 0) return;
        //             mRoom.isClean = false;
        //             //cc.eventManager.removeAllListeners(););
        //             DC.closeByClient = true;
        //             DC.socket.close();
        //             HUD.showScene(HUD_LIST.Home, that);
        //         });
        //     }else if(that.leftSecond > 0){
        //         that.closelabel.setString(that.leftSecond + "秒后关闭");
        //     }
        // }, 1);

        return true;
    },

    setRoom:function(resultlayer, gameOverData){
        this.gameOverData = gameOverData;

        //格式化时间
        this.txtTime.setString(this.gameOverData.EndTime);
        this.txtRoomId.setString("房间号:"+this.gameOverData.RoomID);
        this.txtRounds.setString("局数:"+this.gameOverData.CurrentRound + "/" + this.gameOverData.TotalRound);
        this.setData();
    },
    setData:function(){
        var maxScore = -100;
        if (this.gameOverData.Users[0].Score == 0
            && this.gameOverData.Users[1].Score == 0
            && this.gameOverData.Users[2].Score == 0){
            maxScore = 9999;//都是0,没有赢家
        }else{
            for(var s = 0; s < this.gameOverData.Users.length; s++){
                var score = this.gameOverData.Users[s].Score;
                if(score > maxScore){
                    maxScore = score;
                }
            }
        }

        if(mRoom.getPlayerNum() == 3){
            var info4 = getUI(this, "info4");
            info4.setVisible(false);
            for(var i=0;i<3;i++){
                var info = getUI(this, "info" + (i+1));
                info.setPositionX(50 + i*392 + (1-i)*40);
            }
        }
        var pList = this.gameOverData.Users;
        var fangzhuIsIn = false;
        for(var i=0;i<pList.length;i++){
            var player = pList[i];

            var info = getUI(this, "info" + (i+1));
            var name = getUI(info, "name");
            var id = getUI(info, "id");
            var score = getUI(info, "score");
            var winner = getUI(info, "winner");
            var hpcs = getUI(info, "hpcs");
            var zghx = getUI(info, "zghx");
            var zgfx = getUI(info, "zgfx");
            var zgjf = getUI(info, "zgjf");
            name.setString(ellipsisStr(player.UserName, 7) || '');
            id.setString(player.UserID || '');
            score.setString(player.Score || '0');
            hpcs.setString(player.HuCount || '0');
            zghx.setString(player.MaxHuxi || '0');
            zgfx.setString(player.MaxFanCount || '0');
            zgjf.setString(player.MaxJi || '0');
            //头像
            var avator = getUI(this, "avator" + (i+1));
            var url = decodeURIComponent(player.HeadImgURL);
            if (url == undefined || (url.length == 0)) url = res.defaultHead;
            loadImageToSprite(url, avator);//头像

            if(player.Score >= maxScore){
                winner.setVisible(true);
            }else{
                winner.setVisible(false);
            }

            if(this.gameOverData.Owner && this.gameOverData.Owner == player.UserID){
                fangzhuIsIn = true;
            }
        }
        var fangzhu = getUI(this, "icon_fz_1");
        if(fangzhu) fangzhu.setVisible(fangzhuIsIn);
    },
    onOk: function (sender, type) {
        var ok = touch_process(sender, type);
        if(ok){

        }
    },
    onShareWx:function(sender, type){
        var that = this;
        var ok = touch_process(sender, type);
        if(ok){
            //先隐藏按钮  在现实
            that.bt1.setVisible(false);
            that.close.setVisible(false);
            that.scheduleOnce(function(){
                that.bt1.setVisible(true);
                that.close.setVisible(true);
            }, 1);
            if (!cc.sys.isNative)
                return;
            WXUtils.captureAndShareToWX(that);
        }
    }
}