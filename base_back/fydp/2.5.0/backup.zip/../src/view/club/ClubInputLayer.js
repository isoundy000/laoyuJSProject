/**
 * Created by hjx on 2018/2/8.
 */
(function () {
    var exports = this;

    var $ = null;

    var ClubInputLayer = cc.Layer.extend({
        layerHeight: 0,
        ctor: function (type, data) {
            this._super();

            var that = this;

            var scene = ccs.load(res.ClubInputLayer_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            if(type == 'invite'){
                $('lb_content').setString("请输入要邀请的玩家ID");
                $('img_title').setTexture('res/image/ui/club/word_invite.png');
                $('btn_ok').loadTexture('res/image/ui/club/btn_ok.png');
            }else if(type == 'changeName'){
                $('lb_content').setString("请输入要修改的俱乐部名称");
                $('img_title').setTexture('res/image/ui/club/word_xgmc.png');
                $('btn_ok').loadTexture('res/image/ui/club/btn_qrxg.png');
            }else if(type == 'join'){
                $('lb_content').setString("请输入要加入的俱乐部ID");
                // $('img_title').setTexture('res/image/ui/club/word_invite.png');
                $('img_title').setVisible(false);
                $('btn_ok').loadTexture('res/image/ui/club/btn_ok.png');
                if(data)$('input').setString('' + data);
            }



            var inputNode = $('input');
            inputNode.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);

            inputNode.addEventListener(function (textField, type) {
                switch (type) {
                    case ccui.TextField.EVENT_ATTACH_WITH_IME:
                        //that.setPositionY(320);
                        cc.log("attach with IME");
                        break;
                    case ccui.TextField.EVENT_DETACH_WITH_IME:
                        that.setPositionY(0);
                        cc.log("detach with IME");
                        break;
                    case ccui.TextField.EVENT_INSERT_TEXT:
                        cc.log("insert words");
                        break;
                    case ccui.TextField.EVENT_DELETE_BACKWARD:
                        cc.log("delete word");
                        break;
                    default:
                        break;
                }
            }, that);
            TouchUtils.setOnclickListener($('btn_close'), function () {
                that.removeFromParent();
            });
            TouchUtils.setOnclickListener($('root'), function () {
            });
            TouchUtils.setOnclickListener($('btn_ok'), function () {
                inputNode.didNotSelectSelf();
                var input = inputNode.getString();

                if(type == 'apply'){
                    if(input == null || input == undefined || input == ""){
                        var tip = "俱乐部ID不能为空";
                        if(that.createoradd == "create")  tip = "俱乐部名称不能为空";
                        alert1(tip, true);
                        return;
                    }
                    if(input.length < 1 || input.length > 17){
                        var tip = "群ID长度在1-16字符之间";
                        if(that.createoradd == "create")  tip = "群昵称长度在1-16字符之间";
                        alert1(tip, true);
                        return;
                    }

                    var inputnum = parseInt(input);
                    if (!inputnum) {
                        alert1('群ID不是数字');
                        return;
                    }
                    network.send(2103, {
                        cmd: 'applyClub',
                        club_id: input,
                        name: gameData.nickname,
                        head: gameData.headimgurl
                    });
                }else if(type == 'invite'){
                    var inputnum = parseInt(input);
                    if(!inputnum){
                        alert1('玩家ID不是数字');
                        return;
                    }
                    // console.log('俱乐部id --- ' + data['_id']);
                    network.send(2103, {cmd:'addClubMember', club_id:data['_id'], obj_id:inputnum});
                }else if(type == 'changeName'){
                    var tip = "";
                    var str = input;
                    if(str == null || str == undefined || str == ""){
                        tip = "俱乐部名称为空";
                    }
                    if(tip == "" && (str.length < 2 || str.length > 17)){
                        tip = "群名称长度在2-16字符之间";
                    }
                    if(tip == ""){
                        network.send(2103, {cmd:'modifyClub', club_id:data['_id'], name:str});
                        // that.removeFromParent();
                    }else{
                        alert1(tip);
                    }
                }else if(type == "join"){
                    if(input == null || input == undefined || input == ""){
                        var tip = "俱乐部ID不能为空";
                        if(that.createoradd == "create")  tip = "俱乐部名称不能为空";
                        alert1(tip, true);
                        return;
                    }
                    if(input.length < 1 || input.length > 17){
                        var tip = "群ID长度在1-16字符之间";
                        if(that.createoradd == "create")  tip = "群昵称长度在1-16字符之间";
                        alert1(tip, true);
                        return;
                    }

                    var inputnum = new Number(input);
                    if (_.isNaN(inputnum)) {
                        alert1('请输入正确的群ID（数字）');
                        return;
                    }
                    network.send(2103, {
                        cmd: 'applyClub',
                        club_id: input,
                        name: gameData.nickname,
                        head: gameData.headimgurl
                    });
                }


            });

            return true;
        },
        getLayerHeight: function () {
            return this.layerHeight;
        },
        onEnter : function () {
            this._super();
            var that = this;
            that.msgList = [];
            this.lis1 = cc.eventManager.addCustomListener('applyClub', function (event){
                var data = event.getUserData();
                if(data.result==0)
                    alert1(data.msg);
                that.removeFromParent();
            })
            this.lis2 = cc.eventManager.addCustomListener('addClubMember', function (event){
                var data = event.getUserData();
                if(data.result==0)alert1('成员成功加入俱乐部');
                that.removeFromParent();
            })

            this.lis3 = cc.eventManager.addCustomListener('modifyClub', function (event){
                var data = event.getUserData();
                if(data.result==0)alert1("俱乐部名称修改成功");
                that.removeFromParent();
            })
        },
        onExit : function () {
            this._super();
            cc.eventManager.removeListener(this.lis1);
            cc.eventManager.removeListener(this.lis2);
            cc.eventManager.removeListener(this.lis3);
        }
    });

    exports.ClubInputLayer = ClubInputLayer;
})(window);