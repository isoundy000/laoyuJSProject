var GameResultPenghz = {
    init:function () {
        this.close = getUI(this, "close");
        this.close.addTouchEventListener(this.onClose, this);
        this.nContent = getUI(this, "tableview");
        for(var i=1;i<=4;i++){
            this["score" + i] = getUI(this, "score" + i);
            this["name" + i] = getUI(this, "name" + i);
        }
        return true;
    },
    setData:function (data, players){
        this.itemList = [];
        for(var i=0;i<data.length;i++){
            if(data[i].Change) this.itemList[this.itemList.length] = data[i];
        }
        // console.log(this.itemList);
        var tableView = new cc.TableView(this, cc.size(720, 240));
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.x = 0;
        tableView.y = -1;
        tableView.setDelegate(this);
        tableView.setBounceable(true);
        this.nContent.addChild(tableView);
        this.tableView = tableView;
        tableViewRefresh(this.tableView);

        for(var i=1;i<=4;i++){
            var allscore = this.itemList[this.itemList.length - 1].Change.split("/");
            this["score" + i].setString(allscore[i - 1]);

            if(players && players.length > 0){
                this["name" + i].setString(ellipsisStr(players[i - 1].UserName, 4));
            }
        }
    },
    tableCellTouched: function (table, cell) {

    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(720, 80);
    },

    tableCellAtIndex: function (table, idx) {
        var strValue = idx.toFixed(0);
        var cell = table.dequeueCell();
        if (cell == null) {
            cell = new cc.TableViewCell();
            this.createCell(cell, idx);
        }
        this.updateCell(cell, idx);
        return cell;
    },
    createCell: function (cell, idx) {
        //
        var cp = new cc.Sprite(res.c_chi_png);
        cp.setPosition(cc.p(35, 30));
        cp.setName('cp');
        cell.addChild(cp);
        //吃的那张牌
        var card = new ccui.Text();
        card.setName('card');
        card.setFontSize(30);
        card.setAnchorPoint(cc.p(0, 0.5));
        card.setTextColor(cc.color(255, 255, 255));
        card.enableOutline(cc.color(38, 38, 38), 1);
        card.setPosition(cc.p(50, 30));
        cell.addChild(card);
        for(var i=0;i<4;i++){
            var num = new ccui.Text();
            num.setName('num' + i);
            num.setFontSize(30);
            num.setTextColor(cc.color(255, 255, 255));
            num.enableOutline(cc.color(38, 38, 38), 1);
            num.setPosition(cc.p(200 + 140*i, 30));
            cell.addChild(num);
        }
    },
    updateCell: function (cell, idx) {
        var Action = this.itemList[idx].Action;
        var ActionList = Action.split("/");
        var cpimg = res.c_chi_png;
        if(ActionList[2] == 'peng'){
            cpimg = res.c_peng_png;
        }else if(ActionList[2] == 'wei' || ActionList[2] == 'chouwei'){
            cpimg = res.c_wei_png;
        }else if(ActionList[2] == 'pao'){
            cpimg = res.c_pao_png;
        }else if(ActionList[2] == 'ti') {
            cpimg = res.c_ti_png;
        }else if(ActionList[2] == 'hu'){
            cpimg = res.c_hu_png;
        }
        var cp = cell.getChildByName('cp');
        cp.setTexture(cpimg);
        cp.setScale((ActionList[2] == 'hu') ? 0.8:1);
        //吃的啥牌
        var paiList = ['','一','二','三','四','五',
        '六','七','八','九','十',
        '壹','贰','叁','肆','伍',
        '陆','柒','捌','玖','拾'];
        var actionList = this.itemList[idx].Action.split("/");
        var card = cell.getChildByName('card');
        card.setString("("+ paiList[actionList[3]] +")");
        for(var i=0;i<4;i++){
            var num = cell.getChildByName('num' + i);
            var scoreList = this.itemList[idx].Change.split("/");
            num.setString(scoreList[4 + i]);
        }
    },

    numberOfCellsInTableView: function (table) {
        if (this.itemList == null) return 0;
        return this.itemList.length;
    },

    onClose:function (sender, type) {
        var ok = touch_process(sender, type);
        if(ok){
            this.removeFromParent();
        }
    },
};