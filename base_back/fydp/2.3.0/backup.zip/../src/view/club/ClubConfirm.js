(function () {
    var exports = this;
    var $ = null;

    var ClubConfirm = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        ctor: function (club_id, typ) {
            this._super();
            var that = this;
            var scene = ccs.load(res.ClubConfirm_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            popShowAni($('root.main'));

            TouchUtils.setOnclickListener($("root.main.btn_ok"), function () {
                var str = $('root.main.bg_input.input').getString();
                var tip = "";
                if(typ == "adduser") {
                    if (str == null || str == undefined || str == "") {
                        tip = "用户ID为空";
                    }
                }else {
                    if (str == null || str == undefined || str == "") {
                        tip = "俱乐部名称为空";
                    }
                    if (tip == "" && (str.length < 2 || str.length > 17)) {
                        tip = "群名称长度在2-16字符之间";
                    }
                }
                if(tip == ""){
                    if(typ == "adduser") {
                        //在成员列表里，  无法重复申请
                        var isIn = false;
                        isIn = that.getParent().isUserInClub(str);
                        if(isIn){
                            HUD.showMessage('该成员已加入，无法重复添加', true);
                        }else {
                            network.send(2101, {cmd: 'addClubMember', club_id: club_id, obj_id: str});
                        }
                    } else {
                        network.send(2101, {cmd: 'modifyClub', club_id: club_id, name: str});
                    }
                    that.removeFromParent();
                }else {
                    $('root.main.lb_content2').setOpacity(255);
                    $('root.main.lb_content2').setVisible(true);
                    $('root.main.lb_content2').setString(tip);
                    $('root.main.lb_content2').runAction(cc.sequence(
                        cc.delayTime(1),
                        cc.fadeOut(1)
                    ));
                }
            });
            $('root.main.bg_input.input').addEventListener(function (textField, type) {
                switch (type) {
                    case ccui.TextField.EVENT_ATTACH_WITH_IME:
                        $('root.main').setPositionY(350 + 150);
                        break;
                    case ccui.TextField.EVENT_DETACH_WITH_IME:
                        $('root.main').setPositionY(350);
                        break;
                    case ccui.TextField.EVENT_INSERT_TEXT:
                        break;
                    case ccui.TextField.EVENT_DELETE_BACKWARD:
                        break;
                    default:
                        break;
                }
            }, this);
            TouchUtils.setOnclickListener($("root.main.btn_cancel"), function () {
                popHideAni($('root.main'), function(){
                    that.removeFromParent(true);
                });
            });
            $('root').addTouchEventListener(function (sender, type) {
                if (type == ccui.Widget.TOUCH_ENDED) {
                    $('root.main').setPositionY(350 + 150);
                }
            });
            if(typ == "adduser") {
                $('root.main.lb_content').setString('请输入玩家ID');
                $('root.main.bg_input.input').setPlaceHolder('请输入玩家ID');
            }else {
                $('root.main.lb_content').setString('请输入新的俱乐部名称');
                $('root.main.bg_input.input').setPlaceHolder('请输入新的名称');
            }
            $('root.main.lb_content2').setVisible(false);
        }
    });


    exports.ClubConfirm = ClubConfirm;
})(window);

