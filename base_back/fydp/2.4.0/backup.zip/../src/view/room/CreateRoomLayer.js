(function (exports) {
    var $ = null;

    var data = null;
    var optMap = {};
    var valMap = {};
    var curSelectedTab = null;
    var IDX_DESP = 0;//名称
    var IDX_VALUE = 1;//值
    var IDX_POSX = 2;//x位置
    var IDX_POSY = 3;//y位置
    var IDX_DEF_VAL = 4;//默认选不选中
    var IDX_UNDESELECTABLE = 5;//能不能不选中
    var IDX_DISABLE = 6;//置灰
    var IDX_MUTEX_FIELD = 7;//
    var IDX_DEP_NAME = 8;//依赖关系
    var IDX_HINT = 9;
    var IDX_POPSELECT = 10;//弹窗多选

    var BTN_TEXTURE = {};
    BTN_TEXTURE["choose"] = cc.textureCache.addImage(res.room2_btn1);
    BTN_TEXTURE["button_nochoose"] = cc.textureCache.addImage(res.room2_btn2);


    var CreateRoomLayer = cc.Layer.extend({
        ctor: function (roomId, _data, tabOps, btnNum, isDaikai, gameType, club_id, isSetWanfa) {
            this._super();
            var that = this;

            data = _data || {};

            optMap = {};
            valMap = {};

            var scene = ccs.load(res.CreateRoom_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));
            if (window.inReview) {
                $("btn_scroll.btn_1").setVisible(false);
                $("btn_scroll.btn_2").setVisible(false);
                $("btn_scroll.btn_3").setVisible(false);
                $("btn_scroll.btn_4").setVisible(false);
            }

            //动画
            // layerShowAni(this);

            //初始化限免标志
            if (gameData.map_conf) {
                this.freeData = gameData.map_conf;
                for (var i = 0; i < 14; ++i) {
                    if($("btn_scroll.btn_" + i)) {
                        var vis = false;
                        if (that.freeData["" + i] == 0) {//0正常  1免费 -1不显示
                            vis = false;
                        } else if (that.freeData["" + i] == 1) {
                            vis = true;
                        } else {
                            vis = false;
                        }
                        $("btn_scroll.btn_" + i + ".a").setVisible(vis);
                    }
                }
            }

            // TouchUtils.setOnclickListener($('bg'), function () {}, {
            //     effect: TouchUtils.effects.NONE
            // });

            var btnList = $('btn_scroll').getChildren();
            for (var i = 0; i < btnList.length; i++) {
                if (btnList[i].getName().indexOf('btn') >= 0) {
                    var num = btnList[i].getName().substr(4);
                    if(res['create_btn_' + num])  btnList[i].setTexture(res['create_btn_' + num]);
                }
            }
            curSelectedTab = cc.sys.localStorage.getItem('create_room_tab');

            var _posY = $("btn_scroll.btn_1").getPositionY() - $("btn_scroll.btn_0").getPositionY();

            var showBtnArr = [];
            var hideBtnArr = [];
            if ("huzi" == gameType) {
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_0") {
                    curSelectedTab = "btn_0";
                }
                showBtnArr = [0];
                hideBtnArr = [1,2,3,4,5,6,7,8,9,10,11,12,13];
            } else if ("niuniu" == gameType) {
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_1") {
                    curSelectedTab = "btn_1";
                }
                showBtnArr = [1,12,13,3,4,5,6,2];
                hideBtnArr = [0,7,8,9,10,11];
                if(window.inReview){
                    showBtnArr = [1,3];
                    hideBtnArr = [0,4,5,6,2,7,8,9,10,11,12,13];
                }
            } else if ("majiang" == gameType) {
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_7") {
                    curSelectedTab = "btn_7";
                }
                showBtnArr = [7,8,9];
                hideBtnArr = [0,1,2,3,4,5,6,10,11,12,13];
            }else if ("pdk"== gameType) {
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_10") {
                    curSelectedTab = "btn_10";
                }
                showBtnArr = [10];
                hideBtnArr = [0,1,2,3,4,5,6,7,8,9,11,12,13];
            }else if ("psz"== gameType) {
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_11") {
                    curSelectedTab = "btn_11";
                }
                showBtnArr = [11];
                hideBtnArr = [0,1,2,3,4,5,6,7,8,9,10,12,13];
            }else if ("all" == gameType){
                if (curSelectedTab == undefined || curSelectedTab == null || curSelectedTab != "btn_1") {
                    curSelectedTab = "btn_1";
                }
                showBtnArr = [1,12,13,3,4,5,6,2,7,8,9,10,11];
                hideBtnArr = [0];
            }
            var btnscroll = $("btn_scroll");
            var scrollH = 100 * showBtnArr.length;
            if (scrollH <= 600) {
                scrollH = 600;
            }
            btnscroll.setInnerContainerSize(cc.size(300, scrollH));

            for(var i=0;i<hideBtnArr.length;i++){
                if($("btn_scroll.btn_" + hideBtnArr[i]))  $("btn_scroll.btn_" + hideBtnArr[i]).setVisible(false);
            }
            for(var i=0;i<showBtnArr.length;i++){
                if($("btn_scroll.btn_" + showBtnArr[i])){
                    $("btn_scroll.btn_" + showBtnArr[i]).setVisible(true);
                    $("btn_scroll.btn_" + showBtnArr[i]).setPosition(cc.p(160, scrollH - 50 - i*100));
                }
            }

            if ($("btn_scroll." + curSelectedTab) && res['create_' + curSelectedTab + "_1"]) {
                $("btn_scroll." + curSelectedTab).setTexture(res['create_' + curSelectedTab + "_1"]);
            }
            TouchUtils.setOnclickListener($('btn_back'), function () {
                // layerHideAni(that, function(){
                //     that.removeFromParent();
                // });
                that.removeFromParent();
            }, {sound: 'close'});

            var createRoomFunc = function (daikai, isSetWanfa) {
                isDaikai = daikai;
                var map = {};
                mRoom.wanfa = "";
                var special_gz = [];//特殊规则
                for (var k = 0; k < data.length; k++) {
                    var catName = data[k][0];
                    var optArr = data[k][1];
                    if (catName.charAt(0) == '_')
                        continue;
                    for (var i = 0; i < optArr.length; i++) {
                        var node = $(catName + '_' + i);
                        var userData = node.getUserData();
                        var keyarray = userData.key.split('_');
                        if (node.isVisible() && userData.state) {
                            if (keyarray && keyarray[0] && userData.val != undefined) {
                                if (keyarray[0] == 'mapid' && userData.val != 9) {
                                    map['name'] = userData.desp; //游戏名
                                }
                                if (keyarray[0] == "Fanxing") {
                                    map[keyarray[0]] = map[keyarray[0]] + "," + userData.val;
                                } else {
                                    map[keyarray[0]] = userData.val;
                                }
                                if (keyarray[0] && (keyarray[0] != 'rounds' && keyarray[0] != 'mapid')) {
                                    var despstr = "";
                                    if (keyarray[0] == 'Chipin' || keyarray[0] == 'Difen') {
                                        despstr = userData.desp + "底分";
                                    } else if (keyarray[0] == 'MaxTuizhu') {
                                        despstr = "推注" + userData.desp;
                                    } else if (keyarray[0] == 'BeiShu') {
                                        despstr = "抢庄" + userData.desp;
                                    } else {
                                        despstr = userData.desp;
                                    }
                                    mRoom.wanfa += ((mRoom.wanfa == "") ? "":",") + despstr;
                                    if (keyarray[0] == 'ZhuangMode') {
                                        map['zhuang_gz'] = userData.desp;
                                    }
                                    if (keyarray[0] == 'Chipin') {
                                        map['basescore'] = userData.desp;
                                    }
                                    if (keyarray[0] == 'AA') {
                                        map['room_gz'] = userData.desp;
                                    }
                                    if (keyarray[0] == 'Tuizhu') {
                                        map['gaoji'] = userData.desp;
                                    }
                                    if (keyarray[0] == 'Wuhuaniu' || keyarray[0] == 'Zhadan' ||
                                        keyarray[0] == 'Wuxiaoniu' || keyarray[0] == 'Preview' ||
                                        keyarray[0] == 'Shunzi' || keyarray[0] == 'Hulu' ||
                                        keyarray[0] == 'Tonghua') {
                                        special_gz.push(userData.desp);
                                    }
                                    if (keyarray[0] == "ChipInType") {
                                        map['gaoji'] = userData.desp;
                                    }

                                }

                            }
                        } else {
                            if (keyarray[0] == 'Tuizhu') {
                                map[keyarray[0]] = userData.state;
                            }
                        }
                    }
                }
                map.special_gz = special_gz;
                map.wanfa = mRoom.YOUXIAN;
                if (map.mapid == MAP_ID_DN) {
                    map.wanfa = 'dn';
                    if (map.Players == null) {
                        map.Players = "liu";//"dynamic";
                    }
                    //九人场
                    if (map.Players == "jiu") {
                        map.mapid = 4000;
                    }
                    //抢庄推注
                    if (map.AlwaysTui) {
                        map.mapid = 4001;
                        map.DisableHeiqiang = false;
                    }
                    // map.Replace = true;//换牌
                    map.Beilv = "zhuzhou";
                    if (map.noColor) {//无花双十
                        map.mapid = 4002;
                        map.Beilv = "wuhua";
                    }
                    //疯狂双十
                    if(map['crazy']){
                        map.mapid = 4002;
                        map.Beilv = "crazy";
                    }
                    if (map['AA'] || map['ChipInType'] == 1) {
                        map.Is_ztjr = false;
                    } else {
                        if (gameData.opt_conf && gameData.opt_conf['isztjr_0'] == 1) {
                            map.Is_ztjr = false;
                        } else {
                            map.Is_ztjr = !map['isztjr'];
                            delete  map['isztjr'];
                        }
                    }
                    if (map['name'] == '明牌抢庄') {
                        map['Preview'] = 'si';
                    }
                    if (map['Preview'] && map['Preview'].length > 0) {
                        map.Cuopai = !map.Cuopai;
                    } else {
                        delete  map['Cuopai'];
                    }

                    if(!cc.sys.isNative){
                        map.debug = true;
                    }
                }

                if (map.mapid == MAP_ID_ZHUANZHUAN || map.mapid == MAP_ID_CHANGSHA || map.mapid == MAP_ID_HONGZHONG) {
                    map.wanfa = 'majiang';
                    map.desp = mRoom.wanfa;
                }
                if(map.mapid == MAP_ID_PDK){
                    map.wanfa = 'pdk';
                    map.desp = mRoom.wanfa;
                }
                if(map.mapid == MAP_ID_ZJH){
                    map.wanfa = 'zjh';
                    if(gameData.opt_conf['zjkztjr'] == 1) {
                        if (map.yunxujiaru == null || map.yunxujiaru == undefined) map.yunxujiaru = true;
                        if (map['AA']) {
                            map.yunxujiaru = false;
                            mRoom.wanfa += ",禁止中途加入";
                        }
                    }
                    map.desp = mRoom.wanfa;
                }

                cc.log("-------------" + map.mapid);

                if (club_id) {
                    map.club_id = club_id;//俱乐部
                    isDaikai = true;
                    map.headimgurl = gameData.headimgurl;
                    map.nickname = gameData.nickname;
                }

                map.is_daikai = isDaikai;
                map.wanfadesc = mRoom.wanfa;

                if (!cc.sys.isNative) {
                    // map.debug = true;
                }
                if(isSetWanfa){
                    //设置玩法
                    network.send(2101, {cmd: 'wanfaClub', club_id: club_id, options: map, map_id: map['mapid'], desc: map.desc});
                    that.removeFromParent();
                }else {
                    HUD.showLoading("正在创建房间");
                    mRoom.roomInfo = map;

                    network.start();
                    network.send(3001, {
                        room_id: roomId
                        , map_id: map['mapid']//gameData.appId
                        , mapid: map['mapid']
                        , daikai: isDaikai
                        , options: map
                        , club_id: club_id
                    });
                }

                for (var key in valMap) {
                    cc.sys.localStorage.setItem(key, valMap[key] ? "true" : "false");
                }
                if (curSelectedTab)
                    cc.sys.localStorage.setItem('create_room_tab', curSelectedTab);
            };
            var onCreateOK = function (data) {
                HUD.removeLoading();
                data = JSON.parse(data);
                if (data.result == 0) {
                    DC.wsHost = data.data.Url;
                    mRoom.roomId = data.data.RoomID;
                    gameData.roomId = mRoom.roomId;
                    mRoom.oldRoom = data.data.RoomID;
                    var Option = JSON.parse(data.data.Option);
                    mRoom.rounds = Option.rounds;
                    mRoom.getWanfa(Option);
                    mRoom.ownner = data.data.Ownner;

                    //牛牛
                    if (mRoom.wanfatype == "dn") {
                        gameData.maxPlayerNum = 6;
                    }
                    // DC.wsConnect();
                    if (mRoom.is_daikai == true) {
                        HUD.showMessageBox("提示",
                            "为好友代开房间成功！\n" +
                            "房间号: " + mRoom.roomId + "\n",
                            // "预扣除: " + data['need_cards'] + " 张房卡",
                            function () {
                                that.addChild(new DaiKai());
                            },
                            false
                        );
                    } else {
                        DC.wsConnect(this);
                    }
                } else if (data.result == -5) {
                    var weixin = gameData.weixin.replace(/,/g, "\n");
                    weixin = "您的房卡数量不足\n" + weixin;
                    HUD.showMessageBox('buycard', weixin, function () {
                    })
                } else {
                    HUD.showMessage(data.msg);
                }
            };
            for (var s = 1; s <= 4; s++) {
                var textArr = ['闲家获胜后,下局可以将所赢得的积分与\n底注一起下注。最大推注为底分的10倍。\n不可连续推注。',
                    '手动参与抢庄且倍数高但没抢到庄家的玩家下注时，不能以最小分下注；较低倍数抢庄和不抢庄的玩家，不能使用推注功能。',
                    '推注说明：闲家获胜后，下局可以将所赢得的积分与底注一起下注。最大推注为底分设置的倍数。不可连续推注。',
                    '推注说明：最大倍数抢庄失败的玩家可以按照指定倍率下注推庄'];
                (function (s) {
                    $('btn_help' + s).setVisible(false);
                    TouchUtils.setListeners($('btn_help' + s), {
                        onTouchBegan: function (node, touch, event) {
                            if (that.getChildByName('PopTishiLayer')) {
                                return;
                            }
                            var scene = ccs.load(res.PopTishiLayer_json, 'res/');
                            scene.node.setName('PopTishiLayer');
                            that.addChild(scene.node);
                            $('root.panel.lb_content', scene.node).setString(textArr[s - 1]);

                            var pos = $('btn_help' + s).getPosition();
                            $('root.panel', scene.node).setPosition(cc.p(pos.x + ((s == 4) ? 100 : 0), pos.y));
                        }
                        , onTouchMoveOut: function (node, touch, event) {
                            if (that.getChildByName('PopTishiLayer')) {
                                that.getChildByName('PopTishiLayer').removeFromParent();
                            }
                        }
                        , onTouchEnded: function (node, touch, event) {
                            if (that.getChildByName('PopTishiLayer')) {
                                that.getChildByName('PopTishiLayer').removeFromParent();
                            }
                        }
                    });
                })(s)
            }

            TouchUtils.setOnclickListener($('btn_create'), function () {
                TouchUtils.setClickDisable($('btn_create'), true);
                that.scheduleOnce(function () {
                    TouchUtils.setClickDisable($('btn_create'), false);
                }, 1);
                createRoomFunc(false, isSetWanfa);
            });
            if(isSetWanfa)  $('btn_create').setTexture('res/image/ui/room2/btn_setwanfa.png');
            if ("niuniu" == gameType) {
                $('btn_daikai').setVisible(false);
            }
            if (getNativeVersion() >= "2.2.0") {
                $('btn_daikai').setVisible(false);
            }
            TouchUtils.setOnclickListener($('btn_daikai'), function () {
                var fangkanode0 = optMap['AA_0'];
                var fangkanode1 = optMap['AA_1'];
                fangkanode0.userData.state = true;
                fangkanode0.getChildByName('checkBox').setSelected(true);
                fangkanode1.userData.state = false;
                fangkanode1.getChildByName('checkBox').setSelected(false);
                createRoomFunc(true);
            });
            // $('btn_create').setTexture(isDaikai ? 'res/image/ui/room2/btn_daikai2.png':'res/image/ui/room2/btn_create2.png');
            // $('btn_create.createtitle').setVisible(!isDaikai);
            // //已开
            // TouchUtils.setOnclickListener($('btn_yikai'), function () {
            //     that.addChild(new DaiKai());
            // });
            // //代开
            // TouchUtils.setOnclickListener($('btn_daikai'), function () {
            //     HUD.showMessageBox("提示", "代开房间将预扣除房卡\n\n" +
            //         "房间在第一局结算时扣除\n提前解散不扣除房卡\n\n" +
            //         "确定要代开房间么?",
            //         function () {
            //             createRoomFunc(true);
            //         },
            //         false
            //     )
            // });

            var isFirstIn = true;
            if (data) {
                var baseCheckbox = $('cb');
                for (var k = 0; k < data.length; k++) {
                    var catName = data[k][0];
                    var optArr = data[k][1];
                    //俱乐部创建  房主支付 改为 群主支付
                    if (club_id && catName == "AA") {
                        for (s = 0; s < optArr.length; s++) {
                            if (optArr[s][0] == "房主支付") {
                                optArr[s][0] = "群主支付";
                                break;
                            }
                        }
                    }
                    for (var i = 0; i < optArr.length; i++)
                        (function (catName, i, optArrBak) {
                            var opt = optArr[i];
                            var node = duplicateLayout(baseCheckbox);
                            baseCheckbox.getParent().addChild(node);
                            if (catName != "mapid")
                                node.setVisible(false);

                            var name = catName + '_' + i;
                            var savedVal = cc.sys.localStorage.getItem(name);
                            if (savedVal)
                                opt[IDX_DEF_VAL] = (savedVal == 'true' ? true : false);
                            //单选  复选
                            var cb1 = node.getChildByName('checkBox1');
                            var cb2 = node.getChildByName('checkBox2');
                            if (opt[IDX_MUTEX_FIELD] || opt[IDX_UNDESELECTABLE]) {
                                cb1.setVisible(true);
                                cb2.setVisible(false);
                                cb1.setName('checkBox');
                            } else {
                                cb1.setVisible(false);
                                cb2.setVisible(true);
                                cb2.setName('checkBox');
                            }

                            if (catName.charAt(0) == '_')
                                node.getChildByName('checkBox').setVisible(false);
                            node.setName(name);
                            node.setUserData({
                                desp: opt[IDX_DESP],
                                key: catName,
                                val: opt[IDX_VALUE],
                                state: !!opt[IDX_DEF_VAL],
                                undeselectable: !!opt[IDX_UNDESELECTABLE],
                                mutexField: opt[IDX_MUTEX_FIELD],
                                depName: opt[IDX_DEP_NAME]
                            });
                            node.setPosition(opt[IDX_POSX], opt[IDX_POSY]);

                            var text = node.getChildByName("text");
                            text.setString(decodeURIComponent(opt[IDX_DESP]));

                            //弹出框选择
                            if(opt[IDX_POPSELECT]){
                                for(var s=0;s<opt[IDX_POPSELECT].length;s++){
                                    var selectValue = cc.sys.localStorage.getItem(catName);
                                    if(parseInt(selectValue) >= 0 && selectValue == s){
                                        node.setUserData({
                                            desp: opt[IDX_POPSELECT][s][0],
                                            key: catName,
                                            val: opt[IDX_POPSELECT][s][1],
                                            state: !!opt[IDX_DEF_VAL],
                                            undeselectable: !!opt[IDX_UNDESELECTABLE],
                                            mutexField: opt[IDX_MUTEX_FIELD],
                                            depName: opt[IDX_DEP_NAME],
                                            popselect: s
                                        });
                                        node.getChildByName("text").setString(opt[IDX_POPSELECT][s][0]);
                                        break;
                                    }
                                }
                            }
                            // text.setFontSize(((opt[IDX_DESP] && opt[IDX_DESP].length > 12) ? 33:33));
                            var func = function () {
                                if (opt[IDX_DISABLE]) {
                                    setSelected($(name), false, gameType, isDaikai);
                                    HUD.showMessage("暂未开放, 敬请期待", true);
                                    return;
                                }
                                selectOne(i, catName, name, gameType, isDaikai);
                            };
                            optMap[name] = node;
                            node.getChildByName("checkBox").addEventListener(func);
                            TouchUtils.setOnclickListener(node.getChildByName("text"), func);

                            //弹出框选择
                            if(opt[IDX_POPSELECT]){
                                var nodetext = node.getChildByName("text");
                                //隐藏checkbox
                                node.getChildByName("checkBox").setVisible(false);
                                nodetext.setPositionX(-20);
                                var popselectBg = node.getChildByName("popselectBg");
                                if(!popselectBg){
                                    popselectBg = new cc.Scale9Sprite("res/image/ui/hall/createroom_kuang2.png", cc.rect(0, 0, 68, 68), cc.rect(22, 22, 24, 24));
                                    popselectBg.setAnchorPoint(cc.p(0, 0.5));
                                    popselectBg.setName("popselectBg");
                                    node.addChild(popselectBg, -1);
                                }
                                popselectBg.setPositionX(-30);
                                popselectBg.setContentSize(cc.size(120 + nodetext.getContentSize().width, 55));

                                var arrow = node.getChildByName("arrow");
                                if(!arrow) {
                                    arrow = new cc.Sprite('res/image/ui/hall/createroom_arr2.png');
                                    arrow.setName("arrow");
                                    node.addChild(arrow);
                                }
                                arrow.setPosition(cc.p(popselectBg.getContentSize().width - 60, 0));
                                var text = node.getChildByName("text");
                                // TouchUtils.setTouchRect(node.getChildByName("arrow"), cc.rect(-40, -15, 210, 60));//130  30
                                TouchUtils.setTouchRect(node.getChildByName("arrow"), cc.rect(-11, -14, 40, 40));//18  13
                                TouchUtils.setOnclickListener(node.getChildByName("arrow"), function(){
                                    text.onclickCallBack()
                                });
                                var showPop = function(){
                                    arrow.setTexture('res/image/ui/hall/createroom_arr1.png');
                                    var scene = ccs.load(res.CreateRoomSelectPop, 'res/');
                                    that.addChild(scene.node);

                                    $('root', scene.node).addTouchEventListener(function (sender, type) {
                                        if (type == ccui.Widget.TOUCH_ENDED) {
                                            arrow.setTexture('res/image/ui/hall/createroom_arr2.png');
                                            scene.node.removeFromParent();
                                        }
                                    });
                                    var arrLength = optArrBak[0][10].length;
                                    $('root.bg', scene.node).setPosition(cc.p(optArrBak[0][2] - 30, optArrBak[0][3] - 25));
                                    $('root.bg', scene.node).setContentSize(cc.size(popselectBg.getContentSize().width, 60 * arrLength));
                                    for(var l=0;l<arrLength;l++){
                                        (function(l){
                                            var checkBox0 = $('root.bg.checkBox0', scene.node);
                                            var text0 = $('root.bg.text0', scene.node);
                                            var checkBox = $('root.bg.checkBox' + l, scene.node);
                                            if(!checkBox){
                                                checkBox = duplicateSprite(checkBox0);
                                                checkBox.setName("checkBox" + l);
                                                checkBox.setPositionY(60*l - 30);
                                                checkBox0.getParent().addChild(checkBox);
                                            }
                                            checkBox.setSelected(node.getUserData()['desp'] == optArrBak[0][10][l][0]);
                                            var text = $('root.bg.text' + l, scene.node);
                                            if(!text){
                                                text = duplicateSprite(text0);
                                                text.setPositionY(60*l - 30);
                                                text.setName("text" + l);
                                                text0.getParent().addChild(text);
                                            }
                                            text.setString(optArrBak[0][10][l][0]);
                                            var clickFunc = function(){
                                                for(var m=0;m<arrLength;m++){
                                                    $('root.bg.checkBox' + m, scene.node).setSelected(false);
                                                }
                                                $('root.bg.checkBox' + l, scene.node).setSelected(true);
                                                node.getChildByName("text").setString(optArrBak[0][10][l][0]);
                                                node.userData['val'] = optArrBak[0][10][l][1];
                                                node.userData['desp'] = optArrBak[0][10][l][0];
                                                cc.sys.localStorage.setItem(node.userData['key'], "" + l);
                                            }
                                            checkBox.addEventListener(clickFunc);
                                            TouchUtils.setOnclickListener(text, clickFunc);
                                        })(l);
                                    }
                                }
                                node.getChildByName("checkBox").addEventListener(showPop);
                                if (catName.charAt(0) != '_')
                                    TouchUtils.setOnclickListener(node.getChildByName("text"), showPop);
                            }else {
                                node.getChildByName("checkBox").addEventListener(func);
                                if (catName.charAt(0) != '_')
                                    TouchUtils.setOnclickListener(node.getChildByName("text"), func);
                            }


                            setSelected(node, !!opt[IDX_DEF_VAL], gameType, isDaikai);
                        })(catName, i, optArr);
                }
                baseCheckbox.setVisible(false);
            }
            if (tabOps) {
                var i = 0;
                for (var key in tabOps)
                    (function (idx, btnName, op) {
                        var func = function () {
                            for (var i = 0; i < op['show'].length; i++) {
                                if (optMap[op['show'][i]]) {
                                    optMap[op['show'][i]].setVisible(true);
                                }
                                else {
                                    $(op['show'][i]).setVisible(true);
                                }
                            }
                            for (var i = 0; i < op['hide'].length; i++) {
                                if (optMap[op['hide'][i]])
                                    optMap[op['hide'][i]].setVisible(false);
                                else
                                    $(op['hide'][i]).setVisible(false);
                            }
                            //设置选中
                            if (curSelectedTab && $("btn_scroll." + curSelectedTab) && res['create_' + curSelectedTab]) {
                                $("btn_scroll." + curSelectedTab).setTexture(res['create_' + curSelectedTab]);
                            }
                            if(res['create_' + btnName + "_1"]){
                                $("btn_scroll." + btnName).setTexture(res['create_' + btnName + "_1"]);
                            }
                            var parts = op['click'].split('_');
                            if (!isFirstIn || !curSelectedTab)
                                selectOne(parts[1], parts[0], op['click'], gameType, isDaikai);
                            curSelectedTab = btnName;
                            //选中的那种玩法
                            var setTitieVisiblePos = function (node, visible, x, y) {
                                node.setVisible(visible);
                                if (visible && x) node.setPositionX(x);
                                if (visible && y) node.setPositionY(y);
                            }
                            mRoom.wanfatype ="";
                            if(btnName == 'btn_0'){
                                mRoom.wanfatype = mRoom.YOUXIAN;
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), false, 0, 0);
                                setTitieVisiblePos($('paixing'), false, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), false, 0, 0);
                                setTitieVisiblePos($('beishu'), false, 0, 0);

                                $('wanfaxz_2').setVisible(false);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(true);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);

                            } else if (btnName == 'btn_1') {
                                $('btn_help1').setVisible(true);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help1').setPositionY(250);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), true, 0, 0);
                                setTitieVisiblePos($('paixing'), true, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), true, 0, 250);
                                setTitieVisiblePos($('beishu'), true, 0, 470);

                                $('wanfaxz_2').setVisible(false);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(true);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);
                            } else if (btnName == 'btn_2') {
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), true, 0, 0);
                                setTitieVisiblePos($('paixing'), true, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), true, 0, 250);
                                setTitieVisiblePos($('beishu'), true, 0, 470);

                                $('isztjr_0').setPosition(cc.p(480, 250));

                                $('wanfaxz_2').setVisible(false);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(true);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);
                            } else if (btnName == 'btn_3') {
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(true);
                                $('btn_help2').setPositionY(195);
                                $('btn_help3').setVisible(true);
                                $('btn_help3').setPositionY(250);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), true, 0, 0);
                                setTitieVisiblePos($('paixing'), true, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), true, 0, 250);
                                setTitieVisiblePos($('gaoji'), true, 0, 195);
                                setTitieVisiblePos($('beishu'), true, 0, 470);

                                $('isztjr_0').setPosition(cc.p(720, 195));
                                $('DisableHeiqiang_0').setPosition(cc.p(480, 195));
                                for (var i = 0; i < 4; i++) {
                                    $('MaxTuizhu_' + i).setPositionY(250);
                                }

                                $('wanfaxz_2').setVisible(false);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(true);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);
                            } else if (btnName == 'btn_4' || btnName == 'btn_5' || btnName == 'btn_6' || btnName == 'btn_12' || btnName == 'btn_13') {
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(true);
                                $('btn_help2').setPositionY(140);

                                setTitieVisiblePos($('difen'), true, 0, 0);
                                setTitieVisiblePos($('paixing'), true, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), true, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), true, 0, 195);
                                setTitieVisiblePos($('gaoji'), true, 0, 140);
                                setTitieVisiblePos($('beishu'), true, 0, 470);

                                $('wanfaxz_2').setVisible(false);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(true);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);

                                if (btnName == 'btn_6') {
                                    $('btn_help2').setVisible(false);
                                    $('btn_help4').setVisible(true);
                                    $('btn_help3').setVisible(false);
                                    $('btn_help4').setPosition(cc.p(920, 190));
                                    $('isztjr_0').setPosition(cc.p(480, 140));
                                    $('Cuopai_0').setPosition(cc.p(720, 140));
                                    for (var i = 0; i < 3; i++) {
                                        $('MaxTuizhu_qztzadd_' + i).setPositionY(195);
                                    }
                                } else if(btnName == 'btn_13'){
                                    //疯狂牛牛
                                    setTitieVisiblePos($('beishu'), false, 0, 0);
                                    setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                    setTitieVisiblePos($('paixing'), false, 0, 0);
                                    setTitieVisiblePos($('gaoji'), true, 0, 195);

                                    $('isztjr_0').setPosition(cc.p(480, 195));
                                    $('Cuopai_0').setPosition(cc.p(720, 195));
                                    $('btn_help2').setVisible(false);
                                    $('btn_help3').setVisible(false);
                                    // for (var i = 0; i < 4; i++) {
                                    //     $('BeiShu_mznn_' + i).setPositionY(415);
                                    // }
                                    // for (var i = 0; i < 4; i++) {
                                    //     $('Difen_' + i).setPositionY(470);
                                    // }
                                } else {
                                    $('btn_help4').setVisible(false);
                                    $('btn_help3').setVisible(true);
                                    $('btn_help3').setPositionY(195);
                                    $('isztjr_0').setPosition(cc.p(720, 140));
                                    $('Cuopai_0').setPosition(cc.p(960, 140));
                                    $('DisableHeiqiang_0').setPosition(cc.p(480, 140));
                                    for (var i = 0; i < 4; i++) {
                                        $('MaxTuizhu_' + i).setPositionY(195);
                                    }
                                }
                            } else if (btnName == 'btn_7' || btnName == 'btn_8' || btnName == 'btn_9') {
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), false, 0, 0);
                                setTitieVisiblePos($('paixing'), false, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), false, 0, 0);
                                setTitieVisiblePos($('beishu'), false, 0, 0);

                                $('wanfaxz_2').setVisible(true);
                                $('word_rsxz').setVisible(true);
                                $('zhuamaxz').setVisible(true);
                                $('fkNode3').setVisible(false);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);
                            }else if(btnName == 'btn_10'){
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), false, 0, 0);
                                setTitieVisiblePos($('paixing'), false, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), false, 0, 0);
                                setTitieVisiblePos($('beishu'), false, 0, 0);

                                $('wanfaxz_2').setVisible(true);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(false);
                                //拼三张
                                $('genpai').setVisible(false);
                                $('bipai').setVisible(false);
                                $('menpai').setVisible(false);
                            }else if(btnName == 'btn_11') {
                                $('btn_help1').setVisible(false);
                                $('btn_help2').setVisible(false);
                                $('btn_help3').setVisible(false);
                                $('btn_help4').setVisible(false);

                                setTitieVisiblePos($('difen'), false, 0, 0);
                                setTitieVisiblePos($('paixing'), false, 0, 0);
                                setTitieVisiblePos($('qiangzhuang'), false, 0, 0);
                                setTitieVisiblePos($('tuizhuxx'), false, 0, 0);
                                setTitieVisiblePos($('gaoji'), false, 0, 0);
                                setTitieVisiblePos($('beishu'), false, 0, 0);
                                if(gameData.opt_conf['zjkztjr'] == 1) {
                                    setTitieVisiblePos($('gaoji'), true, 0, 140);
                                }

                                $('wanfaxz_2').setVisible(true);
                                $('word_rsxz').setVisible(false);
                                $('zhuamaxz').setVisible(false);
                                $('fkNode3').setVisible(false);
                                //拼三张
                                $('genpai').setVisible(true);
                                $('bipai').setVisible(true);
                                $('menpai').setVisible(true);
                            }
                        };
                        TouchUtils.setOnclickListener($("btn_scroll." + btnName), func, {
                            swallowTouches: false,
                            sound: 'tab'
                        });
                        if (!curSelectedTab && idx == 0)
                            func();
                        if (curSelectedTab == btnName)
                            func();
                    })(i++, key, tabOps[key]);
            }
            isFirstIn = false;
            //选中
            if (curSelectedTab) {
                var index = curSelectedTab.split("_")[1];
                index = parseInt(index);
                selectOne(index, "mapid", "mapid_" + index, gameType, isDaikai);
            } else {
                selectOne("0", "mapid", "mapid_0", gameType, isDaikai);
            }
        }
    });

    var checkZhuanzhuanZhuama = function () {
        if (curSelectedTab == 'btn_7') {
            var opt = optMap;
            var liangrenwanstate = optMap['liangrenwan_0'].getUserData().state;
            optMap['zhaniao_0'].setVisible(!liangrenwanstate);
            optMap['zhaniao_1'].setVisible(!liangrenwanstate);
            optMap['zhaniao_2'].setVisible(!liangrenwanstate);
            optMap['zhaniao_3'].setVisible(!liangrenwanstate);
            optMap['hongzhong_0'].setVisible(!liangrenwanstate);
            $('zhuamaxz').setVisible(!liangrenwanstate);
        }
    };

    var checkChangshaZhuama = function () {
        if (curSelectedTab == 'btn_8') {
            var buzhuangmaState = optMap['buzhuama_0'].getUserData().state;
            var zhuangma159State = optMap['zhuama159_0'].getUserData().state;
            var zhuangmajingdianState = optMap['zhuamajingdian_0'].getUserData().state;
            var zhuangmafanbeiState = optMap['zhongniaofanbei_0'].getUserData().state;
            for (var i = 0; i < 3; i++) {
                var zhaNiao = optMap['zhaniao_cs_' + i];
                var show = true;
                if (buzhuangmaState) {
                    show = false;
                }
                if (zhuangmajingdianState && zhuangmafanbeiState) {
                    show = false;
                }
                zhaNiao.setVisible(show);
            }
            $('zhuamaxz').setVisible(!buzhuangmaState);
            $('zhongniaofanbei_0').setVisible(!buzhuangmaState && !zhuangma159State);
            $('zhaniao_csfanbei_0').setVisible(zhuangmafanbeiState && optMap['zhongniaofanbei_0'].isVisible());
        }
    };

    var checkOptConf = function () {
        // gameData.opt_conf = {'isztjr_0':1, 'isztjr_sznn_0':1};
        // gameData.opt_conf = {};
        // gameData.opt_conf['Cuopai_sznn_0'] = 1;
        // gameData.opt_conf['Cuopai_0'] = 1;
        for (var optId in gameData.opt_conf) {
            if (gameData.opt_conf.hasOwnProperty(optId)) {
                var opt = optMap[optId];
                var val = gameData.opt_conf[optId];
                if (opt && cc.sys.isObjectValid(opt)) {
                    opt.isEnforce = val == 1;
                    // checkRenWan(optId);
                }
            }
        }

        if (curSelectedTab == 'btn_10') {
            //跑得快 15张没3A炸弹
            var pdkNumofCardsPerUser = optMap['pdkNumofCardsPerUser_1'].getUserData().state;
            optMap['pdk3Abomb_0'].setVisible(!pdkNumofCardsPerUser);
        }
    };
    var setSelected = function (node, isSelected, gameType, isDaiKai) {
        var userData = node.getUserData() || {};
        var key = node.getName();
        valMap[key] = isSelected;
        userData.state = isSelected;
        node.setUserData(userData);
        node.getChildByName("checkBox").setSelected(isSelected);
        if (isSelected) {
            // node.getChildByName("text").enableOutline(cc.color(224, 155, 69), 1);
            // node.getChildByName("text").enableOutline(cc.color(224, 155, 69,255),2);
            node.getChildByName("light").setVisible(true);
        } else {
            // node.getChildByName("text").getVirtualRenderer().disableStroke();
            // node.getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            node.getChildByName("light").setVisible(false);
        }

        if (isSelected && userData.mutexField) {
            for (var key in optMap) {
                var mutexField = userData.mutexField;
                if (mutexField) {
                    var arr = [];
                    if (_.isString(mutexField))
                        arr.push(mutexField);
                    else if (_.isArray(mutexField))
                        arr = mutexField;
                    else
                        continue;
                    for (var k = 0; k < arr.length; k++) {
                        if (key && key.indexOf(arr[k]) == 0) {
                            setSelected(optMap[key], false, gameType, isDaiKai);
                        }
                    }
                }
            }
        }

        // if (isSelected && userData.mutexField) {
        //     var isDaiKai =isDaiKai;
        //     for (var key in optMap) {
        //         if (key && key.indexOf(userData.mutexField) == 0) {
        //             setSelected(optMap[key], false, gameType, isDaiKai);
        //         }
        //     }
        // }

        if (userData.key == 'ChipInType' && userData.val == 1) {
            ShowOrHid(optMap['Preview_0'], !userData.state, isSelected);
            ShowOrHid(optMap['Preview_1'], !userData.state, isSelected);
            ShowOrHid(optMap['Preview_2'], !userData.state, isSelected);

            ShowOrHid(optMap['isztjr_sznn_0'], !userData.state, isSelected);
            ShowOrHid(optMap['Cuopai_sznn_0'], !userData.state, isSelected);
        }
        // ShowOrHid(optMap['Cuopai_sznn_0'], false);
        // ShowOrHid(optMap['Cuopai_0'], false);

        setTimeout(function () {
            for (var key in optMap) {
                var _userData = optMap[key].getUserData();
                var depName = _userData['depName'];
                if (depName) {
                    var arr = [];
                    if (_.isString(depName))
                        arr.push(depName);
                    else if (_.isArray(depName))
                        arr = depName;
                    else
                        continue;
                    var state = false;
                    for (var k = 0; k < arr.length; k++) {
                        var depNode = optMap[arr[k]];
                        if (depNode.getUserData().state) {
                            state = true;
                            break;
                        }
                    }
                    // console.log("key = " + key);
                    optMap[key].setVisible(state);
                    if (optMap[key].isEnforce) {
                        optMap[key].setVisible(false);
                    }
                }
            }
            checkfangka(isDaiKai, gameType);
            checkOptConf();
            checkChangshaZhuama();
            checkZhuanzhuanZhuama();
        }, 0);
    };
    //isSJXZ是否首局下注
    var ShowOrHid = function (nodetargret, isShow, isSJXZ) {
        nodetargret.getChildByName("checkBox").setVisible(isShow);
        nodetargret.getChildByName("text").setVisible(isShow);
        if (isSJXZ) {
            optMap['Preview_0'].userData.state = false;
            optMap['Preview_1'].userData.state = false;
            optMap['Preview_2'].userData.state = false;
            optMap['Preview_0'].getChildByName('checkBox').setSelected(false);
            optMap['Preview_1'].getChildByName('checkBox').setSelected(false);
            optMap['Preview_2'].getChildByName('checkBox').setSelected(false);
            // optMap['Preview_0'].getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            // optMap['Preview_1'].getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            // optMap['Preview_2'].getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            optMap['Preview_0'].getChildByName("light").setVisible(false);
            optMap['Preview_1'].getChildByName("light").setVisible(false);
            optMap['Preview_2'].getChildByName("light").setVisible(false);
        } else {
            optMap['Preview_0'].userData.state = true;
            optMap['Preview_1'].userData.state = false;
            optMap['Preview_2'].userData.state = false;
            optMap['Preview_0'].getChildByName('checkBox').setSelected(true);
            optMap['Preview_1'].getChildByName('checkBox').setSelected(false);
            optMap['Preview_2'].getChildByName('checkBox').setSelected(false);
            // optMap['Preview_0'].getChildByName("text").enableOutline(cc.color(224, 155, 69,255),2);
            // optMap['Preview_1'].getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            // optMap['Preview_2'].getChildByName("text").enableOutline(cc.color(208, 173, 132,0),0);
            optMap['Preview_0'].getChildByName("light").setVisible(true);
            optMap['Preview_1'].getChildByName("light").setVisible(false);
            optMap['Preview_2'].getChildByName("light").setVisible(false);
        }
    };
    var checkfangka = function (isDaiKai, gameType, isXM) {
        var fangkanode0 = optMap['AA_0'];
        var fangkanode1 = optMap['AA_1'];
        $('fkNode1').setLocalZOrder(1);
        $('fkNode2').setLocalZOrder(1);
        $('fkNode3').setLocalZOrder(1);
        var num1 = $('fkNode1.num');
        var num2 = $('fkNode2.num');
        var num3 = $('fkNode3.num');
        var mapid_0 = optMap['mapid_0'];
        var ChipInType_0 = optMap['ChipInType_0'];
        if (!fangkanode0 || !fangkanode1)
            return;
        // if(isXM){
        //     num1.setString('免');
        //     num2.setString('免');
        //     num3.setString('免');
        //     return;
        // }
        var length = 14;
        if (isDaiKai) {
            var mapid = 0;
            for (var i = 0; i < length; i++) {
                if (optMap['mapid_' + i] && optMap['mapid_' + i].userData.state) {
                    mapid = i;
                    break;
                }
            }
            if (mapid == 0) {
                num1.setString('x4');
                num2.setString('x8');
                num3.setString('x12');
            } else if (mapid == 5) {
                //九人名牌
                num1.setString('x9');
                num2.setString('x18');
                num3.setString('x27');
            } else if (mapid == 7 || mapid == 8 || mapid == 9 || mapid == 10) {
                //麻将  跑得快
                num1.setString('x5');
                num2.setString('x10');
            } else {
                num1.setString('x6');
                num2.setString('x12');
                num3.setString('x18');
            }
            fangkanode0.userData.state = true;
            fangkanode0.getChildByName('checkBox').setSelected(true);
            fangkanode1.setVisible(false);
            fangkanode1.userData.state = false;
            fangkanode1.getChildByName('checkBox').setSelected(false);
        } else {
            var mapid = 0;
            for (var i = 0; i < length; i++) {
                if (optMap['mapid_' + i] && optMap['mapid_' + i].userData.state) {
                    mapid = i;
                    break;
                }
            }
            if ("huzi" == gameType) {
                if (fangkanode0.getUserData().state) {
                    num1.setString('x4');
                    num2.setString('x8');
                    num3.setString('x12');
                }
                if (fangkanode1.getUserData().state) {
                    num1.setString('x1');
                    num2.setString('x2');
                    num3.setString('x3');
                }
            } else if ("niuniu" == gameType) {
                if (mapid == 5) {
                    if (fangkanode0.getUserData().state) {
                        num1.setString('x9');
                        num2.setString('x18');
                        num3.setString('x27');
                    }
                    if (fangkanode1.getUserData().state) {
                        num1.setString('x2');
                        num2.setString('x4');
                        num3.setString('x6');
                        if ($('isztjr_0')) $('isztjr_0').setVisible(false);
                        if ($('isztjr_sznn_0')) $('isztjr_sznn_0').setVisible(false);
                    }
                } else {
                    if (fangkanode0.getUserData().state) {
                        num1.setString('x6');
                        num2.setString('x12');
                        num3.setString('x18');
                    }
                    if (fangkanode1.getUserData().state) {
                        num1.setString('x2');
                        num2.setString('x4');
                        num3.setString('x6');

                        if ($('isztjr_0')) $('isztjr_0').setVisible(false);
                        if ($('isztjr_sznn_0')) $('isztjr_sznn_0').setVisible(false);
                    }
                }
            } else if ("pdk" == gameType || "majiang" == gameType) {
                if (fangkanode0.getUserData().state) {
                    num1.setString('x5');
                    num2.setString('x10');
                }
                if(fangkanode1.getUserData().state) {
                    num1.setString('x2');
                    num2.setString('x4');
                }
            } else if ("psz" == gameType) {
                if (fangkanode0.getUserData().state) {
                    num1.setString('x6');
                    num2.setString('x12');
                }
                if(fangkanode1.getUserData().state) {
                    num1.setString('x2');
                    num2.setString('x4');
                    if ($('yunxujiaru_0')) $('yunxujiaru_0').setVisible(false);
                }
            }
        }
    };

    var checkDeps = function () {
        for (var key in optMap) {
            var _userData = optMap[key].getUserData();
            var depName = _userData['depName'];
            if (depName) {
                var depNode = optMap[depName];
                optMap[key].setVisible(depNode.getUserData().state);
            }
        }
    };

    var selectOne = function (i, catName, name, gameType, isDaiKai) {
        // if(name.indexOf("NaN") >= 0)  return;
        // console.log(i+"==="+catName+"=="+name);
        i = parseInt(i);
        var cnt = 0;
        var cancelIdx = -1;
        for (var j = 0; true; j++) {
            if (i == j)
                continue;
            if ($(catName + '_' + j)) {
                cancelIdx = j;
                setSelected($(catName + '_' + j), false, gameType, isDaiKai);
                cnt++;
            }
            else break;
        }
        var val = (cancelIdx == i ? true : !$(name).getUserData().state);
        if ($(name).getUserData().undeselectable)
            val = true;
        setSelected($(name), val, gameType, isDaiKai);
    };


    exports.CreateRoomLayer = CreateRoomLayer;
})(this);

