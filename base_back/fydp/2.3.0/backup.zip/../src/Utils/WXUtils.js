(function (exports) {
    var appId = null;
    exports.WXUtils = {
        isWXAppInstalled: function () {
            if (!cc.sys.isNative)
                return false;
            return (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("WXUtil", "isWXAppInstalled")
                : jsb.reflection.callStaticMethod(packageUri + "/utils/WeixinUtil", "isWXAppInstalled", "()I"));
        },
        getAppid: function () {
            if (appId)
                return appId;
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("WXUtil", "getWeixinAppId")
                : jsb.reflection.callStaticMethod(packageUri + '/Global', "getWeixinAppId", "()Ljava/lang/String;"));
        },
        setWxPayCode: function (code) {

            if(cc.sys.os == cc.sys.OS_ANDROID)
            {
                jsb.reflection.callStaticMethod(packageUri + "/Global", "setWxPayCode", "(Ljava/lang/String;)V", code);
            }
            else
            {
                jsb.reflection.callStaticMethod("WXUtil", "setWxPayCode:", code);
            }
        },
        getWxPayCode: function () {
            var wxPayCode  = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("WXUtil", "getWxPayCode")
                : jsb.reflection.callStaticMethod(packageUri + '/Global', "getWxPayCode", "()Ljava/lang/String;"));
            return wxPayCode;
        },
        redirectToWeixinLogin: function () {
            if (cc.sys.os == cc.sys.OS_IOS)
                jsb.reflection.callStaticMethod("WXUtil", "redirectToWeixinLogin");
            else
                jsb.reflection.callStaticMethod(packageUri + "/utils/WeixinUtil", "redirectToWeixinLogin", "()V");
        },
        getWXLoginCode: function () {
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("WXUtil", "getWXLoginCode")
                : jsb.reflection.callStaticMethod(packageUri + "/utils/WeixinUtil", "getWXLoginCode", "()Ljava/lang/String;"));
        },
        setWXLoginCode: function (code) {
            return appId = (cc.sys.os == cc.sys.OS_IOS
                ? jsb.reflection.callStaticMethod("WXUtil", "setWXLoginCode:", code)
                : jsb.reflection.callStaticMethod(packageUri + "/utils/WeixinUtil", "setWXLoginCode", "(Ljava/lang/String;)V", code));
        },

        shareTexture:function (texture) {
            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";
            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/WeixinUtil",
                        "sharePic",
                        "(Ljava/lang/String;Z)V",
                        nameJPG,
                        false
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "WXUtil",
                        "sharePic:imageName:sceneType:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG,
                        0
                    );
                });
            }
        },
        captureAndShareToWX2: function (texture) {
            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/WeixinUtil",
                        "sharePic",
                        "(Ljava/lang/String;Z)V",
                        nameJPG,
                        false
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "WXUtil",
                        "sharePic:imageName:sceneType:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG,
                        0
                    );
                });
            }
        },


        captureAndShareToWX: function (node, depthStencilFormat) {
            var winSize = cc.director.getWinSize();
            var texture = new cc.RenderTexture(winSize.width, winSize.height,null,depthStencilFormat);
            if (!texture)
                return;

            texture.retain();

            texture.setAnchorPoint(0, 0);
            texture.begin();
            node.visit();
            texture.end();

            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/WeixinUtil",
                        "sharePic",
                        "(Ljava/lang/String;Z)V",
                        nameJPG,
                        false
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "WXUtil",
                        "sharePic:imageName:sceneType:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG,
                        0
                    );
                });
            }
        },
        //分享到朋友圈
        captureAndShareToPyq: function (node, depthStencilFormat) {
            var winSize = cc.director.getWinSize();
            var texture = new cc.RenderTexture(winSize.width, winSize.height,null,depthStencilFormat);
            if (!texture)
                return;

            texture.retain();

            texture.setAnchorPoint(0, 0);
            texture.begin();
            node.visit();
            texture.end();

            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/WeixinUtil",
                        "sharePic",
                        "(Ljava/lang/String;Z)V",
                        nameJPG,
                        true
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "WXUtil",
                        "sharePic:imageName:sceneType:",
                        jsb.fileUtils.getWritablePath(),
                        nameJPG,
                        1
                    );
                });
            }
        },
        captureAndCopy: function (node) {
            var winSize = cc.director.getWinSize();
            var texture = new cc.RenderTexture(winSize.width, winSize.height);
            if (!texture)
                return;

            texture.retain();

            texture.setAnchorPoint(0, 0);
            texture.begin();
            node.visit();
            texture.end();

            var time = timestamp2time(Math.round((new Date()).valueOf() / 1000));
            time = time.replace(/[\s:-]+/g, '_');
            var nameJPG = "ss-" + time + ".jpg";

            if (cc.sys.os == cc.sys.OS_ANDROID) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, false, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        packageUri + "/utils/WeixinUtil",
                        "sharePic",
                        "(Ljava/lang/String;Z)V",
                        nameJPG,
                        false
                    );
                });
            }
            else if (cc.sys.os == cc.sys.OS_IOS) {
                texture.saveToFile(nameJPG, cc.IMAGE_FORMAT_JPEG, true, function (renderTexture, str) {
                    texture.release();
                    jsb.reflection.callStaticMethod(
                        "AppController",
                        "fetchUDID:type:",
                        cc.sys.writablePath + '/' + nameJPG,
                        'public.jpeg'
                    );
                });
            }
        },
        shareText: function (text, sceneType, transaction) {
            if (!cc.sys.isNative) {
                return;
            }
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(
                    "WXUtil",
                    "shareText:sceneType:",
                    text,
                    (sceneType ? 1 : 0)
                );
            }
            else {
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/WeixinUtil",
                    "shareText",
                    "(Ljava/lang/String;ZLjava/lang/String;)V",
                    text,
                    (sceneType ? true : false),
                    transaction
                );
            }
        },
        shareUrl: function (url, title, description, sceneType, transaction) {
            if (!cc.sys.isNative)  return;
            if (cc.sys.os == cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(
                    "WXUtil",
                    "shareUrl:title:description:sceneType:",
                    url,
                    title,
                    description,
                    (sceneType ? 1 : 0)
                );
            }
            else {
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/WeixinUtil",
                    "shareUrl",
                    "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V",
                    url,
                    title,
                    description,
                    (sceneType ? true : false),
                    transaction
                );
            }
        },
        // beginWxPay: function (cid) {
        //     showLoading("正在跳转微信支付...")
        //     var that = this;
        //     var data = {
        //         appid: WXA[gameData.appId],
        //         playerid: gameData.uid,
        //         unionid:gameData.unionid,
        //         area: gameData.parent_area,
        //         cid: cid,
        //         timestamp: getCurTimestamp(),
        //         wechatOrderKey:"78445A3D4370C7B35318D1FF348EA63B"
        //     };
        //     data.sign = Crypto.MD5("" + data.appid + data.playerid + data.unionid + data.area + data.cid + data.player + data.timestamp);
        //     NetUtils.httpPost("http://pay.yayayouxi.com/payServer/game/wechatOrder", data,
        //         function (data) {
        //             hideLoading();
        //             if (data["prepay_id"]) {
        //                 that.wxPay(data["prepay_id"]);
        //             } else {
        //                 alert1("支付请求失败,请检查网络");
        //             }
        //         },
        //         function (error) {
        //             hideLoading();
        //             alert1("支付请求失败,请检查网络");
        //         }
        //     );
        // },
        beginWxPay: function (cid) {
            //showLoading("正在跳转微信支付...")
            var that = this;
            var data = {
                appid: WXA[gameData.appId],
                playerid: gameData.uid,
                unionid:gameData.unionid,
                area: gameData.parent_area,
                cid: cid,
                timestamp: getCurTimestampM(),
                payType:6,//6代表H5支付
                ciType:1//1代表房卡2代表金币
            };
            data.sign = Crypto.MD5("yayapay" + data.appid + data.playerid + data.unionid + data.area + data.cid + data.timestamp + data.payType + data.ciType);
            data = _.isString(data) ? data : JSON.stringify(data);
            cc.sys.openURL('https://pay.yayayouxi.com/payServer/wxpay/web_pay/index.html?param='+Base64.encode(data));
        },
        wxPay: function (prepayId) {
            var nonceStr = randomString(16);
            var packageValue = "Sign=WXPay";
            var timeStamp = getCurTimestamp();
            if (cc.sys.os == cc.sys.OS_IOS) {
                var str = "appid=" + WXA[gameData.appId] + "&noncestr=" + nonceStr + "&package=" + packageValue + "&partnerid=" + WXP[gameData.appId] + "&prepayid=" + prepayId + "&timestamp=" + timeStamp + "&key=" + WXK[gameData.appId];
                var ios_sign = Crypto.MD5(str).toUpperCase();
                jsb.reflection.callStaticMethod(
                    "WXUtil",
                    "wxPay:prepayId:package:nonceStr:timeStamp:sign:",
                    WXP[gameData.appId],
                    prepayId,
                    packageValue,
                    nonceStr,
                    timeStamp + "",
                    ios_sign
                );
            } else if (cc.sys.os == cc.sys.OS_ANDROID) {
                var android_sign = Crypto.MD5("appid=" + WXA[gameData.appId] + "&noncestr=" + nonceStr + "&package=" + packageValue + "&partnerid=" + WXP[gameData.appId] + "&prepayid=" + prepayId + "&timestamp=" + timeStamp+"&key=" + WXK[gameData.appId]).toUpperCase();
                jsb.reflection.callStaticMethod(
                    packageUri + "/utils/WeixinUtil",
                    "wxPay",
                    "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
                    WXA[gameData.appId],
                    WXP[gameData.appId],
                    prepayId,
                    packageValue,
                    nonceStr,
                    timeStamp + "",
                    android_sign
                );
            }
        }
    };

})(this);