(function () {
    var exports = this;
    var $ = null;
    var leftLayerW = 370;
    var niuYouQunBtnW = 80;

    var ClubLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        ctor: function () {
            this._super();
            var that = this;

            // if(gameData.headimgurl == null || gameData.headimgurl == "")  gameData.headimgurl = "http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLUqaOLnLDxwNeeh4hKiapicYLWWaa3d7KqU496Zq5gxTzicq1ibzibbsP5HF16btErnND6jURs0YWx5Yg/0";

            var scene = ccs.load(res.ClubLayer_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            this.myClubData = [];
            this.curLayer = "hide";//三个状态 先是hide隐藏 clublist俱乐部列表 roomlist房间列表
            this.createoradd = 'create';
            this.roomList = [];
            this.clickClubIndex = 0;

            //只显示 tab 按钮
            $('black').setPositionX(-cc.winSize.width);
            $('bg.btn_nyq.btn_left').setRotation(180);
            $('bg').setPositionX(- leftLayerW);
            $('clubLayer').setPositionX(- leftLayerW);
            this.initClubLayer();

            TouchUtils.setOnclickListener($("bg.btn_nyq"), function () {
                if(that.curLayer == "hide"){
                    that.showClub();
                }else{
                    if(that.curLayer == "clublist"){
                        that.curLayer = "hide";
                        $('black').setPositionX(-cc.winSize.width);
                        $('bg').runAction(cc.moveTo(0.1, cc.p(-leftLayerW, 0)));
                        $('clubLayer').runAction(cc.moveTo(0.1, cc.p(-leftLayerW, 0)));
                    }else if(that.curLayer == "roomlist"){
                        that.curLayer = "hide";
                        $('bg').setContentSize(cc.size(leftLayerW + niuYouQunBtnW, cc.winSize.height));
                        $('roomsLayer').setVisible(false);
                        $('bg.btn_nyq').setPositionX(leftLayerW + niuYouQunBtnW/2 - 10);
                        $('black').setPositionX(-cc.winSize.width);
                        $('bg').setPositionX(- leftLayerW);
                        $('clubLayer').setPositionX(-leftLayerW);
                    }
                    $('bg.btn_nyq.btn_left').setRotation(180);
                    //清除数据
                    var UserMsgLayer = that.getChildByName('UserMsgLayer');
                    if(UserMsgLayer){
                        UserMsgLayer.removeFromParent();
                    }
                }
            });

            //消息
            network.addListener(2101, function (data) {
                var cmd = data['command'];
                var errorCode = data['errorCode'];
                var errorMsg = data['errorMsg'];
                if(cmd == "queryClub"){
                    that.clickClubIndex = 0;
                    that.myClubData = data['arr'];
                    that.sortMyClubData();

                    if(that.myClubData.length == 0){
                        $('clubLayer.noclubtip').setVisible(true);
                        $('clubLayer.clubsScrollview').setVisible(false);
                        $('clubLayer.addClubLayer').setVisible(false);

                        $('roomsLayer').setVisible(false);
                        $('bg').setContentSize(cc.size(leftLayerW + niuYouQunBtnW, cc.winSize.height));
                        $('bg.btn_nyq').setPositionX(leftLayerW + niuYouQunBtnW/2 - 10);
                        return;
                    }else{
                        $('clubLayer.noclubtip').setVisible(false);
                        that.setClubScrollView();
                    }

                    if(that.myClubData && that.myClubData.length > 0){
                        var club_id = that.myClubData[0]['id'];
                        network.send(2101, {cmd:'listClubRoom', club_id:club_id});
                        network.send(2101, {cmd:'queryMSG', club_id: club_id});
                        network.send(2101, {cmd:'flushClub', club_id: club_id});
                    }
                }else if(cmd == "createClub"){
                    if(errorCode == 0) {
                        alert0('提示', '俱乐部创建成功');
                    }else{
                        HUD.showMessage(errorMsg, true);
                    }
                }else if(cmd == "applyClub"){
                    if(errorCode == 0) {
                        alert0('提示', '俱乐部申请成功');

                        $('clubLayer.addClubLayer').setVisible(false);
                        var clubsScrollview = $('clubLayer.clubsScrollview');
                        clubsScrollview.setPosition(cc.p(0, 30));
                    }else{
                        alert1(errorMsg);
                    }
                }else if(cmd == "listClubRoom"){
                    that.roomList = data['arr'];
                    that.roomList.sort(function(a, b){
                        return b['create_time'] - a['create_time'];
                    });
                    that.initRoomLayer();
                    //设置房间的数量 online_room
                    var roomLength = that.roomList.length;
                    if(that.myClubData && that.myClubData[that.clickClubIndex]) {
                        that.myClubData[that.clickClubIndex]['online_room'] = roomLength;
                    }
                    if(that.roomtxt && cc.sys.isObjectValid(that.roomtxt)) that.roomtxt.setString('已开房间(' + roomLength + ")");
                }else if(cmd == "queryMSG"){
                    that.msgList = [];
                    var club_id = 0;
                    if(that.clickClubIndex >= 0 && that.myClubData && that.myClubData[that.clickClubIndex]){
                        club_id = that.myClubData[that.clickClubIndex]['id'];
                    }
                    for(var i=0;i<data['arr'].length;i++){
                        if(data['arr'][i]['club_id'] == club_id){
                            that.msgList.push(data['arr'][i]);
                        }
                    }
                    // that.msgList = data['arr'] || [];
                    that.initMsgsLayer();
                }else if(cmd == "flushClub"){
                    if(data['originCommand'] == 'flushClub') {
                        that.usersList = data['msg']['members'];
                        that.initUsersLayer();
                    }
                    if(data['originCommand'] == 'removeClubMember'){
                        if(data['msg']){
                            that.usersList = data['msg']['members'];
                            that.initUsersLayer();
                            that.myClubData[that.clickClubIndex] = data['msg'];
                            that.setClubScrollView();
                        }
                    }
                    if(data['originCommand'] == 'modifyClub'){
                        var newClubName = data['msg']['name'];
                        that.myClubData[that.clickClubIndex].name = newClubName;
                        that.setClubScrollView();
                    }
                    if(data['originCommand'] == 'createClub'){
                        //创建 createClub
                        if(data['msg']){
                            that.myClubData.push(data['msg']);
                            that.sortMyClubData();
                        }
                        that.clickClubIndex = that.myClubData.length - 1;
                        $('clubLayer.noclubtip').setVisible(false);
                        that.setClubScrollView();
                        if(that.myClubData && that.myClubData.length > 0){
                            var club_id = that.myClubData[that.clickClubIndex ]['id'];
                            network.send(2101, {cmd:'listClubRoom', club_id:club_id});
                        }
                    }
                    if(data['originCommand'] == 'addClubMember'){//添加成员
                        if(data['msg']){
                            that.myClubData[that.clickClubIndex] = data['msg'];
                            that.setClubScrollView();
                        }
                    }
                    if(data['originCommand'] == 'wanfaClub'){
                        //设置玩法
                        // that.setWanfaInfo = {map_id: data['msg']['map_id'], options: data['msg']['options']};
                        var clubInfo = that.myClubData[that.clickClubIndex];
                        clubInfo['map_id'] = data['msg']['map_id'];
                        clubInfo['options'] = data['msg']['options'];
                    }
                }else if(cmd == "removeClubMember"){
                    HUD.showMessage('删除成功', true);
                }else if(cmd == "agreeClub"){
                    that.msgList = data['arr'] || [];
                    that.initMsgsLayer();

                    network.send(2101, {cmd:'queryClub'});
                }else if(cmd == "modifyClub"){
                    if(errorCode == 0) {
                        alert0('提示', '俱乐部名称修改成功');
                    }else{
                        HUD.showMessage(errorMsg, true);
                    }
                }else if(cmd == "deleteClub"){
                    if(errorCode == 0) {
                        alert0('提示', '俱乐部删除成功');
                    }else{
                        HUD.showMessage(errorMsg, true);
                    }
                }else if(cmd == "addClubMember"){
                    if(errorCode == 0) {
                        alert0('提示', '添加成员成功');
                    }else{
                        HUD.showMessage(errorMsg, true);
                    }
                }else if(cmd == "wanfaClub"){
                    if(errorCode == 0) {
                        alert0('提示', '设置玩法成功');
                    }else{
                        HUD.showMessage(errorMsg, true);
                    }
                }
            });
        },
        showClub:function(){
            this.curLayer = "clublist";
            $('black').setPositionX(0);
            $('bg').runAction(cc.moveTo(0.1, cc.p(0, 0)));
            $('bg.btn_nyq.btn_left').setRotation(0);
            $('clubLayer').stopAllActions();
            $('clubLayer').runAction(cc.moveTo(0.1, cc.p(0, 0)));
            $('clubLayer.addClubLayer').setVisible(false);

            this.clickClubIndex = 0;

            network.send(2101, {cmd:'queryClub'});
        },
        sortMyClubData:function () {
            this.myClubData.sort(function(a, b){
                var aquan = (a['owner_uid'] == gameData.uid) ? 1000:0;
                var bquan = (b['owner_uid'] == gameData.uid) ? 1000:0;
                return bquan - aquan;
            });
        },
        //club
        showCreateOrAddClubLayer:function(addorcreate, clubid){
            var that = this;
            var addClubLayer =  $('clubLayer.addClubLayer');
            if(addClubLayer.isVisible() == false){
                $('clubLayer.clubsScrollview').runAction(cc.sequence(
                    cc.moveBy(0.2, cc.p(0, -700))
                ));

                addClubLayer.setScaleY(0);
                $('clubLayer.addClubLayer.bg_input.input').setString("");
                addClubLayer.setVisible(true);
                addClubLayer.runAction(cc.sequence(
                    cc.scaleTo(0.2, 1, 1)
                ));
            }
            $('clubLayer.addClubLayer.title_create').setTexture((addorcreate == "add") ?
                'res/image/ui/club/title_join.png':'res/image/ui/club/title_create.png');
            $('clubLayer.addClubLayer.bg_input.input').setPlaceHolder(((addorcreate == "add") ? "输入俱乐部ID":"输入俱乐部名称"));
            that.createoradd = addorcreate;

            if(clubid){
                $('clubLayer.addClubLayer.bg_input.input').setString(clubid);
            }
        },
        initClubLayer:function(){
            var that = this;
            $("clubLayer.add").setLocalZOrder(1);
            TouchUtils.setTouchRect($("clubLayer.add"), cc.rect(-30, -30, 100, 100));//40 40
            TouchUtils.setOnclickListener($("clubLayer.add"), function () {
                $('clubLayer.noclubtip').setVisible(false);

                var UserMsgLayer = new ClubUserMsgLayer(that.myClubData[that.clickClubIndex], null, 'addorcreate', that);
                UserMsgLayer.setName('UserMsgLayer');
                that.addChild(UserMsgLayer);
            }, {swallowTouches:true});
            TouchUtils.setOnclickListener($("clubLayer.addClubLayer.confirm"), function () {
                var input = $('clubLayer.addClubLayer.bg_input.input').getString();
                if(input == null || input == undefined || input == ""){
                    var tip = "俱乐部ID不能为空";
                    if(that.createoradd == "create")  tip = "俱乐部名称不能为空";
                    HUD.showMessage(tip, true);
                    return;
                }
                if(input.length < 1 || input.length > 17){
                    var tip = "群ID长度在1-16字符之间";
                    if(that.createoradd == "create")  tip = "群昵称长度在2-16字符之间";
                    HUD.showMessage(tip, true);
                    return;
                }

                if(that.createoradd == "create"){
                    network.send(2101, {cmd: 'createClub', name: input, owner_name:gameData.nickname, head:gameData.headimgurl});
                }else{
                    var inputnum = parseInt(input);
                    if(!inputnum){
                        HUD.showMessage('俱乐部ID不是数字', true);
                        return;
                    }
                    //自己在的俱乐部  不能继续申请
                    var isIn = false;
                    for(var s=0;s<that.myClubData.length;s++){
                       if(that.myClubData[s]['id'] == input){
                           isIn = true;
                           break;
                       }
                    }
                    if(isIn){
                        HUD.showMessage('您已加入该俱乐部，无法重复申请', true);
                    }else {
                        network.send(2101, {
                            cmd: 'applyClub',
                            club_id: input,
                            name: gameData.nickname,
                            head: gameData.headimgurl
                        });
                    }
                }
            });
            TouchUtils.setOnclickListener($("clubLayer.addClubLayer.cancel"), function () {
                $('clubLayer.addClubLayer').setVisible(false);
                var clubsScrollview = $('clubLayer.clubsScrollview');
                clubsScrollview.setPosition(cc.p(0, 30));
            });

            $('roomsLayer').setVisible(false);
            $('clubLayer.addClubLayer').setVisible(false);
            $('clubLayer.noclubtip').setVisible(false);
        },
        setClubScrollView:function(){
            var that = this;
            $('clubLayer.addClubLayer').setVisible(false);

            var clubsScrollview = $('clubLayer.clubsScrollview');
            clubsScrollview.setPosition(cc.p(0, 30));
            clubsScrollview.setVisible(true);
            clubsScrollview.removeAllChildren();

            that.clubItemArr = [];
            var row0 = ccs.load(res.ClubItem_json, "res/").node;
            row0.setName('row0');
            var itemSize = row0.getChildByName('row').getContentSize();
            clubsScrollview.addChild(row0);
            var rowCount = this.myClubData.length;
            var innerHeight = itemSize.height * rowCount;
            if(innerHeight <= clubsScrollview.getContentSize().height)  innerHeight = clubsScrollview.getContentSize().height;
            var delta = clubsScrollview.getContentSize().height - innerHeight;
            for (var i = 0; i <= rowCount-1; i++) {
                (function (i) {
                    var node = clubsScrollview.getChildByName('row' + i);
                    if (!node) {
                        node = new cc.Layer();
                        node.addChild(row0.getChildByName('row').clone());
                        node.setName('row' + i);
                        clubsScrollview.addChild(node);
                    }
                    that.clubItemArr[i] = [];
                    //bg
                    var row = node.getChildByName('row');
                    var bg = row.getChildByName('bg');
                    if(!bg){
                        bg = new cc.Sprite('res/image/ui/club/btn_xuanze.png');
                        bg.setPosition(cc.p(itemSize.width/2, itemSize.height/2));
                        bg.setName('bg');
                        row.addChild(bg, -1);
                    }
                    that.clubItemArr[i].bg = bg;
                    bg.setTexture((i != that.clickClubIndex) ? 'res/image/ui/club/btn_weixuanze.png'
                        : 'res/image/ui/club/btn_xuanze.png');
                    TouchUtils.setOnclickListener(bg, function(){
                        if(that.clubItemArr && that.clubItemArr.length > 0) {
                            for (var k = that.clubItemArr.length-1; k >= 0; k--) {
                                var rowbg = that.clubItemArr[k]['bg'];
                                if(rowbg){
                                    rowbg.setTexture(((k != i) ? 'res/image/ui/club/btn_weixuanze.png'
                                        : 'res/image/ui/club/btn_xuanze.png'));
                                }
                                var roomtxt = row.getChildByName('roomtxt');
                                if(k == i && roomtxt){
                                    that.roomtxt = roomtxt
                                }
                            }
                        }
                        that.clickClubIndex = i;
                        var club_id = that.myClubData[i]['id'];
                        network.send(2101, {cmd:'listClubRoom', club_id:club_id});
                        network.send(2101, {cmd:'queryMSG', club_id: club_id});
                    }, {swallowTouches: false});
                    var clubInfo = that.myClubData[i];
                    var setData = function(ref){
                        var players_count = clubInfo['players_count'] || 1;
                        $("name", ref).setString(ellipsisStr(clubInfo['name'], 6) + "(" + players_count + ")");
                        var online_room = clubInfo['online_room'] || 0;
                        $("roomtxt", ref).setString('已开房间(' + online_room + ")");

                        //头像
                        var members4 = clubInfo['members4'] || clubInfo['members'];
                        if(members4) {
                            if (members4.length == 1) {
                                $("head_1", ref).setVisible(false);
                                $("head_2", ref).setVisible(false);
                                $("head_3", ref).setVisible(false);
                                $("head_4", ref).setVisible(false);
                                $("head", ref).setVisible(true);
                                if (members4[0]['head'] == null || members4[0]['head'] == undefined || members4[0]['head'] == "") {
                                    members4[0]['head'] = res.defaultHead;
                                }
                                loadImageToSprite2(decodeURIComponent(members4[0]['head']), $('head', ref));
                            } else {
                                var memberLength = members4.length;
                                if(memberLength >= 4)  memberLength = 4;
                                $("head", ref).setVisible(false);
                                for (var s = 0; s < memberLength; s++) {
                                    if (members4[s]['head'] == null || members4[s]['head'] == undefined || members4[s]['head'] == "") {
                                        members4[s]['head'] = res.defaultHead;
                                    }
                                    $('head_' + (s + 1), ref).setVisible(true);
                                    loadImageToSprite2(decodeURIComponent(members4[s]['head']), $('head_' + (s + 1), ref));
                                }
                                for (s; s < 4; s++) {
                                    $('head_' + (s + 1), ref).setVisible(false);
                                }
                            }
                        }
                    };
                    setData($('row', node));
                    node.setPosition(cc.p(
                        10,
                        innerHeight - (i+1) * itemSize.height
                    ));
                })(i);
            }
            clubsScrollview.innerHeight = innerHeight;
        },
        //房间列表
        initRoomLayer:function(){
            var that = this;
            this.curLayer = "roomlist";
            $('clubLayer').stopAllActions();
            $('clubLayer').setPositionX(0);

            var clubname = "";
            if(that.clickClubIndex >= 0 && that.myClubData && that.myClubData[that.clickClubIndex]){
                clubname = ellipsisStr(that.myClubData[that.clickClubIndex]['name'], 6) + "(ID:" + that.myClubData[that.clickClubIndex]['id'] + ")";
            }
            $('roomsLayer.clubname').setString(clubname);
            //无房间提示
            if(that.roomList.length > 0){
                $("roomsLayer.noroomtip").setVisible(false);
            }else{
                $("roomsLayer.noroomtip").setVisible(true);
            }
            var owner_uid = 0;
            if(that.clickClubIndex >= 0 && that.myClubData && that.myClubData[that.clickClubIndex]){
                owner_uid = that.myClubData[that.clickClubIndex]['owner_uid'];
            }
            //能不能编辑用户列表
            if(gameData.uid == owner_uid){
                TouchUtils.setClickDisable($("roomsLayer.btn_set"), false);
                $("roomsLayer.btn_set").setOpacity(255);
            }else{
                TouchUtils.setClickDisable($("roomsLayer.btn_set"), true);
                $("roomsLayer.btn_set").setOpacity(100);
            }

            if(that.roomTableView == null){
                TouchUtils.setOnclickListener($("roomsLayer.btn_msg"), function () {
                    $("roomsLayer.noroomtip").setVisible(false);
                    that.msgList = [];
                    var UserMsgLayer = new ClubUserMsgLayer(that.myClubData[that.clickClubIndex], that.msgList, 'msgs', that);
                    UserMsgLayer.setName('UserMsgLayer');
                    that.addChild(UserMsgLayer);

                    var clubid = that.myClubData[that.clickClubIndex]['id'];
                    network.send(2101, {cmd: 'queryMSG', club_id: clubid});
                });
                TouchUtils.setOnclickListener($("roomsLayer.copy"), function () {
                    var club = that.myClubData[that.clickClubIndex];
                    // savePasteBoard(club_id);
                    // alert0('提示', '复制成功');
                    var content = "玩家[" + gameData.nickname + "]邀请您加入俱乐部[" + club['name'] + "]，俱乐部ID[" + club['id'] + "]";
                    // console.log(content);
                    WXUtils.shareUrl(MWINDOWURL[gameData.appId] + '?roomid=0' + club['id'], "风云俱乐部", content, 0, getCurTimestamp() + gameData.uid);

                });
                TouchUtils.setOnclickListener($("roomsLayer.btn_users"), function () {
                    $("roomsLayer.noroomtip").setVisible(false);
                    that.usersList = [];
                    var UserMsgLayer = new ClubUserMsgLayer(that.myClubData[that.clickClubIndex], that.usersList, 'users', that);
                    UserMsgLayer.setName('UserMsgLayer');
                    that.addChild(UserMsgLayer);

                    var club_id = that.myClubData[that.clickClubIndex]['id'];
                    network.send(2101, {cmd:'flushClub', club_id: club_id});
                });
                TouchUtils.setOnclickListener($("roomsLayer.btn_set"), function () {
                    $("roomsLayer.noroomtip").setVisible(false);
                    var UserMsgLayer = that.getChildByName('UserMsgLayer');
                    if(UserMsgLayer){
                        UserMsgLayer.removeFromParent();
                    }
                    var UserMsgLayer = new ClubUserMsgLayer(that.myClubData[that.clickClubIndex], null, 'set', that);
                    UserMsgLayer.setName('UserMsgLayer');
                    that.addChild(UserMsgLayer);
                });

                TouchUtils.setOnclickListener($("roomsLayer.createroom"), function () {
                    var parent = that.getParent();
                    var club_id = that.myClubData[that.clickClubIndex]['id'];
                    var options = that.myClubData[that.clickClubIndex]['options'];
                    var map_id = that.myClubData[that.clickClubIndex]['map_id'];
                    if(map_id == null || map_id == undefined || map_id == "" || map_id == 0){
                        alert0('提示', '请先设置玩法选项');
                    }else{
                        network.start();
                        network.send(3001, {
                            room_id: 0
                            , map_id: map_id//gameData.appId
                            , mapid: map_id
                            , daikai: true
                            , options: options
                            , club_id: club_id
                        });
                    }
                    // parent.createRoomLayer(true, "all", club_id);
                });

                $('bg').setContentSize(cc.size(cc.winSize.width, cc.winSize.height));
                $('bg.btn_nyq').setPositionX(1230);
                $('bg').setPositionX(-cc.winSize.width + leftLayerW);
                $('bg').stopAllActions();
                $('bg').runAction(cc.sequence(
                    cc.moveTo(0.2, cc.p(0, 0)).easing(cc.easeIn(1)),
                    cc.callFunc(function () {
                        $('roomsLayer').setVisible(true);
                        var roomsLayer = $('roomsLayer');
                        var roombg = $('roomsLayer.bg');
                        var roomTableView = new cc.TableView(that, cc.size(roombg.getContentSize().width,
                            roombg.getContentSize().height - 70));
                        roomTableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                        roomTableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
                        roomTableView.x = 0;
                        roomTableView.y = 110;
                        roomTableView.setDelegate(that);
                        roomTableView.setBounceable(true);
                        roomsLayer.addChild(roomTableView);
                        that.roomTableView = roomTableView;
                    })
                ));
            }else{
                if($('roomsLayer').isVisible()){
                    this.roomTableView.reloadData();
                }else{
                    $('bg').setContentSize(cc.size(cc.winSize.width, cc.winSize.height));
                    $('bg.btn_nyq').setPositionX(1230);
                    $('bg').setPositionX(-cc.winSize.width + leftLayerW);
                    $('bg').stopAllActions();
                    $('bg').runAction(cc.sequence(
                        cc.moveTo(0.2, cc.p(0, 0)).easing(cc.easeIn(1)),
                        cc.callFunc(function () {
                            $('roomsLayer').setVisible(true);
                            var roomsLayer = $('roomsLayer');
                            var roombg = $('roomsLayer.bg');
                            that.roomTableView.reloadData();
                        })
                    ));
                }
            }
        },
        tableCellTouched: function (table, cell) {
            var idx = cell.getIdx();
            var roomid = this.roomList[idx]['room_id'];
            showLoading();
            network.send(3002, {
                room_id: '' + roomid
            });
        },
        tableCellSizeForIndex: function (table, idx) {
            return cc.size(650, 250);
        },
        tableCellAtIndex: function (table, idx) {
            var cell = table.dequeueCell();
            if(cell == null) {
                cell = new cc.TableViewCell();
            }
            var row0 = cell.getChildByName('cellrow');
            if(!row0) {
                row0 = ccs.load(res.RoomItem_json, "res/").node;
                row0.setName("cellrow");
                cell.addChild(row0);
            }
            var roomInfo = this.roomList[idx];
            var setData = function(ref){
                var option = JSON.parse(roomInfo.option);
                var nickname = option['nickname'] || "";
                $('bg.fangzhuname', ref).setString(ellipsisStr(nickname, 6) + "(ID:" + roomInfo['owner_uid'] + ")");
                var gamename = "";
                if(roomInfo['map_id'] == MAP_ID_PDK || roomInfo['map_id'] == MAP_ID_ZJH ||
                    roomInfo['map_id'] == MAP_ID_ZHUANZHUAN || roomInfo['map_id'] == MAP_ID_CHANGSHA || roomInfo['map_id'] == MAP_ID_HONGZHONG){
                    gamename = option['zhuang_gz'];
                    gamename = gameData.mapIdMaName[roomInfo.map_id];
                }else{
                    gamename = getZhuangMode(option);
                }
                $("bg.name", ref).setString(gamename + "(房号：" + roomInfo['room_id'] + ")");
                var difenstr = "";
                if(option['Difen']) difenstr = option['Difen'].replace(',', '/');
                if(option['basescore']) difenstr = option['basescore'];
                $("bg.fen", ref).setString(difenstr);
                var zhifutype = (option['AA'] ? 'AA支付':'房主支付');
                $("bg.fu", ref).setString(zhifutype);
                $("bg.ju", ref).setString(option['rounds'] || option['jushu']);
                var BeiShu = "";
                if(option['BeiShu'])  BeiShu = option['BeiShu'] + "倍";
                $("bg.gui", ref).setString(BeiShu);

                if (option['headimgurl'] == null || option['headimgurl'] == undefined || option['headimgurl'] == "") {
                    option['headimgurl'] = res.defaultHead;
                }
                loadImageToSprite2(decodeURIComponent(option['headimgurl']), $('head', ref));
            };
            setData($('row', row0));

            return cell;
        },
        numberOfCellsInTableView: function (table) {
            return this.roomList.length;
        },
        //消息列表
        setWeiduMegNum:function(num){
            if(num > 0){
                $("roomsLayer.btn_msg.numbg").setVisible(true);
                $("roomsLayer.btn_msg.numbg.num").setString(num);
            }else{
                $("roomsLayer.btn_msg.numbg").setVisible(false);
            }
        },
        initMsgsLayer:function(){
            var that = this;
            this.setWeiduMegNum(this.msgList.length);
            var UserMsgLayer = this.getChildByName('UserMsgLayer');
            if (UserMsgLayer){
                UserMsgLayer.initMsgLayer(that.msgList);
            }
        },
        //用户列表
        initUsersLayer:function(){
            var that = this;
            var UserMsgLayer = this.getChildByName('UserMsgLayer');
            if(UserMsgLayer){
                UserMsgLayer.initUserLayer(that.usersList);
            }
        },
        //判断该人是不是在列表里
        isUserInClub : function(uid){
            if(this.usersList && this.usersList.length > 0){
                for(var i=0;i<this.usersList.length;i++){
                    if(this.usersList[i]['uid'] == uid){
                        return true;
                    }
                }
                return false;
            }
            return false;
        }
    });

    exports.ClubLayer = ClubLayer;
})(window);

