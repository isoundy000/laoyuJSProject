(function () {
    var exports = this;

    var $ = null;

    var interval = null;

    var ShenqingjiesanLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        onExit: function () {
            cc.Layer.prototype.onExit.call(this);
        },
        ctor: function (type, content, onOk, onCancel, canCancel) {
            this._super();

            var that = this;

            var scene = ccs.load(res.PhzRoomQuit_json,"res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            TouchUtils.setOnclickListener($('root.btn_confirm'), function (node) {
                network.send(3009, {room_id: gameData.roomId, is_accept: 1});
            });
            TouchUtils.setOnclickListener($('root.panel.btn_cancel'), function (node) {
                network.send(3009, {room_id: gameData.roomId, is_accept: 0});
            });

            return true;
        },
        setArr: function (leftSeconds, arr) {
            var that = this;
            var haveISelected = false;
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].uid == gameData.uid) {
                    haveISelected = true;
                    break;
                }
            }
            var content = "玩家【" + gameData.playerMap[arr[0].uid].nickname + "】申请解散房间, " + (haveISelected ? "请等待其他玩家选择 (超过5分钟未做选择, 则默认同意)" : "请问是否同意? (超过5分钟未做选择, 则默认同意)") + "\n\n";
            var selectedUid = {};
            selectedUid[arr[0].uid] = true;
            for (var i = 1; i < arr.length; i++) {
                selectedUid[arr[i].uid] = true;
                content += "【" + gameData.playerMap[arr[i].uid].nickname + "】 " + (arr[i]['is_accept'] ? "同意" : "拒绝") + "\n";
            }
            for (var i = 0; i < gameData.players.length; i++) {
                var player = gameData.players[i];
                if (!selectedUid[player.uid]) {
                    content += "【" + player.nickname + "】 " + ("等待选择") + "\n";
                }
            }
            $('root.panel.lb_content').setString(content);

            if (haveISelected) {
                $('root.panel.btn_ok').setVisible(false);
                $('root.panel.btn_cancel').setVisible(false);
            }

            if (interval) {
                clearInterval(interval);
                interval = null;
            }
            var func = function () {
                if (leftSeconds <= 0 || !cc.sys.isObjectValid(that)) {
                    clearInterval(interval);
                    interval = null;
                    return;
                }
                $('root.panel.lb_sec').setString(leftSeconds + '');
                leftSeconds--;
            };
            func();
            interval = setInterval(func, 1000);
        }
    });

    exports.Ma_ShenqingjiesanLayer = ShenqingjiesanLayer;
})(window);
