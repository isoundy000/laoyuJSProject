/**
 * Created by hjx on 2018/2/7.
 */
(function () {
    var exports = this;

    var $ = null;
    var ClubInfoItem = cc.Layer.extend({
        layerHeight: 0,
        ctor: function (data, cl) {
            this._super();

            var that = this;

            var scene = ccs.load(res.ClubInfoItem_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            this.layerWidth = this.getChildByName("Layer").getBoundingBox().width;

            // console.log("club info ");
            // console.log(data.members);

            $('lb_name').setString(ellipsisStr(data.name,10));
            $('lb_qz').setString(ellipsisStr(data.nick, 5));
            $('lb_id').setString("" + data._id);
            $('lb_players').setString(data.players_count || '');
            $('lb_count').setString(data.players_count || '');
            loadImageToSprite(data.head, $('head'));

            TouchUtils.setOnclickListener($('btn_in_club'), function () {
                var tablesLayer = window.maLayer.getChildByName('ClubTablesLayer');
                if(!tablesLayer) {
                    tablesLayer = new ClubTablesLayer(data._id, true);
                    tablesLayer.setName('ClubTablesLayer');
                    window.maLayer.addChild(tablesLayer);
                }
            }, {swallowTouches:false});
            return true;
        },
        enterClub:function(clubId){
            var clayer = window.maLayer.getChildByName('ClubTablesLayer');
            if(!clayer) {
                clayer = new ClubTablesLayer(clubId);
                clayer.setName('ClubTablesLayer');
                window.maLayer.addChild(clayer);
            }
        },
        getLayerWidth: function () {
            return this.layerWidth;
        }
    });

    var ClubTableItem = cc.Layer.extend({
        layerHeight: 0,
        layerWidth: 0,
        ctor: function (data, pos, count, layer) {
            this._super();

            var that = this;

            var scene = null;
            console.log("count ==== " + count);
            if(count == 9){
                scene = ccs.load(res.ClubTableItem3_json, 'res/');
            }else if(count>=5){
                scene = ccs.load(res.ClubTableItem2_json, 'res/');
            }else{
                scene = ccs.load(res.ClubTableItem_json, 'res/');
            }

            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            this.layerWidth = this.getChildByName("Layer").getBoundingBox().width;
            this.layerHeight = this.getChildByName("Layer").getBoundingBox().height;

            if(count==5){
                $('table').setTexture('res/image/ui/club/table_for_5.png');
            }else if(count==3 || count==2){
                $('table').setTexture('res/image/ui/club/table_for_3.png');
            }

            if(data){
                console.log("ClubTableItem ------club info 房号:"+data.room_id);
                console.log(data);
                $('table.lb_num').setString("房号:" + data.room_id);
                $('table.lb_num').setVisible(true);
                var options = data.option;
                if(_.isString(data.option)){
                    options = JSON.parse(options)
                }
                // $('table.Text_5').setString("局数:" +0+"/"+(options.jushu || options.rounds));
                if(data.status == 1){
                    $('table.state').setTexture('res/image/ui/club/icon_wait.png');
                }else{
                    $('table.state').setTexture('res/image/ui/club/icon_start.png');
                }
                for(var i=1; i<=9; i++){
                    if(!$('table.row' + i))break;
                    $('table.row' + i).setVisible(false);
                }
                for(var i=1; i<=data.heads.length; i++){
                    if($('table.row' + i)){
                        $('table.row' + i).setVisible(true);
                        loadImageToSprite(data.heads[i-1], $('table.row'+i+'.head'), 30);
                        $('table.row'+i+'.lb_name').setString(ellipsisStr(data.nicknames[i-1], 5));
                    }else{
                        break;
                    }
                }
            }else{
                console.log("---- no --");
                $('table.lb_num').setVisible(false);
                for(var i=1; i<=9; i++){
                    if(!$('table.row' + i))break;
                    $('table.row' + i).setVisible(false);
                }
                $('table.state').setTexture('res/image/ui/club/icon_wait.png');
            }

            var startPos = null;
            TouchUtils.setOntouchListener($('table'), undefined,  {
                onTouchBegan : function (node, touch) {
                    startPos = node.convertToWorldSpace(cc.p(0,0));
                },
                onTouchEnded: function (node, event) {
                    //记录时间 5秒以内只能点击一次
                    var time = new Date().getTime();
                    if(Math.abs(gameData.clickClubRoomTime - time) <= 1000){
                        return;
                    }
                    var info = getClubCurrentWanfaInfo();
                    var clubid = 0;
                    if(info) {
                        var options = info.options;
                        if (_.isString(options)) {
                            options = JSON.parse(options)
                        }
                        clubid = options['club_id'];
                        if (!clubid) clubid = info.club_id;
                    }
                    //俱乐部进去的要回大厅  继续打开俱乐部
                    gameData.enterRoomWithClubID = clubid;

                    gameData.clickClubRoomTime  = time;
                    var endPos = node.convertToWorldSpace(cc.p(0,0));
                    if(Math.abs(endPos.x - startPos.x)<=50){
                        console.log("ok --- ");
                        if(data){
                            console.log('点击牌桌'  +data.room_id);
                            showLoading();
                            network.send(3002, {
                                room_id: '' + data.room_id
                            });
                        }else{

                            if(info){
                                options.pos = pos;
                                options.desp = info.desc;
                                showLoading();
                                var last3001Data = {
                                    room_id: 0
                                    , club_id: clubid
                                    , map_id: options['mapid']//gameData.appId
                                    , mapid: options['mapid']
                                    , daikai: false
                                    //, shipin: videoStatus
                                    , options: options
                                    , timestamp: getCurrentTimeMills()
                                };
                                gameData.last3001Data = last3001Data;
                                network.send(3001, last3001Data);
                                // console.log(options); console.log("玩法说明：");
                            }
                        }
                    }
                },
                swallowTouches:false
            });
            return true;
        },
        getLayerWidth: function () {
            return this.layerWidth;
        },
        getLayerHeight: function () {
            return this.layerHeight;
        }
    });

    exports.ClubInfoItem = ClubInfoItem;
    exports.ClubTableItem = ClubTableItem;
})(window);