//     跑得快（扑克）配置     //

var pdk_src = [
    'src/submodules/pdk/PokerJieSuanLayer.js',
    'src/submodules/pdk/PokerLayer.js',
    'src/submodules/pdk/PokerZongJiesuanLayer.js',
    'src/submodules/pdk/WanfaLayer.js',
    'src/submodules/pdk/QiepaiLayer.js'
];

var pdk_res = {
    PkScene_pdk_json: 'res/submodules/pdk/ccs/PkScene.json',
    PokerJieSuan_json: 'res/submodules/pdk/ccs/PokerJieSuan.json',
    PokerZongJieSuan_json: 'res/submodules/pdk/ccs/PokerZongJiesuan.json',
    PkQiepai_pdk_json: 'res/submodules/pdk/ccs/QiepaiLayer.json',
};

var pdk_create_room_tabData = {
    btn_10: {
        click: ['mapid_0'],
        show: [],
        hide: []
    }
};

var pdk_create_room_wanFaData = [
    ['mapid', [
        ['跑得快', MAP_ID.PDK, -1000, -1000, true, true, false]
    ]],
    ['AA',
        [['房主支付', false, 480, 580, true, true, false, null, ['mapid_0']],
            ['AA支付', true, 720, 580, false, true, false, null, ['mapid_0']]
        ]],
    ['jushu', [
        ['8局', 8, 480, 525, true, true, false, null, ['mapid_0']],
        ['16局', 16, 720, 525, false, true, false, null, ['mapid_0']]
    ]],
    //跑得快
    ['sanrenwan_pdk', [
        ['三人玩', true, 480, 470, true, true, false, ['liangren_pdk_0'], 'mapid_0']
    ]],

    ['liangren_pdk', [
        ['二人玩', true, 720, 470, false, true, false, ['zhuaniao_0', 'sanrenwan_pdk_0'], 'mapid_0']
    ]],
    ['pdk3Abomb', [
        ['3A当炸弹', true, 720, 305, false, false, false, ['pdk3A1bomb_0'], ['mapid_0']]
    ]],
    ['pdk3A1bomb', [
        ['3A带1张当炸弹', true, 720, 250, false, false, false, ['pdk3Abomb_0'], ['mapid_0']]
    ]],

    ['pdkNumofCardsPerUser', [
        ['16张', 16, 480, 415, true, true, false, null, 'mapid_0'],
        ['15张', 15, 720, 415, false, true, false, null, 'mapid_0']
    ]],
    ['zhuaniao', [
        ['抓鸟(红桃10)', true, 480, 360, false, false, false, null, 'mapid_0']
    ]],
    ['heisanzhuang', [
        ['黑桃3先出', true, 720, 360, false, false, false, null, 'mapid_0']
    ]],
    ['sidai2or3', [
        ['允许4带3', 2, 480, 250, true, false, false, null, 'mapid_0']
    ]],

    ['xianshipai', [
        ['显示余牌', true, 480, 305, true, false, false, null, 'mapid_0']
    ]],
    ['anticheating', [
        ['防作弊', true, 960, 305, false, false, false, null, 'mapid_0']
    ]],
    ['qiepai', [
        ['切牌', true, 480, 195, true, false, false, null, ['mapid_0']]
    ]],
];

var pdk_fangka = {
    btn_10: [[5, 10], [2, 4]]
};
