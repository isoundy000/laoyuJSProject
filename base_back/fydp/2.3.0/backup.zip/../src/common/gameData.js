var APP_ID_HN = 1;
var APP_ID_HB = 2;
var APP_ID_SC = 3;
var APP_ID_JIANGXI = 4;
var APP_ID_HEBEI = 5;
var APP_ID_GUANGDONG = 7;
var APP_ID_ANHUI = 9;
var APP_ID_SHANDONG = 12;
var APP_ID_SHAN3XI = 13;
var APP_ID_HENAN = 20;
var APP_ID_GUANGXI = 25;
var APP_ID_DDZ = 201;
var APP_ID_SHANXI = 0;
var APP_ID_PK = 200;
var APP_ID_NN = 203;
var APP_ID_PENGHUZI = 305;//株洲斗牌
var APP_ID_QUANMINDOUPAI = 306;//全民斗牌

var MAP_ID_PHZ = 9;
var MAP_ID_ZHUANZHUAN = 1;
var MAP_ID_CHANGSHA = 5;
var MAP_ID_HONGZHONG = 22;
var MAP_ID_DN = 203;
var MAP_ID_NN = 203;
var MAP_ID_CRAZYNN = 2004;
var MAP_ID_DN = 203;
var MAP_ID_XIANGYANG_PDK = 203;
var MAP_ID_PDK = 200;
var MAP_ID_DDZ_JD = 201;//斗地主
var MAP_ID_LAIZI_DDZ = 206;
var MAP_ID_ZJH = 207;

var DAIKUAN_URL = "http://tuanzidai.cn/frontend_loan_service/common?funid=201&appid=3&channel=120477";
var FANGKA_KEY = 'haidao_zhan';

var FENXIANG_URL = 'http://pay.yayayouxi.com/payServer/player/share/';

var ZADAN_KEY = "lok_t_oga";
// var ZADAN_URL = "http://10.0.14.226:8080/payServer/activity/"; 
var ZADAN_URL = 'http://pay.yayayouxi.com/payServer/activity/';



var MWINDOWURL = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = "https://aidhyd.mlinks.cc/A0Gc";//全名斗牌
    t[APP_ID_PENGHUZI] = "https://aidhyd.mlinks.cc/Acj4";//株洲
    return t;
})();
var COMPANYNAME = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = "风云";//全名斗牌
    t[APP_ID_PENGHUZI] = "丫丫";//株洲
    return t;
})();
// 商户
var WXP = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = "1480895852";//需要根据区域替换--微信申请信息
    t[APP_ID_PENGHUZI] = "1480895852";//需要根据区域替换--微信申请信息
    return t;
})();
/*
 wxb45a03a146f54e45     全民
 5b83027d0cdbd14a59986e51df93cc9a

 wx1f322fc80f8d5e44     株洲
 cf10be973460f595223ad88c627cde82
 */
// appid
var WXA = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = "wxb45a03a146f54e45";//需要根据区域替换--微信申请信息
    t[APP_ID_PENGHUZI] = "wx1f322fc80f8d5e44";//需要根据区域替换--微信申请信息
    return t;
})();
// key
var WXK = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = "252419947aaeb4a8dabe9c8cc2453c12";//需要根据区域替换--微信申请信息
    t[APP_ID_PENGHUZI] = "252419947aaeb4a8dabe9c8cc2453c12";//需要根据区域替换--微信申请信息
    return t;
})();

var WXS = (function () {
    var t = [];
    t[APP_ID_QUANMINDOUPAI] = ['5b83', '027d', '0cdbd', '14a5', '9986', 'e51d', 'f93', 'cc9a'];
    t[APP_ID_PENGHUZI] = ['cf10', 'be97', '3460', 'f5952', '23ad88', 'c627c', 'de82'];
    return t;
})();


var ALOV = (function () {
    var t = [];
    t[APP_ID_PENGHUZI] = ['mj-hn-sound', 'http://mj-hn-sound.oss-cn-hangzhou.aliyuncs.com', 'IhWyMYkOv0w6yn2P', ['KqQ', 'sUD', 'lMJ', 'W3x', 'nDj', 'Eg5', '5nq', 'ZaL', 'IV5', 'Uta']];
    t[APP_ID_QUANMINDOUPAI] = ['mj-hn-sound', 'http://mj-hn-sound.oss-cn-hangzhou.aliyuncs.com', 'IhWyMYkOv0w6yn2P', ['KqQ', 'sUD', 'lMJ', 'W3x', 'nDj', 'Eg5', '5nq', 'ZaL', 'IV5', 'Uta']];
    return t;
})();

var ALOR = (function () {
    var t = [];
    t[APP_ID_PENGHUZI] = 'http://mj-hn.oss-cn-hangzhou.aliyuncs.com/';
    t[APP_ID_QUANMINDOUPAI] = 'http://mj-hn.oss-cn-hangzhou.aliyuncs.com/';
    return t;
})();
var gameData = {
    isWXAppInstalled: null

    , isXianLiaoAppInstalled: null
    , isLBAppInstalled: null

    , lotteryNum: 1
    , pluginNum: 1
    , appId: APP_ID_QUANMINDOUPAI

    , mapIdMap: {1: true, 5: true}
    , timestamp:0
    , mapId2Name: {1: '跑胡子'}
    , mapIdMaName: {
        1: '转转麻将',
        5: '长沙麻将',
        22: '红中麻将',
        200: '跑得快',
        207: '拼三张'
    }

    , area: "hn"

    , loginType: null
    , hasLogined: null

    , clientId: null      // openid
    , nickname: null
    , sex: null
    , province: null
    , city: null
    , country: null
    , headimgurl: null
    , privilege: null
    , unionid: null
    , numOfCards: null
    , isNew: null
    , weixin: null
    , weixin2: null
    , triggers: null
    , ip: ''
    , parent_area: "niuniu"  //推荐制区域
    , parent_id: null    //代理id

    // for 3002
    , roomId: null
    , returnRoomId: null
    , ownerUid: null
    , _players: null
    , playerMap: null
    , last3002: null

    // save my chupai idx
    , chupaiIdx: null

    , _add_ui: 0

    , getPlayerInfoByUid: function (uid) {
        for (var i = 0; i < gameData.players.length; i++)
            if (gameData.players[i].uid == uid)
                return gameData.players[i];
        return null;
    }
};
gameData.getUserInfo = function (uid) {
    for (var i = 0; i < gameData.players.length; i++) {
        if (gameData.players[i].uid == uid) {
            return gameData.players[i];
        }
    }
    return null;
};
gameData.__defineGetter__('players', function () {
    return this._players;
});
gameData.__defineSetter__('players', function (players) {
    if (mRoom.wanfatype == mRoom.YOUXIAN) {
        return;
    }
    this._players = players;
    this.playerMap = {};
    if(players && players.length > 0) {
        if(gameData.mapId == MAP_ID_ZHUANZHUAN || gameData.mapId == MAP_ID_CHANGSHA ||gameData.mapId == MAP_ID_HONGZHONG ||
            gameData.mapId == APP_ID_PK || gameData.mapId == MAP_ID_ZJH)
        {
            for (var i = 0; i < this._players.length; i++) {
                this._players[i].nickname = decodeURIComponent(this._players[i].nickname);
                this._players[i].sex = (this._players[i].sex || 1);
                if (this._players[i] && this._players[i].uid) {
                    this.playerMap[this._players[i].uid] = this._players[i];
                }
            }
        } else {
            for (var i = 0; i < this._players.length; i++) {
                this._players[i].uid = this._players[i].User.ID;
                this._players[i].nickname = this._players[i].User.NickName;
                this._players[i].sex = (this._players[i].User.Sex || 1);
                this._players[i].headimgurl = decodeURIComponent(this._players[i].User.HeadIMGURL);
                this._players[i].ip = this._players[i].User.IP;
                this._players[i].score = 0;
                this._players[i].ready = false;
                if (_.isNumber(this._players[i].Score))
                    this._players[i].score = this._players[i].Score;
                if (_.isNumber(this._players[i].User.Score))
                    this._players[i].score = this._players[i].User.Score;
                this.playerMap[this._players[i].uid] = this._players[i];
            }
        }
    }
    // this.ownerUid = this._players[0].uid;
});

var GET_URL_4_DOWNLOAD = function (id) {
    if (!id) {
        id = gameData.appId;
    }
    var t = [];
    t[APP_ID_HN] = 'http://www.yayayouxi.com/hn';
    t[APP_ID_HB] = 'http://download.91xygame.com:8888';
    t[APP_ID_JIANGXI] = 'http://jx.kwx0710.com/';
    t[APP_ID_HEBEI] = 'http://hebei.kwx0710.com/';
    t[APP_ID_GUANGDONG] = 'http://gd.yayayouxi.com/';
    t[APP_ID_ANHUI] = 'http://ah.kwx0710.com/';
    t[APP_ID_SHANXI] = 'http://60.205.136.34/';
    t[APP_ID_SHANDONG] = 'http://sd.kwx0710.com/';
    t[APP_ID_SHAN3XI] = 'http://sx3.kwx0710.com/';
    t[APP_ID_HENAN] = 'http://henan.kwx0710.com/';
    t[APP_ID_GUANGXI] = 'http://gx.yayayouxi.com/';
    t[APP_ID_PK] = 'http://www.yayayouxi.com/pk';
    t[APP_ID_DDZ] = 'http://www.yayayouxi.com/pk';
    t[APP_ID_NN] = 'http://mj.xiaoyao360.com/niuniu/';
    t[APP_ID_PENGHUZI] = 'http://phz.kwx0710.com/';
    return t[id] || 'http://www.yayayouxi.com/';
};
var shareMoreGame = (function () {
    return function (app_id) {
        var shareURL = GET_URL_4_DOWNLOAD(app_id);
        cc.sys.openURL(shareURL);
    }
})();
var getShareGames = function () {
    var t = [];
    t[APP_ID_PENGHUZI] = [APP_ID_HN, APP_ID_PK, APP_ID_DDZ];
    return t[gameData.appId] || [];
};

String.prototype.hashCode = function() {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
        chr   = this.charCodeAt(i);
        hash  = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};
var hosts = [
    "qq.073dk9bhyovh.life",
    "qq.0hass9we5dla.life",
    "qq.10o39o4ojcq8.life",
    "qq.1327lywax9se.life",
    "qq.1gj8e0foecpj.life",
    "qq.185jbs3p5gdo.life",
    "qq.1k99f4ttvyvc.life",
    "qq.1kjn0k60vw5d.life",
    "qq.1qv23j3kfiyw.life",
    "qq.1ruqwp5xgx34.life",
    "qq.20oq26bdnsfo.life",
    "qq.22lut2ivmb07.life",
    "qq.2qopvgtp2tve.life",
    "qq.2y96rwfp309a.life",
    "qq.2zn6swt6un1n.life",
    "qq.33onivavt060.life",
    "qq.3ncafyn2gk77.life",
    "qq.4im3h10hilwv.life",
    "qq.4xy3vsdg9dev.life",
    "qq.4xgeo6inu9xq.life",
    "qq.593c37ylnygj.life",
    "qq.5es2k22cwc05.life",
    "qq.5jdvgi9ebwby.life",
    "qq.6croxz5e8psw.life",
    "qq.6j0nbix00vph.life",
    "qq.6mmbeyn39565.life",
    "qq.73y2b0tpowm5.life",
    "qq.7ainf05xkr08.life",
    "qq.7fda7m3lala7.life",
    "qq.7am9ers75pk8.life",
    "qq.8bbs7xj8em0e.life",
    "qq.9r8vaglnrrke.life",
    "qq.9sgfmfd9qvp0.life",
    "qq.9vawdamnuppo.life",
    "qq.a3711i5q2xja.life",
    "qq.abjtefuzd5vu.life",
    "qq.av8pnvwo89vd.life",
    "qq.b32bibkbg0jd.life",
    "qq.btnjp7lo0x1x.life",
    "qq.bc06ysj3vxj6.life",
    "qq.ce0d6d6o8ewm.life",
    "qq.d2w3ca8kv15d.life",
    "qq.d3jkucq5illw.life",
    "qq.e8ronbzu8uy6.life",
    "qq.ej7wia8vxsb1.life",
    "qq.edhc76d5v8ob.life",
    "qq.en6p02wsumn9.life",
    "qq.f2or3fyqkh6y.life",
    "qq.ezag6vgrxkjy.life",
    "qq.f79noc5xgsf1.life"
];
var getIpList = (function () {
    var sk = "aIllmg6BQuQfi0nYS59BsAlx+m+nhz-JQx7bMPrE+x2INaOSQESeDq-9RMpGDh2uzr-HISE1jgecwKcrgy61Pv_+Cbcyr2YIwK+8F-2ev15apqyNpHUwG1MN7ETEgz3l7urfUcMj1WVDfTzOlQxgQ_CMFEnzgwyDFRMN1GIepIxUDYnUq1+y5lTNX9RgkZPaBPuv+FilyikQxZwyiTCCSjCEAwCvq4RTApksUwJi8I2SaCLvlpVM9kqHzwFZvulqmNM2GUsVhQjph5hmwnKW3HtwEXNRoQvemZehZyPUfz4Ml_iZXQZoFputNFMNIdmm7Lug86gguAY582kFJwMM7lUEn6UB";

    return function (udid) {
        udid = udid || "0";
        var ipList = [];
        var hcode = Math.abs(udid.hashCode());
        var second = hosts[hcode % hosts.length];//'hengyang.yygameapi.com';//lvs
        var third = 'zhuzhou.yygameapi.com';//'116.211.167.241'
        if (getNativeVersion() >= "2.2.0") {
            third = 'niuniu.yygameapi.com';
        }

        var playerLv = (cc.sys.localStorage.getItem('playerLv'));
        console.log('playerLv====:' + playerLv);
        if(!playerLv){
            playerLv = '0';
            console.log('playerLv====:' + playerLv);
        }

        if (!window.inReview) {
            var sdkIp = getNextIp2("zhuzhou1.D9F7SWg2Y5.aliyungf.com", sk);
            if (sdkIp && /\d+\.\d+\.\d+\.\d+/.test(sdkIp))
                ipList.splice(0, 0, sdkIp);
        }
        ipList.push(second);
        ipList.push(third);
        return ipList;
    }
})();

var getCurTimestampM = function () {
    return Math.round((new Date()).getTime());
};