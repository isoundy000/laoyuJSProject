var ChatNotSendNode = {
    init:function () {


        return true;
    },

    /** @returns ChatNotSendNode */
    getCom: function (p, name) {return getCom(p, name, this);}
};