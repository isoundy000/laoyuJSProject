/**
 * Created by dbz on 2017/6/23.
 */
(function () {
    var exports = this;

    var  $ = null;

    var VerifyLayer = cc.Layer.extend({
        onEnter : function(){
            cc.Layer.prototype.onEnter.call(this);
        },
        ctor : function (parent){
            this._super();
            var that = this;
            var size = cc.winSize;

            var scene = ccs.load(res.verify_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            var panelOriPos = $('Panel_1.bg').getPosition();
            var panelnewPos = cc.p(panelOriPos.x, panelOriPos.y + cc.winSize.height / 2);

            TouchUtils.setOnclickListener($('Panel_1.bg.btn_back'), function () {
                that.removeFromParent(true);
            });

            TouchUtils.setOnclickListener($('Panel_1.bg.btn_cancel'), function () {
                that.removeFromParent(true);
            });

            var txtXing = $('Panel_1.bg.TextField_1');
            var txtMing = $('Panel_1.bg.TextField_2');

            TouchUtils.setOnclickListener($('Panel_1.bg.btn_sure'), function () {
                var xingming = txtXing.getString();
                var shenfenzheng = txtMing.getString();

                if(!(/^[\u4e00-\u9fa5]+$/.test(xingming))){
                    $('Panel_1.bg.tishiBg.Text_3').setString('姓名填写错误,请重新填写');
                    $('Panel_1.bg.tishiBg').setVisible(true);
                    $('Panel_1.bg.tishiBg').runAction(cc.sequence(cc.delayTime(1), cc.callFunc(function () {
                        $('Panel_1.bg.tishiBg').setVisible(false);
                    })));
                    return;
                }

                if(!(that.isNumberOrCharacter(shenfenzheng))){
                    $('Panel_1.bg.tishiBg.Text_3').setString('身份证填写错误,请重新填写');
                    $('Panel_1.bg.tishiBg').setVisible(true);
                    $('Panel_1.bg.tishiBg').runAction(cc.sequence(cc.delayTime(1), cc.callFunc(function () {
                        $('Panel_1.bg.tishiBg').setVisible(false);
                    })));
                    return;
                }

                //network.send(2008, {real_name: xingming, identity_card_id: shenfenzheng});
                var reqPara = {real_name: xingming, identity_card_id: shenfenzheng, unionid:gameData.unionid};
                var timestamp = new Date().getTime();
                reqPara.time = timestamp;
                var uir = '/yxAuth/Auth?time=' + timestamp;
                var paramd5 = Crypto.MD5("request:" + uir);
                reqPara.sign = paramd5;
                var uir = '/yxAuth/Auth?time=' + timestamp + '&sign=' + paramd5;
                DC.httpPost(uir, reqPara, function (response) {
                    var respJson = JSON.parse(response);
                    if (respJson.result == 0) {
                        alert1('认证成功', function () {
                            gameData.real_name = respJson.real_name;
                            gameData.identity_card_id = respJson.identity_card_id;
                            parent.setYanzheng(false);
                            that.removeFromParent(true);
                        });
                    }
                }, false, DC.httpHost2, function (response) {
                    alert1('验证失败,请重试！');
                });
            });

            txtXing.addEventListener(function (textField, type) {
                var xingming = txtXing.getString();
                switch (type) {
                    case ccui.TextField.EVENT_ATTACH_WITH_IME:
                        cc.log("attach with IME");
                        break;
                    case ccui.TextField.EVENT_DETACH_WITH_IME:
                        cc.log("detach with IME");
                        if(xingming.length == 0){
                            $('Panel_1.bg.detach_0').setVisible(false);
                            $('Panel_1.bg.detach_0_0').setVisible(false);
                            break
                        }

                        if(/^[\u4e00-\u9fa5]+$/.test(xingming)){
                            $('Panel_1.bg.detach_0').setVisible(true);
                            $('Panel_1.bg.detach_0_0').setVisible(false);
                        }else{
                            $('Panel_1.bg.detach_0').setVisible(false);
                            $('Panel_1.bg.detach_0_0').setVisible(true);
                        }
                        break;
                    case ccui.TextField.EVENT_INSERT_TEXT:
                        cc.log("insert words");
                        break;
                    case ccui.TextField.EVENT_DELETE_BACKWARD:
                        cc.log("delete word");
                        if(/^[\u4e00-\u9fa5]+$/.test(xingming) && xingming.length > 0){
                            $('Panel_1.bg.detach_0').setVisible(true);
                            $('Panel_1.bg.detach_0_0').setVisible(false);
                        }else{
                            $('Panel_1.bg.detach_0').setVisible(false);
                            $('Panel_1.bg.detach_0_0').setVisible(true);
                        }
                        break;
                    default:
                        break;
                }
            }, this);

            txtMing.addEventListener(function (textField, type) {
                var shenfenzheng = txtMing.getString();
                switch (type) {
                    case ccui.TextField.EVENT_ATTACH_WITH_IME:
                        $('Panel_1.bg').setPosition(panelnewPos);
                        cc.log("attach with IME");
                        break;
                    case ccui.TextField.EVENT_DETACH_WITH_IME:
                        $('Panel_1.bg').setPosition(panelOriPos);
                        cc.log("detach with IME");
                        if(shenfenzheng.length == 0){
                            $('Panel_1.bg.detach_1').setVisible(false);
                            $('Panel_1.bg.detach_1_1').setVisible(false);
                            break;
                        }

                        if(that.isNumberOrCharacter(shenfenzheng) && shenfenzheng.length == 18){
                            $('Panel_1.bg.detach_1').setVisible(true);
                            $('Panel_1.bg.detach_1_1').setVisible(false);
                        }else{
                            $('Panel_1.bg.detach_1').setVisible(false);
                            $('Panel_1.bg.detach_1_1').setVisible(true);
                        }
                        break;
                    case ccui.TextField.EVENT_INSERT_TEXT:
                        cc.log("insert words");
                        break;
                    case ccui.TextField.EVENT_DELETE_BACKWARD:
                        cc.log("delete word");
                        if(that.isNumberOrCharacter(shenfenzheng) && shenfenzheng.length == 18){
                            $('Panel_1.bg.detach_1').setVisible(true);
                            $('Panel_1.bg.detach_1_1').setVisible(false);
                        }else{
                            $('Panel_1.bg.detach_1').setVisible(false);
                            $('Panel_1.bg.detach_1_1').setVisible(true);
                        }
                        break;
                    default:
                        break;
                }
            }, this);

            // network.addListener(2008, function (data) {
            //     if(data.success){
            //         alert1('认证成功', function () {
            //             gameData.hasShiMing = true;
            //             MainLayer.setYanzheng(true);
            //             that.removeFromParent(true);
            //         });
            //     }else{
            //         alert1('验证失败,请重试！');
            //     }
            // });
        },

        isNumberOrCharacter: function(_string) {

            var charecterCount = 0;
            for(var i=0; i < _string.length; i++){
                var character = _string.substr(i,1);
                var temp = character.charCodeAt();
                if (48 <= temp && temp <= 57){

                }else if(temp == 88){

                    charecterCount += 1;
                }else if(temp == 120){

                    charecterCount += 1;
                }else{
                    return false;
                }
            }
            if(charecterCount <= 1){
                return true
            }
        }
    });

    exports.VerifyLayer = VerifyLayer;

})(window);