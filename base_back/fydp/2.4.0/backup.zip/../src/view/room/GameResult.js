var GameResult = {
    init:function () {
        var that = this;
        this.btBack = getUI(this, "btBack");

        this.close = getUI(this, "close");
        this.close.addTouchEventListener(this.onClose, this);
        this.share = getUI(this, "share");
        this.share.addTouchEventListener(this.onShare, this);
        this.penghuzibtn = getUI(this, "penghuzibtn");
        this.penghuzibtn.addTouchEventListener(this.onPenghuziDetail, this);
        this.roomid = getUI(this, "roomid");
        this.time = getUI(this, "time");

        this.nCombos = getUI(this, "nCombos");
        this.twin = getUI(this, "twin");

        this.kuang2 = getUI(this, "kuang2");
        this.kuang2_ly = getUI(this, "kuang2_ly");
        this.kuang2_sy = getUI(this, "kuang2_sy");
        this.zhx_ly = getUI(this, "zhx_ly");
        this.thx_ly = getUI(this, "thx_ly");
        this.xingcard = getUI(this, "xingcard");
        this.xingcount = getUI(this, "xingcount");

        this.n0 = getUI(this, "n0");
        this.n1 = getUI(this, "n1");
        this.n2 = getUI(this, "n2");
        this.n3 = getUI(this, "n3");

        this.nHu = getUI(this, "nHu");

        //关闭按钮 5秒后 才可以点击
        this.leftSecond = 3;
        this.closelabel = getUI(this.btBack, "closelabel");
        that.closelabel.setString("关闭");
        TouchUtils.setOnclickListener(that.btBack, function (node) {
            that.room.showRoomClean();
            that.room.showReadyJiesuan(true);
            that.removeFromParent();
        });

        // TouchFilter.grayScale(this.btBack);
        // this.schedule(function () {
        //     that.leftSecond--;
        //     if(that.leftSecond == 0){
        //         TouchFilter.remove(that.btBack);
        //         that.closelabel.setString("关闭");
        //         TouchUtils.setOnclickListener(that.btBack, function (node) {
        //             if(that.leftSecond > 0) return;
        //             that.room.showRoomClean();
        //             that.room.showReadyJiesuan(true);
        //             that.removeFromParent();
        //         });
        //     }else if(that.leftSecond > 0){
        //         that.closelabel.setString(that.leftSecond + "秒后关闭");
        //     }
        // }, 1);
        this.penghuzibtn.setVisible((mRoom.wanfatype == mRoom.YOUXIAN) ? true:false);
        return true;
    },

    setRoom:function(room, huInfo, gameOverData, isReplay){
        this.room = room;
        this.huInfo = huInfo;
        this.gameOverData = gameOverData;
        this.isReplay = isReplay;
        // console.log(huInfo);

        this.time.setString(this.gameOverData.EndTime);
        this.roomid.setString("房号:" + mRoom.roomId + " 局数:" + mRoom.getRound(mRoom.curRound));

        this.setData();
    },

    setData:function(){
        this.index = 0;

        var titleImg = "";
        var isHuang = false;
        playEffect('getw');
        if(this.huInfo != null){
            this.winCards = [];
            var comListArray = [];
            if(this.huInfo.openList) {
                for (var i=0;i<this.huInfo.openList.length;i++) {
                    comListArray.push(this.huInfo.openList[i])
                }
            }
            if(this.huInfo.kanList) {
                for (var i=0;i<this.huInfo.kanList.length;i++) {
                    comListArray.push(this.huInfo.kanList[i])
                }
            }
            if(this.huInfo.huList) {
                if(mRoom.wanfatype == mRoom.WEIMAQUE){
                    for(var s=0;s<this.huInfo.huList.length;s++){
                        //偎麻雀
                        var onelist = this.huInfo.huList[s];
                        if(onelist.typ == 12 && onelist.cards.length > 4){
                            var t = {typ:12};
                            t.cards = [];
                            for (var i = 0; i < onelist.cards.length; i++) {
                                if(onelist.cards[i]) {
                                    t['cards'].push(onelist.cards[i]);
                                    if (t.cards.length == 3 || i == onelist.cards.length - 1) {
                                        comListArray.push(t);
                                        t = {typ:12};
                                        t['cards'] = [];
                                    }
                                }
                            }
                        }else{
                            comListArray.push(onelist);
                        }
                    }
                }else{
                    for (var i = 0; i < this.huInfo.huList.length; i++) {
                        comListArray.push(this.huInfo.huList[i])
                    }
                }
            }
            // this.addComboList(this.huInfo.openList);
            // this.addComboList(this.huInfo.kanList);
            this.addComboList(comListArray);

            if (this.winCards && this.winCards.length > 0){
                for(var s=this.winCards.length-1;s>=0;s--){
                    var card = this.winCards[s];
                    if (this.gameOverData.ByCard && this.gameOverData.ByCard == card.data){
                        var huicon = new cc.Sprite('res/image/ui/card/back.png');
                        huicon.setAnchorPoint(cc.p(0.5, 0.5));
                        huicon.setPosition(cc.p(card.getContentSize().width/2, card.getContentSize().height/2));
                        huicon.setOpacity(160);
                        card.addChild(huicon, 2);
                        break;
                    }
                }
            }
            if(this.gameOverData.Winner == gameData.uid){
                titleImg = "twin.png";
            }else{
                titleImg = "tlose.png";
            }
        }else{
            titleImg = "thuang.png";
            isHuang = true;
        }

        this.twin.setTexture("res/image/ui/result/" + titleImg);

        if(mRoom.getPlayerNum() == 3){
            for(var i=0;i<3;i++){
                var n = this["n" + i];
                n.setPosition(cc.p(-540, 385 - i*170));
                n.setScale(0.95);
            }
            this.n3.setVisible(false);
        }
        for(var i=0;i<this.gameOverData.Users.length;i++){
            var gr = this.gameOverData.Users[i];
            this.setPlayerInfo(i + 1, gr, this.gameOverData.Winner, isHuang);
        }

        if(mRoom.wanfatype == mRoom.LEIYANG) {
            //耒阳
            this.kuang2_ly.setVisible(true);
            this.kuang2.setVisible(false);
            this.kuang2_sy.setVisible(false);
            this.zhx_ly.setVisible(true);
            this.thx_ly.setVisible(true);
            this.zhx_ly.setString(this.gameOverData.WinnerXi);
            for (var i = 0; i < this.gameOverData.Users.length; i++) {
                var gr = this.gameOverData.Users[i];
                var pos = mRoom.getUserPosIndex(gr.UserID);
                var name = getUI(this.kuang2_ly, "name_" + (pos));
                var scoreS = getUI(this.kuang2_ly, "score_" + (pos));
                var scoreB = getUI(this.kuang2_ly, "score_b" + (pos));
                name.setString(ellipsisStr(gr.UserName, 7));
                scoreS.setString(gr.SmallTiLong || 0);
                scoreB.setString(gr.BigTiLong || 0);
            }
            for (var i = 0; i < 3; i++) {
                var n = this["n" + i];
                var t = getUI(n, "t" + i);
                t.setString("得分:");
            }
        }else if(mRoom.wanfatype == mRoom.SHAOYANGBOPI) {
            //邵阳剥皮
            this.kuang2_ly.setVisible(false);
            this.kuang2.setVisible(false);
            this.kuang2_sy.setVisible(true);
            this.zhx_ly.setVisible(false);
            this.thx_ly.setVisible(false);
            for (var i = 0; i < this.gameOverData.Users.length; i++) {
                var gr = this.gameOverData.Users[i];
                var pos = mRoom.getUserPosIndex(gr.UserID);
                var name = getUI(this.kuang2_sy, "name" + (pos));
                var scoreS = getUI(this.kuang2_sy, "score" + (pos));
                name.setString(ellipsisStr(gr.UserName, 7));
                var score = mRoom.scoreInfo[gr.UserID] || 0;
                scoreS.setString(score || 0);
            }
        }else if(mRoom.wanfatype == mRoom.YOUXIAN) {
            this.kuang2_ly.setVisible(false);
            this.kuang2.setVisible(false);
            this.kuang2_sy.setVisible(false);
            this.zhx_ly.setVisible(false);
            this.thx_ly.setVisible(false);
        }else if(mRoom.wanfatype == mRoom.GUILIN){
            // console.log(this.gameOverData);
            this.kuang2_ly.setVisible(false);
            this.kuang2.setVisible(false);
            this.kuang2_sy.setVisible(false);
            this.thx_ly.setVisible(true);
            this.thx_ly.setTexture("res/image/ui/result/thx.png");
            this.zhx_ly.setVisible(true);
            this.zhx_ly.setString(this.gameOverData.WinnerXi);
            if(this.gameOverData.XingCard && this.gameOverData.XingCard > 0) {
                this.xingcard.setVisible(true);
                var cardimg = "res/image/ui/card/dx" + (this.gameOverData.XingCard) + ".png";
                if(this.gameOverData.XingCard > 10)
                    cardimg = "res/image/ui/card/dd" + (this.gameOverData.XingCard - 10) + ".png";
                var action = cc.sequence(
                    cc.scaleTo(0.5, -0.8, 0.8)
                    , cc.callFunc(function (card) {
                        card.setTexture(cardimg);
                        card.setFlippedX(true);
                    })
                );
                this.xingcard.runAction(action);

                this.xingcount.setVisible(true);
                this.xingcount.setString(this.gameOverData.XingCount + "醒");
            }
        }else{
            this.txt1 = getUI(this.kuang2, "txt1");
            this.txt2 = getUI(this.kuang2, "txt2");
            this.txt3 = getUI(this.kuang2, "txt3");
            this.t1 = getUI(this.kuang2, "t1");
            this.t2 = getUI(this.kuang2, "t2");
            this.t3 = getUI(this.kuang2, "t3");

            this.kuang2_ly.setVisible(false);
            this.kuang2.setVisible(true);
            this.kuang2_sy.setVisible(false);
            this.zhx_ly.setVisible(false);
            this.thx_ly.setVisible(false);
            if(mRoom.wanfatype == mRoom.FANGPAOFA ||
                mRoom.wanfatype == mRoom.XIANGXIANG) {
                this.t1.setTexture("res/image/ui/result/hx.png");
                this.t2.setTexture("res/image/ui/result/tfan.png");
                this.t3.setTexture("res/image/ui/result/thx.png");
                this.txt1.setString(this.gameOverData.WinnerXi);
                this.txt2.setString(this.gameOverData.WinnerFan);
                this.txt3.setString(this.gameOverData.WinnerJi);
            }else if(mRoom.wanfatype == mRoom.CHENZHOU) {
                //tunshu
                this.t1.setTexture("res/image/ui/result/hx.png");
                this.t2.setTexture("res/image/ui/result/tfan.png");
                this.t3.setTexture("res/image/ui/result/tunshu.png");
                this.txt1.setString(this.gameOverData.WinnerXi);
                this.txt2.setString(this.gameOverData.WinnerFan);
                this.txt3.setString(this.gameOverData.WinnerJi);
            }else if(mRoom.wanfatype == mRoom.HENGDONG) {
                //衡东  蚂蚁上树只显示胡息
                this.t1.setTexture("res/image/ui/result/hx.png");
                this.t2.setTexture("res/image/ui/result/tfan.png");
                this.t3.setTexture("res/image/ui/result/tji.png");
                this.txt1.setString(this.gameOverData.WinnerXi);
                this.txt2.setString(this.gameOverData.WinnerFan);
                this.txt3.setString(this.gameOverData.WinnerJi);
                this.t2.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                this.t3.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                this.txt2.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
                this.txt3.setVisible(!(mRoom.subWanfa == 'mayishangshu'));
            }else if(mRoom.wanfatype == mRoom.WEIMAQUE){
                this.t1.setTexture("res/image/ui/result/tyingxi.png");
                this.t2.setTexture("res/image/ui/result/tzongxi.png");
                this.t3.setVisible(false);
                this.txt1.setString(this.gameOverData.WinnerXi);
                this.txt2.setString(this.gameOverData.WinnerJi);
                this.txt3.setVisible(false);
            }else{
                //全名堂   胡   番数  级数
                this.t1.setTexture("res/image/ui/result/hx.png");
                this.t2.setTexture("res/image/ui/result/tfan.png");
                this.t3.setTexture("res/image/ui/result/tji.png");
                this.txt1.setString(this.gameOverData.WinnerXi);
                this.txt2.setString(this.gameOverData.WinnerFan);
                this.txt3.setString(this.gameOverData.WinnerJi);
            }
            //长沙显示分数,不是胡息
            for (var i = 0; i < 3; i++) {
                var n = this["n" + i];
                var t = getUI(n, "t" + i);
                t.setString("分数:");
            }
        }
        this.setHuInfo(this.gameOverData.FanFlag, this.gameOverData.FanFlag2);

        var kuang3 = getUI(this, 'kuang3');
        var kuang4 = getUI(this, 'kuang4');
        if(mRoom.wanfatype == mRoom.YOUXIAN || mRoom.wanfatype == mRoom.GUILIN){
            kuang3.setVisible(false);
            kuang4.setVisible(true);
            for(var i=0;i<this.gameOverData.LeftCards.length;i++){
                var card = HUD.showLayer(HUD_LIST.Card, kuang4);
                card.setData(this.gameOverData.LeftCards[i], null, 2);
                card.setPosition(cc.p(-10 + 52 * (i%15), 30 - 50*(Math.floor(i/15))));
            }
        }else{
            kuang3.setVisible(true);
            kuang4.setVisible(false);
            for(var i=0;i<this.gameOverData.LeftCards.length;i++){
                var card = HUD.showLayer(HUD_LIST.Card, kuang3);
                card.setData(this.gameOverData.LeftCards[i], null, 2);
                card.setPosition(cc.p(-10 + 44 * (i%12), 30 - 50*(Math.floor(i/12))));
            }
        }

        //回放
        if (this.isReplay) {
            this.btBack.setVisible(false);
            this.close.setVisible(true);
        }else{
            this.btBack.setVisible(true);
            this.close.setVisible(false);
        }
    },

    setPlayerInfo:function(index, gr, winner, isHuang){
        var pos = mRoom.getUserPosIndex(gr.UserID);
        var n = this["n" + pos];
        var txtUserName = getUI(n, "txtUserName");
        var txtUserId = getUI(n, "txtUserId");
        var txtScore = getUI(n, "txtScore");
        var dianpao = getUI(n, "dianpao");
        var t = getUI(n, "t" + pos);

        if(mRoom.wanfatype == mRoom.GUILIN){
            t.setString("总舵数:");
        }
        //点炮
        // console.log(this.gameOverData);
        if (this.gameOverData.ByWho && this.gameOverData.ByWho != null && this.gameOverData.ByWho == gr.UserID){
            dianpao.setVisible(true);
        }
        //赢家
        if (this.gameOverData.Winner && this.gameOverData.Winner != null && this.gameOverData.Winner == gr.UserID){
            dianpao.setVisible(true);
            dianpao.setTexture("res/image/ui/roomclean/hu.png");
        }
        //头像
        var avatorbg = getUI(n, "head");
        var avator = avatorbg.getChildByName("avator");
        if (avator == null) {
            avator = new cc.Sprite('res/image/ui/transparent/transparent_97x99.png');
            avator.setPosition(avatorbg.getContentSize().width / 2, avatorbg.getContentSize().height / 2);
            avator.setScale(0.9);
            avator.setName('avator');
            avatorbg.addChild(avator, -1);
        }
        var url = (mRoom.getUserByUserId(gr.UserID) == null ? null : mRoom.getUserByUserId(gr.UserID).HeadIMGURL);
        url = decodeURIComponent(url);
        if (url == undefined || (url.length == 0)) url = 'res/image/defaultHead.jpg';
        loadImageToSprite(url, avator);//头像

        txtUserName.setString(gr.UserName);
        txtUserId.setString(gr.UserID);
        if(gr.Result) {
            if (gr.Result > 0)
                txtScore.setString("+" + gr.Result);
            else
                txtScore.setString(gr.Result);
        }else{
            txtScore.setString("0");
        }
        var score = mRoom.scoreInfo[gr.UserID] || 0;
        // mRoom.scoreInfo[gr.UserID] = score + gr.Result + 0;
        mRoom.scoreInfo[gr.UserID] = gr.Score;

        var win = getUI(n, "win");
        if(gr.Result > 0){
            win.setTexture('res/image/ui/result/win.png');
        }else if(gr.Result == 0) {
            win.setTexture('res/image/ui/result/ping.png');
        }else{
            win.setTexture('res/image/ui/result/lose.png');
        }
        //显示得分
        this.room.updateScore(pos);
    },

    setHuInfo:function(flag, flag2){
        var index = 0;
        var imgs = ["h_hong2", "h_hei2", "h_zimo", "h_tian2", "h_di2", "h_yidian", "h_hw", "h_ddh", "h_wudh"];
        var fans = ["", "", "", "", "", "", "", "", ""];
        if(mRoom.isallmt == true){  //全名堂
            var info = mCard.getHuCardCountInfo(this.huInfo);
            var big = info.big;
            var small = info.small;
            var red = info.red;

            imgs = ["h_hong2", "h_zdh", "h_jdh", "h_hw", "h_wh", "h_ddh", "h_big", "h_small",
                "h_hdh", "h_zimo", "h_tian2", "h_di2", "h_myjh"];
            //海底胡	玩家所胡的牌是墩中最后的一只牌（平胡加1番，名堂胡加2番）
            var isPingHu = true;
            for(var i=0;i<imgs.length;i++){
                var isOk = mAction.checkOpen(flag, 1<<i);
                if(isOk && i < 8) {
                    isPingHu = false;
                    break;
                }
            }
            var hdx_fan = 2;

            fans = ["", "", "", "", "", "", "", "", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.FANGPAOFA){
            // 一点红 0x1 1
            // 自摸 0x2  2
            // 一块匾 0x4  4
            // 乌胡 0x8  8
            // 海底胡 0x10   16
            // 红胡 0x20   32
            // 卡胡 0x40   64
            // 天胡 0x80    128
            // 地胡 0x100   256
            // 10红 0x200 10红  512
            imgs = ["h_yidian", "h_zimo", "h_bian", "h_wh", "h_hdh", "h_hong2",
                "h_ka", "h_tian2", "h_di2", "h_shi"];
            fans = ['', '', '', '', '', '', '', '', '', ''];
        }
        //天地红黑  无全名堂
        if(mRoom.subWanfa != undefined && (mRoom.subWanfa == 'tiandihonghei' || mRoom.subWanfa == 'wumingtang')){
            imgs = ["h_hong2", "h_hei2", "h_zimo", "h_tian2", "h_di2"];
            // fans = [2, 2, 1, 2, 2];
            fans = ["", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.LEIYANG){
            // 1		2		4		8 		16		32     64   128     256
            // 红胡		黑胡		无胡		卡胡		天胡		举手   自摸   一点红  地胡
            imgs = ["h_hong2", "h_hei2", "h_wuh", "h_ka", "h_tian2", "h_jz", "h_zimo", "h_yidian", "h_di2"];
            fans = ["", "", "", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.CHANGSHA){
            // 红胡		点胡		红乌		黑胡		天胡		地胡		对对胡		大胡		小胡
            // 1		2		4		8		16		32		64			128		256
            // 十红		一点红	十八小	十八大	二比		三比		四比		双飘		海底胡  自摸
            // 512		1024	2048	4096	8192	16384	32768	65536	131072  262144
            imgs = ["h_hong2", "h_dianh", "h_wh", "h_hei2", "h_tian2", "h_di2", "h_ddh", "h_dah", "h_xiaoh",
                "h_shi", "h_yidian", "h_small", "h_big", "h_ebh", "h_sbh", "h_sibh", "h_sph", "h_hdh", "h_zimo"];
            fans = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.SHAOYANG){
            imgs = ["h_hong2", "h_hei2", "h_tian2", "h_di2"];
            fans = ["", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.SHAOYANGBOPI){
            //天胡 地胡 自摸 中庄
            imgs = ["h_tian2", "h_di2", "h_zimo", "h_zhh"];
            fans = ["+10", "+10", "+10", ""];
        }
        if(mRoom.wanfatype == mRoom.HONGGUAIWAN){
            //天湖	地胡		点胡		红胡		乌胡		碰碰胡		十八大		十六小		海底胡	自摸
            //1		2		4		8		16		 32			64			128			256		512
            imgs = ["h_tian2", "h_di2", "h_dianh", "h_hong2", "h_wh", "h_pph", "h_big", "h_small", "h_hdh", "h_zimo"];
            fans = ["", "", "", "", "", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.XIANGXIANG){
            // 自摸	黑胡	红乌	红胡	 30胡	30红 	天胡 	地胡
            // 1	2	4	8	 16	     32	    64	    128
            imgs = ["h_zimo", "h_hei2", "h_wh", "h_hong2", "h_30huh", "h_30hongh", "h_tian2", "h_di2"];
            fans = ["", "", "", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.YOUXIAN) {
            //天胡  地胡  中庄 跑双 双龙 7对 五福  "" ""  "" 连中(X1)
            // 1     2    4    8  16   32  64 128 256 512 1024 2048
            imgs = ["h_tian2", "h_di2", "h_zhh", "h_psh", "h_slh", "h_qdh", "h_wfh", "", "", "",
                "h_lzh2", "h_lzh3", "h_lzh4", "h_lzh5","h_lzh6", "h_lzh7", "h_lzh8", "h_lzh9","h_lzh10"];
            fans = ["", "", "", "", "", "", "", "", "", "",
                "", "", "", "","", "", "", "",""];
        }
        if(mRoom.wanfatype == mRoom.GUILIN) {
            //天胡  地胡  自摸
            // 1     2    4    8
            imgs = ["h_tian2", "h_di2", "h_zimo", ""];
            fans = ["", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.CHENZHOU || mRoom.wanfatype == mRoom.MAOHUZI) {
            //天胡 自摸  红胡 黑胡 毛胡
            //1     2    4    8   16
            imgs = ["h_tian2", "h_zimo", "h_hong2", "h_hei2", "h_maoh"];
            fans = ["", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.HENGYANG){
            //自摸，大红，小红，一点红，黑胡
            //1 ，  2，   4，    8，   16
            imgs = ["h_zimo", "h_dahong", "h_xiaohong", "h_yidian", "h_hei2"];
            fans = ["", "", "", "", ""];
        }
        if(mRoom.subWanfa == 'bashifan'){
            //     自摸 红胡 真点胡  乌胡  对对胡  大 小  听胡  天胡  地胡  耍猴  海底  大团圆  行行息  背靠背  魅一级
            //1 ，  2，  4，   8，   16    32   64 128 256   512  1024 2048 4096 8192   16384   32768  65536
            //多黄单番 一黄一番  两黄两番  三黄三番  多黄多番
            //131072   261072
            imgs = ["", "h_zimo", "h_hong2", "h_zdh", "h_wh", "h_ddh", "h_dah", "h_xiaoh", "h_th",
            "h_tian2", "h_di2", "h_sh", "h_hdh", "h_dty", "h_xxx", "h_bkb", "h_myjh",
                "h_dhdf", "h_yhyf", "h_lhlf", "h_shsf", "h_dhdf2"];
            fans = ["", "", "", "", "", "","", "", "", "", "", "", "", "", "", "","", "", "", "", "", ""];
        }
        if(mRoom.wanfatype == mRoom.HENGDONG){
            //自摸，天胡，地胡，红胡，黑胡，小胡 碰碰胡，
            //1     2    4     8    16   32 64
            imgs = ["h_zimo", "h_tian2", "h_di2", "h_hong2", "h_hei2", "h_xiaoh", "h_pph"];
            fans = ["", "", "", "", "", ""];
        }
        var imgs2 = [];
        if(mRoom.wanfatype == mRoom.WEIMAQUE){
            //大小卓通用：
            //自摸： 0x1 红胡：0x2 多红：0x4 对子胡：0x8 乌对：0x10 乌胡：0x20 点胡：0x40 满园花：0x80 大字胡：0x100 小字胡：0x200
            //海底胡：0x400 单吊：0x800 卡偎：0x1000 天胡:0x2000 地胡：0x4000 全求人：0x8000 项对：0x10000 飘对：0x20000 鸡丁:0x40000 上下五千年:0x80000
            imgs = ["h_zimo", "h_hong2", "h_dred", "h_dzhu", "h_wdui", "h_wh", "h_dianh", "h_myhua", "h_dazi", "h_xiaozihu",
            "h_hdh", "h_dand", "h_kw", "h_tian2", "h_di2", "h_qqr", "h_xdui", "h_piaod", "h_jd", "h_sxwqn"];
            //印胡 0x1  纯印 0x2  卓胡 0x4  姊妹卓 0x8  三乱卓 0x10  姊妹卓带拖 0x20  祖孙卓 0x40  四乱卓 0x80  祖孙卓带拖 0x100  八碰头 0x200
            //假八碰头 0x400  背靠背 0x800  手牵手 0x1000  龙摆尾 0x2000
            //全黑  0x4000 无息 0x8000 六队红 0x10000 九队 0x20000 四边对 0x40000 边坎 0x80000 真背靠背 0x10000 凤摆尾 0x200000 卡胡 0x400000
            imgs2 = ["h_yinh", "h_chunyin", "h_zhuoh", "h_zmz", "h_sanlz", "h_zmzdt", "h_zsz", "h_szll", "h_zszdt", "h_bapengtou",
            "h_jbpt", "h_bkb", "h_sqs", "h_lbw",
                "h_quanhei", "h_wuxi", "h_liuduihong", "h_jiudui", "h_sibiandui", "h_biankan", "h_beikaobei", "h_fengbaiwei", "h_ka"];

        }
        for(var i=0;i<imgs.length;i++){
            var isOk = mAction.checkOpen(flag, 1<<i);
            if(isOk && imgs[i] != "") {
                var spr = new cc.Sprite("res/image/ui/result/" + imgs[i] +".png");
                spr.setAnchorPoint(0, 0.5);
                this.nHu.addChild(spr);
                spr.setPosition(10, -20 - index * 50);
                index ++;
            }
        }
        for(var i=0;i<imgs2.length;i++){
            var isOk2 = mAction.checkOpen(flag2, 1<<i);
            if(isOk2 && imgs2[i] != "") {
                var spr = new cc.Sprite("res/image/ui/result/" + imgs2[i] +".png");
                spr.setAnchorPoint(0, 0.5);
                this.nHu.addChild(spr);
                spr.setPosition(10, -20 - index * 50);
                index ++;
            }
        }
    },
    addComboList:function(comboList){
        var hasDui = null;
        for(var i=0;i < comboList.length;i++){
            var comboInfo = comboList[i];
            if(comboInfo.typ != mCard.comboTypes.dui){
                var ci = HUD.showLayer(HUD_LIST.ComboInfo, this.nCombos);
                ci.setData(comboInfo,  comboList);
                ci.setPosition(10 + this.index * 60,  5);
                this.index ++;

                var cardSprite = ci.getCardSprite();
                for(var s=0;s<cardSprite.length;s++){
                    this.winCards[this.winCards.length] = cardSprite[s];
                }
            }else{
                hasDui = comboInfo;
            }
        }
        if(hasDui != null){
            var ci = HUD.showLayer(HUD_LIST.ComboInfo, this.nCombos);
            ci.setData(hasDui, comboList);
            ci.setPosition(10 + this.index * 60,  5);

            var cardSprite = ci.getCardSprite();
            for(var s=0;s<cardSprite.length;s++){
                this.winCards[this.winCards.length] = cardSprite[s];
            }
        }
    },

    onClose: function (sender, type) {
        var ok = touch_process(sender, type);
        if(ok){
            if(mRoom.isReplay){
                mRoom.isReplay = false;
                clearInterval(mRoom.interval);
                clearGameMWRoomId();
                HUD.showScene(HUD_LIST.Home);
            }else{
                this.removeFromParent();
            }

        }
    },

    onShare:function(sender, type) {
        var that = this;
        var ok = touch_process(sender, type);
        if(ok){
            if (!cc.sys.isNative)
                return;
            WXUtils.captureAndShareToWX(that);
        }
    },
    onPenghuziDetail:function (sender, type) {
        var that = this;
        var ok = touch_process(sender, type);
        if(ok){
            //var rec_uel = DC.httpHost4 + "/" +  mRoom.roomId + '-' + mRoom.curRound;
            //httpGet(rec_uel, this.recSucess.bind(this), this.recFail.bind(this));
            var gameresultPhz = HUD.showLayer(HUD_LIST.GameResultPenghz, this);
            gameresultPhz.setData(that.gameOverData.Changes, that.gameOverData.Users);
        }
    },
    recSucess: function (data) {
        var newdata = JSON.parse(data);
        var penghzData = null;
        var users = null;
        for(var i=0;i<newdata.length;i++){
            if(newdata[i].cmd == 105){
                penghzData = newdata[i].data.Changes;
                users =  newdata[i].data.Users;
                break;
            }
        }
        var gameresultPhz = HUD.showLayer(HUD_LIST.GameResultPenghz, this);
        gameresultPhz.setData(penghzData, users);
    },
    recFail: function () {
        HUD.showMessage('获取结果失败');
    }
};