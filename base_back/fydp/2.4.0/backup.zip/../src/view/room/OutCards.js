var OutCards = {
    init: function () {
        this.removeAllChildren();
        return true;
    },

    setPos: function (pos) {
        this.pos = pos;
    },

    addCard: function (cardNo, animation, showCard, parent) {
        var cardList = mAction.outCards[this.pos];
        cardList.push(cardNo);

        var card = HUD.showLayer(HUD_LIST.Card, this);
        if(animation){
            var cardBigTmp = HUD.showLayer(HUD_LIST.Card, parent);
            cardBigTmp.setPosition(showCard.getPosition());
            cardBigTmp.setData(cardNo, null, 1);
            cardBigTmp.setRotation(showCard.getRotation());
            card.setVisible(false);
            showCard.setVisible(false);
        }
        card.setData(cardNo, null, 2);
        card.setName("card"+cardNo);

        var x = 5;
        if (this.pos == 0)
            x = 5;
        var rowIndex = parseInt((cardList.length - 1) / x);
        var colIndex = (cardList.length - 1) % x;
        var pos = null;
        var frompos = null;
        if (mRoom.getPlayerNum() == 3) {
            if (this.pos == 1) {
                pos = cc.p(150 - colIndex * 45, 15 - rowIndex * 45);
                frompos = cc.p(780, 320);
            } else if (this.pos == 2) {
                pos = cc.p(colIndex * 45, 15 - rowIndex * 45);
                frompos = cc.p(260, 320);
            } else if (this.pos == 0) {
                pos = cc.p(150 - colIndex * 45, 15 - rowIndex * 45);
                frompos = cc.p(510, 320);
            }
        } else {
            if (this.pos == 1) {
                pos = cc.p(145 - colIndex * 45, rowIndex * 45);
            } else if (this.pos == 2) {
                pos = cc.p(145 - colIndex * 45, - rowIndex * 45);
            } else if (this.pos == 0) {
                pos = cc.p(colIndex * 45 + 25, rowIndex * 45);
            } else if (this.pos == 3){
                pos = cc.p(colIndex * 45 + 25, - rowIndex * 45);
            }
        }


        if (animation) {
            card.setPosition(pos);
            var worldpos = card.convertToNodeSpace(cardBigTmp.getPosition());
            // console.log(worldpos);
            cardBigTmp.runAction(cc.sequence(
                cc.delayTime(0.2)
                , cc.spawn(cc.moveBy(0.3, -worldpos.x, -worldpos.y), cc.scaleTo(0.3, 0.5, 0.2))
                , cc.callFunc(function(){
                    cardBigTmp.removeFromParent();
                    card.setVisible(true);
                })
            ));
        } else {
            card.setData(cardNo, null, 2);
            card.setPosition(pos);
            card.setVisible(true);
        }
    },

    //删除cardNo的牌
    removeCard: function (cardNo) {
        var cardList = mAction.outCards[this.pos];
        //cc.log("ruru:----移除弃牌----begin："+this.pos+"--" + cardList );
        var curNo = -1;
        for (var i = 0; i< cardList.length; ++i){
            if(cardList[i] == cardNo){
                curNo = i;
            }
        }
        if (curNo == -1) return;

        cardList.splice(curNo, 1);
        //cc.log("ruru:----移除弃牌～～～"+cardNo );

        var card = this.getChildByName("card"+cardNo);
        if(card != null) {
            //cc.log("ruru:----移除弃牌----end："+card +"————————————————"+cardList );
            card.removeFromParent(true);

        }

        //重置所有牌列表的位置
        var carChildList = this.getChildren();
        for (var i =0; i<carChildList.length; ++i){
            var x = 5;
            if (this.pos == 0)
                x = 5;
            var rowIndex = parseInt(i / x);
            var colIndex = parseInt(i % x);
            var pos = null;
            var frompos = null;
            if (mRoom.getPlayerNum() == 3) {
                if (this.pos == 1) {
                    pos = cc.p(150 - colIndex * 45, 15 - rowIndex * 45);
                    frompos = cc.p(780, 320);
                } else if (this.pos == 2) {
                    pos = cc.p(colIndex * 45, 15 - rowIndex * 45);
                    frompos = cc.p(260, 320);
                } else if (this.pos == 0) {
                    pos = cc.p(150 - colIndex * 45, 15 - rowIndex * 45);
                    frompos = cc.p(510, 320);
                }
            } else {
                if (this.pos == 1) {
                    pos = cc.p(145 - colIndex * 45, rowIndex * 45);
                    frompos = cc.p(780, 320);
                } else if (this.pos == 2) {
                    pos = cc.p(145 - colIndex * 45, rowIndex * 45);
                    frompos = cc.p(260, 320);
                } else if (this.pos == 0) {
                    pos = cc.p(colIndex * 45 + 25, rowIndex * 45);
                    frompos = cc.p(510, 320);
                } else {
                    pos = cc.p(colIndex * 45 + 25, rowIndex * 45);
                    frompos = cc.p(510, 320);
                }
            }
            carChildList[i].setPosition(pos);
        }
    },

    //重置当前牌的所有位置
    resetCard: function () {
        var cardList = this.getChildren();
        for (var i = 0; i < cardList.length; i++) {
            var card = cardList[i];
            card.setData(cardList[i], null, 2);
        }
    },

    /** @returns OutCards */
    getCom: function (p, name) {
        return getCom(p, name, this);
    }
};