/**
 * Created by spring on 2018/3/29.
 */

(function () {
    var exports = this;

    var $ = null;

    var ClubSelectGameLayer = cc.Layer.extend({
        ctor: function (clubid, pos) {
            this._super();

            var that = this;

            var scene = ccs.load(res.ClubSelectGameLayer_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Layer"));

            TouchUtils.setOnclickListener($('root.close'), function () {
                that.removeFromParent();
            }, {effect: TouchUtils.effects.NONE});

            var games = ['niuniu', 'psz', 'pdk', 'majiang', 'kaokao'];
            var btnList = [];
            for (var i = 0; i < games.length; i++) {
                (function (name) {
                    btnList[i] = $('root.club_wanfa' + games[i]);
                    btnList[i].setVisible(true);
                    var offx = (cc.winSize.width - (games.length-1) * 240)/2;
                    btnList[i].setPositionX(offx + i*240);

                    TouchUtils.setOnclickListener(btnList[i], function (sender) {
                        // window.maLayer.createRoomLayer(games[i], 0, clubid, currentWanfaIdx);
                        SubUpdateUtils.showCreateRoom(name, true, clubid, true, pos);
                        that.removeFromParent();
                    }, {swallowTouches: false, effect: TouchUtils.effects.NONE});
                })(games[i]);
            }

            return true;
        }
    });

    exports.ClubSelectGameLayer = ClubSelectGameLayer;
})(window);