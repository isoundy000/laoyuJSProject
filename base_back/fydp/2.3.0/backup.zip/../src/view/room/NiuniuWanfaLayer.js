/**
 * Created by dengwenzhong on 2017/6/8.
 */

(function () {
    var exports = this;

    var $ = null;
    var NiuniuWanfaLayer = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        onExit: function () {
            cc.Layer.prototype.onExit.call(this);
        },
        ctor: function (data) {
            this._super();

            var that = this;


            //var scene = load_ccs("niuniu/NiuniuWanfa",this);
            // var scene = load_ccs("niuniu/NiuniuWanfa",this);
            var scene = ccs.load(res.NiuniuWanfa_json, "res/");
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));
            this.setContent(data);

            TouchUtils.setOnclickListener($('root.btClose'), function (node) {
                that.removeFromParent(true);
            }, {sound:'close'});
            return true;
        },
        setContent: function (data) {
            var fufei = data['AA']?"AA支付":"房主支付";
            var gaoji = '';
            var paixing = '无';
            var difen = data.Difen ? data.Difen.replace(',','/') : "无";
            var qitas = "";
            var tuizhus = "";
            if(!data.Difen){
                difen = data.basescore ? data.basescore : "无";
            }

            if(data['ChipInType']  == '1'){
                gaoji = '首局下注';
            }

            if(data['ChipInType']  == '2'){
                gaoji = '闲家推注';
            }

            var index = 0;
            if (data['Preview'] && data['Preview'].length > 0) {
                index = 1;
                var Preview = "全扣  ";
                if(data['Preview'] == "si"){
                    Preview = "扣一张  ";
                }else if(data['Preview'] == "san"){
                    Preview = "扣两张  ";
                }
                gaoji = gaoji + ((gaoji == '') ? '':' ') + Preview;
            }
            paixing = '';
            if(data.Xiaobeilv){
                paixing = paixing + ((data.Xiaobeilv == "3222") ? '双十x3十带九x2十带八x2十带七x2  ' : '双十x4十带九x3十带八x2十带七x2  ');
            }
            if(data.kuozhan1){
                paixing = paixing + "五花x6炸弹x6五小x8  ";
            }
            if(data.kuozhan2){
                paixing = paixing + "顺子x5葫芦x5同花x5  ";
            }

            if(data.DisableHeiqiang){
                gaoji = gaoji + "下注限制" + "  ";
            }
            if(data.MaxTuizhu >= 0){
                tuizhus = tuizhus + data.MaxTuizhu + "倍";
            }
            if(data.Is_ztjr){
                qitas = qitas + "游戏中途加入";
            }else if(data.Is_ztjr == false){
                qitas = qitas + "游戏中禁止加入";
            }
            if(data.Meiniuxiazhuang){
                qitas = qitas + "没十下庄" + "  ";
            }

            if(data.Preview || data.Preview_mp){
                qitas = qitas + "，" + (data.Cuopai ? "搓牌":"禁止搓牌");
            }

            $('root.panel.fufei_value').setString(fufei);
            $('root.panel.jushu_value').setString((data.jushu || data.rounds)+"局");
            $('root.panel.paixing_value').setString(paixing);
            $('root.panel.difen_value').setString(difen);
            $('root.panel.xuanxiang_value').setString(gaoji);
            $('root.panel.wanfa_value').setString(data.BeiShu ? data.BeiShu+"倍" : "无");
            $('root.panel.qita_value').setString(qitas);
            $('root.panel.tuizhu_value').setString(tuizhus);

            var ZhuangMode = getZhuangMode(data);
            $('root.panel.zhuangjia_value').setString(ZhuangMode);
        }
    });

    exports.NiuniuWanfaLayer = NiuniuWanfaLayer;
})(window);
