var CardSelect = {
    init:function () {
        this.img = getUI(this, "img");
        this.img.setOpacity(0);

        this.img.setTouchEnabled(true);
        this.img.setSwallowTouches(true);
        this.img.addTouchEventListener(this.onSelect, this);

        this.c1 = Card.getCom(this, "c1");
        this.c2 = Card.getCom(this, "c2");
        this.c3 = Card.getCom(this, "c3");

        return true;
    },

    setData:function(eatCard, data, parent, level, cards, index){
        //排序  吃的牌放在第一位
        for(var i=0;i<data.length;i++){
            if (eatCard == data[i]){
                var tmp = data[0];
                data[0] = data[i];
                data[i] = tmp;
                break;
            }
        }
        this.index = index;
        this.parent = parent;
        this.eatCard = eatCard;
        this.data = data;
        this.level = level;
        this.cards = mCard.copyCards(cards);
        for(var i=0;i<3;i++){
            var card = data[i];
            this["c" + (i+1)].setData(card);
            this.cards.push(card);
        }
    },
    setChiData:function(eatCard, data){
        //排序  吃的牌放在第一位
        for(var i=0;i<data.length;i++){
            if (eatCard == data[i]){
                var tmp = data[0];
                data[0] = data[i];
                data[i] = tmp;
                break;
            }
        }
        this.eatCard = eatCard;
        this.data = data;
        for(var i=0;i<3;i++){
            var card = data[i];
            this["c" + (i+1)].setData(card);
        }
    },
    setTouchEnableStatus:function(status){
        this.img.setTouchEnabled(status);
    },
    onSelect: function (sender, type) {
        var that = this;
        var ok = touch_process(sender, type);
        if(ok){
            if(that.data.length == 3){
                that.parent.sendChi(that.cards);
            }else{
                that.parent.showBiCard(that.level + 1, this.data[3], that.cards, that.index);
            }
        }
    },

    /** @returns CardSelect */
    getCom: function (p, name) {return getCom(p, name, this);}
};