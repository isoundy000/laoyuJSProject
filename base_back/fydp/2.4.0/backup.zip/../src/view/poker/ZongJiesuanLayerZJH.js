(function () {
    var exports = this;

    var $ = null;

    var RESULT_TEXTURE = {};
    RESULT_TEXTURE["win"] = cc.textureCache.addImage("res/image/ui/zjh/unit/icon_win.png");
    RESULT_TEXTURE["ping"] = cc.textureCache.addImage("res/image/ui/zjh/unit/icon_ping.png");
    RESULT_TEXTURE["lose"] = cc.textureCache.addImage("res/image/ui/zjh/unit/icon_lose.png");

    var ZongJiesuanLayerZJH = cc.Layer.extend({
        onEnter: function () {
            cc.Layer.prototype.onEnter.call(this);
        },
        ctor: function (data) {
            this._super();

            var that = this;

            var scene = ccs.load(res.ZongJiesuanLayerZJH_json, 'res/');
            this.addChild(scene.node);
            $ = create$(this.getChildByName("Scene"));

            $('lb_ts').setString(timestamp2time(data['ts'], "yyyy-mm-dd HH:MM:ss"));
            $('lb_roomid').setString('房号' + gameData.roomId);
            $('lb_jushu').setString('局数' + data['cur_round'] + '/' + data['total_round']);

            var players = data.players;

            // if (players.length == 5) {
            //     for (var i = 0; i < players.length; i++) {
            //         if (players[i].uid == gameData.uid) {
            //             var tmp = players[i];
            //             players.splice(i, 1);
            //             players.splice(0, 0, tmp);
            //             break;
            //         }
            //     }
            // }
            $('daikuan').setVisible(!window.inReview);
            TouchUtils.setOnclickListener($('daikuan'), function () {
                if(cc.sys.isNative){
                    cc.sys.openURL(DAIKUAN_URL);
                }else{
                    window.open(DAIKUAN_URL, "_blank");
                }
            }, {effect : TouchUtils.effects.SEPIA});

            var myTotalScore = 0;
            var highestScore = 0;
            var baseGap = $('info1').getPositionX() - $('info0').getPositionX();
            if (players.length == 3) {
                $('info0').setPositionX($('info0').getPositionX() + baseGap / 4);
                $('info1').setPositionX($('info1').getPositionX() + baseGap / 2);
                $('info2').setPositionX($('info2').getPositionX() + baseGap * 3 / 4);
            } else if (players.length == 2) {
                $('info0').setPositionX($('info0').getPositionX() + baseGap * 2 / 3);
                $('info1').setPositionX($('info1').getPositionX() + baseGap * 7 / 6);
            }
            for (var i = 0; i < 4; i++) {
                $('info' + i).setVisible(false);
            }
            for (var i = 0; i < 5; i++) {
                $('info5_' + i).setVisible(false);
            }
            var info = players.length == 5 ? 'info5_' : 'info';
            for (var i = 0; i < players.length; i++) {
                var player = players[i];
                var score = player.total_score;
                if (score > highestScore) {
                    highestScore = score;
                }
                var playerInfo = gameData.getPlayerInfoByUid(players[i].uid);
                if (!playerInfo) {
                    continue;
                }

                $(info + i).setVisible(true);
                loadImageToSprite(decodeURIComponent(playerInfo.headimgurl), $(info + i + '.head'));
                $(info + i + '.txt_name').setString(ellipsisStr(decodeURIComponent(playerInfo.nickname), 5));
                $(info + i + '.txt_id').setString('ID ' + playerInfo.uid);
                $(info + i + '.txt_high').setString(player.max_score);
                $(info + i + '.txt_bomb').setString(decodeURIComponent(player.max_cardtype));
                $(info + i + '.txt_sucess').setString(player.win);
                $(info + i + '.txt_fail').setString(player.lose);
                $(info + i + ".icon_fz").setVisible(player.uid == data.owner_id && !data['is_daikai']);
                if (player.uid == gameData.uid) {
                    myTotalScore = score;
                }
                var lbTotalSocre = $(info + i + ".txt_score");
                var lbTotalSocre2 = $(info + i + ".txt_score2");
                if (score > 0) {
                    lbTotalSocre.setVisible(true);
                    lbTotalSocre2.setVisible(false);
                    lbTotalSocre.setString("+" + score);
                } else {
                    lbTotalSocre.setVisible(false);
                    lbTotalSocre2.setVisible(true);
                    lbTotalSocre2.setString(score);
                }

                var result = $(info + i + ".icon_result");
                if (score > 0) {
                    result.setTexture(RESULT_TEXTURE["win"]);
                } else if (score < 0) {
                    result.setTexture(RESULT_TEXTURE["lose"]);
                } else {
                    result.setTexture(RESULT_TEXTURE["ping"]);
                }
            }
            for (var i = 0; i < players.length; i++) {
                $(info + i + ".icon_dyj").setVisible(highestScore > 0 && players[i].total_score == highestScore);
            }
            if (myTotalScore >= 0) {
                playEffect('vvictory');
            } else {
                playEffect('vfailure');
            }
            var btnShare = $('btn_share');
            if (gameData.loginType == 'yk') {
                btnShare.setVisible(false);
            }

            if(window.inReview){
                btnShare.setVisible(false);
                $('btn_close').setPositionX(1280/2);
            }
            TouchUtils.setOnclickListener(btnShare, function () {
                if (!cc.sys.isNative)
                    return;
                WXUtils.captureAndShareToWX(that,0x88F0);
                // that.addChild(new ShareTypeLayer(that));
            });

            // network.disconnect();
            gameData.lastRoom = 0;
            // Filter.grayScale($('btn_close'));
            TouchUtils.setOnclickListener($('btn_close'), function () {
                HUD.showScene(HUD_LIST.Home, null);
            });

            return true;
        },
        scheduleClose: function (time) {
            var that = this;
            if (time > 0) {
                $('btn_close.Text_60').setString(time + '秒后可关闭');
                that.stopAllActions();
                that.runAction(cc.sequence(
                    cc.delayTime(1),
                    cc.callFunc(function () {
                        that.scheduleClose(time - 1);
                    })
                ))
            } else {
                Filter.remove($('btn_close'));
                $('btn_close.Text_60').setString('关 闭');
                TouchUtils.setOnclickListener($('btn_close'), function () {
                    HUD.showScene(HUD_LIST.Home, null);
                });
            }
        },
        onEnter: function () {
            this._super();
            AgoraUtil.hideAllVideo();
        },
        onExit: function () {
            this._super();
            AgoraUtil.showAllVideo();
        }
    });

    exports.ZongJiesuanLayerZJH = ZongJiesuanLayerZJH;
})(window);
